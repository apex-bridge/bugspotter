# BugSpotter TODO

## SDK - Console & Network Log Filtering

**Issue**: SDK captures its own internal logs and API calls in bug reports, which pollutes the data sent to the backend.

**Current Behavior**:

- Console logs with `[BugSpotter]` prefix (SDK debug output) are captured
- Network requests to the BugSpotter API endpoint are captured
- These internal SDK operations appear in bug reports alongside user application data

**Proposed Solution**:

1. **Console Logs**: Filter out messages starting with `[BugSpotter]` prefix in `ConsoleCapture.addLog()`
2. **Network Logs**: Add `apiEndpoint` parameter to `CaptureManagerConfig` and filter SDK API calls in `NetworkCapture`

**Files to Modify**:

- `packages/sdk/src/capture/console.ts` - Add `shouldCaptureLog()` filter
- `packages/sdk/src/capture/network.ts` - Use existing `filterUrls` option
- `packages/sdk/src/core/capture-manager.ts` - Pass endpoint to NetworkCapture
- `packages/sdk/tests/capture/console.test.ts` - Add test for SDK log filtering

**Considerations**:

- Should we filter SDK logs by default or make it configurable?
- Should we only filter SDK logs at certain log levels (e.g., keep errors)?
- Network filtering needs the API endpoint URL - should be passed from BugSpotter.init()

**Priority**: Medium
**Status**: Pending discussion
