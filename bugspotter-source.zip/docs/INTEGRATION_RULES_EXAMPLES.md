# Integration Rules - Step-by-Step UI Examples

**BugSpotter Admin Panel**  
**Last Updated**: January 6, 2026

This guide provides **copy-paste ready examples** for creating integration rules through the admin UI. Each rule includes exact field values and step-by-step instructions.

---

## ⚠️ Current UI Limitations

The admin UI currently supports these rule settings:

- ✅ **Basic Information** (Name, Enabled, Execution Order, Auto-create)
- ✅ **Filter Conditions** (Error Message, URL, Browser, OS, etc.)
- ✅ **Field Mappings** (priority, labels, assignee, components, etc.)
- ✅ **Description Template** (Optional) - Custom ticket description with variables like `{{error.message}}`
- ✅ **Throttling** (Max per hour/day, Group By, Digest Mode)

**Not yet available in UI** (API-only):

- ❌ **Attachment Configuration** - Control which attachments (screenshot, logs, replay) to include

To use Attachment Config, create rules via API:

```bash
POST /api/v1/integrations/:platform/:projectId/rules
{
  "name": "My Rule",
  "attachment_config": { "screenshot": true, "console_logs": true }
}
```

---

## 🎬 Including Session Replay & Screenshots in Tickets

**To see replay and screenshot links in your Jira tickets**, add `{{replay_url}}` and `{{screenshot_url}}` to your description template:

### Jira Wiki Markup Format

```
*Session Replay*:
[Watch Session Replay|{{replay_url}}]

*Screenshot*:
!{{screenshot_url}}|width=800!
```

### How It Works

1. **BugSpotter captures** the session replay and screenshot when enabled
2. **Files are uploaded** to your storage backend (S3, local, etc.)
3. **Shareable links generated** with expiration (default: 7 days for screenshots, 30 days for replays)
4. **Variables `{{replay_url}}` and `{{screenshot_url}}`** are replaced with actual links in ticket

### Example Ticket with Replay & Screenshot

```
h3. Critical Production Error

*Error*: TypeError: Cannot read property 'id' of undefined

*Session Replay*:
[Watch Session Replay|https://bugspotter.yourdomain.com/replay/abc123]

*Screenshot*:
!https://cdn.bugspotter.io/screenshots/bug-123.png|width=800!

*User*: user@example.com
*Page*: https://app.yourdomain.com/dashboard
```

### Configuration

Ensure session replay and screenshots are enabled in your SDK:

```javascript
BugSpotter.init({
  apiKey: 'your-api-key',
  endpoint: 'https://api.bugspotter.io',

  // Enable session replay
  replay: {
    enabled: true,
    samplingRate: 1.0, // Capture 100% of sessions
    maskAllInputs: true, // Privacy: mask sensitive inputs
  },

  // Enable automatic screenshots
  screenshot: {
    enabled: true,
    captureOnError: true, // Auto-capture when error occurs
  },
});
```

### Available Template Variables

| Variable             | Description                    | Example Value                            |
| -------------------- | ------------------------------ | ---------------------------------------- |
| `{{replay_url}}`     | Shareable session replay link  | `https://app.bugspotter.io/replay/abc`   |
| `{{screenshot_url}}` | Direct screenshot image URL    | `https://cdn.bugspotter.io/img/123.png`  |
| `{{title}}`          | Bug report title               | `TypeError: Cannot read property 'id'`   |
| `{{description}}`    | Bug report description         | `Error occurred when loading dashboard`  |
| `{{browser}}`        | Browser name                   | `Chrome`                                 |
| `{{os}}`             | Operating system               | `Windows 11`                             |
| `{{url}}`            | Page URL where error occurred  | `https://app.yourcompany.com/dashboard`  |
| `{{user_email}}`     | User's email address           | `user@example.com`                       |
| `{{timestamp}}`      | When error occurred (ISO 8601) | `2026-01-08T10:30:00.000Z`               |
| `{{error.message}}`  | Error message from metadata    | `Cannot read property 'id' of undefined` |
| `{{stack_trace}}`    | Stack trace from metadata      | `at App.render (main.js:123:45)`         |

**Troubleshooting**: If variables appear empty in tickets:

**For `{{replay_url}}`**:

- ✅ Check that `replay.enabled: true` in SDK config
- ✅ Verify storage backend is configured (S3 or local)
- ✅ Ensure bug report has session replay attached
- ✅ Check BugSpotter logs for replay upload errors

**For `{{screenshot_url}}`**:

- ✅ Check that `screenshot.enabled: true` in SDK config
- ✅ Verify `captureOnError: true` is set
- ✅ Ensure bug report has screenshot attached
- ✅ Check storage backend permissions for image uploads

---

## 🔍 Understanding Rule Types: Auto-Create vs Manual

### Two Types of Integration Rules

**1. Auto-Create Rules** (`auto_create = true`)

- **When**: Bug report is created, system automatically evaluates rules
- **Action**: Creates ticket immediately if filters match
- **Use Case**: Critical errors, production bugs, specific page failures

**2. Manual Rules** (`auto_create = false`)

- **When**: User manually clicks "Create Ticket" in BugSpotter UI
- **Action**: Creates ticket when user triggers it manually
- **Use Case**: Less urgent bugs, bugs needing triage, internal tool errors

### Fallback Behavior (Important!)

**⚠️ If you ONLY have auto-create rules and none match:**

The system falls back to "backward compatibility mode" and creates tickets for **ALL** bug reports anyway.

**Why?** This ensures integrations without manual rules still work for all bugs (legacy behavior).

**How to prevent fallback:**

Create at least one manual rule with a filter. Example:

```json
{
  "name": "Manual Review Rule",
  "auto_create": false,
  "filters": [{ "field": "status", "operator": "equals", "value": "open" }]
}
```

Now bugs that don't match auto-create rules will NOT create tickets automatically.

### Rule Evaluation Logic

```
When bug report arrives:

1. Check auto-create rules (sorted by priority, highest first)
   - If rule matches → Create ticket via that rule, STOP
   - If no auto-create rules match → Continue to step 2

2. Check manual rules
   - If manual rules exist AND none match → No ticket created
   - If NO manual rules exist → Fallback: Create ticket anyway (backward compatibility)

3. When user clicks "Create Ticket" button:
   - Check manual rules
   - If rule matches → Use that rule's field mappings
   - If no rules match → Create with default settings
```

### Example Scenarios

**Scenario 1: Only auto-create rules, bug matches**

```
Rules: 3 auto-create rules
Bug: Matches "Critical Production Errors" rule
Result: ✅ Ticket created via rule (with custom description template)
```

**Scenario 2: Only auto-create rules, bug doesn't match**

```
Rules: 3 auto-create rules
Bug: "Calculation time error" (doesn't match any filter)
Result: ✅ Ticket STILL created (fallback mode, NO custom template)
```

**Scenario 3: Auto-create + manual rules, bug doesn't match auto-create**

```
Rules: 3 auto-create + 1 manual rule
Bug: "Calculation time error" (doesn't match auto-create filters)
Result: ❌ No ticket created automatically
       ✅ User can manually create ticket via UI (uses manual rule if it matches)
```

**Scenario 4: No rules at all**

```
Rules: None
Bug: Any bug report
Result: ✅ Ticket created for all bugs (full backward compatibility)
```

### Recommended Setup

**For most users (selective auto-ticket creation):**

1. Create 3-5 auto-create rules for critical issues
2. Create 1 manual rule as a catch-all (prevents fallback)
3. Bugs matching auto-create rules → Immediate tickets with custom templates
4. Bugs not matching → Available for manual ticket creation in UI

**For simple "create all tickets" behavior:**

1. Don't create any rules OR
2. Create only auto-create rules with no filters (matches everything)

---

## Prerequisites

Before creating rules:

1. ✅ Jira integration already created and configured
2. ✅ Project linked to Jira integration
3. ✅ Navigate to: **Integrations** → **Your Jira Integration** → **Rules** tab
4. ✅ Click **"Create Rule"** button

---

## 📌 Important: Understanding Rule Priority vs Bug Report Priority

### Two Different "Priority" Concepts

**1. Rule Priority** (REQUIRED - execution order)

- **Value**: Numbers like `1000`, `800`, `600`
- **Purpose**: Determines which rule is evaluated FIRST when a bug report arrives
- **Behavior**: Higher number = evaluated first (Rule with priority 1000 runs before priority 800)
- **Required**: YES - every rule MUST have a priority number
- **Example**: If both Rule 1 (priority 1000) and Rule 2 (priority 800) match the same bug report, only Rule 1 executes

**2. Bug Report Priority Filter** (OPTIONAL - data field)

- **Value**: Text values like `critical`, `high`, `medium`, `low`
- **Purpose**: Filters bug reports based on their priority field value
- **Behavior**: Only matches bug reports where priority field equals/contains specified value
- **Required**: NO - this is an optional filter, bug reports may not have priority set
- **Problem**: Default SDK modal does NOT have a priority selector for end-users

### When Bug Report Priority Filtering Works

**The `priority` field is optional in bug reports** and typically NOT set by end-users through the default SDK modal. Priority filtering is most useful when:

✅ **You're using the API directly** - Setting priority programmatically based on error type
✅ **Custom SDK implementation** - You've added a priority selector to your bug report form
✅ **Server-side auto-classification** - Backend logic assigns priority based on error patterns

### Recommended Filtering Approach

**Most users should focus on filtering by**:

- Error Message patterns (fatal, exception, crash)
- URL Pattern (specific pages or features)
- Browser and Operating System (platform-specific issues)
- User Email (authenticated vs unauthenticated)
- Status (open, in-progress, resolved)

**Rules with bug report priority filters below are examples** - adjust based on your implementation or remove priority filters entirely.

### Example: Rule Priority in Action

```
Incoming bug report matches multiple rules:
- Rule A (priority 1000): Critical Production Errors → EXECUTES ✓
- Rule B (priority 800): Production Chrome Crashes → SKIPPED (Rule A already matched)
- Rule C (priority 600): Mobile Safari Issues → SKIPPED

Result: Only Rule A creates a ticket because it has highest priority
```

---

## Rule 1: Critical Production Errors (Highest Priority)

**Use Case**: Immediately create tickets for fatal errors in production that require immediate attention.

**Note**: This rule uses Error Message patterns instead of Bug Priority field, making it suitable for all implementations.

### Step-by-Step Instructions

1. Click **"Create Rule"** button
2. Fill in the following fields:

#### Basic Information

| Field                   | Value                        |
| ----------------------- | ---------------------------- |
| **Rule Name**           | `Critical Production Errors` |
| **Enabled**             | ✓ (checked)                  |
| **Execution Order**     | `1000`                       |
| **Auto-create Tickets** | ✓ (checked)                  |

#### Filters (Click "Add Filter" for each)

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(fatal|critical|exception|crash|unhandled|null reference|undefined|cannot read property)`
  > Matches severe error patterns

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `(app\.|dashboard\.|portal\.)`
  > Matches main application domains (optional - remove to match all URLs)

**Filter 3 (Optional - only if using API with priority):**

- **Field**: `Bug Priority (optional field)`
- **Operator**: `In (comma-separated)`
- **Value**: `critical, high`
  > Skip this filter if not setting priority programmatically

#### Throttling Settings

| Field                 | Value         |
| --------------------- | ------------- |
| **Enable Throttling** | ✓ (checked)   |
| **Max per Hour**      | `10`          |
| **Max per Day**       | `50`          |
| **Group By**          | `Error Type`  |
| **Digest Mode**       | ✗ (unchecked) |

#### Field Mappings (Jira-specific)

| Field Name   | Field Value                            |
| ------------ | -------------------------------------- |
| **priority** | `Highest`                              |
| **labels**   | `["critical", "production", "urgent"]` |
| **assignee** | `platform-team-lead`                   |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Critical Production Error Detected

**Error**: {{error.message}}
**Error Type**: {{metadata.error_type}}
**Severity**: {{priority}}

**User Details**:

- User: {{user_email}}
- Browser: {{browser}} {{browser_version}}
- OS: {{os}}

**Technical Details**:

- URL: {{url}}
- Timestamp: {{timestamp}}
- Session ID: {{session_id}}
- Request ID: {{metadata.request_id}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Stack Trace**:
```

{{stack_trace}}

```

**Impact**: Critical production error - immediate attention required
```

2. Click **"Save Rule"** button

**Result**: Any critical error in production with fatal/exception keywords will immediately create a Jira ticket assigned to platform team lead.

---

## Rule 2: Production Chrome Crashes

**Use Case**: Track browser crashes in production on Chrome (most common browser).

**Note**: Uses Browser + Error Message patterns instead of Bug Priority field.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                       |
| ----------------------- | --------------------------- |
| **Rule Name**           | `Production Chrome Crashes` |
| **Enabled**             | ✓                           |
| **Execution Order**     | `800`                       |
| **Auto-create Tickets** | ✓                           |

#### Filters

**Filter 1:**

- **Field**: `Browser`
- **Operator**: `Equals`
- **Value**: `chrome`

**Filter 2:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(crash|freeze|unresponsive|out of memory|heap)`
  > Chrome-specific crash patterns

**Filter 3:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `app.yourcompany.com`
  > Replace `yourcompany.com` with your production domain

**Filter 4:**

- **Field**: `Status`
- **Operator**: `Equals`
- **Value**: `open`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `15`         |
| **Max per Day**               | `100`        |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓ (checked)  |
| **Digest Interval (minutes)** | `30`         |

#### Field Mappings

| Field Name   | Field Value                         |
| ------------ | ----------------------------------- |
| **priority** | `High`                              |
| **labels**   | `["chrome", "production", "crash"]` |

#### Description Template

**Note**: Using Jira Wiki Markup formatting:

```
h3. Browser Crash Detected on Production

*Error*: {{error.message}}

*Browser Information*:
* Browser: {{browser}} {{browser_version}}
* OS: {{os}}
* Viewport: {{viewport_width}}x{{viewport_height}}

*Page Details*:
* URL: {{url}}
* Referrer: {{referrer}}

*User Context*:
* User: {{user_email}}
* Session Duration: {{session_duration}}

*Session Replay*:
[Watch Session Replay|{{replay_url}}]

*Stack Trace*:
{code}
{{stack_trace}}
{code}

*Affected Users*: This issue has occurred {{occurrence_count}} times
```

2. Click **"Save Rule"**

**Result**: Chrome crashes batched every 30 minutes to prevent ticket spam during incidents.

---

## Rule 3: Mobile Safari Issues

**Use Case**: Track Safari-specific bugs on iOS devices.

**Note**: Filters by platform only - captures all iOS Safari errors.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                  |
| ----------------------- | ---------------------- |
| **Rule Name**           | `Mobile Safari Issues` |
| **Enabled**             | ✓                      |
| **Execution Order**     | `600`                  |
| **Auto-create Tickets** | ✓                      |

#### Filters

**Filter 1:**

- **Field**: `Browser`
- **Operator**: `Equals`
- **Value**: `safari`

**Filter 2:**

- **Field**: `Operating System`
- **Operator**: `Regular Expression`
- **Value**: `(iOS|iPhone|iPad)`

**Filter 3 (Optional - exclude minor issues):**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(error|exception|failed|undefined|null)`
  > Only match actual errors, not warnings

#### Throttling Settings

| Field                         | Value  |
| ----------------------------- | ------ |
| **Enable Throttling**         | ✓      |
| **Max per Hour**              | `20`   |
| **Max per Day**               | `150`  |
| **Group By**                  | `User` |
| **Digest Mode**               | ✓      |
| **Digest Interval (minutes)** | `60`   |

#### Field Mappings

| Field Name   | Field Value                   |
| ------------ | ----------------------------- |
| **priority** | `Medium`                      |
| **labels**   | `["safari", "mobile", "ios"]` |

#### Description Template

**Note**: Using Jira Wiki Markup formatting:

```
h3. Mobile Safari Issue

*Issue*: {{title}}

*Device Information*:
* Device: {{os}}
* Browser: {{browser}} {{browser_version}}
* Viewport: {{viewport_width}}x{{viewport_height}}

*Issue Details*:
* URL: {{url}}
* Error: {{error.message}}

*Session Replay*:
[Watch Session Replay|{{replay_url}}]

*Frequency*: {{occurrence_count}} occurrences in last hour
```

2. Click **"Save Rule"**

**Result**: iOS Safari bugs batched hourly, grouped by user to prevent spam.

---

## Rule 4: Third-Party API Failures

**Use Case**: API integration failures (Stripe, Twilio, AWS, etc.) automatically routed to integration team.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                      |
| ----------------------- | -------------------------- |
| **Rule Name**           | `Third-Party API Failures` |
| **Enabled**             | ✓                          |
| **Execution Order**     | `750`                      |
| **Auto-create Tickets** | ✓                          |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(API|timeout|401|403|429|500|502|503|504|network error|fetch failed)`
  > HTTP error codes and API failure patterns

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `(api\.|stripe\.com|twilio\.com|sendgrid\.com|amazonaws\.com|firebase\.com)`
  > Matches third-party API domains or your API subdomain

#### Throttling Settings

| Field                 | Value        |
| --------------------- | ------------ |
| **Enable Throttling** | ✓            |
| **Max per Hour**      | `8`          |
| **Max per Day**       | `40`         |
| **Group By**          | `Error Type` |
| **Digest Mode**       | ✗            |

#### Field Mappings

| Field Name   | Field Value                                     |
| ------------ | ----------------------------------------------- |
| **priority** | `High`                                          |
| **labels**   | `["api-failure", "third-party", "integration"]` |
| **assignee** | `integration-team`                              |

#### Description Template

**Note**: Using Jira Wiki Markup formatting:

```
h3. Third-Party API Failure

*Service*: {{metadata.service_name}}
*HTTP Status*: {{metadata.http_status}}
*Error*: {{error.message}}

*Request Details*:
* Endpoint: {{metadata.endpoint}}
* Method: {{metadata.http_method}}
* Timestamp: {{timestamp}}
* Retry Attempts: {{metadata.retry_count}}

*User Impact*:
* User: {{user_email}}
* Action: {{metadata.user_action}}
* Page: {{url}}

*Session Replay*:
[Watch Session Replay|{{replay_url}}]

*Response Body*:
{code}
{{metadata.response_body}}
{code}
```

2. Click **"Save Rule"**

**Result**: API failures immediately assigned to integration team with network logs attached.

---

## Rule 5: Internal Tools Errors (Manual Review)

**Use Case**: Errors in internal tools/admin interfaces require manual review before creating tickets.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                   |
| ----------------------- | --------------------------------------- |
| **Rule Name**           | `Internal Tools Errors - Manual Review` |
| **Enabled**             | ✓                                       |
| **Execution Order**     | `700`                                   |
| **Auto-create Tickets** | ✗ (unchecked)                           |

#### Filters

**Filter 1:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(admin|internal|dashboard|tools)`
  > Matches internal tools URLs

**Filter 2 (Optional - only severe errors need review):**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(error|exception|failed|crash)`
  > Exclude minor warnings from manual review queue

#### Throttling Settings

| Field                 | Value         |
| --------------------- | ------------- |
| **Enable Throttling** | ✗ (unchecked) |

> No throttling needed since manual review prevents spam

#### Field Mappings

| Field Name   | Field Value                           |
| ------------ | ------------------------------------- |
| **priority** | `High`                                |
| **labels**   | `["internal-tools", "manual-review"]` |
| **assignee** | `internal-tools-team`                 |

#### Description Template

**Note**: Using Jira Wiki Markup formatting:

```
h3. Internal Tools Error Detected

⚠️ *Manual review required before ticket creation*

*Error*: {{error.message}}

*User Context*:
* Email: {{user_email}}
* Role: {{metadata.user_role}}

*Action Attempted*:
* URL: {{url}}
* Action: {{metadata.user_action}}
* Feature: {{metadata.feature_name}}

*Session Replay*:
[Watch Session Replay|{{replay_url}}]

*Error Details*:
{code}
{{stack_trace}}
{code}

*Review Checklist*:
* [ ] Verify this is not a permission issue
* [ ] Check if error is reproducible
* [ ] Determine if ticket creation is necessary
* [ ] Assess impact on internal operations
```

2. Click **"Save Rule"**

**Result**: Internal tools errors flagged in BugSpotter but NOT auto-created in Jira. Team reviews and manually creates tickets as needed.

---

## Rule 6: Unauthenticated User Errors (Digest)

**Use Case**: Batch bugs from unauthenticated users to reduce noise.

**Note**: Filters by user authentication status - works for all bug reports.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                         |
| ----------------------- | ----------------------------- |
| **Rule Name**           | `Unauthenticated User Errors` |
| **Enabled**             | ✓                             |
| **Execution Order**     | `300`                         |
| **Auto-create Tickets** | ✓                             |

#### Filters

**Filter 1:**

- **Field**: `User Email`
- **Operator**: `Equals`
- **Value**: `` (empty string - represents unauthenticated users)

**Filter 2:**

- **Field**: `status`
- **Operator**: `equals`
- **Value**: `open`

**Filter 3 (Optional - exclude trivial issues):**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(error|exception|failed|timeout)`
  > Only batch actual errors, not warnings

#### Throttling Settings

| Field                         | Value           |
| ----------------------------- | --------------- |
| **Enable Throttling**         | ✓               |
| **Max per Hour**              | `30`            |
| **Max per Day**               | `200`           |
| **Group By**                  | `Error Type`    |
| **Digest Mode**               | ✓               |
| **Digest Interval (minutes)** | `120` (2 hours) |

#### Field Mappings

| Field Name   | Field Value                                  |
| ------------ | -------------------------------------------- |
| **priority** | `Low`                                        |
| **labels**   | `["unauthenticated", "anonymous", "digest"]` |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Unauthenticated User Error Report

**Summary**: {{occurrence_count}} similar errors in last 2 hours

**Error**: {{error.message}}

**Pages Affected**:
{{affected_urls}}

**Browser Distribution**:

- Chrome: {{browser_stats.chrome}}%
- Safari: {{browser_stats.safari}}%
- Firefox: {{browser_stats.firefox}}%
- Other: {{browser_stats.other}}%

**Geographic Distribution**:
{{geographic_stats}}

**Common Pattern**:
{{common_pattern_description}}

**Recommendation**: Review error logs and determine priority for next sprint.
```

2. Click **"Save Rule"**

**Result**: Unauthenticated user errors batched every 2 hours into single summary ticket.

---

## Rule 7: High-Volume Error Spike Detection

**Use Case**: Detect sudden error spikes that might indicate production incidents.

**Note**: Monitors error volume regardless of priority - catches all incidents.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                   |
| ----------------------- | ----------------------- |
| **Rule Name**           | `Error Spike Detection` |
| **Enabled**             | ✓                       |
| **Execution Order**     | `900`                   |
| **Auto-create Tickets** | ✓                       |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(error|exception|fatal|crash|failed)`
  > Match actual errors, not warnings

**Filter 2:**

- **Field**: `status`
- **Operator**: `equals`
- **Value**: `open`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `5`          |
| **Max per Day**               | `20`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `15`         |

> Note: Short 15-min interval to quickly detect spikes

#### Field Mappings

| Field Name   | Field Value                           |
| ------------ | ------------------------------------- |
| **priority** | `Highest`                             |
| **labels**   | `["incident", "spike", "production"]` |
| **assignee** | `on-call-engineer`                    |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 🚨 Error Spike Detected - Possible Production Incident

**Alert**: {{occurrence_count}} similar errors in last 15 minutes

**Error Pattern**: {{error.message}}

**Affected Components**:

- Pages: {{affected_pages}}
- Browsers: {{affected_browsers}}
- Users: {{affected_user_count}}

**Timeline**:

- First occurrence: {{first_occurrence}}
- Latest occurrence: {{latest_occurrence}}
- Peak rate: {{peak_rate}}/minute

**Recommended Actions**:

1. Check application server logs
2. Review recent deployments
3. Check third-party service status
4. Notify engineering team lead

**Quick Links**:

- [Server Dashboard](https://monitoring.yourcompany.com)
- [Error Logs](https://logs.yourcompany.com)
```

2. Click **"Save Rule"**

**Result**: Rapid error increases create incident tickets assigned to on-call engineer within 15 minutes.

---

## Rule 8: Authenticated User Errors (Standard Priority)

**Use Case**: Track errors from logged-in users with standard handling.

**Note**: Filters by authentication status - suitable for all implementations.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                       |
| ----------------------- | --------------------------- |
| **Rule Name**           | `Authenticated User Errors` |
| **Enabled**             | ✓                           |
| **Execution Order**     | `500`                       |
| **Auto-create Tickets** | ✓                           |

#### Filters

**Filter 1:**

- **Field**: `User Email`
- **Operator**: `Regular Expression`
- **Value**: `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`
  > Matches valid email addresses (authenticated users)

**Filter 2:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(error|exception|failed|timeout|undefined|null)`
  > Match actual errors affecting users

#### Throttling Settings

| Field                 | Value        |
| --------------------- | ------------ |
| **Enable Throttling** | ✓            |
| **Max per Hour**      | `25`         |
| **Max per Day**       | `150`        |
| **Group By**          | `Error Type` |
| **Digest Mode**       | ✗            |

#### Field Mappings

| Field Name   | Field Value                                 |
| ------------ | ------------------------------------------- |
| **priority** | `Medium`                                    |
| **labels**   | `["authenticated-user", "customer-impact"]` |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Authenticated User Error

**User**: {{user_email}}
**Customer Tier**: {{metadata.customer_tier}}

**Error**: {{error.message}}

**Context**:

- Page: {{url}}
- Browser: {{browser}} on {{os}}
- Time: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**User Journey**:
{{metadata.user_journey}}

**Business Impact**: {{metadata.revenue_impact}}
```

2. Click **"Save Rule"**

**Result**: Authenticated user errors create individual tickets with full context.

---

## Quick Reference Table

| Rule Name                   | Execution Order | Auto-create | Throttle (hour/day) | Digest     | Use Case               |
| --------------------------- | --------------- | ----------- | ------------------- | ---------- | ---------------------- |
| Critical Production Errors  | 1000            | ✓           | 10/50               | ✗          | Critical system errors |
| Error Spike Detection       | 900             | ✓           | 5/20                | ✓ (15min)  | Incident detection     |
| Production Chrome Crashes   | 800             | ✓           | 15/100              | ✓ (30min)  | Browser crashes        |
| Third-Party API Failures    | 750             | ✓           | 8/40                | ✗          | Integration issues     |
| Internal Tools Errors       | 700             | ✗           | None                | -          | Manual review          |
| Mobile Safari Issues        | 600             | ✓           | 20/150              | ✓ (60min)  | Mobile UX              |
| Authenticated User Errors   | 500             | ✓           | 25/150              | ✗          | User issues            |
| Unauthenticated User Errors | 300             | ✓           | 30/200              | ✓ (120min) | Anonymous users        |

---

## Testing Your Rules

After creating rules, test with sample bug reports:

### Test Rule 1 (Critical Production Errors)

Create a test bug report via API:

```bash
curl -X POST 'https://api.bugspotter.io/api/v1/bug-reports' \
  -H 'x-api-key: YOUR_API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{
    "title": "Fatal exception in dashboard",
    "description": "Unhandled exception when loading user data",
    "priority": "critical",
    "url": "https://app.yourcompany.com/dashboard",
    "browser": "chrome",
    "metadata": {
      "error_message": "Fatal error: Cannot read property of undefined",
      "error_type": "TypeError",
      "request_id": "req_abc123"
    }
  }'
```

**Expected**: Jira ticket created within 1 minute, assigned to platform-team-lead.

### Test Rule 5 (Internal Tools - Manual Review)

```bash
curl -X POST 'https://api.bugspotter.io/api/v1/bug-reports' \
  -H 'x-api-key: YOUR_API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{
    "title": "Internal dashboard error",
    "description": "Cannot load reporting interface",
    "priority": "high",
    "url": "https://app.yourcompany.com/internal/reports",
    "user_email": "staff@yourcompany.com"
  }'
```

**Expected**: Bug report visible in BugSpotter, but NO Jira ticket created (manual review required).

---

## Monitoring & Adjusting Rules

### Check Rule Activity

1. Go to **Integrations** → **Your Jira Integration** → **Activity** tab
2. Filter by rule name to see trigger history
3. Check throttle status (e.g., "8/10 used this hour")

### Common Adjustments

**Too many tickets?**

- ✅ Increase digest interval (30min → 60min)
- ✅ Lower throttle limits (20/hour → 10/hour)
- ✅ Add more restrictive filters

**Missing important bugs?**

- ✅ Lower priority threshold (critical → high, medium)
- ✅ Expand regex patterns in filters
- ✅ Remove overly restrictive filters

**Wrong assignee?**

- ✅ Edit Field Mappings → Update assignee value
- ✅ Use different assignees for different rule priorities

---

## Best Practices

1. **Start Simple**: Create 2-3 rules, monitor for 1 week, then add more
2. **Use Descriptive Names**: Include priority level and use case in rule name
3. **Leave Priority Gaps**: Use 100, 200, 300 (not 1, 2, 3) for easy insertion
4. **Test Before Enabling**: Create rule with `Enabled: ✗`, test, then enable
5. **Document Custom Fields**: Add notes about Jira custom field IDs in description
6. **Review Quarterly**: Disable unused rules, adjust throttle limits
7. **Monitor Throttle Stats**: If frequently hitting limits, increase them
8. **Use Digest for Low Priority**: Batch non-urgent issues to reduce noise

---

## Troubleshooting

### Rule Not Triggering

**Check**:

1. Rule is enabled (✓)
2. Bug report matches ALL filters (AND logic)
3. Throttle limit not exceeded
4. Integration is enabled for the project
5. No higher-priority rule already triggered

### Too Many Tickets

**Fix**:

1. Enable digest mode
2. Lower throttle limits
3. Increase digest interval
4. Add more specific filters (narrow scope)

### Tickets Missing Information

**Fix**:

1. Update description template with `{{variable}}` syntax
2. Ensure metadata fields are populated in bug reports
3. Check attachment configuration
4. Verify field mappings use valid Jira field names

---

## Real-World Example: QuickMart E-commerce Rules

This section shows how to create **domain-specific rules** for an e-commerce site using actual error patterns.

### QuickMart Error Patterns

From production monitoring, QuickMart sees these common errors:

1. **Cart race condition** - medium priority, duplicate items from double-clicks
2. **Payment processor freeze** - critical priority, gateway timeouts
3. **Search parser crashed** - high priority, special character handling
4. **Image lazy load failed** - low priority, CDN timeouts
5. **Promo code validation failed** - high priority, discount calculation errors

---

## Rule A: Critical Payment Gateway Failures

**Use Case**: Payment processor timeouts and freezes require immediate attention - revenue loss!

### Step-by-Step Instructions

1. Click **"Create Rule"** button
2. Fill in the following fields:

#### Basic Information

| Field                   | Value                               |
| ----------------------- | ----------------------------------- |
| **Rule Name**           | `Critical Payment Gateway Failures` |
| **Enabled**             | ✓ (checked)                         |
| **Execution Order**     | `1000`                              |
| **Auto-create Tickets** | ✓ (checked)                         |

#### Filters (Click "Add Filter" for each)

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(payment.*freeze|gateway.*timeout|payment.*failed|processor.*error)`
  > Matches payment-related failures

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/checkout`
  > Only checkout page errors

#### Throttling Settings

| Field                 | Value         |
| --------------------- | ------------- |
| **Enable Throttling** | ✓ (checked)   |
| **Max per Hour**      | `5`           |
| **Max per Day**       | `20`          |
| **Group By**          | `Error Type`  |
| **Digest Mode**       | ✗ (unchecked) |

#### Field Mappings (Jira-specific)

| Field Name   | Field Value                                 |
| ------------ | ------------------------------------------- |
| **priority** | `Highest`                                   |
| **labels**   | `["payment", "critical", "revenue-impact"]` |
| **assignee** | `payment-team-lead`                         |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 🚨 CRITICAL: Payment Gateway Failure

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Impact**: Customer unable to complete purchase - immediate revenue loss

**Action Required**:

1. Check payment gateway status dashboard
2. Review recent gateway API changes
3. Failover to backup processor if needed
```

2. Click **"Save Rule"** button

**Result**: Payment gateway failures create immediate tickets assigned to payment team lead.

---

## Rule B: Promo Code Validation Failures

**Use Case**: Track discount calculation errors that prevent customers from using promo codes.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                            |
| ----------------------- | -------------------------------- |
| **Rule Name**           | `Promo Code Validation Failures` |
| **Enabled**             | ✓                                |
| **Execution Order**     | `800`                            |
| **Auto-create Tickets** | ✓                                |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(promo.*validation|discount.*failed|coupon.*error|code.*not.*applied)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(checkout|cart)`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `10`         |
| **Max per Day**               | `50`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓ (checked)  |
| **Digest Interval (minutes)** | `30`         |

#### Field Mappings

| Field Name   | Field Value                               |
| ------------ | ----------------------------------------- |
| **priority** | `High`                                    |
| **labels**   | `["promo-code", "validation", "revenue"]` |
| **assignee** | `pricing-team`                            |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Promo Code Validation Failure

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Occurrences**: {{occurrence_count}} in last 30 minutes

**Action**: Verify promo code configuration and discount calculation logic
```

2. Click **"Save Rule"**

**Result**: Promo code errors batched every 30 minutes, assigned to pricing team.

---

## Rule C: Search Parser Crashes

**Use Case**: Special character handling failures in search functionality.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                   |
| ----------------------- | ----------------------- |
| **Rule Name**           | `Search Parser Crashes` |
| **Enabled**             | ✓                       |
| **Execution Order**     | `750`                   |
| **Auto-create Tickets** | ✓                       |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(search.*crash|parser.*exception|unhandled.*character|search.*failed)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/search`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `15`         |
| **Max per Day**               | `75`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `60`         |

#### Field Mappings

| Field Name   | Field Value                     |
| ------------ | ------------------------------- |
| **priority** | `High`                          |
| **labels**   | `["search", "parser", "crash"]` |
| **assignee** | `search-team`                   |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Search Parser Crash

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Search Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**User Impact**: Search functionality broken for queries with special characters

**Affected Queries**: {{occurrence_count}} similar crashes in last hour

**Fix Needed**: Sanitize search input to escape special characters: $ % & # @
```

2. Click **"Save Rule"**

**Result**: Search crashes batched hourly, assigned to search team.

---

## Rule D: Cart Race Conditions

**Use Case**: Duplicate item additions from rapid double-clicks (UX improvement).

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                  |
| ----------------------- | ---------------------- |
| **Rule Name**           | `Cart Race Conditions` |
| **Enabled**             | ✓                      |
| **Execution Order**     | `600`                  |
| **Auto-create Tickets** | ✓                      |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(cart.*duplicate|race.*condition|item.*added.*twice|double.*click)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/product/`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `20`         |
| **Max per Day**               | `100`        |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `120`        |

#### Field Mappings

| Field Name   | Field Value                        |
| ------------ | ---------------------------------- |
| **priority** | `Medium`                           |
| **labels**   | `["cart", "race-condition", "ux"]` |
| **assignee** | `frontend-team`                    |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Cart Race Condition - Batch Report

**Issue**: Users adding items twice due to rapid double-clicks

**Occurrences**: {{occurrence_count}} in last 2 hours

**Browser Distribution**:

- Chrome: {{browser_stats.chrome}}%
- Safari: {{browser_stats.safari}}%
- Firefox: {{browser_stats.firefox}}%

**Frequency**: {{occurrence_count}} occurrences in 2 hours

**Fix**: Implement debouncing on "Add to Cart" button (300ms delay)
```

2. Click **"Save Rule"**

**Result**: Cart race conditions batched every 2 hours for UX improvements.

---

## Rule E: CDN Image Load Failures

**Use Case**: Track CDN timeout issues for product images (low priority).

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                     |
| ----------------------- | ------------------------- |
| **Rule Name**           | `CDN Image Load Failures` |
| **Enabled**             | ✓                         |
| **Execution Order**     | `400`                     |
| **Auto-create Tickets** | ✓                         |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(image.*failed|lazy.*load.*error|CDN.*timeout|product-image.*\.jpg)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(product|category)`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `30`         |
| **Max per Day**               | `200`        |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `240`        |

#### Field Mappings

| Field Name   | Field Value                        |
| ------------ | ---------------------------------- |
| **priority** | `Low`                              |
| **labels**   | `["cdn", "images", "performance"]` |
| **assignee** | `devops-team`                      |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### CDN Image Load Failures - 4 Hour Digest

**Failed Images**: {{occurrence_count}} images failed to load

**Impact**: Minor visual degradation, images show placeholder

**Pages Affected**: {{url}}

**Action**: Check CDN cache and consider fallback image URLs
```

2. Click **"Save Rule"**

**Result**: CDN image failures batched every 4 hours for DevOps review.

---

### QuickMart Rules Summary

| Rule                     | Execution Order | Priority | Error Pattern               | Assignee          | Digest  |
| ------------------------ | --------------- | -------- | --------------------------- | ----------------- | ------- |
| Payment Gateway Failures | 1000            | Highest  | freeze, timeout, failed     | payment-team-lead | ✗       |
| Promo Code Validation    | 800             | High     | validation, discount        | pricing-team      | ✓ 30min |
| Search Parser Crashes    | 750             | High     | crash, exception, character | search-team       | ✓ 60min |
| Cart Race Conditions     | 600             | Medium   | duplicate, race condition   | engineering       | ✓ 2hr   |
| CDN Image Failures       | 400             | Low      | lazy load, CDN timeout      | devops            | ✓ 4hr   |

### How These Rules Process Your Errors

Using your actual QuickMart errors:

**1. Cart race condition (medium - duplicate)**

- ✅ Matches Rule D: `cart.*duplicate|race.*condition`
- Batched every 2 hours
- Creates digest ticket for engineering team

**2. Payment processor freeze (critical - freeze)**

- ✅ Matches Rule A: `payment.*freeze|gateway.*timeout`
- Immediate ticket to payment-team-lead
- Critical priority, no batching

**3. Search parser crashed (high - crash)**

- ✅ Matches Rule C: `search.*crash|parser.*exception`
- Batched every 60 minutes
- Groups by search query for deduplication

**4. Image lazy load failed (low - network-error)**

- ✅ Matches Rule E: `image.*failed|lazy.*load.*error`
- Batched every 4 hours
- Low priority, manual review during sprint planning

**5. Promo code validation failed (high - validation-error)**

- ✅ Matches Rule B: `promo.*validation|discount.*failed`
- Batched every 30 minutes
- Groups by promo code to track specific code issues

---

## Rule F: TalentHub Recruiting Platform Rules

**Use Case**: Specialized rules for a recruiting platform handling resume uploads, candidate communications, and data exports.

### TalentHub Error Patterns

From production monitoring, TalentHub sees these common errors:

1. **Search query parser error** - high priority, crashes with special search operators
2. **File upload stalled** - critical priority, resume uploads freeze at 99%
3. **Timezone conversion failed** - high priority, incorrect scheduling for interviews
4. **Email queue race condition** - critical priority, duplicate emails to candidates
5. **Excel export corrupted** - medium priority, malformed candidate data exports

---

## Rule F1: Search Query Parser Crashes

**Use Case**: Search functionality crashes when parsing complex queries with operators (AND, OR, quotes).

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                             |
| ----------------------- | --------------------------------- |
| **Rule Name**           | `TalentHub Search Parser Crashes` |
| **Enabled**             | ✓                                 |
| **Execution Order**     | `950`                             |
| **Auto-create Tickets** | ✓                                 |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(search.*parser.*error|unexpected token|query.*crash|parser.*failed)`
  > Matches search parser failures

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/candidates/search`
  > Only candidate search page

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `12`         |
| **Max per Day**               | `60`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `45`         |

#### Field Mappings

| Field Name   | Field Value                             |
| ------------ | --------------------------------------- |
| **priority** | `High`                                  |
| **labels**   | `["search", "parser", "crash", "high"]` |
| **assignee** | `search-team`                           |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 🔍 Search Query Parser Crash

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Search Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Occurrences**: {{occurrence_count}} similar crashes in last 45 minutes

**User Impact**: Search functionality broken - recruiters cannot find candidates

**Recommended Fix**:

1. Sanitize search query input to escape special operators
2. Add validation for parentheses matching
3. Implement error boundary with user-friendly message

**Query Examples Affected**:

- Queries with nested operators: (senior AND engineer) OR developer
- Queries with quotes: "senior engineer"
- Queries with special characters: C++ OR C#
```

2. Click **"Save Rule"**

**Result**: Search parser crashes batched every 45 minutes, assigned to search team.

---

## Rule F2: Critical Resume Upload Failures

**Use Case**: File uploads stalling at 99% prevent candidates from submitting applications.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                              |
| ----------------------- | ---------------------------------- |
| **Rule Name**           | `TalentHub Resume Upload Failures` |
| **Enabled**             | ✓                                  |
| **Execution Order**     | `1000`                             |
| **Auto-create Tickets** | ✓                                  |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(upload.*stalled|progress.*frozen|file.*99%|upload.*freeze)`
  > Matches upload freeze patterns

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(application|upload|resume)`

#### Throttling Settings

| Field                 | Value        |
| --------------------- | ------------ |
| **Enable Throttling** | ✓            |
| **Max per Hour**      | `8`          |
| **Max per Day**       | `40`         |
| **Group By**          | `Error Type` |
| **Digest Mode**       | ✗            |

#### Field Mappings

| Field Name   | Field Value                                          |
| ------------ | ---------------------------------------------------- |
| **priority** | `Highest`                                            |
| **labels**   | `["file-upload", "critical", "freeze", "candidate"]` |
| **assignee** | `platform-team-lead`                                 |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 🚨 CRITICAL: Resume Upload Frozen

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Impact**: Candidate unable to submit application - critical UX failure

**File Details**:

- Filename: resume.pdf (or similar)
- Progress: Frozen at 99%
- Network: {{metadata.network_status}}

**Action Required**:

1. Check file upload service logs
2. Verify S3/storage backend connectivity
3. Review multipart upload configuration
4. Check for file size limits (>10MB may timeout)

**Candidate Impact**: Application submission blocked - immediate fix needed
```

2. Click **"Save Rule"**

**Result**: Upload failures create immediate critical tickets with full network logs.

---

## Rule F3: Timezone Conversion Errors

**Use Case**: Interview scheduling fails due to incorrect PST/EST offset calculations.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                  |
| ----------------------- | -------------------------------------- |
| **Rule Name**           | `TalentHub Timezone Conversion Errors` |
| **Enabled**             | ✓                                      |
| **Execution Order**     | `900`                                  |
| **Auto-create Tickets** | ✓                                      |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(timezone.*failed|offset.*calculation|PST.*EST|invalid.*timezone|time.*conversion.*error)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(schedule|interview|calendar)`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `15`         |
| **Max per Day**               | `75`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `60`         |

#### Field Mappings

| Field Name   | Field Value                                               |
| ------------ | --------------------------------------------------------- |
| **priority** | `High`                                                    |
| **labels**   | `["timezone", "scheduling", "calculation-error", "high"]` |
| **assignee** | `scheduling-team`                                         |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## ⏰ Timezone Conversion Failure

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Occurrences**: {{occurrence_count}} failures in last hour

**User Impact**: Interview scheduling broken - incorrect times shown to candidates

**Affected Timezones**:

- Source: PST (Pacific Standard Time)
- Target: EST (Eastern Standard Time)
- Expected Offset: -3 hours
- Actual Offset: {{metadata.actual_offset}}

**Recommended Fix**:

1. Update timezone library to latest version
2. Add DST (Daylight Saving Time) handling
3. Validate offset calculations in unit tests
4. Consider using moment-timezone or date-fns-tz

**Business Impact**: Missed interviews, candidate frustration, recruiter credibility
```

2. Click **"Save Rule"**

**Result**: Timezone errors batched hourly for scheduling team review.

---

## Rule F4: Email Queue Race Conditions

**Use Case**: Duplicate emails sent to candidates due to concurrent queue processing.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                 |
| ----------------------- | ------------------------------------- |
| **Rule Name**           | `TalentHub Email Duplicate Detection` |
| **Enabled**             | ✓                                     |
| **Execution Order**     | `950`                                 |
| **Auto-create Tickets** | ✓                                     |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(email.*race.*condition|duplicate.*message|queue.*duplicate|sent.*twice)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(email|communication|message)`

#### Throttling Settings

| Field                 | Value        |
| --------------------- | ------------ |
| **Enable Throttling** | ✓            |
| **Max per Hour**      | `6`          |
| **Max per Day**       | `30`         |
| **Group By**          | `Error Type` |
| **Digest Mode**       | ✗            |

#### Field Mappings

| Field Name   | Field Value                                            |
| ------------ | ------------------------------------------------------ |
| **priority** | `Highest`                                              |
| **labels**   | `["email", "race-condition", "duplicate", "critical"]` |
| **assignee** | `messaging-team`                                       |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 📧 CRITICAL: Duplicate Email Race Condition

**Error**: {{title}}  
**Details**: {{description}}

**Affected Users**: 47 candidates received duplicate messages

**User**: {{user_email}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Impact**: Unprofessional candidate experience - multiple identical emails

**Technical Details**:

- Queue System: {{metadata.queue_system}}
- Message ID: {{metadata.message_id}}
- Sent Count: {{metadata.sent_count}} (expected: 1)
- Workers Processing: {{metadata.worker_count}}

**Root Cause**: Concurrent queue workers processing same message

**Recommended Fix**:

1. Implement distributed lock (Redis) before email send
2. Add idempotency key to message processing
3. Check "sent" status before sending
4. Increase message visibility timeout in queue

**Business Impact**: Candidate frustration, brand reputation damage
```

2. Click **"Save Rule"**

**Result**: Email duplicates create immediate critical tickets for messaging team.

---

## Rule F5: Excel Export Data Corruption

**Use Case**: Candidate data exports have invalid cell formatting, breaking Excel compatibility.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                               |
| ----------------------- | ----------------------------------- |
| **Rule Name**           | `TalentHub Excel Export Corruption` |
| **Enabled**             | ✓                                   |
| **Execution Order**     | `700`                               |
| **Auto-create Tickets** | ✓                                   |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(excel.*corrupt|export.*invalid|cell.*format|xlsx.*error|candidate.*data.*export)`

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(export|download|report)`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `20`         |
| **Max per Day**               | `100`        |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `90`         |

#### Field Mappings

| Field Name   | Field Value                                           |
| ------------ | ----------------------------------------------------- |
| **priority** | `Medium`                                              |
| **labels**   | `["excel", "export", "corruption", "data-integrity"]` |
| **assignee** | `reports-team`                                        |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 📊 Excel Export Corruption - Batch Report

**Error**: {{title}}  
**Details**: {{description}}

**Occurrences**: {{occurrence_count}} corrupted exports in last 90 minutes

**User**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**User Impact**: Recruiters unable to open exported candidate data in Excel

**Data Corruption Details**:

- Export Type: Candidate data export
- File Format: .xlsx
- Error: Invalid cell format in candidate data
- Affected Columns: {{metadata.affected_columns}}

**Recommended Fix**:

1. Validate cell data types before export (string vs number)
2. Escape special characters in text fields
3. Check for null/undefined values
4. Test with Excel compatibility validator

**Common Corruption Causes**:

- Phone numbers formatted as scientific notation
- Dates in non-standard format
- Special characters in names (é, ñ, ü)
- HTML tags in notes field

**Workaround**: Export as CSV and import to Excel manually
```

2. Click **"Save Rule"**

**Result**: Excel export errors batched every 90 minutes for reports team review.

---

### TalentHub Rules Summary

| Rule                    | Execution Order | Error Pattern           | Assignee           | Digest  | Priority |
| ----------------------- | --------------- | ----------------------- | ------------------ | ------- | -------- |
| Resume Upload Failures  | 1000            | upload freeze, 99%      | platform-team-lead | ✗       | Highest  |
| Email Race Conditions   | 950             | duplicate, queue        | messaging-team     | ✗       | Highest  |
| Search Parser Crashes   | 950             | parser error, token     | search-team        | ✓ 45min | High     |
| Timezone Conversion     | 900             | offset, PST/EST         | scheduling-team    | ✓ 60min | High     |
| Excel Export Corruption | 700             | corrupt, invalid format | reports-team       | ✓ 90min | Medium   |

### How These Rules Process Your Errors

Using your actual TalentHub error examples:

**1. Search query parser error: Unexpected token "senior" at position 0 (high - crash)**

- ✅ Matches Rule F1: `search.*parser.*error|unexpected token`
- Batched every 45 minutes
- Assigned to search-team with high priority
- Groups similar crashes for pattern detection

**2. File upload stalled: Progress frozen at 99% for resume.pdf (critical - freeze)**

- ✅ Matches Rule F2: `upload.*stalled|progress.*frozen|file.*99%`
- Immediate critical ticket to platform-team-lead
- No batching due to critical business impact
- Full network logs attached for debugging

**3. Timezone conversion failed: Invalid offset calculation for PST to EST (high - calculation-error)**

- ✅ Matches Rule F3: `timezone.*failed|offset.*calculation|PST.*EST`
- Batched every 60 minutes
- Assigned to scheduling-team
- Includes recommended fix for DST handling

**4. Email queue race condition: Duplicate messages sent to 47 candidates (critical - duplicate)**

- ✅ Matches Rule F4: `email.*race.*condition|duplicate.*message`
- Immediate critical ticket to messaging-team
- No batching - critical candidate experience issue
- Includes idempotency fix recommendations

**5. Excel export corrupted: Invalid cell format in candidate data export (medium - corruption)**

- ✅ Matches Rule F5: `excel.*corrupt|export.*invalid|cell.*format`
- Batched every 90 minutes
- Assigned to reports-team with medium priority
- Groups by error type to identify common corruption patterns

---

## Rule F: RecruiterPro ATS Errors

**Use Case**: Track critical issues in recruiting application affecting candidate experience and HR workflows.

### Background

RecruiterPro is an applicant tracking system with these common error patterns:

1. **Search query parser error** - high priority, candidate search crashes
2. **File upload stalled** - critical priority, resume uploads freeze
3. **Timezone conversion failed** - high priority, interview scheduling errors
4. **Email queue race condition** - critical priority, duplicate candidate emails
5. **Excel export corrupted** - medium priority, reporting data integrity

---

## Rule F1: Critical Candidate Experience Failures

**Use Case**: Resume upload freezes and duplicate emails directly impact candidates - revenue and reputation risk.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                    |
| ----------------------- | ---------------------------------------- |
| **Rule Name**           | `Critical Candidate Experience Failures` |
| **Enabled**             | ✓                                        |
| **Execution Order**     | `1000`                                   |
| **Auto-create Tickets** | ✓                                        |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(file upload.*stalled|progress frozen|email.*race condition|duplicate.*sent)`
  > Matches resume upload and email duplication issues

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(apply|candidate|upload)`
  > Candidate-facing pages only

#### Throttling Settings

| Field                 | Value         |
| --------------------- | ------------- |
| **Enable Throttling** | ✓             |
| **Max per Hour**      | `8`           |
| **Max per Day**       | `30`          |
| **Group By**          | `Error Type`  |
| **Digest Mode**       | ✗ (unchecked) |

#### Field Mappings

| Field Name   | Field Value                                           |
| ------------ | ----------------------------------------------------- |
| **priority** | `Highest`                                             |
| **labels**   | `["candidate-experience", "critical", "recruitment"]` |
| **assignee** | `platform-team-lead`                                  |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

````markdown
## 🚨 CRITICAL: Candidate Experience Failure

**Error**: {{title}}  
**Details**: {{description}}

**Candidate Impact**: {{user_email}}  
**Browser**: {{browser}} on {{os}}  
**Page**: {{url}}  
**Time**: {{timestamp}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Business Impact**:

- Revenue loss: Failed applications
- Reputation risk: Negative candidate experience
- Duplicate communications: Poor brand perception

**Error Details**:

```
{{stack_trace}}
```

**Action Required**:

1. Check file upload service status
2. Review email queue processing
3. Notify recruiting team of potential application gaps
4. Contact affected candidates if email duplicates sent
````

2. Click **"Save Rule"**

**Result**: Resume upload freezes and duplicate email errors create immediate tickets.

---

## Rule F2: Interview Scheduling Errors

**Use Case**: Timezone conversion failures cause incorrect interview times - impacts candidate and recruiter experience.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                         |
| ----------------------- | ----------------------------- |
| **Rule Name**           | `Interview Scheduling Errors` |
| **Enabled**             | ✓                             |
| **Execution Order**     | `900`                         |
| **Auto-create Tickets** | ✓                             |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(timezone.*conversion.*failed|invalid offset|schedule.*error|PST|EST|UTC)`
  > Matches timezone and scheduling calculation errors

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/interview`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `12`         |
| **Max per Day**               | `50`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `30`         |

#### Field Mappings

| Field Name   | Field Value                                         |
| ------------ | --------------------------------------------------- |
| **priority** | `High`                                              |
| **labels**   | `["scheduling", "timezone", "interview", "urgent"]` |
| **assignee** | `scheduling-team`                                   |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Interview Scheduling Error

**Error**: {{title}}  
**Details**: {{description}}

**User**: {{user_email}}  
**Time**: {{timestamp}}  
**Occurrences**: {{occurrence_count}} in last 30 minutes

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Impact**: Incorrect interview times may cause:

- Candidate no-shows
- Recruiter time wasted
- Interview re-scheduling overhead

**Action**: Verify timezone conversion logic for PST/EST/UTC calculations
```

2. Click **"Save Rule"**

**Result**: Timezone errors batched every 30 minutes, assigned to scheduling team.

### Console Log Filtering for Timezone Errors

To capture only timezone-related console errors and exclude noise, configure your SDK:

```javascript
// Configure BugSpotter SDK with console log filtering
BugSpotter.init({
  apiKey: 'your-api-key',
  endpoint: 'https://api.bugspotter.io',

  // Console log filtering - capture errors matching timezone patterns
  captureConsole: {
    levels: ['error'], // Only capture console.error()
    maxLogs: 50,

    // Filter to include only timezone/scheduling errors
    filter: (logEntry) => {
      const message = logEntry.message.toLowerCase();

      // Include these timezone error patterns
      const timezonePatterns = [
        /timezone.*conversion.*failed/i,
        /invalid offset/i,
        /pst|est|utc/i,
        /schedule.*error/i,
        /invalid.*timezone/i,
        /time.*conversion.*error/i,
      ];

      // Exclude third-party analytics noise
      const excludePatterns = [/google analytics/i, /facebook pixel/i, /ad blocker/i];

      const isTimezoneError = timezonePatterns.some((pattern) => pattern.test(message));
      const isNoise = excludePatterns.some((pattern) => pattern.test(message));

      return isTimezoneError && !isNoise;
    },
  },

  // Network filtering - exclude analytics requests
  captureNetwork: {
    filterUrls: (url) => {
      const excludeDomains = ['google-analytics.com', 'facebook.com/tr', 'doubleclick.net'];

      return !excludeDomains.some((domain) => url.includes(domain));
    },
  },
});
```

**Benefits**:

- ✅ Only captures timezone-related errors (reduces noise by ~80%)
- ✅ Excludes third-party analytics console spam
- ✅ Matches the rule's regex pattern exactly
- ✅ Prevents false positives from unrelated errors

**Test the Filter**:

```javascript
// These WILL be captured (match timezone patterns):
console.error('Timezone conversion failed: Invalid offset calculation for PST to EST');
console.error('Schedule error: Cannot parse UTC timestamp');
console.error('Invalid timezone: America/Los_Angeles');

// These will NOT be captured (filtered out):
console.warn('Timezone warning'); // warn level, not error
console.error('Google Analytics timeout'); // third-party noise
console.error('Payment failed'); // unrelated error
```

---

## Rule F3: Search and Export Failures

**Use Case**: Candidate search crashes and Excel export corruption impact recruiter productivity.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                        |
| ----------------------- | ---------------------------- |
| **Rule Name**           | `Search and Export Failures` |
| **Enabled**             | ✓                            |
| **Execution Order**     | `750`                        |
| **Auto-create Tickets** | ✓                            |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(search.*parser.*error|unexpected token|excel.*export.*corrupted|invalid cell format)`
  > Matches search parser and export errors

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(search|export|candidates)`

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `15`         |
| **Max per Day**               | `75`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `60`         |

#### Field Mappings

| Field Name   | Field Value                              |
| ------------ | ---------------------------------------- |
| **priority** | `Medium`                                 |
| **labels**   | `["search", "export", "data-integrity"]` |
| **assignee** | `data-team`                              |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
### Recruiter Productivity Impact - Search/Export Errors

**Error Summary**: {{occurrence_count}} errors in last hour

**Error Types**:

- Search parser crashes: {{metadata.search_errors}}
- Excel export corruption: {{metadata.export_errors}}

**Details**: {{description}}

**User**: {{user_email}}
**Page**: {{url}}
**Time**: {{timestamp}}

**Impact**: Recruiter workflow disruption

**Recommended Actions**:

1. Search: Sanitize query input for special characters
2. Export: Validate cell format before Excel generation
3. Consider fallback to CSV export if Excel continues failing
```

2. Click **"Save Rule"**

**Result**: Search/export errors batched hourly for data team review.

---

### RecruiterPro Rules Summary

| Rule                          | Execution Order | Error Pattern                        | Assignee           | Digest  | Priority |
| ----------------------------- | --------------- | ------------------------------------ | ------------------ | ------- | -------- |
| Critical Candidate Experience | 1000            | upload stalled, email race condition | platform-team-lead | ✗       | Critical |
| Interview Scheduling Errors   | 900             | timezone conversion, offset          | scheduling-team    | ✓ 30min | High     |
| Search and Export Failures    | 750             | parser error, excel corrupted        | data-team          | ✓ 60min | Medium   |

### How These Rules Process RecruiterPro Errors

**1. Search query parser error: Unexpected token "senior" at position 0 (high - crash)**

- ✅ Matches Rule F3: `search.*parser.*error|unexpected token`
- Batched every 60 minutes
- Assigned to data-team
- Medium priority (recruiter productivity)

**2. File upload stalled: Progress frozen at 99% for resume.pdf (critical - freeze)**

- ✅ Matches Rule F1: `file upload.*stalled|progress frozen`
- Immediate ticket (no digest)
- Assigned to platform-team-lead
- Critical priority (candidate experience)

**3. Timezone conversion failed: Invalid offset calculation for PST to EST (high - calculation-error)**

- ✅ Matches Rule F2: `timezone.*conversion.*failed|invalid offset`
- Batched every 30 minutes
- Assigned to scheduling-team
- High priority (interview coordination)

**4. Email queue race condition: Duplicate messages sent to 47 candidates (critical - duplicate)**

- ✅ Matches Rule F1: `email.*race condition|duplicate.*sent`
- Immediate ticket (no digest)
- Assigned to platform-team-lead
- Critical priority (brand reputation)

**5. Excel export corrupted: Invalid cell format in candidate data export (medium - corruption)**

- ✅ Matches Rule F3: `excel.*export.*corrupted|invalid cell format`
- Batched every 60 minutes
- Assigned to data-team
- Medium priority (reporting functionality)

---

## Rule G: TalentFlow HR Platform Console Log Filtering

**Use Case**: Filter console logs for TalentFlow recruiting platform to focus on actionable errors while excluding noise.

### TalentFlow Error Patterns

From production monitoring, TalentFlow sees these common console log errors:

1. **Search Query Parser Crash** 🔴 - high severity, search crashes with "senior" keyword
2. **Resume Upload Freeze** 🔴 - critical severity, file upload stalls at 99%
3. **Interview Timezone Calculation Error** 🔴 - high severity, PST to EST conversion fails
4. **Bulk Email Duplication** 🔴 - critical severity, race condition sends duplicate emails to 47 candidates
5. **Excel Export Corruption** 🟡 - medium severity, invalid cell formatting in candidate exports

---

## Rule G1: Critical TalentFlow System Failures

**Use Case**: Immediately escalate critical failures that block core recruiting workflows (uploads, emails).

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                 |
| ----------------------- | ------------------------------------- |
| **Rule Name**           | `TalentFlow Critical System Failures` |
| **Enabled**             | ✓                                     |
| **Execution Order**     | `1000`                                |
| **Auto-create Tickets** | ✓                                     |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(File upload stalled.*Progress frozen at 99%|Email queue race condition.*Duplicate messages sent to \d+ candidates)`
  > Matches upload freezes and email duplication

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(upload-resume|send-bulk-email)`
  > Critical workflow pages only

#### Throttling Settings

| Field                 | Value         |
| --------------------- | ------------- |
| **Enable Throttling** | ✓             |
| **Max per Hour**      | `5`           |
| **Max per Day**       | `20`          |
| **Group By**          | `Error Type`  |
| **Digest Mode**       | ✗ (unchecked) |

#### Field Mappings

| Field Name   | Field Value                                         |
| ------------ | --------------------------------------------------- |
| **priority** | `Highest`                                           |
| **labels**   | `["talentflow", "critical", "freeze", "duplicate"]` |
| **assignee** | `platform-team-lead`                                |

#### Description Template

**Note**: Use Jira Wiki Markup formatting (not Markdown):

```
*🚨 CRITICAL: TalentFlow System Failure*

*Error*: {{title}}
*Severity*: Critical
*Type*: {{metadata.error_type}}

*User Impact*:
* User: {{user_email}}
* Browser: {{browser}} {{browser_version}}
* OS: {{os}}
* Page: {{url}}
* Time: {{timestamp}}

*Error Details*:
{{description}}

*Stack Trace*:
{code}
{{stack_trace}}
{code}

*Business Impact*:
* Resume uploads frozen → Candidate applications blocked
* Duplicate emails sent → Brand reputation damage

*Action Required*:
# Check file upload service (S3/storage backend)
# Review email queue worker configuration
# Implement idempotency checks for email sending
# Add distributed lock (Redis) to prevent race conditions
```

**Jira Formatting Reference**:

- Bold: `*text*` (single asterisk, not double)
- Code block: `{code}...{code}` (not triple backticks)
- Bullet list: `*` at start of line
- Numbered list: `#` at start of line
- Headers: `h1.`, `h2.`, `h3.` etc.

2. Click **"Save Rule"**

**Result**: Upload freezes and email duplications create immediate critical tickets.

---

## Rule G2: TalentFlow High-Priority Calculation Errors

**Use Case**: Track calculation errors in search parsing and timezone conversions that impact recruiting operations.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                         |
| ----------------------- | --------------------------------------------- |
| **Rule Name**           | `TalentFlow High-Priority Calculation Errors` |
| **Enabled**             | ✓                                             |
| **Execution Order**     | `900`                                         |
| **Auto-create Tickets** | ✓                                             |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `(Search query parser error.*Unexpected token.*at position \d+|Timezone conversion failed.*Invalid offset calculation for (PST|EST))`
  > Matches search parser crashes and timezone errors

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Regular Expression`
- **Value**: `/(search-candidates|schedule-interview)`
  > Search and scheduling pages

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `12`         |
| **Max per Day**               | `60`         |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `45`         |

#### Field Mappings

| Field Name   | Field Value                                                 |
| ------------ | ----------------------------------------------------------- |
| **priority** | `High`                                                      |
| **labels**   | `["talentflow", "calculation-error", "search", "timezone"]` |
| **assignee** | `engineering-team`                                          |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## ⚠️ TalentFlow Calculation Error - High Priority

**Error**: {{title}}
**Severity**: High
**Type**: {{metadata.error_type}}

**Occurrences**: {{occurrence_count}} similar errors in last 45 minutes

**User Context**:

- User: {{user_email}}
- Browser: {{browser}} on {{os}}
- Page: {{url}}
- Action: {{metadata.button_action}}

**Session Replay**:
[Watch Session Replay]({{replay_url}})

**Error Categories**:

#### 1. Search Query Parser Crashes:

- Pattern: "Unexpected token 'senior' at position 0"
- Impact: Recruiters cannot search for candidates
- Root Cause: Parser fails on keywords like "senior", "manager", "lead"

#### 2. Timezone Conversion Failures:

- Pattern: "Invalid offset calculation for PST to EST"
- Impact: Interview times displayed incorrectly
- Root Cause: DST handling missing, hardcoded offsets

**Stack Trace**:
```

{{stack_trace}}

```

**Recommended Fixes**:

#### For Search Errors:
1. Sanitize query input before parsing
2. Add keyword escaping for reserved terms
3. Implement error boundary with fallback to simple search

#### For Timezone Errors:
1. Use moment-timezone or date-fns-tz library
2. Add DST transition handling
3. Store all times in UTC, convert for display only
4. Add unit tests for timezone edge cases

**Business Impact**: {{metadata.affected_user_count}} recruiters affected
```

2. Click **"Save Rule"**

**Result**: Search and timezone errors batched every 45 minutes with detailed fix recommendations.

---

## Rule G3: TalentFlow Medium-Priority Data Integrity Issues

**Use Case**: Track data export corruption that impacts reporting but not immediate workflows.

### Step-by-Step Instructions

1. Click **"Create Rule"** button

#### Basic Information

| Field                   | Value                                       |
| ----------------------- | ------------------------------------------- |
| **Rule Name**           | `TalentFlow Data Integrity Issues (Medium)` |
| **Enabled**             | ✓                                           |
| **Execution Order**     | `750`                                       |
| **Auto-create Tickets** | ✓                                           |

#### Filters

**Filter 1:**

- **Field**: `Error Message`
- **Operator**: `Regular Expression`
- **Value**: `Excel export corrupted.*Invalid cell format in candidate data export`
  > Matches Excel export corruption

**Filter 2:**

- **Field**: `URL Pattern`
- **Operator**: `Contains`
- **Value**: `/export-excel`
  > Export functionality page

#### Throttling Settings

| Field                         | Value        |
| ----------------------------- | ------------ |
| **Enable Throttling**         | ✓            |
| **Max per Hour**              | `20`         |
| **Max per Day**               | `100`        |
| **Group By**                  | `Error Type` |
| **Digest Mode**               | ✓            |
| **Digest Interval (minutes)** | `90`         |

#### Field Mappings

| Field Name   | Field Value                                               |
| ------------ | --------------------------------------------------------- |
| **priority** | `Medium`                                                  |
| **labels**   | `["talentflow", "corruption", "excel", "data-integrity"]` |
| **assignee** | `reports-team`                                            |

#### Description Template

**Note**: Using Markdown formatting (automatically converted to Jira format):

```markdown
## 📊 TalentFlow Data Export Corruption

**Error**: {{title}}
**Severity**: Medium
**Type**: {{metadata.error_type}}

**Occurrences**: {{occurrence_count}} corrupted exports in last 90 minutes

**User Context**:

- User: {{user_email}}
- Browser: {{browser}} on {{os}}
- Export Page: {{url}}
- Time: {{timestamp}}

**Issue Description**:
Excel export contains invalid cell formatting, making file unopenable in Microsoft Excel.

**Common Corruption Causes**:

- Phone numbers formatted as scientific notation (8.05E+11)
- Dates in non-standard format (text instead of date type)
- Special characters in candidate names (é, ñ, ü, apostrophes)
- HTML tags from notes field not stripped
- Null/undefined values causing empty cells

**Stack Trace**:
```

{{stack_trace}}

```

**Recommended Fixes**:
1. **Phone Numbers**: Format as text with leading apostrophe: '(805) 555-1234
2. **Dates**: Use Excel date serial format or ISO 8601
3. **Special Characters**: Escape HTML entities, use UTF-8 encoding
4. **Notes Field**: Strip HTML tags with DOMPurify or similar
5. **Null Values**: Replace with empty string "" instead of undefined

**Workaround**: Export as CSV and manually import to Excel

**Affected Columns**: {{metadata.corrupted_columns}}

**Business Impact**: Recruiter productivity - manual data cleanup required
```

2. Click **"Save Rule"**

**Result**: Excel corruption errors batched every 90 minutes for reports team review.

---

### TalentFlow Console Log Filtering Summary

| Rule                        | Execution Order | Error Pattern                                   | Assignee           | Digest  | Severity |
| --------------------------- | --------------- | ----------------------------------------------- | ------------------ | ------- | -------- |
| Critical System Failures    | 1000            | File upload stalled, Email race condition       | platform-team-lead | ✗       | Critical |
| High-Priority Calculation   | 900             | Search parser error, Timezone conversion failed | engineering-team   | ✓ 45min | High     |
| Medium-Priority Data Issues | 750             | Excel export corrupted                          | reports-team       | ✓ 90min | Medium   |

### Error Pattern Matching Examples

**Your TalentFlow Errors → Rule Mapping**:

**1. Search Query Parser Crash 🔴**

```
Button: "Search" (search-candidates)
Message: "Search query parser error: Unexpected token 'senior' at position 0"
```

- ✅ **Matches Rule G2**: `Search query parser error.*Unexpected token.*at position \d+`
- Batched every 45 minutes
- Assigned to engineering-team
- High priority

**2. Resume Upload Freeze 🔴**

```
Button: "Upload Resume" (upload-resume)
Message: "File upload stalled: Progress frozen at 99% for resume.pdf"
```

- ✅ **Matches Rule G1**: `File upload stalled.*Progress frozen at 99%`
- Immediate ticket (no digest)
- Assigned to platform-team-lead
- Critical priority

**3. Interview Timezone Calculation Error 🔴**

```
Button: "Schedule Interview" (schedule-interview)
Message: "Timezone conversion failed: Invalid offset calculation for PST to EST"
```

- ✅ **Matches Rule G2**: `Timezone conversion failed.*Invalid offset calculation for (PST|EST)`
- Batched every 45 minutes
- Assigned to engineering-team
- High priority

**4. Bulk Email Duplication 🔴**

```
Button: "Send Assessment Email to Selected Candidates" (send-bulk-email)
Message: "Email queue race condition: Duplicate messages sent to 47 candidates"
```

- ✅ **Matches Rule G1**: `Email queue race condition.*Duplicate messages sent to \d+ candidates`
- Immediate ticket (no digest)
- Assigned to platform-team-lead
- Critical priority

**5. Excel Export Corruption 🟡**

```
Button: "Export Candidates to Excel" (export-excel)
Message: "Excel export corrupted: Invalid cell format in candidate data export"
```

- ✅ **Matches Rule G3**: `Excel export corrupted.*Invalid cell format in candidate data export`
- Batched every 90 minutes
- Assigned to reports-team
- Medium priority

### Console Log Filtering Configuration

To implement these rules effectively, configure **console log filtering** in your TalentFlow integration:

```javascript
// Example SDK configuration for TalentFlow
BugSpotter.init({
  apiKey: 'your-api-key',
  endpoint: 'https://api.bugspotter.io',

  // Console log filtering - capture errors only
  captureConsole: {
    levels: ['error'], // Only capture console.error, ignore debug/info/warn
    maxLogs: 50,

    // Custom filter to exclude known noise
    filter: (logEntry) => {
      const message = logEntry.message.toLowerCase();

      // Exclude these patterns from console logs
      const excludePatterns = [
        /third-party analytics/i,
        /google analytics/i,
        /facebook pixel/i,
        /ad blocker/i,
      ];

      return !excludePatterns.some((pattern) => pattern.test(message));
    },
  },

  // Network filtering - exclude analytics and CDN
  captureNetwork: {
    filterUrls: (url) => {
      const excludeDomains = [
        'google-analytics.com',
        'facebook.com/tr',
        'doubleclick.net',
        'cdn.jsdelivr.net',
      ];

      return !excludeDomains.some((domain) => url.includes(domain));
    },
  },
});
```

### Best Practices for TalentFlow Console Filtering

1. **Capture Errors Only**: Set `levels: ['error']` to exclude debug/info/warn noise
2. **Filter Third-Party Scripts**: Exclude analytics, CDN errors not actionable by your team
3. **Group by Error Type**: Use throttling with `Group By: Error Type` to batch similar issues
4. **Prioritize by Business Impact**: Critical = revenue/candidate experience, High = recruiter productivity, Medium = reporting
5. **Use Digest Mode**: Batch medium/low priority errors to reduce ticket spam
6. **Monitor Rule Activity**: Check integration Activity tab weekly to adjust throttle limits

---

## Next Steps

After creating these rules:

1. ✅ **Enable 2-3 rules** for initial testing
2. ✅ **Monitor for 1 week** and check Activity tab daily
3. ✅ **Adjust throttle limits** based on actual volume
4. ✅ **Enable remaining rules** gradually
5. ✅ **Document** your rule strategy in Jira project description
6. ✅ **Train team** on manual review workflow (Rule 5)

---

**Questions?** Check the comprehensive guide: `docs/JIRA_INTEGRATION_QUICKSTART.md`
