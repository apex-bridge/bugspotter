# Jira Integration Quickstart Guide

**BugSpotter Admin Panel**  
**Last Updated**: January 9, 2026

A concise, step-by-step guide for creating a Jira integration using the Guided Mode with custom Markdown templates.

---

## Prerequisites

### Backend Requirements

**Custom code plugins require `isolated-vm` to be installed on the backend server.** If you see this error:

```
isolated-vm module not available. Plugin code execution requires isolated-vm to be installed and built.
```

The backend administrator needs to install the dependency:

```bash
# On the backend server
cd packages/backend
pnpm install isolated-vm

# Or rebuild all dependencies
pnpm install --force
```

**Note**: `isolated-vm` is a native module that requires:

- Node.js with native build tools
- Python 3.x
- C++ compiler (GCC/Clang on Linux/Mac, MSVC on Windows)

For Docker deployments, ensure the Dockerfile includes build dependencies.

### Jira Requirements

Before starting, gather these:

1. **Jira instance URL** (e.g., `https://yourcompany.atlassian.net`)
2. **Jira email address** (your account email)
3. **Jira API token** (generate from Jira Account Settings → Security → API tokens)
4. **Jira project key** (e.g., `PROJ`, `BUG`, `DEV`)
5. **Admin access** to BugSpotter

---

## Step-by-Step Instructions

### **Step 1: Navigate to Create Integration**

Go to: https://demo.admin.bugspotter.io/integrations/create

### **Step 2: Basic Information**

Fill in these fields:

1. **Integration Type**: Enter a unique identifier
   - Example: `jira_production`
   - Rules: lowercase letters, numbers, and underscores only
   - This is your internal identifier

2. **Display Name**: Enter a human-readable name
   - Example: `Jira - Production Environment`
   - This appears in the admin UI

3. **Description** (optional):
   - Example: `Production Jira instance for bug tracking`

4. **Plugin Source**:
   - Leave as **"Custom Code Plugin"** (only option)

### **Step 3: Choose Guided Mode**

Click the **"Guided Mode (Recommended)"** button at the top of the Custom Plugin Code section.

### **Step 4: Plugin Metadata** (Blue border)

1. **Plugin Name\*** (required): `jira-production`
   - Internal identifier used in logs and debugging
2. **Platform\*** (required): `jira`
   - **Why required**: Identifies which external system tickets are created in
   - **Why "jira"**: For Jira integrations, use `jira` for consistency
   - **Note**: You can use other values like `github`, `linear`, or custom names, but `jira` is the standard identifier for Jira systems
3. **Version**: `1.0.0` (default)
   - Update this when you modify the plugin
4. **Description**: `Integration with Jira Cloud for creating bug tickets`

### **Step 5: Authentication Helper** (Green border)

1. **Authentication Type**: Select **"Basic Auth (email + API token)"**
2. Review the auto-generated preview showing the `auth` variable

### **Step 6: Ticket Creation Logic** (Purple border) - REQUIRED

Copy and paste this code:

```javascript
// Extract config values (backend normalizes instanceUrl/serverUrl/host to same field)
const { instanceUrl, projectKey, issueType, priority, labels } = context.config;

// Build Jira API payload (ADF format required by Jira Cloud)
const response = await fetch(instanceUrl + '/rest/api/3/issue', {
  method: 'POST',
  headers: {
    Authorization: 'Basic ' + auth,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    fields: {
      project: { key: projectKey },
      summary: bugReport.title || 'Bug Report',
      description: {
        type: 'doc',
        version: 1,
        content: [
          {
            type: 'paragraph',
            content: [
              {
                type: 'text',
                text: bugReport.description || 'No description provided',
              },
            ],
          },
        ],
      },
      issuetype: { name: issueType || 'Bug' },
      priority: priority ? { name: priority } : undefined,
      labels: labels ? labels.split(',').map((l) => l.trim()) : undefined,
    },
  }),
});

// Handle errors
if (!response.ok) {
  const error = await response.text();
  throw new Error('Failed to create Jira ticket: ' + error);
}

// Parse response
const data = await response.json();

// Return required format
return {
  ticketId: data.key,
  ticketUrl: instanceUrl + '/browse/' + data.key,
};
```

### **Step 7: Test Connection** (Orange border) - OPTIONAL

1. Check the box: **"Add Test Connection Function (Optional)"**
2. Paste this code:

```javascript
// Test if credentials are valid
const { instanceUrl } = context.config;

const response = await fetch(instanceUrl + '/rest/api/3/myself', {
  headers: {
    Authorization: 'Basic ' + auth,
  },
});

if (!response.ok) {
  const status = response.status;
  if (status === 401) {
    throw new Error('Invalid credentials - check email and API token');
  } else if (status === 403) {
    throw new Error('Insufficient permissions');
  } else {
    throw new Error('Connection test failed with status: ' + status);
  }
}

return true;
```

### **Step 8: Config Validation** (Red border) - OPTIONAL

1. Check the box: **"Add Config Validation Function (Optional)"**
2. Paste this code:

```javascript
// Define required fields
const required = ['instanceUrl', 'email', 'apiToken', 'projectKey'];

// Check for missing fields
const missing = required.filter((field) => !config[field]);

if (missing.length > 0) {
  return {
    valid: false,
    errors: [`Missing required fields: ${missing.join(', ')}`],
  };
}

// Validate URL format (check instanceUrl or serverUrl for backward compatibility)
const url = config.instanceUrl || config.serverUrl;
if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
  return {
    valid: false,
    errors: ['Instance URL must start with http:// or https://'],
  };
}

// Validate email format
if (!config.email.includes('@')) {
  return {
    valid: false,
    errors: ['Email must be a valid email address'],
  };
}

// All valid
return { valid: true };
```

### **Step 9: Enable Code Execution**

Check the checkbox: **"Enable Code Execution"** at the bottom of the Custom Plugin Code section.

### **Step 10: Submit**

1. Click **"Create Integration"** button
2. Wait 2-3 seconds for:
   - Backend to generate complete plugin code
   - Security analysis to run automatically
   - Integration to be created and marked as active
3. You'll be redirected to `/integrations` page

---

## Configure for Your Project (Per-Project Configuration)

**Custom plugins support per-project configuration** - each project can have different settings for the same integration type.

After creating the integration:

1. Go to **Integrations** page
2. Find your integration (e.g., "Jira - Production Environment")
3. Click **Configure**
4. You'll see a **dynamic configuration form** where you can add fields:

### Add Configuration Fields

Click **"Add Configuration Field"** and enter these fields one by one:

#### **Required Fields**

These fields are **required** for the integration to work:

| Field Name    | Field Value                     | Description                                        |
| ------------- | ------------------------------- | -------------------------------------------------- |
| `instanceUrl` | `https://company.atlassian.net` | Your Jira instance URL (no trailing slash)         |
| `email`       | `you@company.com`               | Your Jira account email for authentication         |
| `apiToken`    | `ATATT3xFfGF0...`               | API token from Jira Account Settings → Security    |
| `projectKey`  | `PROJ`                          | Jira project key (uppercase, e.g., PROJ, BUG, DEV) |

#### **Optional Fields** (Recommended)

These fields provide additional control over ticket creation:

| Field Name  | Field Value            | Description                                            |
| ----------- | ---------------------- | ------------------------------------------------------ |
| `issueType` | `Bug`                  | Default issue type (Bug, Task, Story, etc.)            |
| `priority`  | `High`                 | Default priority (Highest, High, Medium, Low, Lowest)  |
| `assignee`  | `john.doe`             | Default assignee username (leave empty for unassigned) |
| `labels`    | `bugspotter,automated` | Comma-separated labels to add to tickets               |

#### **Advanced Fields** (Template Customization)

**NEW: Custom Markdown Templates with Live Preview**

BugSpotter now supports custom Markdown templates with a live preview editor. The template uses Markdown syntax and is automatically converted to Jira's ADF (Atlassian Document Format) when creating tickets.

**Template Editor Features:**

- ✅ **Markdown syntax** - Write templates in familiar Markdown
- ✅ **Live preview** - See rendered output in real-time with tab navigation
- ✅ **Variable substitution** - Dynamic placeholders replaced automatically
- ✅ **Syntax highlighting** - CodeMirror editor with Markdown support
- ✅ **Accessibility** - Full keyboard navigation and screen reader support

| Field Name             | Example Value                        | Description                                                         |
| ---------------------- | ------------------------------------ | ------------------------------------------------------------------- |
| `custom_template`      | See Markdown template examples below | Custom ticket description template with Markdown formatting         |
| `include_console_logs` | `false`                              | Include console logs in ticket description (default: false)         |
| `include_network_logs` | `false`                              | Include network request logs in ticket description (default: false) |
| `console_log_limit`    | `10`                                 | Maximum number of console logs to include (default: 10)             |
| `network_log_limit`    | `10`                                 | Maximum number of network requests to include (default: 10)         |
| `network_filter`       | `failures`                           | Network log filter: "all" or "failures" (default: failures)         |

**Important Notes:**

- Console and network logs are **disabled by default** to avoid Jira's CONTENT_LIMIT_EXCEEDED errors
- All debugging data is available through the shared replay link instead
- Enable logs only if you need them in the ticket description and keep limits low (10-20 max)

**Template Variables** (available in `custom_template`):

Core fields:

- `{{title}}` - Bug report title
- `{{description}}` - Bug report description
- `{{priority}}` - Bug priority (low, medium, high, critical)
- `{{timestamp}}` - ISO timestamp when bug was reported

User & session:

- `{{user_email}}` - User's email (or "Unknown")
- `{{session_id}}` - Session identifier (or "N/A")

Error information:

- `{{error.message}}` - Error message from metadata.error.message
- `{{error.type}}` - Error type/name from metadata.error.type
- `{{stack_trace}}` - Full stack trace from metadata.error.stack

Browser & environment:

- `{{browser}}` - Browser name (or "Unknown")
- `{{browser_version}}` - Browser version number
- `{{os}}` - Operating system (or "Unknown")
- `{{viewport_width}}` - Browser viewport width in pixels
- `{{viewport_height}}` - Browser viewport height in pixels

Location:

- `{{url}}` - Full page URL where bug occurred
- `{{referrer}}` - Referrer URL (previous page)

Attachments:

- `{{replay_url}}` - Shared session replay URL (if enabled)
- `{{screenshot_url}}` - Screenshot URL (if captured)

Dynamic metadata (2 levels supported):

- `{{metadata.request_id}}` - Top-level: metadata.request_id
- `{{metadata.user.name}}` - Nested: metadata.user.name
- Any custom metadata field you include in bug reports

**Example Markdown Templates**:

**Simple Template**:

```markdown
## Bug Report: {{title}}

**Description**: {{description}}

**Environment**:

- Browser: {{browser}} {{browser_version}}
- OS: {{os}}
- URL: {{url}}

**Reported**: {{timestamp}}
```

**Detailed Template with Links**:

```markdown
# 🐛 {{title}}

## Description

{{description}}

## Environment Details

- **Browser**: {{browser}} {{browser_version}}
- **OS**: {{os}}
- **Viewport**: {{viewport_width}}x{{viewport_height}}
- **URL**: [{{url}}]({{url}})
- **User**: {{user_email}}

## Error Information

**Type**: {{error.type}}
**Message**: {{error.message}}

### Stack Trace
```

{{stack_trace}}

```

## Debug Resources
- [🎬 Watch Session Replay]({{replay_url}})
- [📸 View Screenshot]({{screenshot_url}})

---
*Reported at {{timestamp}} | Session: {{session_id}}*
```

**Customer Support Template**:

```markdown
## Customer Report

**Priority**: {{priority}}
**Customer**: {{metadata.customer.name}} ({{metadata.customer.tier}})
**Account ID**: {{metadata.customer.account_id}}

### Issue Details

{{description}}

**Affected Feature**: {{metadata.feature}}
**Error Code**: {{metadata.error_code}}

### User Environment

- Browser: {{browser}} on {{os}}
- Page: {{url}}
- Session: {{session_id}}

### Next Steps

1. Review [session replay]({{replay_url}})
2. Check error logs for session {{session_id}}
3. Contact customer via {{user_email}}
```

**How to Use Custom Templates**:

1. **Via Integration Rule UI** (Recommended):
   - Go to Integrations → Your Jira Integration → Rules tab
   - Click "Edit" on a rule or "Add Rule"
   - Scroll to "Custom Ticket Template" section
   - Toggle "Use Custom Template" checkbox
   - The Markdown editor appears with **Edit** and **Preview** tabs:
     - **Edit tab**: Write your Markdown template with syntax highlighting
     - **Preview tab**: See real-time rendered output (switches every 500ms)
   - Use keyboard navigation: Tab/Shift+Tab to switch between edit and preview
   - Variables like `{{title}}` will be shown as-is in preview
   - Click "Save Rule" to apply

2. **Via Project Integration Config**:
   - Go to Integrations → Configure → Add field
   - Field name: `custom_template`
   - Field value: Paste your Markdown template
   - This sets a default template for all rules in the project

**Markdown to ADF Conversion**:

The backend automatically converts Markdown to Jira's ADF format:

- Headers (`#`, `##`, `###`) → ADF headings
- Bold (`**text**`) → ADF strong marks
- Italic (`*text*`) → ADF emphasis marks
- Links (`[text](url)`) → ADF hyperlinks
- Code blocks (` ``` `) → ADF code blocks
- Lists (`-`, `*`, `1.`) → ADF bullet/numbered lists
- Blockquotes (`>`) → ADF blockquotes

**Error Handling**:
If Markdown→ADF conversion fails (invalid syntax):

- Fallback: Plain text wrapped in ADF paragraph
- Warning logged with template excerpt (first 200 chars)
- Ticket still created successfully
- Check logs for "Markdown to ADF conversion failed" messages

**Variable Cleanup**:

- Unmatched variables ({{unknown_var}}) are removed automatically
- Empty Markdown links ([text]() or [](url)) are removed
- This prevents broken links in Jira tickets

#### **Field Name Aliases**

The backend supports multiple field name variations for compatibility. Use any of these:

| Preferred Name | Accepted Aliases               | Notes                     |
| -------------- | ------------------------------ | ------------------------- |
| `instanceUrl`  | `serverUrl`, `host`, `baseUrl` | All map to same field     |
| `email`        | `username`                     | For basic authentication  |
| `apiToken`     | `password`                     | Treated as sensitive data |

**Important**: Field names must match what your plugin code expects in `context.config`. The backend automatically normalizes variations.

#### **How to Add Each Field**

For each field in the tables above:

1. Enter the **Field Name** in the left input (e.g., `instanceUrl`)
2. Enter the **Field Value** in the right input (e.g., `https://bugspotter-team.atlassian.net`)
3. Click **"Add Field"** button
4. Repeat for each field

After adding all fields, click **"Save Configuration"** button at the bottom.

#### **Complete Example Configuration**

Your "Current Configuration" section should look like this after adding all fields:

```
Current Configuration

instanceUrl
https://bugspotter-team-cbvi4hjc.atlassian.net         [Remove]

projectKey
DEMO                                                    [Remove]

email
bot@yourcompany.com                                     [Remove]

apiToken
ATATT3xFfGF0_example_token_here                        [Remove]

issueType
Bug                                                     [Remove]

priority
High                                                    [Remove]

labels
bugspotter,automated,production                         [Remove]
```

**Security Note**: The `apiToken` is automatically encrypted before storage. You'll see it displayed as asterisks (`***`) after saving.

### Multi-Project Setup

**You can configure the same integration for multiple projects** with different settings:

Example: Configure `jira_production` for three projects:

- **Project A**: `serverUrl=https://team-a.atlassian.net`, `projectKey=TEAMA`
- **Project B**: `serverUrl=https://team-b.atlassian.net`, `projectKey=TEAMB`
- **Project C**: `serverUrl=https://shared.atlassian.net`, `projectKey=SHARED`

Each project gets its own isolated configuration stored in the `project_integrations` table.

---

## Test Ticket Creation

1. Create a test bug report in BugSpotter
2. Go to **Integrations** → **Activity** tab
3. Verify ticket was created successfully
4. Check your Jira project for the new ticket

---

## Common Issues

### "isolated-vm module not available" error

**Error message**:

```
Connection test failed: isolated-vm module not available.
Plugin code execution requires isolated-vm to be installed and built.
```

**Cause**: The backend server is missing the `isolated-vm` native module required for secure plugin code execution.

**Solution** (requires backend server access):

1. **For Railway/Render/Fly.io deployments**: The dependency is already in `package.json`, but the native module may have failed to build during deployment.

   **Check deployment logs** for errors like:

   ```
   gyp ERR! build error
   gyp ERR! stack Error: `make` failed with exit code: 2
   ```

   **Fix**: Add a build configuration file to ensure build tools are available:

   **For Railway** - Create `nixpacks.toml` in project root:

   ```toml
   [phases.setup]
   nixPkgs = ['python3', 'gcc', 'gnumake', 'pkg-config']

   [phases.install]
   cmds = ['pnpm install']
   ```

   **For Render** - Ensure your `render.yaml` includes:

   ```yaml
   services:
     - type: web
       name: bugspotter-backend
       env: node
       buildCommand: pnpm install && pnpm --filter @bugspotter/backend build
   ```

   Then redeploy.

2. **For Docker deployments**: The Dockerfile already includes build tools. Just rebuild:

   ```bash
   docker-compose build --no-cache backend
   docker-compose up -d backend
   ```

3. **For manual/VPS deployments**:
   ```bash
   cd packages/backend
   pnpm install isolated-vm --force
   pm2 restart all  # or your process manager
   ```

**Why this is needed**: Custom code plugins run in an isolated V8 context for security. The `isolated-vm` package provides this sandboxing to prevent malicious code from accessing the server environment.

### "Missing required fields" error

**Solution**: Ensure Plugin Name, Platform, and Ticket Creation Logic are filled.

### "Type must be lowercase..." error

**Solution**: Integration Type should only use lowercase letters, numbers, and underscores (e.g., `jira_prod`, not `Jira-Prod`).

### Ticket creation fails with 401 error

**Solution**:

- Verify Jira API token is correct
- Check email matches your Jira account
- Regenerate API token in Jira if needed

### Ticket creation fails with 400 error

**Solution**:

- Verify project key exists in Jira
- Check "Bug" issue type exists in your project
- Confirm you have permission to create issues

---

## What Happens Behind the Scenes

When you submit a Guided Mode integration:

1. **Backend generates complete plugin code** from your parts:

   ```javascript
   module.exports = {
     metadata: {
       /* your metadata */
     },
     factory: (context) => ({
       platform: 'jira',
       createTicket: async (bugReport, projectId) => {
         // Authentication helper + your code
       },
       testConnection: async () => {
         /* your code */
       },
       validateConfig: (config) => {
         /* your code */
       },
     }),
   };
   ```

2. **Runs security analysis** on generated code
3. **Stores the code** in database
4. **Marks integration as active** (if security passes)

---

## Additional Resources

- **Comprehensive Guide**: See `docs/JIRA_CUSTOM_CODE_PLUGIN_GUIDE.md` for detailed explanations, advanced examples, and troubleshooting
- **Jira REST API**: https://developer.atlassian.com/cloud/jira/platform/rest/v3/
- **BugSpotter Integration API**: See `API_DOCUMENTATION.md`

---

## Configuration Field Reference

### Required Fields Explained

#### `instanceUrl`

- **What it is**: The base URL of your Jira instance
- **Format**: Must start with `https://` (or `http://` for local testing)
- **Examples**:
  - Jira Cloud: `https://yourcompany.atlassian.net`
  - Jira Server/Data Center: `https://jira.yourcompany.com`
- **Common mistakes**:
  - ❌ Including trailing slash: `https://company.atlassian.net/`
  - ❌ Including `/browse` or other paths
  - ✅ Correct: `https://company.atlassian.net`

#### `email`

- **What it is**: Your Jira account email address used for Basic Authentication
- **Format**: Valid email address
- **Requirements**:
  - Must have permission to create issues in the target project
  - Account must be active and not suspended
- **Examples**:
  - `bot@yourcompany.com` (recommended: use a dedicated service account)
  - `your.name@yourcompany.com`
- **Security tip**: Create a dedicated service account for automated integrations

#### `apiToken`

- **What it is**: API token that authenticates your requests to Jira
- **How to generate**:
  1. Log into Jira with your account
  2. Go to **Account Settings** → **Security** → **API Tokens**
  3. Click **Create API Token**
  4. Give it a name (e.g., "BugSpotter Integration")
  5. Copy the generated token immediately (you can't view it again)
- **Format**: Long alphanumeric string starting with `ATATT` (for Atlassian Cloud)
- **Security**:
  - Never commit tokens to version control
  - Tokens are encrypted before storage in BugSpotter
  - Rotate tokens periodically for security
- **Troubleshooting**: If you get 401 errors, regenerate the token

#### `projectKey`

- **What it is**: The unique identifier for your Jira project
- **Format**: Usually 2-10 uppercase letters/numbers
- **How to find it**:
  1. Open your Jira project
  2. Look at the URL: `https://company.atlassian.net/browse/PROJ-123`
  3. The project key is `PROJ` (before the dash)
  4. Or check Project Settings → Details → Key
- **Examples**: `BUG`, `PROJ`, `DEMO`, `DEV`, `SUPPORT`
- **Case sensitive**: Must be uppercase (e.g., `BUG`, not `bug`)

### Optional Fields Explained

#### `issueType`

- **What it is**: The type of Jira issue to create (default: `Bug`)
- **Common values**:
  - `Bug` - For defects and issues
  - `Task` - For general work items
  - `Story` - For user stories (Scrum/Agile)
  - `Epic` - For large features
  - `Subtask` - For breaking down larger issues
- **How to check available types**:
  1. Go to your Jira project
  2. Create Issue → Click issue type dropdown
  3. Use the exact name shown (case-sensitive)
- **Default**: If not specified, uses `Bug`

#### `priority`

- **What it is**: Default priority level for created tickets
- **Standard values**:
  - `Highest` - Critical, blocks progress
  - `High` - Important, should be addressed soon
  - `Medium` - Normal priority (default in Jira)
  - `Low` - Can be deferred
  - `Lowest` - Nice to have
- **Custom priorities**: Some Jira instances have custom priority schemes
- **Default**: If not specified, Jira uses project default (usually `Medium`)

#### `assignee`

- **What it is**: Default user to assign tickets to
- **Format**: Jira username or account ID
- **Examples**:
  - Username: `john.doe`
  - Account ID: `5b10a2844c20165700ede21g` (for Jira Cloud)
- **Special values**:
  - Leave empty for unassigned tickets
  - Use `-1` for automatic assignment (if configured in Jira)
- **Permissions**: Assignee must have access to the project

#### `labels`

- **What it is**: Tags added to tickets for categorization and filtering
- **Format**: Comma-separated list of labels
- **Examples**:
  - Single label: `bugspotter`
  - Multiple labels: `bugspotter,automated,production,high-priority`
- **Rules**:
  - No spaces in individual labels (use hyphens or underscores)
  - Case-sensitive in Jira searches
  - Labels are automatically created if they don't exist
- **Use cases**:
  - Track source: `bugspotter`, `automated`
  - Environment: `production`, `staging`, `development`
  - Customer: `enterprise-client`, `free-tier`

### Advanced Configuration

#### Custom Fields (Enterprise)

If your Jira project uses custom fields, you can add them to the configuration:

```javascript
// In your createTicket code, add custom fields
fields: {
  project: { key: projectKey },
  summary: bugReport.title,
  // ... other standard fields ...

  // Custom fields use ID format
  customfield_10001: 'Custom Value',           // Text field
  customfield_10002: { value: 'Option A' },    // Select list
  customfield_10003: [{ value: 'Tag1' }],      // Multi-select
}
```

To find custom field IDs:

1. Create an issue manually in Jira
2. Use browser DevTools → Network tab
3. Find the POST request to `/rest/api/3/issue`
4. Check the payload for `customfield_*` entries

#### Multiple Projects Configuration

You can configure the same integration type for different projects:

**Project A** (Production environment):

- `instanceUrl`: `https://prod.atlassian.net`
- `projectKey`: `PROD`
- `priority`: `High`
- `labels`: `production,bugspotter`

**Project B** (Staging environment):

- `instanceUrl`: `https://staging.atlassian.net`
- `projectKey`: `STAGE`
- `priority`: `Medium`
- `labels`: `staging,bugspotter`

Each project maintains its own configuration in the `project_integrations` database table.

---

**Summary**: You've successfully created a Jira integration! Bug reports will now automatically create Jira tickets. 🎉
