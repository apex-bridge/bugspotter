# Creating a Jira Integration with Custom Code Plugin

**Admin Guide for BugSpotter**  
**Last Updated**: December 20, 2025 (Edit Form Refactored with Guided/Advanced Modes)

---

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Step-by-Step Process](#step-by-step-process)
4. [Custom Plugin Code Structure](#custom-plugin-code-structure)
5. [Security Analysis](#security-analysis)
6. [Testing the Integration](#testing-the-integration)
7. [Editing Plugin Code](#editing-plugin-code)
8. [Troubleshooting](#troubleshooting)

---

## Overview

This guide walks you through creating a **Jira integration with a custom code plugin** from the admin panel. Custom code plugins allow you to:

- Implement custom business logic for ticket creation
- Transform bug report data into Jira-specific formats
- Add custom field mappings beyond the built-in Jira plugin
- Integrate with self-hosted Jira instances with custom configurations

**Two Development Modes Available:**

1. **Guided Mode (Recommended)** - Simplified interface with separate fields for metadata, authentication, and ticket creation logic. Best for most users. → [Jump to Guided Mode instructions](#step-5a-guided-mode-recommended)

2. **Advanced Mode** - Write complete plugin code with `module.exports` boilerplate. Best for complex customizations or users who prefer full control. → [Jump to Advanced Mode instructions](#step-5b-advanced-mode)

**Security Note**: All custom plugin code is analyzed for security violations and executed in a secure sandbox with memory and time limits.

---

## Prerequisites

Before starting, you need:

1. **Admin Access**: You must have admin role in BugSpotter
2. **Jira Credentials**:
   - Jira instance URL (e.g., `https://company.atlassian.net`)
   - Email address for authentication
   - API token (generated from Jira Account Settings)
   - Project key (e.g., `PROJ`)
3. **JavaScript Knowledge**: Basic understanding of JavaScript for writing plugin code

### Generating Jira API Token

1. Log in to Jira
2. Go to **Account Settings** → **Security**
3. Click **Create and manage API tokens**
4. Generate a new token and save it securely

---

## Step-by-Step Process

### Step 1: Navigate to Integrations Page

1. Log in to BugSpotter admin panel
2. Click **Integrations** in the sidebar
3. Click **Create Integration** button

### Step 2: Fill Basic Information

Fill in the following fields:

- **Integration Type**: Unique identifier for this integration (e.g., `jira_custom_prod`)
  - Must be lowercase letters, numbers, and underscores only
  - This will be used as the integration identifier in the system
- **Display Name**: Human-readable name (e.g., `Jira Production Instance`)
  - This name will appear in the admin panel and project settings
- **Description** _(optional)_: Brief description of the integration
  - Example: "Custom Jira integration for production bug tracking"

### Step 3: Select Custom Code Plugin Source

1. **Plugin Source**: The dropdown shows **Custom Code Plugin**
   - This allows you to write custom JavaScript code for the integration
   - Code will be stored in the database and executed securely
   - This is currently the only available plugin source option

### Step 4: Configure Integration Settings

After creating the integration, you need to configure it with your Jira credentials:

1. Navigate to the integration details page
2. Click **Configure** or **Settings** button
3. Fill in the following configuration fields:

**Required Configuration Fields:**

- **Base URL/Server URL**: Your Jira instance URL
  - Example: `https://company.atlassian.net`
  - For self-hosted: `https://jira.company.com`
  - **Important**: Do not include trailing slash

- **Email**: Your Jira account email address
  - This is used for Basic Authentication
  - Must have permission to create issues in the project

- **API Token**: Your Jira API token
  - Generate from Jira Account Settings → Security → API Tokens
  - Keep this secure - it's equivalent to your password

- **Project Key**: Jira project identifier
  - Example: `PROJ`, `BUG`, `DEV`
  - Must be uppercase letters/numbers
  - Must exist in your Jira instance

- **Issue Type** _(optional)_: Type of issue to create
  - Default: `Bug`
  - Other examples: `Task`, `Story`, `Incident`
  - Must exist in your Jira project's issue type scheme

**How Configuration Works:**

When you configure an integration:

1. Configuration is stored encrypted in the database
2. Integration status changes from `not_configured` to `active`
3. The integration becomes available for projects to use
4. Projects can then link to this integration

**Frontend-to-Backend Configuration Mapping:**

The admin panel frontend sends configuration in a nested structure that gets automatically mapped to the format expected by Jira plugins:

```javascript
// Frontend sends (nested authentication):
{
  "baseUrl": "https://company.atlassian.net",
  "authentication": {
    "email": "user@company.com",
    "apiToken": "your-api-token"
  },
  "projectKey": "PROJ",
  "issueType": "Bug"
}

// Backend automatically flattens to:
{
  "host": "https://company.atlassian.net",  // baseUrl → host
  "email": "user@company.com",               // authentication.email → email
  "apiToken": "your-api-token",              // authentication.apiToken → apiToken
  "projectKey": "PROJ",
  "issueType": "Bug",
  "enabled": true
}
```

**Supported Field Variations:**

The backend accepts multiple field name variations for compatibility:

| Frontend Field            | Backend Field | Aliases Supported          |
| ------------------------- | ------------- | -------------------------- |
| `baseUrl`                 | `host`        | `instanceUrl`, `serverUrl` |
| `authentication.email`    | `email`       | `username`                 |
| `authentication.apiToken` | `apiToken`    | `password`                 |
| `authentication.type`     | _(ignored)_   | Used for UI only           |

**Testing the Configuration:**

After saving configuration:

1. Click **Test Connection** button
2. Backend will:
   - Map frontend config to backend format
   - Call integration's `validateConfig()` method (if defined)
   - Attempt to authenticate with Jira
   - Log the test result
3. You'll see success or error message
4. Check worker logs for detailed error information if test fails

**Important Notes:**

- **One-time setup**: Configuration is saved with the integration, not per-project
- **All projects share config**: When you link this integration to a project, it uses the same credentials
- **Status change**: Integration status automatically changes to `active` when config is saved
- **Security**: API tokens are stored encrypted in the database
- **Updates**: You can update configuration anytime by clicking **Edit Configuration**

### Step 5: Choose Your Development Mode

**NEW**: BugSpotter now offers two modes for creating custom integrations:

1. **Guided Mode (Recommended)** - Simplified interface with separate fields for each component
2. **Advanced Mode** - Write the complete plugin code with `module.exports` boilerplate

#### Switching Between Modes

You'll see two buttons at the top of the Custom Plugin Code section:

- **Guided Mode (Recommended)** - Best for most users
- **Advanced Mode** - For users who need full control or complex customization

Click the mode you want to use. You can switch between modes at any time.

---

## Step 5A: Guided Mode (Recommended)

**Best for**: Most users, especially those new to BugSpotter custom plugins.

Guided Mode simplifies plugin creation by breaking it into focused sections. You only write the core business logic - BugSpotter generates the boilerplate code automatically.

### Section 1: Plugin Metadata

Define basic information about your plugin:

- **Plugin Name\*** (required): Internal identifier (e.g., `jira-integration`)
  - Used in logs and debugging
  - Must be unique across your plugins
  - Lowercase with hyphens recommended

- **Platform\*** (required): Platform identifier (e.g., `jira`)
  - Used for ticket routing and display
  - Should match the service you're integrating with

- **Version** (optional): Semantic version (default: `1.0.0`)
  - Update this when you modify the plugin
  - Follows semver format: `major.minor.patch`

- **Description** (optional): Brief description of the plugin
  - Example: "Integration with Jira Cloud for creating bug tickets"
  - Appears in admin panel and logs

**Example:**

```
Plugin Name: jira-production
Platform: jira
Version: 1.0.0
Description: Production Jira instance integration for bug tracking
```

### Section 2: Authentication Helper

**Purpose**: Simplifies authentication by auto-generating credential handling code.

Choose your authentication type from the dropdown:

#### Option 1: Basic Auth (email + API token)

**When to use**: Jira Cloud, Jira Server, most Atlassian products

**Generated code:**

```javascript
const auth = Buffer.from(context.config.email + ':' + context.config.apiToken).toString('base64');
```

**Required config fields** (provided when configuring project):

- `email` - Your Jira account email
- `apiToken` - Your Jira API token

**Use in your code:**

```javascript
headers: {
  'Authorization': 'Basic ' + auth
}
```

#### Option 2: Bearer Token

**When to use**: GitHub, GitLab, many modern REST APIs

**Generated code:**

```javascript
const auth = context.config.apiToken;
```

**Required config fields**:

- `apiToken` - Your Bearer token

**Use in your code:**

```javascript
headers: {
  'Authorization': 'Bearer ' + auth
}
```

#### Option 3: API Key

**When to use**: Services that use API key in headers (e.g., SendGrid, Stripe)

**Generated code:**

```javascript
const apiKey = context.config.apiKey;
```

**Required config fields**:

- `apiKey` - Your API key

**Use in your code:**

```javascript
headers: {
  'X-API-Key': apiKey
}
```

#### Option 4: Custom (I'll handle it myself)

**When to use**: Complex auth schemes (OAuth, HMAC, custom tokens)

**Generated code:** None - you implement authentication yourself

**Example custom auth:**

```javascript
// OAuth 2.0 example
const response = await fetch(context.config.tokenUrl, {
  method: 'POST',
  body: new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: context.config.clientId,
    client_secret: context.config.clientSecret,
  }),
});
const { access_token } = await response.json();
```

### Section 3: Ticket Creation Logic\* (Required)

**Purpose**: Write the core function body for creating tickets.

**What to write**: Just the function body - **no** `module.exports`, **no** `async function` declaration. BugSpotter wraps your code automatically.

**Available variables:**

- `context` - Plugin context object:
  - `context.config` - Your configuration (baseUrl, email, projectKey, etc.)
  - `context.httpClient` - HTTP client for API requests (axios instance)
  - `context.db` - Database client (if needed)
  - `context.storage` - Storage service (if needed)

- `bugReport` - Bug report object:
  - `bugReport.title` - Bug title
  - `bugReport.description` - Bug description
  - `bugReport.priority` - Priority level (low/medium/high/critical)
  - `bugReport.status` - Current status
  - `bugReport.browser` - Browser name
  - `bugReport.os` - Operating system
  - `bugReport.url` - Page URL where bug occurred
  - `bugReport.metadata` - Additional metadata object

- `auth` - Authentication variable (if using helper)
  - Automatically available if you selected an authentication helper
  - Not available if you chose "Custom" auth

**Required return value**: Object with:

```javascript
{
  ticketId: string,  // External ticket ID
  ticketUrl: string  // URL to view ticket in external system
}
```

**Example (Jira):**

```javascript
// Extract config values
const { serverUrl, projectKey } = context.config;

// Build Jira API payload
const response = await fetch(serverUrl + '/rest/api/3/issue', {
  method: 'POST',
  headers: {
    Authorization: 'Basic ' + auth, // From authentication helper
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    fields: {
      project: { key: projectKey },
      summary: bugReport.title || 'Bug Report',
      description: {
        type: 'doc',
        version: 1,
        content: [
          {
            type: 'paragraph',
            content: [
              {
                type: 'text',
                text: bugReport.description || 'No description',
              },
            ],
          },
        ],
      },
      issuetype: { name: 'Bug' },
      priority: {
        name: bugReport.priority === 'critical' ? 'Highest' : 'High',
      },
    },
  }),
});

// Handle errors
if (!response.ok) {
  const error = await response.text();
  throw new Error('Failed to create Jira ticket: ' + error);
}

// Parse response
const data = await response.json();

// Return required format
return {
  ticketId: data.key,
  ticketUrl: serverUrl + '/browse/' + data.key,
};
```

**Tips:**

- Always validate `context.config` values before using them
- Add descriptive error messages for debugging
- Use `context.httpClient` for better error handling (but `fetch` works too)
- Test your code with different bug report formats

### Section 4: Test Connection (Optional)

**Purpose**: Validate credentials before using the integration.

**When to add**: If your API has a "test connection" or "validate credentials" endpoint.

**What to write**: Function body that tests if credentials work.

**Available variables**: Same as Ticket Creation Logic (`context`, `auth`)

**Required return value**:

- `true` if connection successful
- Throw error if connection fails

**Example (Jira):**

```javascript
// Test Jira credentials by fetching current user
const { serverUrl } = context.config;

const response = await fetch(serverUrl + '/rest/api/3/myself', {
  headers: {
    Authorization: 'Basic ' + auth,
  },
});

// If credentials are invalid, Jira returns 401
if (!response.ok) {
  const status = response.status;
  if (status === 401) {
    throw new Error('Invalid credentials - check email and API token');
  } else if (status === 403) {
    throw new Error('Insufficient permissions');
  } else {
    throw new Error('Connection test failed with status: ' + status);
  }
}

// Success
return true;
```

**Example (GitHub):**

```javascript
const { baseUrl } = context.config;

const response = await fetch(baseUrl + '/user', {
  headers: {
    Authorization: 'Bearer ' + auth,
    Accept: 'application/vnd.github.v3+json',
  },
});

if (!response.ok) {
  throw new Error('GitHub authentication failed');
}

return true;
```

### Section 5: Config Validation (Optional)

**Purpose**: Validate configuration fields before saving.

**When to add**: To provide helpful error messages for missing or invalid config fields.

**What to write**: Function body that checks the `config` object.

**Available variables**:

- `config` - Configuration object to validate (NOT `context.config` - just `config`)

**Required return value**:

```javascript
{
  valid: boolean,
  errors?: string[]  // Array of error messages (if invalid)
}
```

**Example (Jira):**

```javascript
// Define required fields
const required = ['serverUrl', 'email', 'apiToken', 'projectKey'];

// Check for missing fields
const missing = required.filter((field) => !config[field]);

if (missing.length > 0) {
  return {
    valid: false,
    errors: [`Missing required fields: ${missing.join(', ')}`],
  };
}

// Validate URL format
if (!config.serverUrl.startsWith('http://') && !config.serverUrl.startsWith('https://')) {
  return {
    valid: false,
    errors: ['Server URL must start with http:// or https://'],
  };
}

// Validate email format
if (!config.email.includes('@')) {
  return {
    valid: false,
    errors: ['Email must be a valid email address'],
  };
}

// Validate project key format (uppercase letters and numbers)
if (!/^[A-Z0-9]+$/.test(config.projectKey)) {
  return {
    valid: false,
    errors: ['Project key must be uppercase letters and numbers only'],
  };
}

// All valid
return { valid: true };
```

**Example (GitHub):**

```javascript
const errors = [];

if (!config.owner) {
  errors.push('Repository owner is required');
}

if (!config.repo) {
  errors.push('Repository name is required');
}

if (!config.token) {
  errors.push('GitHub personal access token is required');
}

// Validate token format (should start with 'ghp_' for new tokens)
if (config.token && !config.token.startsWith('ghp_') && !config.token.startsWith('github_pat_')) {
  errors.push('Token format looks incorrect - should start with ghp_ or github_pat_');
}

if (errors.length > 0) {
  return { valid: false, errors };
}

return { valid: true };
```

### How Guided Mode Works (Behind the Scenes)

When you submit a Guided Mode integration, BugSpotter:

1. **Generates complete plugin code** from your parts:

   ```javascript
   module.exports = {
     metadata: { /* your metadata */ },
     factory: (context) => ({
       platform: 'jira',
       createTicket: async (bugReport, projectId) => {
         // Authentication helper code (if selected)
         const auth = Buffer.from(...).toString('base64');

         // Your createTicket code here
         const { serverUrl, projectKey } = context.config;
         const response = await fetch(...);
         // ...
       },
       testConnection: async () => {
         // Your testConnection code (if provided)
       },
       validateConfig: (config) => {
         // Your validateConfig code (if provided)
       }
     })
   };
   ```

2. **Runs security analysis** on the generated code
3. **Stores the code** in the database
4. **Marks integration as active** immediately (if security passes)

**Benefits:**

- Less boilerplate to write
- Faster development
- Fewer syntax errors
- Consistent code structure
- Easier to maintain

---

## Step 5B: Advanced Mode

**Best for**: Users who need full control or complex customizations.

In the **Plugin Code** textarea, write your Jira integration plugin. The code must follow this structure:

```javascript
module.exports = {
  metadata: {
    name: 'Custom Jira Integration',
    platform: 'jira',
    version: '1.0.0',
    description: 'Custom Jira integration for E2E testing',
  },

  factory: (context) => ({
    platform: 'jira',

    createTicket: async (bugReport, projectId) => {
      // 1. Build authentication header (Basic Auth)
      const auth = Buffer.from(context.config.email + ':' + context.config.apiToken).toString(
        'base64'
      );

      // 2. Build Jira ticket payload
      const payload = {
        fields: {
          project: { key: context.config.projectKey },
          summary: bugReport.title,
          description: bugReport.description || 'Bug reported via BugSpotter',
          issuetype: { name: 'Bug' },
        },
      };

      // 3. Make API request to Jira
      const response = await context.httpClient.post(
        context.config.baseUrl + '/rest/api/3/issue',
        payload,
        {
          headers: {
            Authorization: 'Basic ' + auth,
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
        }
      );

      // 4. Return ticket information
      return {
        id: response.data.id,
        url: context.config.baseUrl + '/browse/' + response.data.key,
        platform: 'jira',
      };
    },
  }),
};
```

**Code Structure Explained:**

- **`metadata`**: Plugin information (name, platform, version, description)
- **`factory(context)`**: Function that creates the integration service
  - `context.config`: Configuration object with your Jira settings
  - `context.httpClient`: HTTP client for making API requests (axios instance)
  - `context.db`: Database client for queries (if needed)
  - `context.storage`: Storage service for file uploads (if needed)
- **`createTicket(bugReport, projectId)`**: Main function that creates Jira tickets
  - `bugReport`: Object containing bug report data (title, description, etc.)
  - `projectId`: BugSpotter project ID
  - **Returns**: Object with `{ id, url, platform }`

### Step 5: Run Security Analysis (Advanced Mode Only)

**Note**: In **Guided Mode**, security analysis happens automatically when you click "Create Integration". You don't need to manually analyze the code.

In **Advanced Mode**, before you can submit the code, you **must** run security analysis:

1. Click **Analyze Security** button
2. Wait for analysis to complete (usually takes 1-2 seconds)
3. Review the security analysis results:
   - ✅ **Safe**: No security violations found
   - ⚠️ **Warnings**: Potential issues (e.g., HTTP requests, external dependencies)
   - ❌ **Violations**: Forbidden operations detected (code cannot be used)

**Security Checks:**

- ❌ **Forbidden**: `eval()`, `Function()`, `require()`, filesystem access, `child_process`
- ⚠️ **Warnings**: HTTP requests, large code size, complex logic
- ✅ **Safe**: Pure functions, controlled API usage

### Step 6: Enable Code Execution

**Guided Mode**: The checkbox is checked automatically after the backend generates and validates your code.

**Advanced Mode**: After successful security analysis:

1. Check the **Enable Code Execution** checkbox
   - This checkbox only becomes enabled after security analysis passes
   - This grants permission for the code to be executed in the sandbox

### Step 7: Submit the Integration

1. Click **Create Integration** button
   - **Guided Mode**: Backend generates code from your parts, runs security analysis, and creates the integration
   - **Advanced Mode**: Your analyzed code is submitted directly
2. Wait for the integration to be created (usually 2-3 seconds)
3. You'll be redirected to the **Integrations** overview page
4. Your new integration should appear in the list with status "Active"

---

## Custom Plugin Code Structure

### Required Plugin Interface

```typescript
interface IntegrationPlugin {
  metadata: {
    name: string;
    platform: string;
    version: string;
    description?: string;
  };

  factory: (context: PluginContext) => IntegrationService;
}

interface PluginContext {
  config: any; // Your configuration object
  httpClient: AxiosInstance; // HTTP client for API requests
  db: DatabaseClient; // Database client (optional)
  storage: IStorageService; // Storage service (optional)
}

interface IntegrationService {
  platform: string;
  createTicket(bugReport: BugReport, projectId: string): Promise<TicketResult>;
}

interface TicketResult {
  id: string; // External ticket ID
  url: string; // URL to view ticket
  platform: string; // Platform identifier
}
```

### BugReport Object

Your `createTicket` function receives a `bugReport` object with the following structure:

```typescript
interface BugReport {
  id: string;
  title: string;
  description?: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority?: 'low' | 'medium' | 'high' | 'critical';
  browser?: string;
  os?: string;
  url?: string;
  user_agent?: string;
  metadata?: Record<string, any>;
  created_at: Date;
  updated_at: Date;
}
```

### Advanced Example with Custom Fields

```javascript
module.exports = {
  metadata: {
    name: 'Advanced Jira Integration',
    platform: 'jira',
    version: '2.0.0',
    description: 'Jira integration with custom field mapping and priority conversion',
  },

  factory: (context) => ({
    platform: 'jira',

    createTicket: async (bugReport, projectId) => {
      // Convert BugSpotter priority to Jira priority
      const priorityMap = {
        low: 'Low',
        medium: 'Medium',
        high: 'High',
        critical: 'Highest',
      };

      const jiraPriority = priorityMap[bugReport.priority || 'medium'];

      // Build authentication
      const auth = Buffer.from(context.config.email + ':' + context.config.apiToken).toString(
        'base64'
      );

      // Build comprehensive description with metadata
      let description = bugReport.description || 'Bug reported via BugSpotter';

      if (bugReport.metadata) {
        description += '\n\n--- Technical Details ---\n';
        description += `Browser: ${bugReport.browser || 'Unknown'}\n`;
        description += `OS: ${bugReport.os || 'Unknown'}\n`;
        description += `URL: ${bugReport.url || 'N/A'}\n`;

        if (bugReport.metadata.errorMessage) {
          description += `\nError: ${bugReport.metadata.errorMessage}\n`;
        }

        if (bugReport.metadata.stackTrace) {
          description += `\nStack Trace:\n${bugReport.metadata.stackTrace}\n`;
        }
      }

      // Build Jira payload with custom fields
      const payload = {
        fields: {
          project: { key: context.config.projectKey },
          summary: bugReport.title,
          description: description,
          issuetype: { name: 'Bug' },
          priority: { name: jiraPriority },
          labels: ['bugspotter', 'automated'],
          // Add custom fields if configured
          ...(context.config.customFields || {}),
        },
      };

      // Create ticket
      const response = await context.httpClient.post(
        context.config.baseUrl + '/rest/api/3/issue',
        payload,
        {
          headers: {
            Authorization: 'Basic ' + auth,
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
        }
      );

      // Optionally add screenshot as attachment
      if (bugReport.screenshot_url && context.storage) {
        const attachmentUrl = `${context.config.baseUrl}/rest/api/3/issue/${response.data.key}/attachments`;

        // Download screenshot from storage
        const screenshotBuffer = await context.storage.download(bugReport.screenshot_url);

        // Upload to Jira (using form-data)
        await context.httpClient.post(attachmentUrl, screenshotBuffer, {
          headers: {
            Authorization: 'Basic ' + auth,
            'X-Atlassian-Token': 'no-check',
            'Content-Type': 'image/png',
          },
        });
      }

      return {
        id: response.data.id,
        url: context.config.baseUrl + '/browse/' + response.data.key,
        platform: 'jira',
      };
    },
  }),
};
```

---

## Security Analysis

### What Gets Analyzed

The security analyzer checks your code for:

1. **Forbidden Operations**:
   - `eval()`, `Function()` constructor (code injection risks)
   - `require()`, `import()` (dependency injection)
   - Filesystem access (`fs`, `path`, `__dirname`)
   - Child processes (`child_process`, `exec`)
   - Network access outside provided `httpClient`

2. **Warnings**:
   - HTTP requests (ensure credentials are secured)
   - External dependencies
   - Large code size (>5000 characters)
   - Complex nested logic

3. **Code Hash**:
   - SHA-256 hash of your code for integrity verification
   - Stored in database to detect tampering

### Security Analysis Results

After clicking **Analyze Security**, you'll see:

```json
{
  "safe": true,
  "violations": [],
  "warnings": [
    "Uses HTTP requests - ensure credentials are secured",
    "Accesses context.config - validate configuration before use"
  ],
  "risk_level": "low",
  "code_hash": "sha256:abc123..."
}
```

**Risk Levels:**

- **Low**: Safe to use with standard precautions
- **Medium**: Review warnings carefully before enabling
- **High**: Multiple warnings, thorough review required
- **Critical**: Security violations found, code cannot be used

---

## Testing the Integration

### Test Connection from Admin Panel

After creating the integration:

1. Go to **Integrations** overview page
2. Find your integration in the list
3. Click **Test Connection** button (if available)
4. Verify that the test succeeds

### Manual Ticket Creation Test

You can trigger ticket creation manually using the admin API:

```bash
curl -X POST 'http://localhost:4000/api/v1/admin/integrations/jira_custom_prod/trigger' \
  -H 'Authorization: Bearer YOUR_ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "bugReportId": "uuid-of-existing-bug-report",
    "projectId": "uuid-of-project"
  }'
```

### Configure Project to Use Integration

1. Go to **Projects** page
2. Select a project
3. Go to **Integrations** tab
4. Enable your custom Jira integration
5. **Note**: Configuration is already set at the integration level
   - No need to provide credentials again
   - Integration uses the global configuration you set in Step 4
6. Click **Save**
7. Optionally test the connection from project settings

### Verify Automatic Ticket Creation

1. Create a new bug report in BugSpotter (via SDK or API)
2. Check the integration queue logs:
   ```bash
   docker logs bugspotter-worker
   ```
3. Verify that a ticket was created in Jira
4. Check the bug report in BugSpotter admin panel - it should show the linked Jira ticket

---

## Editing Plugin Code

After creating an integration, you can modify its plugin code at any time. **The editing interface works the same way as the creation form**, with both Guided Mode and Advanced Mode available.

### Accessing the Edit Page

1. Go to **Integrations** overview page
2. Find your integration in the list
3. Click the **Edit** button (pencil icon) or click on the integration name
4. You'll be taken to the **Edit Integration** page

### Editing Modes

Just like during creation, you have two options for editing:

#### Guided Mode (Recommended)

Best for making changes to specific parts of your integration:

1. **Switch to Guided Mode** if not already active
2. Edit any of the following sections:
   - **Plugin Metadata**: Update name, platform identifier, version, or description
   - **Authentication Type**: Change between Basic Auth, API Key, or OAuth2
   - **Authentication Setup Code**: Modify how authentication headers are configured
   - **Ticket Creation Code**: Update the `createTicket` function logic
3. Click **Analyze Security** to validate your changes
4. Review the security analysis results
5. Enable code execution if satisfied
6. Click **Update Integration** to save changes

**Benefits**:

- Structured interface with clear separation of concerns
- Backend automatically generates complete plugin code from your parts
- Easier to make targeted changes without affecting other parts
- Security analysis runs automatically before saving

#### Advanced Mode

Best for complex refactoring or when you need full control:

1. **Switch to Advanced Mode**
2. Edit the complete plugin code directly in the code editor
3. Ensure your code maintains the required structure:
   - `module.exports` with `metadata` and `factory`
   - Correct `metadata` object with `name`, `platform`, `version`
   - Factory function returning object with `platform` and `createTicket` method
4. Click **Analyze Security** to validate your changes
5. Review the security analysis results
6. Enable code execution if satisfied
7. Click **Update Integration** to save changes

**Benefits**:

- Full control over the entire plugin code
- See the complete generated code
- Make complex refactoring changes
- Better for advanced users familiar with the plugin structure

### Important Notes About Editing

- **Mode Switching**: You can switch between Guided and Advanced modes at any time during editing
  - When switching from Advanced to Guided, the system parses your code to extract the parts
  - When switching from Guided to Advanced, the system shows the generated complete code
- **Security Re-Analysis**: Always required after making code changes
- **Code Execution**: Must be re-enabled after security analysis passes
- **Configuration**: Integration configuration (credentials, URLs) is managed separately in the Settings page
- **Version Updates**: Consider incrementing the version number in metadata when making significant changes

### Common Editing Scenarios

**Scenario 1: Update Ticket Creation Logic**

- Use **Guided Mode**
- Navigate to the **Ticket Creation Code** section
- Modify the `createTicket` function body
- Run security analysis and update

**Scenario 2: Change Authentication Method**

- Use **Guided Mode**
- Update the **Authentication Type** dropdown
- Modify the **Authentication Setup Code** accordingly
- Update your integration configuration with new credentials (Settings page)
- Run security analysis and update

**Scenario 3: Add Custom Field Mapping**

- Use **Guided Mode** or **Advanced Mode** depending on complexity
- Modify the ticket creation logic to include additional field mappings
- Run security analysis and update

**Scenario 4: Major Refactoring**

- Use **Advanced Mode**
- Refactor the complete plugin code
- Ensure structure remains valid (metadata + factory)
- Run security analysis and update

### Testing After Editing

After updating your integration:

1. **Test Connection**: Click the **Test Connection** button if available
2. **Manual Test**: Trigger a test ticket creation from the admin panel
3. **Monitor Logs**: Check worker logs for any execution errors
4. **Verify in Jira**: Ensure tickets are created correctly with your changes

---

## Troubleshooting

### Common Issues

#### 1. Security Analysis Fails (Advanced Mode)

**Problem**: Code contains forbidden operations

**Solution**:

- Review the violations list in the security analysis results
- Remove or replace forbidden operations:
  - Use `context.httpClient` instead of raw `axios` imports
  - You can use `fetch` (it's safe and built-in)
  - Don't use `eval()` or `Function()` constructor
  - Don't access filesystem or spawn processes
  - Don't use `require()` - all dependencies must be provided via context

#### 1b. Integration Creation Fails (Guided Mode)

**Problem**: Error when clicking "Create Integration" in Guided Mode

**Common Errors**:

- **"Missing required fields"**: Fill in Plugin Name, Platform, and createTicket code
- **"Code failed security validation"**: Your code uses forbidden operations
  - Check createTicket code for `eval()`, `require()`, filesystem access
  - Remove any attempts to import external libraries
  - Use `fetch` or `context.httpClient` for HTTP requests only

**Debugging Tips**:

- Simplify your createTicket code to minimum working version
- Test with a simple `return { ticketId: 'TEST-1', ticketUrl: 'https://example.com' };`
- Add error handling with descriptive messages
- Check browser console for detailed error messages

#### 2. "Enable Code Execution" Checkbox Disabled (Advanced Mode)

**Problem**: Cannot enable code execution

**Solution**:

- Run security analysis first by clicking **Analyze Security**
- Wait for analysis to complete (green checkmark or warnings)
- Only then will the checkbox become enabled

**Note**: In Guided Mode, this checkbox is managed automatically

#### 3. Integration Creation Fails

**Problem**: Error when clicking **Create Integration**

**Common Errors**:

- **"Type already exists"**: Choose a different integration type identifier
- **"Type must be lowercase..."**: Use only lowercase letters, numbers, and underscores
- **"Code failed security validation"**: Your code has security violations - fix them first

#### 4. Ticket Creation Fails

**Problem**: Tickets aren't created in Jira

**Debugging Steps**:

1. **Check Worker Logs**:

   ```bash
   docker logs bugspotter-worker -f
   ```

   Look for error messages related to your integration

2. **Check API Credentials**:
   - Verify Jira base URL is correct (no trailing slash)
   - Verify email and API token are valid
   - Test credentials manually with curl:

   ```bash
   curl -u "email@company.com:API_TOKEN" \
     https://company.atlassian.net/rest/api/3/myself
   ```

3. **Check Jira Project Key**:
   - Ensure the project key exists in your Jira instance
   - Verify you have permission to create issues in that project

4. **Check Issue Type**:
   - Verify "Bug" issue type exists in your Jira project
   - Some projects use different issue type names

5. **Review Plugin Code**:
   - Add `console.log()` statements for debugging (visible in worker logs)
   - Check that all required fields are provided
   - Verify HTTP request format matches Jira API v3

#### 5. HTTP Client Errors

**Problem**: API requests fail in your code

**Solutions**:

**Using `fetch` (Recommended for Guided Mode):**

```javascript
const response = await fetch(url, {
  method: 'POST',
  headers: {
    Authorization: 'Basic ' + auth,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(payload),
});

if (!response.ok) {
  const error = await response.text();
  throw new Error(`API error (${response.status}): ${error}`);
}

const data = await response.json();
return {
  ticketId: data.key,
  ticketUrl: context.config.serverUrl + '/browse/' + data.key,
};
```

**Using `context.httpClient` (Advanced Mode):**

```javascript
try {
  const response = await context.httpClient.post(url, payload, { headers });
  return {
    id: response.data.id,
    url: response.data.self,
    platform: 'jira',
  };
} catch (error) {
  console.error('Failed to create Jira ticket:', error.message);
  if (error.response) {
    console.error('Response status:', error.response.status);
    console.error('Response data:', error.response.data);
  }
  throw error; // Re-throw to trigger retry logic
}
```

**Common Issues**:

- **CORS errors**: Not applicable - code runs on backend, not browser
- **401 Unauthorized**: Check credentials in project configuration
- **404 Not Found**: Verify API endpoint URL
- **400 Bad Request**: Check payload format - log it before sending

---

## Additional Resources

- **Jira REST API Documentation**: https://developer.atlassian.com/cloud/jira/platform/rest/v3/
- **BugSpotter Integration API**: See `API_DOCUMENTATION.md` → Integration Endpoints
- **Plugin System Architecture**: See `INTEGRATION_MANAGEMENT.md` → Custom Plugin Development
- **Security Best Practices**: See `SECURITY.md`

---

## Summary Checklist

Before creating your integration, ensure you have:

- [ ] Admin access to BugSpotter
- [ ] Jira instance URL
- [ ] Jira email and API token
- [ ] Jira project key
- [ ] Understanding of security restrictions

### Guided Mode Steps (Recommended):

1. [ ] Navigate to **Integrations** → **Create Integration**
2. [ ] Fill basic information (type, name, description)
3. [ ] Plugin source is automatically set to **Custom Code Plugin**
4. [ ] Click **Guided Mode (Recommended)** button
5. [ ] Fill Plugin Metadata (name, platform, version)
6. [ ] Select Authentication Type (Basic Auth, Bearer, API Key, or Custom)
7. [ ] Write Ticket Creation Logic (just the function body)
8. [ ] Optionally add Test Connection code
9. [ ] Optionally add Config Validation code
10. [ ] Check **Enable Code Execution** (checked automatically)
11. [ ] Click **Create Integration** (backend generates and validates code automatically)
12. [ ] **Configure the integration** with Jira credentials (Step 4)
    - [ ] Navigate to integration settings
    - [ ] Fill Base URL, Email, API Token, Project Key
    - [ ] Click Save Configuration
    - [ ] Test Connection
13. [ ] Link integration to a project
14. [ ] Test ticket creation
15. [ ] Monitor worker logs for any errors

### Advanced Mode Steps:

1. [ ] Navigate to **Integrations** → **Create Integration**
2. [ ] Fill basic information (type, name, description)
3. [ ] Plugin source is automatically set to **Custom Code Plugin**
4. [ ] Click **Advanced Mode** button
5. [ ] Write/paste your complete custom plugin code with `module.exports`
6. [ ] Click **Analyze Security** and review results
7. [ ] Check **Enable Code Execution** after successful analysis
8. [ ] Click **Create Integration**
9. [ ] **Configure the integration** with Jira credentials (Step 4)
   - [ ] Navigate to integration settings
   - [ ] Fill Base URL, Email, API Token, Project Key
   - [ ] Click Save Configuration
   - [ ] Test Connection
10. [ ] Link integration to a project
11. [ ] Test ticket creation
12. [ ] Monitor worker logs for any errors

---

**Need Help?**

If you encounter issues not covered in this guide:

- Check the worker logs: `docker logs bugspotter-worker`
- Review backend logs: `docker logs bugspotter-api`
- Check the integration activity logs in the admin panel
- Review the Jira API documentation for endpoint-specific errors
