# Migration 014: Enforce Unique Integration Type

**Status**: Ready for review
**Branch**: `refactor/unique-integration-type`
**Date**: 2025-12-25

## Problem

Custom integrations had a confusing dual-identifier system:

- `integrations.type` = generic `'custom_integration'` for all custom plugins
- `config.plugin_metadata.platform` = actual unique identifier (`'my-crm'`, `'my-helpdesk'`, etc.)

This caused:

1. **Outbox worker failures** - `platform='custom_integration'` couldn't be found in plugin registry
2. **Code complexity** - COALESCE logic everywhere to extract the real platform
3. **Confusion** - Two fields serving the same purpose

## Solution

**Make `integrations.type` the single source of truth for platform identifiers.**

### Architecture Change

**Before:**

```javascript
// Built-in
{ type: 'jira', ... }

// Custom (all the same!)
{ type: 'custom_integration', config: { plugin_metadata: { platform: 'my-crm' } } }
{ type: 'custom_integration', config: { plugin_metadata: { platform: 'my-helpdesk' } } }
```

**After:**

```javascript
// Built-in
{ type: 'jira', ... }

// Custom (unique types)
{ type: 'my-crm', ... }
{ type: 'my-helpdesk', ... }
```

## Changes Made

### 1. Database Migration (`014_enforce_unique_integration_type.sql`)

- Updates existing `custom_integration` records to use their `metadata.platform` as `type`
- Syncs `project_integrations.platform` to match new `integrations.type`
- Syncs `ticket_creation_outbox.platform` to match new `integrations.type`
- Adds `UNIQUE` constraint on `integrations.type`

### 2. Backend Code

**`integration.repository.ts`:**

- Simplified `getCustomPluginsPlatforms()` - no more COALESCE, just use `type`

**`admin-integrations.ts`:**

- Updated type validation regex: `[a-z0-9_-]+` (added hyphens)
- Enhanced error messages emphasizing uniqueness
- Better documentation about type being the platform identifier

### 3. Admin UI (`apps/admin/src/pages/integrations/create.tsx`)

- Changed label: "Integration Type" → "Platform Identifier (Type)"
- Updated placeholder: `jira_custom` → `my-crm`
- Updated pattern: `[a-z0-9_]+` → `[a-z0-9_-]+` (allow hyphens)
- Auto-sanitize input: strip invalid characters as user types
- Enhanced help text:
  ```
  Unique identifier for this integration (e.g., my-crm, custom-helpdesk).
  Use lowercase letters, numbers, hyphens, and underscores only.
  This cannot be changed later.
  ```

## Migration Safety

### Data Migration

The SQL migration safely handles existing data:

1. **Preserves existing integrations** - Updates `type` from metadata
2. **Updates all references** - Fixes `project_integrations` and `ticket_creation_outbox`
3. **Idempotent** - Safe to run multiple times (uses `WHERE` clauses)

### Rollback Plan

If issues arise:

```sql
-- Remove constraint
ALTER TABLE integrations DROP CONSTRAINT IF EXISTS integrations_type_unique;

-- Revert to generic type (not recommended - loses uniqueness)
UPDATE integrations
SET type = 'custom_integration'
WHERE plugin_code IS NOT NULL;
```

## Testing Checklist

- [ ] Run migration on test database
- [ ] Verify existing custom integrations updated correctly
- [ ] Create new custom integration via UI - verify type is unique
- [ ] Attempt duplicate type - verify 409 Conflict error
- [ ] Trigger automatic ticket creation - verify outbox worker finds plugin
- [ ] Check health endpoint - verify custom plugins show with correct platform

## Benefits

1. **Simpler codebase** - No more COALESCE logic scattered everywhere
2. **Better errors** - Clear "platform not found" vs "type not unique"
3. **URL-friendly** - Hyphens allowed (e.g., `my-crm` better than `my_crm`)
4. **Single source of truth** - `type` IS the platform identifier
5. **Prevents data bugs** - Database constraint enforces uniqueness

## Breaking Changes

None for existing data (migration handles it). However:

- **New integrations** must have globally unique `type` values
- **Type cannot be changed** after creation (enforced by UNIQUE constraint)

## Related Issues

Fixes: Outbox worker error "Platform 'custom_integration' not supported"
