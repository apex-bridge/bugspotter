# BugSpotter: System Workflows

**Quick Reference**: Complete end-to-end workflows for all major system operations.

---

## Table of Contents

1. [Bug Report Lifecycle](#1-bug-report-lifecycle)
2. [Authentication Flow](#2-authentication-flow)
3. [API Key Management](#3-api-key-management)
4. [Queue Job Processing](#4-queue-job-processing)
5. [Integration Plugin System](#5-integration-plugin-system)
6. [Storage Operations](#6-storage-operations)
7. [Data Retention](#7-data-retention)
8. [Admin Panel Operations](#8-admin-panel-operations)

---

## 1. Bug Report Lifecycle

### SDK → Backend → Queue → Integration

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Browser (SDK)                                                     │
│ ────────────────────────────────────────────────────────────────────│
│ User triggers bug report                                             │
│   ↓                                                                  │
│ SDK captures:                                                        │
│ • Screenshot (html-to-image, ~500ms)                                │
│ • Session replay (rrweb buffer, last 30s)                           │
│ • Console logs (last 100 entries)                                   │
│ • Network requests (Fetch/XHR intercept)                            │
│ • Browser metadata (UA, OS, viewport)                               │
│   ↓                                                                  │
│ PII Sanitization (10+ patterns, <10ms)                              │
│ • Email → [REDACTED-EMAIL]                                          │
│ • Phone → [REDACTED-PHONE]                                          │
│ • Credit Card → [REDACTED-CREDITCARD]                               │
│ • IIN/BIN → [REDACTED-IIN] (Kazakhstan)                             │
│   ↓                                                                  │
│ Transport Layer                                                      │
│ • POST /api/v1/reports                                              │
│ • Header: x-api-key: bgs_xxxxx                                      │
│ • Body: { title, description, metadata, screenshot, replay }        │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 2. Backend API (Fastify)                                             │
│ ────────────────────────────────────────────────────────────────────│
│ Auth Middleware                                                      │
│ • Validate API key (bgs_ prefix)                                    │
│ • Load project from database                                        │
│ • Attach to request.authContext                                     │
│   ↓                                                                  │
│ Route Handler: POST /api/v1/reports                                 │
│ • Validate request schema (Fastify JSON Schema)                     │
│ • Create bug_reports record                                         │
│ • Generate presigned S3 URLs (1h expiry)                            │
│ • Return: { id, screenshot_url, replay_url, status }                │
│   ↓                                                                  │
│ Audit Middleware                                                     │
│ • Log action: "bug_report_created"                                  │
│ • Record: user_id, project_id, resource_id, timestamp               │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 3. Storage Layer (S3/Local)                                          │
│ ────────────────────────────────────────────────────────────────────│
│ Screenshot Upload                                                    │
│ • PUT to presigned URL (from step 2)                                │
│ • Streaming upload (5MB chunks, 4 concurrent)                       │
│ • Path: screenshots/{project_id}/{bug_id}/original.png              │
│   ↓                                                                  │
│ Session Replay Upload                                                │
│ • PUT to presigned URL                                              │
│ • Path: replays/{project_id}/{bug_id}/metadata.json                 │
│ • Chunks: replays/{project_id}/{bug_id}/chunks/N.json.gz            │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 4. Queue System (BullMQ + Redis)                                     │
│ ────────────────────────────────────────────────────────────────────│
│ Screenshot Queue                                                     │
│ • Job: { projectId, bugReportId, screenshotKey }                    │
│ • Worker: createScreenshotWorker()                                  │
│   - Dependencies: BugReportRepository, IStorageService, Redis       │
│   - Process: Validate key, download, optimize, generate thumbnail   │
│   - Update: bug_reports.screenshot_url                              │
│   - Retry: 3 attempts with exponential backoff                      │
│   ↓                                                                  │
│ Replay Queue (Supports Both Flows)                                   │
│ • Legacy Flow: { projectId, bugReportId, replayData: events[] }     │
│   - Process: Chunk events, compress (gzip), upload to S3            │
│ • Presigned Flow: { projectId, bugReportId, replayKey }             │
│   - Process: Verify upload, download, decompress, validate          │
│ • Worker: createReplayWorker()                                      │
│   - Dependencies: BugReportRepository, IStorageService, Redis       │
│   - Update: bug_reports.replay_url (signed URL, 30-day expiry)      │
│   ↓                                                                  │
│ Integration Queue (if enabled)                                       │
│ • Job: { bugReportId, platform: 'jira', projectId }                 │
│ • Worker: createIntegrationWorker()                                 │
│   - Dependencies: PluginRegistry, BugReportRepository, Redis        │
│   - Load plugin: pluginRegistry.getService('jira')                  │
│   - Create ticket: jiraService.createFromBugReport()                │
│   - Store: tickets table (external_id, external_url)                │
│   ↓                                                                  │
│ Notification Queue (if configured)                                   │
│ • Job: { ruleId, bugId, channelIds }                                │
│ • Worker: createNotificationWorker()                                │
│   - Dependencies: DatabaseClient, IStorageService, Redis            │
│   - Load channels: email, slack, webhook                            │
│   - Send notifications with retry logic                             │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 5. External Integration (Jira/GitHub/Linear)                         │
│ ────────────────────────────────────────────────────────────────────│
│ Jira Plugin                                                          │
│ • Load encrypted credentials from project_integrations              │
│ • Decrypt with AES-256-GCM                                          │
│ • Create issue via REST API                                         │
│   POST /rest/api/2/issue                                            │
│   {                                                                  │
│     "fields": {                                                      │
│       "project": { "key": "PROJ" },                                 │
│       "summary": bug.title,                                         │
│       "description": { "type": "doc", ... }, // ADF format          │
│       "priority": { "name": "High" },                               │
│       "issuetype": { "name": "Bug" }                                │
│     }                                                                │
│   }                                                                  │
│ • Attach screenshot if present                                      │
│ • Store: tickets.external_id = PROJ-123                             │
│         tickets.external_url = https://jira.com/browse/PROJ-123     │
└──────────────────────────────────────────────────────────────────────┘
```

### Timeline

1. **SDK Capture**: 500-1000ms (screenshot + metadata collection)
2. **API Creation**: 50-200ms (database insert + presigned URL generation)
3. **Upload**: 300-1000ms (S3 streaming upload, depends on file size)
4. **Queue Processing**: 2-10s (screenshot optimization + replay chunking)
5. **Integration**: 1-5s (external API call, depends on platform)

**Total**: ~4-17 seconds from user trigger to external ticket creation

---

## 2. Authentication Flow

### JWT + httpOnly Cookies (Admin Panel)

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Initial Login                                                     │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/auth/login                                              │
│ Body: { email, password }                                            │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Validate credentials (bcrypt.compare)                             │
│ • Generate tokens:                                                   │
│   - Access token: JWT (1h expiry, payload: { userId, email, role }) │
│   - Refresh token: JWT (7d expiry, payload: { userId, type })       │
│ • Set httpOnly cookie:                                              │
│   Set-Cookie: refresh_token=xxx; HttpOnly; Secure; SameSite=Strict  │
│ • Return: { accessToken, user: { id, email, role } }                │
│   ↓                                                                  │
│ Frontend (React):                                                    │
│ • Store accessToken in memory (React state)                         │
│ • Refresh token stored in browser cookie (JS-inaccessible)          │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 2. Authenticated Requests                                            │
│ ────────────────────────────────────────────────────────────────────│
│ GET /api/v1/projects                                                 │
│ Header: Authorization: Bearer {accessToken}                          │
│   ↓                                                                  │
│ Backend Auth Middleware:                                             │
│ • Extract Bearer token                                               │
│ • Verify JWT signature (secret key)                                 │
│ • Check expiry                                                       │
│ • Attach user to request.authUser                                   │
│   ↓                                                                  │
│ Route Handler:                                                       │
│ • Access request.authUser.id, .email, .role                         │
│ • Apply RBAC checks (isAdmin, checkProjectAccess)                   │
│ • Return resource                                                    │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 3. Token Refresh (before expiry)                                     │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/auth/refresh                                            │
│ Cookie: refresh_token=xxx (sent automatically)                       │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Extract refresh token from cookie                                 │
│ • Verify JWT signature and expiry                                   │
│ • Generate new access token (1h)                                    │
│ • Rotate refresh token (new 7d token)                               │
│ • Set new httpOnly cookie                                           │
│ • Return: { accessToken }                                           │
│   ↓                                                                  │
│ Frontend:                                                            │
│ • Update in-memory accessToken                                      │
│ • Axios interceptor handles 401 → auto-refresh                      │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 4. Logout                                                            │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/auth/logout                                             │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Clear httpOnly cookie: Set-Cookie: refresh_token=; Max-Age=0      │
│   ↓                                                                  │
│ Frontend:                                                            │
│ • Clear in-memory accessToken                                       │
│ • Redirect to /login                                                 │
└──────────────────────────────────────────────────────────────────────┘
```

### API Key Authentication (SDK)

```
┌──────────────────────────────────────────────────────────────────────┐
│ SDK Request                                                          │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/reports                                                 │
│ Header: x-api-key: bgs_xxxxx                                         │
│   ↓                                                                  │
│ Backend Auth Middleware:                                             │
│ • Extract x-api-key header                                          │
│ • Validate prefix (bgs_)                                            │
│ • Query: api_keys table (hash lookup)                               │
│ • Check: enabled=true, permissions=['bug_reports:create']           │
│ • Validate: allowed_projects includes target project                │
│ • Attach: request.authContext.apiKey, .project                      │
│   ↓                                                                  │
│ Route Handler:                                                       │
│ • Access request.authContext.project.id                             │
│ • Create bug report linked to project                               │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 3. API Key Management

### Creation (Admin Only)

```
┌──────────────────────────────────────────────────────────────────────┐
│ POST /api/v1/api-keys                                                │
│ Header: Authorization: Bearer {adminAccessToken}                     │
│ Body: {                                                              │
│   type: 'production',                                                │
│   name: 'Production SDK Key',                                        │
│   permission_scope: 'custom',                                        │
│   permissions: ['bug_reports:create', 'bug_reports:read'],           │
│   allowed_projects: ['uuid1', 'uuid2'],                              │
│   rate_limit_per_minute: 100,                                        │
│   rate_limit_per_hour: 5000,                                         │
│   rate_limit_per_day: 50000,                                         │
│   burst_limit: 20,                                                   │
│   expires_at: '2026-01-01T00:00:00Z'                                 │
│ }                                                                     │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Verify isAdmin(request) → 403 if not admin                        │
│ • Generate key: bgs_ + 32 random bytes (base64url)                  │
│ • Hash key: SHA-256 (fast lookup for high-entropy keys)             │
│ • Store:                                                             │
│   - id: UUID                                                         │
│   - key_hash: SHA-256 hash                                          │
│   - key_prefix: first 8 chars (bgs_xxxx)                            │
│   - type: production|development|test                                │
│   - name: user-provided                                              │
│   - permissions: JSON array                                          │
│   - allowed_projects: UUID array                                     │
│   - created_by: admin user ID                                        │
│   - last_used_at: null                                               │
│ • Return: { api_key: 'bgs_xxxxx', key_details: { id, name, ... } }  │
│   ⚠️  API key shown ONCE - user must save it                        │
└──────────────────────────────────────────────────────────────────────┘
```

### Usage Tracking

```
┌──────────────────────────────────────────────────────────────────────┐
│ Every API Request with API Key                                       │
│   ↓                                                                  │
│ UPDATE api_keys                                                      │
│ SET last_used_at = NOW()                                             │
│ WHERE id = {key_id}                                                  │
│   ↓                                                                  │
│ Admin can view:                                                      │
│ • Last used timestamp                                                │
│ • Usage frequency                                                    │
│ • Identify unused keys                                               │
└──────────────────────────────────────────────────────────────────────┘
```

### Rotation

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Create new key (same permissions)                                 │
│ 2. Deploy new key to production                                     │
│ 3. Verify traffic using new key                                     │
│ 4. DELETE /api/v1/api-keys/{old_key_id}                             │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 4. Queue Job Processing

### Worker Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│ WorkerManager (Singleton)                                            │
│ ────────────────────────────────────────────────────────────────────│
│ Dependencies:                                                        │
│ • DatabaseClient (db)                                                │
│ • IStorageService (storage)                                         │
│ • PluginRegistry (pluginRegistry, optional)                         │
│   ↓                                                                  │
│ Worker Registry (Discriminated Union)                                │
│ ┌────────────────────────────────────────────────────────────────┐  │
│ │ Screenshot Worker                                              │  │
│ │ • Type: WORKER_DEPENDENCY_TYPE.REPOSITORY                      │  │
│ │ • Factory: (BugReportRepository, IStorageService, Redis)       │  │
│ │ • Queue: 'screenshots'                                         │  │
│ │ • Concurrency: 5                                               │  │
│ │ • Purpose: Processes screenshot uploads from bug reports       │  │
│ │   - Validates screenshot storage keys                          │  │
│ │   - Downloads original image from S3                           │  │
│ │   - Optimizes image (compression, format conversion)           │  │
│ │   - Generates thumbnail (320x240 by default)                   │  │
│ │   - Uploads optimized versions back to S3                      │  │
│ │   - Updates bug_reports.screenshot_url with signed URLs        │  │
│ │ • Processing Time: 2-5 seconds per screenshot                  │  │
│ │ • Retry Strategy: 3 attempts with exponential backoff          │  │
│ └────────────────────────────────────────────────────────────────┘  │
│ ┌────────────────────────────────────────────────────────────────┐  │
│ │ Replay Worker                                                  │  │
│ │ • Type: WORKER_DEPENDENCY_TYPE.REPOSITORY                      │  │
│ │ • Factory: (BugReportRepository, IStorageService, Redis)       │  │
│ │ • Queue: 'replays'                                             │  │
│ │ • Concurrency: 3                                               │  │
│ │ • Purpose: Processes session replay data from rrweb            │  │
│ │   - Validates replay storage keys (presigned upload flow)      │  │
│ │   - Downloads compressed replay data from S3                   │  │
│ │   - Decompresses and validates rrweb event format              │  │
│ │   - Chunks events by time duration (30s default)               │  │
│ │   - Compresses chunks with gzip                                │  │
│ │   - Uploads chunks and metadata to S3                          │  │
│ │   - Updates bug_reports.replay_url with signed URLs (30d)      │  │
│ │ • Processing Time: 5-10 seconds per replay                     │  │
│ │ • Max Replay Size: 100MB (configurable)                        │  │
│ └────────────────────────────────────────────────────────────────┘  │
│ ┌────────────────────────────────────────────────────────────────┐  │
│ │ Notification Worker                                            │  │
│ │ • Type: WORKER_DEPENDENCY_TYPE.DATABASE                        │  │
│ │ • Factory: (DatabaseClient, IStorageService, Redis)            │  │
│ │ • Queue: 'notifications'                                       │  │
│ │ • Concurrency: 5                                               │  │
│ │ • Purpose: Sends notifications when bug reports match rules    │  │
│ │   - Loads notification rules from database                     │  │
│ │   - Evaluates rule conditions (status, priority, etc.)         │  │
│ │   - Fetches notification channels (email, Slack, webhook)      │  │
│ │   - Formats message with bug report context                    │  │
│ │   - Delivers to all configured channels                        │  │
│ │   - Tracks delivery success/failure rates                      │  │
│ │   - Retries failed deliveries with backoff                     │  │
│ │ • Processing Time: 1-3 seconds per notification                │  │
│ │ • Channels: Email (SMTP), Slack (Webhooks), Custom Webhooks    │  │
│ └────────────────────────────────────────────────────────────────┘  │
│ ┌────────────────────────────────────────────────────────────────┐  │
│ │ Integration Worker                                             │  │
│ │ • Type: WORKER_DEPENDENCY_TYPE.INTEGRATION                     │  │
│ │ • Factory: (PluginRegistry, BugReportRepository, Redis)        │  │
│ │ • Queue: 'integrations'                                        │  │
│ │ • Concurrency: 10                                              │  │
│ │ • Purpose: Creates tickets on external platforms (Jira, etc.)  │  │
│ │   - Loads integration config from project_integrations         │  │
│ │   - Decrypts credentials (AES-256-GCM)                         │  │
│ │   - Gets plugin from registry (Jira, GitHub, Linear, etc.)     │  │
│ │   - Calls plugin.createFromBugReport()                         │  │
│ │   - Creates external ticket via platform API                   │  │
│ │   - Attaches screenshots if present                            │  │
│ │   - Stores ticket reference in tickets table                   │  │
│ │   - Links external_id and external_url to bug report           │  │
│ │ • Processing Time: 1-5 seconds (depends on platform API)       │  │
│ │ • Supported Platforms: Jira, GitHub (via custom plugins)       │  │
│ └────────────────────────────────────────────────────────────────┘  │
│ ┌────────────────────────────────────────────────────────────────┐  │
│ │ Outbox Worker                                                  │  │
│ │ • Type: WORKER_DEPENDENCY_TYPE.OUTBOX                          │  │
│ │ • Factory: (DatabaseClient, PluginRegistry, Redis)             │  │
│ │ • Queue: 'outbox'                                              │  │
│ │ • Concurrency: 2                                               │  │
│ │ • Purpose: Processes transactional outbox for reliable tickets │  │
│ │   - Polls ticket_creation_outbox table every 10 seconds        │  │
│ │   - Finds pending entries (status: 'pending')                  │  │
│ │   - Enqueues Bull jobs for each pending entry                  │  │
│ │   - Marks entry as 'processing' (prevents duplicates)          │  │
│ │   - Calls integration service to create external ticket        │  │
│ │   - Marks entry as 'completed' with external ticket details    │  │
│ │   - Handles failures with exponential backoff (max 3 retries)  │  │
│ │   - Moves exhausted retries to dead letter queue               │  │
│ │ • Processing Time: 1-5 seconds per outbox entry                │  │
│ │ • Pattern: Transactional Outbox (guarantees ticket creation)   │  │
│ │ • Benefits: No orphaned tickets, automatic retries, idempotent │  │
│ └────────────────────────────────────────────────────────────────┘  │
│   ↓                                                                  │
│ Worker Instantiation (Type-Safe)                                     │
│ switch (workerConfig.type) {                                         │
│   case WORKER_DEPENDENCY_TYPE.REPOSITORY:                            │
│     return factory(db.bugReports, storage, connection);              │
│   case WORKER_DEPENDENCY_TYPE.DATABASE:                              │
│     return factory(db, storage, connection);                         │
│   case WORKER_DEPENDENCY_TYPE.INTEGRATION:                           │
│     return factory(pluginRegistry, db.bugReports, connection);       │
│   case WORKER_DEPENDENCY_TYPE.OUTBOX:                                │
│     return factory(db, pluginRegistry, connection);                  │
│ }                                                                     │
└──────────────────────────────────────────────────────────────────────┘
```

### Job Lifecycle

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Job Creation                                                      │
│ ────────────────────────────────────────────────────────────────────│
│ queueManager.addJob('screenshots', {                                 │
│   projectId: 'uuid',                                                 │
│   bugReportId: 'uuid',                                               │
│   screenshotKey: 'screenshots/proj/bug/original.png'                 │
│ }, {                                                                  │
│   attempts: 3,                                                       │
│   backoff: { type: 'exponential', delay: 1000 }                     │
│ })                                                                    │
│   ↓                                                                  │
│ BullMQ → Redis:                                                      │
│ • LPUSH queue:screenshots { jobData, options }                      │
│ • SET job:123 { state: 'waiting', ... }                             │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 2. Worker Processing                                                 │
│ ────────────────────────────────────────────────────────────────────│
│ Worker polls Redis (BRPOP queue:screenshots)                         │
│   ↓                                                                  │
│ State: waiting → active                                              │
│   ↓                                                                  │
│ Execute processFn(job):                                              │
│ • Validate screenshot key                                            │
│ • Download from S3                                                   │
│ • Optimize image (sharp library)                                     │
│ • Generate thumbnail                                                 │
│ • Upload optimized versions                                          │
│ • Update bug_reports.screenshot_url                                  │
│   ↓                                                                  │
│ State: active → completed (or failed)                                │
│   ↓                                                                  │
│ Event Emission:                                                      │
│ • worker.on('completed', (job) => ...)                              │
│ • Update metrics: jobsProcessed++, lastProcessedAt                   │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 3. Retry on Failure                                                  │
│ ────────────────────────────────────────────────────────────────────│
│ If job throws error:                                                 │
│ • Attempt 1 fails → retry after 1s (exponential backoff)            │
│ • Attempt 2 fails → retry after 2s                                  │
│ • Attempt 3 fails → move to failed queue                            │
│   ↓                                                                  │
│ worker.on('failed', (job, error) => ...)                            │
│ • Log error details                                                  │
│ • Update metrics: jobsFailed++, lastError                            │
│ • Alert admin (if configured)                                        │
└──────────────────────────────────────────────────────────────────────┘
```

### Health Monitoring

```
GET /api/v1/queues/health
Response: {
  healthy: true,
  workers: {
    screenshots: true,
    replays: true,
    integrations: true,
    notifications: true,
    outbox: true
  }
}

GET /api/v1/queues/metrics
Response: {
  totalWorkers: 5,
  runningWorkers: 5,
  totalJobsProcessed: 15234,
  totalJobsFailed: 12,
  workers: [
    {
      workerName: 'screenshots',
      isRunning: true,
      jobsProcessed: 8421,
      jobsFailed: 5,
      avgProcessingTimeMs: 1523,
      lastProcessedAt: '2025-10-28T10:30:00Z'
    },
    {
      workerName: 'replays',
      isRunning: true,
      jobsProcessed: 4231,
      jobsFailed: 3,
      avgProcessingTimeMs: 6842,
      lastProcessedAt: '2025-10-28T10:29:45Z'
    },
    {
      workerName: 'integrations',
      isRunning: true,
      jobsProcessed: 1823,
      jobsFailed: 2,
      avgProcessingTimeMs: 2341,
      lastProcessedAt: '2025-10-28T10:28:30Z'
    },
    {
      workerName: 'notifications',
      isRunning: true,
      jobsProcessed: 634,
      jobsFailed: 1,
      avgProcessingTimeMs: 891,
      lastProcessedAt: '2025-10-28T10:27:15Z'
    },
    {
      workerName: 'outbox',
      isRunning: true,
      jobsProcessed: 125,
      jobsFailed: 1,
      avgProcessingTimeMs: 2154,
      lastProcessedAt: '2025-10-28T10:26:00Z'
    }
  ],
  uptime: 86400000
}
```

---

## 5. Integration Plugin System

### Plugin Discovery & Registration

```
┌──────────────────────────────────────────────────────────────────────┐
│ Server Startup                                                       │
│ ────────────────────────────────────────────────────────────────────│
│ PluginRegistry.loadPlugins()                                         │
│   ↓                                                                  │
│ 1. Scan directory: /integrations/*/plugin.ts                         │
│   ↓                                                                  │
│ 2. For each plugin file:                                             │
│    • Import module                                                   │
│    • Validate exports (default export = IntegrationPlugin)           │
│    • Check metadata (name, platform, version, requiredEnvVars)       │
│    • Call lifecycle.validate() if present                            │
│    • Register in plugins Map                                         │
│    • Call lifecycle.onLoad(context) if present                       │
│   ↓                                                                  │
│ 3. Log results:                                                      │
│    "Registered integration plugin: Jira Integration v1.0.0"          │
│    "Plugin loading complete: 1 successful, 0 failed"                 │
└──────────────────────────────────────────────────────────────────────┘
```

### Jira Plugin Workflow

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Configuration (Admin Panel)                                       │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/integrations/jira/{projectId}                           │
│ Body: {                                                              │
│   host: 'company.atlassian.net',                                     │
│   email: 'bot@company.com',                                          │
│   apiToken: 'ATATT3xFfGF...',                                        │
│   projectKey: 'PROJ',                                                │
│   issueType: 'Bug',                                                  │
│   priority: 'High'                                                   │
│ }                                                                     │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Encrypt credentials (AES-256-GCM)                                  │
│ • Store in integrations table:                                       │
│   {                                                                  │
│     project_id: uuid,                                                │
│     type: 'jira',                                                    │
│     enabled: true,                                                   │
│     config: { host, email, projectKey, issueType, priority },       │
│     encrypted_credentials: 'iv.salt.authTag.ciphertext'              │
│   }                                                                  │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 2. Create Ticket (Manual or Automated)                               │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/integrations/jira/{projectId}/tickets                   │
│ Body: { bug_report_id: 'uuid' }                                      │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Load config from project_integrations                              │
│ • Decrypt credentials                                                │
│ • Get plugin: pluginRegistry.getService('jira')                      │
│ • Call: jiraService.createFromBugReport(bugReport, projectId)        │
│   ↓                                                                  │
│ Jira Plugin:                                                         │
│ • Build ADF payload (Atlassian Document Format)                      │
│ • Map priority: critical → Highest, high → High, ...                │
│ • POST /rest/api/2/issue                                             │
│ • Attach screenshot if present                                       │
│ • Parse response: { id: '10123', key: 'PROJ-45', self: 'url' }      │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Create tickets record:                                             │
│   {                                                                  │
│     bug_report_id: uuid,                                             │
│     external_platform: 'jira',                                       │
│     external_id: 'PROJ-45',                                          │
│     external_url: 'https://company.atlassian.net/browse/PROJ-45',   │
│     status: 'open'                                                   │
│   }                                                                  │
│ • Return: { ticket_id, external_id, external_url }                   │
└──────────────────────────────────────────────────────────────────────┘
```

### Adding New Plugin

```
1. Create plugin directory:
   /integrations/{platform}/

2. Implement service:
   {platform}-service.ts
   • Implement IntegrationService interface
   • createFromBugReport(), testConnection()

3. Create plugin file:
   plugin.ts
   export default {
     metadata: {
       name: 'GitHub Integration',
       platform: 'github',
       version: '1.0.0',
       description: 'Create GitHub issues from bug reports',
       author: 'ApexBridge',
       requiredEnvVars: ['GITHUB_APP_ID']
     },
     factory: (context) => new GitHubService(context.db),
     lifecycle: {
       async onLoad(context) {
         console.log('GitHub plugin loaded');
       },
       async validate() {
         // Check env vars, validate config
       }
     }
   };

4. Auto-discovery:
   • PluginRegistry scans /integrations/*/plugin.ts
   • Registers on startup
   • No changes to core code required!
```

---

## 6. Storage Operations

### Presigned URL Upload Flow

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. Request Presigned URL                                             │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/uploads/presigned                                       │
│ Body: {                                                              │
│   resource_type: 'screenshot',                                       │
│   filename: 'bug-screenshot.png',                                    │
│   content_type: 'image/png',                                         │
│   project_id: 'uuid',                                                │
│   bug_report_id: 'uuid'                                              │
│ }                                                                     │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Validate resource_type (whitelist)                                 │
│ • Validate IDs (UUID format + path traversal check)                 │
│ • Sanitize filename (basename, control chars, extensions)            │
│ • Build storage key:                                                 │
│   screenshots/{project_id}/{bug_id}/sanitized-filename.png           │
│ • Generate presigned URL (S3 SDK, 1h expiry)                        │
│ • Return: {                                                          │
│     upload_url: 'https://s3.../presigned-url',                      │
│     storage_key: 'screenshots/...',                                  │
│     expires_at: '2025-10-28T11:30:00Z'                              │
│   }                                                                  │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 2. Direct Upload (Client → S3)                                       │
│ ────────────────────────────────────────────────────────────────────│
│ PUT {upload_url}                                                     │
│ Headers:                                                             │
│   Content-Type: image/png                                            │
│   Content-Length: 524288                                             │
│ Body: <binary data>                                                  │
│   ↓                                                                  │
│ S3:                                                                  │
│ • Validate presigned signature                                       │
│ • Check expiry (<1h)                                                │
│ • Stream upload (5MB chunks, 4 concurrent)                           │
│ • Store at key: screenshots/{project_id}/{bug_id}/filename.png       │
│ • Return: 200 OK                                                     │
└──────────────────────────────────────────────────────────────────────┘
                                 ↓
┌──────────────────────────────────────────────────────────────────────┐
│ 3. Confirm Upload                                                    │
│ ────────────────────────────────────────────────────────────────────│
│ PATCH /api/v1/reports/{bug_id}                                       │
│ Body: { screenshot_url: 'screenshots/proj/bug/file.png' }            │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Validate storage key exists in S3                                  │
│ • Update bug_reports.screenshot_url                                  │
│ • Enqueue screenshot processing job                                  │
└──────────────────────────────────────────────────────────────────────┘
```

### Storage Security (Defense in Depth)

```
Layer 1: Whitelist Validation
  ✓ resource_type ∈ ['screenshots', 'replays', 'attachments']

Layer 2: ID Validation
  ✓ UUID format: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
  ✓ No path traversal: reject if contains '..'

Layer 3: Filename Sanitization
  ✓ Extract basename: path.basename(filename)
  ✓ Remove control chars: /[\x00-\x1F\x7F]/g
  ✓ Decode safely: decodeURIComponent with error handling
  ✓ Truncate: max 255 chars with extension preservation
  ✓ Handle reserved names: Windows (CON, PRN, AUX, ...)

Layer 4: Final Key Sanitization
  ✓ Remove unsafe chars: /[^a-zA-Z0-9/_.-]/g
  ✓ Normalize slashes: replace // with /
  ✓ Remove leading/trailing slashes
```

---

## 7. Data Retention

### Retention Policy Execution

```
┌──────────────────────────────────────────────────────────────────────┐
│ Daily Cron Job (2 AM UTC)                                            │
│ ────────────────────────────────────────────────────────────────────│
│ RetentionScheduler.run()                                             │
│   ↓                                                                  │
│ For each project:                                                    │
│   ↓                                                                  │
│   Load retention_policies:                                           │
│   • type: 'time-based' | 'count-based' | 'archive'                  │
│   • config: { days: 90 } | { count: 10000 } | { archive: 180, ... } │
│   ↓                                                                  │
│   RetentionService.applyPolicy(projectId, policy)                    │
│     ↓                                                                │
│     Time-Based Strategy:                                             │
│     • SELECT id FROM bug_reports                                     │
│       WHERE project_id = $1                                          │
│         AND deleted_at IS NULL                                       │
│         AND legal_hold = false                                       │
│         AND created_at < NOW() - INTERVAL '90 days'                 │
│     • UPDATE bug_reports SET deleted_at = NOW()                      │
│       WHERE id = ANY($1)                                             │
│     • Log: "Marked 42 reports for deletion (project: uuid)"          │
│     ↓                                                                │
│     Count-Based Strategy:                                            │
│     • SELECT id FROM bug_reports                                     │
│       WHERE project_id = $1                                          │
│         AND deleted_at IS NULL                                       │
│         AND legal_hold = false                                       │
│       ORDER BY created_at DESC                                       │
│       OFFSET 10000                                                   │
│     • UPDATE bug_reports SET deleted_at = NOW()                      │
│     ↓                                                                │
│     Archive Strategy:                                                │
│     • Archive at 180 days (move to cold storage)                    │
│     • Delete at 365 days (permanent)                                 │
│   ↓                                                                  │
│   Permanent Deletion (after 30-day soft delete window):              │
│   • SELECT id FROM bug_reports                                       │
│     WHERE deleted_at < NOW() - INTERVAL '30 days'                   │
│   • DELETE FROM sessions WHERE bug_report_id = ANY($1)               │
│   • DELETE FROM tickets WHERE bug_report_id = ANY($1)                │
│   • DELETE FROM bug_reports WHERE id = ANY($1)                       │
│   • Delete S3 objects:                                               │
│     - screenshots/{project_id}/{bug_id}/*                            │
│     - replays/{project_id}/{bug_id}/*                                │
└──────────────────────────────────────────────────────────────────────┘
```

### Legal Hold Protection

```
┌──────────────────────────────────────────────────────────────────────┐
│ Set Legal Hold (Admin Only)                                          │
│ ────────────────────────────────────────────────────────────────────│
│ PATCH /api/v1/retention/legal-hold                                   │
│ Body: { report_ids: ['uuid1', 'uuid2'], hold: true }                │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Verify admin role                                                  │
│ • UPDATE bug_reports                                                 │
│   SET legal_hold = true                                              │
│   WHERE id = ANY($1)                                                 │
│ • Create audit log:                                                  │
│   action: 'legal_hold_applied'                                       │
│   user_id: admin.id                                                  │
│   resource_ids: ['uuid1', 'uuid2']                                   │
│   ↓                                                                  │
│ Effect:                                                              │
│ • Retention policies SKIP reports with legal_hold = true            │
│ • Reports remain until hold is manually released                     │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 8. Admin Panel Operations

### System Setup (First-Time)

```
┌──────────────────────────────────────────────────────────────────────┐
│ GET /api/v1/setup/status                                             │
│ Response: { initialized: false }                                     │
│   ↓                                                                  │
│ POST /api/v1/setup/initialize                                        │
│ Body: {                                                              │
│   admin: {                                                           │
│     email: 'admin@company.com',                                     │
│     password: 'secure-password',                                     │
│     name: 'Admin User'                                               │
│   },                                                                 │
│   project: {                                                         │
│     name: 'My First Project'                                         │
│   }                                                                   │
│ }                                                                     │
│   ↓                                                                  │
│ Backend (Transaction):                                               │
│ 1. Create admin user (role: 'admin', bcrypt password)               │
│ 2. Create default project                                           │
│ 3. Create project membership (admin → project, role: 'owner')       │
│ 4. Store system config (initialized: true)                          │
│   ↓                                                                  │
│ Response: {                                                          │
│   success: true,                                                     │
│   user: { id, email, role: 'admin' },                               │
│   project: { id, name },                                            │
│   access_token: 'jwt...',                                            │
│   // refresh_token set in httpOnly cookie                           │
│ }                                                                     │
│   ↓                                                                  │
│ Frontend:                                                            │
│ • Store accessToken in memory                                       │
│ • Redirect to /projects                                              │
└──────────────────────────────────────────────────────────────────────┘
```

### Project Management

```
┌──────────────────────────────────────────────────────────────────────┐
│ Create Project                                                       │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/projects                                                │
│ Body: { name: 'Mobile App' }                                         │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Create project record                                             │
│ • Create project membership (creator → owner)                       │
│ • Return: { id, name, created_at }                                  │
│                                                                       │
│ Note: API keys are created separately via POST /api/v1/api-keys     │
│ (admin-only endpoint, see section 3: API Key Management)            │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│ Invite User to Project                                               │
│ ────────────────────────────────────────────────────────────────────│
│ POST /api/v1/projects/{id}/members                                   │
│ Body: { user_id: 'uuid', role: 'developer' }                        │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Verify requester is project admin/owner                           │
│ • Create project_members record                                     │
│ • User can now access project resources                             │
└──────────────────────────────────────────────────────────────────────┘
```

### Bug Report Management

```
┌──────────────────────────────────────────────────────────────────────┐
│ List Bug Reports (with Filters)                                      │
│ ────────────────────────────────────────────────────────────────────│
│ GET /api/v1/reports?                                                 │
│   project_id=uuid                                                    │
│   &status=open                                                       │
│   &priority=high,critical                                            │
│   &created_after=2025-01-01                                          │
│   &page=1                                                            │
│   &limit=50                                                          │
│   &sort_by=created_at                                                │
│   &sort_order=desc                                                   │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Build WHERE clause with parameterized queries                      │
│ • Execute: SELECT * FROM bug_reports                                 │
│           WHERE project_id = $1                                      │
│             AND status = $2                                          │
│             AND priority = ANY($3)                                   │
│             AND created_at >= $4::timestamptz                        │
│           ORDER BY created_at DESC                                   │
│           LIMIT $5 OFFSET $6                                         │
│ • Return: {                                                          │
│     data: [...bug reports...],                                       │
│     pagination: {                                                    │
│       page: 1,                                                       │
│       limit: 50,                                                     │
│       total: 342,                                                    │
│       pages: 7                                                       │
│     }                                                                │
│   }                                                                  │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│ Update Bug Report Status                                             │
│ ────────────────────────────────────────────────────────────────────│
│ PATCH /api/v1/reports/{id}                                           │
│ Body: { status: 'resolved' }                                         │
│   ↓                                                                  │
│ Backend:                                                             │
│ • Verify project access                                              │
│ • UPDATE bug_reports SET status = $1 WHERE id = $2                  │
│ • Create audit log: "bug_report_updated"                            │
│ • Return updated report                                              │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Performance Benchmarks

### API Response Times (p95)

- **Bug Report Creation**: <200ms
- **List Reports (50 items)**: <100ms
- **Screenshot Upload (1MB)**: <500ms
- **Session Replay Upload (500KB)**: <300ms
- **Token Refresh**: <50ms

### Queue Throughput

- **Job Insertion**: 2,500 jobs/s
- **Screenshot Processing**: 1-3s per job
- **Replay Processing**: 2-5s per job
- **Concurrent Operations**: 100+ ops in <5s

### Memory Usage

- **Backend Baseline**: ~100MB
- **Backend Under Load**: ~150MB
- **SDK Runtime**: ~5MB
- **Streaming Uploads**: Constant 5MB (not linear)

---

## Security Checklist

- ✅ **SQL Injection**: Parameterized queries + identifier validation
- ✅ **Path Traversal**: Multi-layer filename/key sanitization
- ✅ **XSS**: httpOnly cookies + CSP headers
- ✅ **CSRF**: SameSite=Strict cookies
- ✅ **Rate Limiting**: 100 req/15min per IP
- ✅ **Encryption**: AES-256-GCM for credentials, bcrypt for passwords
- ✅ **RBAC**: Admin/Viewer/Owner roles with resource checks
- ✅ **IDOR**: Project access validation on all routes
- ✅ **Memory Safety**: Streaming uploads, no buffer accumulation

---

**Last Updated**: October 28, 2025  
**Version**: 0.3.0  
**Author**: ApexBridge Technologies
