# BugSpotter Integration Management Guide

**Version**: 1.0.0  
**Last Updated**: December 1, 2025

## Table of Contents

1. [Overview](#overview)
2. [Integration Architecture](#integration-architecture)
3. [User Integration Management](#user-integration-management)
4. [Admin Integration Management](#admin-integration-management)
5. [Security Considerations](#security-considerations)
6. [Custom Plugin Development](#custom-plugin-development)
7. [Webhook Configuration](#webhook-configuration)
8. [Monitoring & Troubleshooting](#monitoring--troubleshooting)
9. [Best Practices](#best-practices)

---

## Overview

BugSpotter provides a flexible integration system that allows you to connect bug reports with external issue tracking platforms like Jira, GitHub Issues, Linear, and custom internal systems. The integration system supports:

- **Built-in Integrations**: Pre-configured integrations for popular platforms (Jira, GitHub, etc.)
- **Custom Integrations**: Admin-created integrations for proprietary or niche platforms
- **Plugin System**: Code-based plugins for advanced customization (✅ enabled with secure RPC bridge)
- **Webhooks**: Bidirectional communication with external systems
- **Activity Logging**: Complete audit trail of all integration actions

### Integration Roles

**Users** can:

- Configure project-specific integrations
- Test integration connections
- Enable/disable integrations for their projects
- Create integration rules with auto-create or manual triggers

**Admins** can:

- Create new integration types
- Manage global integration configurations
- Analyze and deploy custom plugin code
- Configure webhooks
- Monitor integration activity logs

### Integration Rule Behavior

BugSpotter supports two types of ticket creation:

**1. Automatic (Rule-Based) Ticket Creation:**

- **When enabled**: Create integration rules with `auto_create = true`
- **Behavior**: Only matching bug reports create tickets automatically
- **Use case**: Selective ticket creation for critical errors, specific pages, or user segments

**2. Manual (Fallback) Ticket Creation:**

- **When triggered**: If NO auto-create rules match AND NO manual rules exist
- **Behavior**: ALL bug reports create tickets (backward compatibility mode)
- **Use case**: Simple integrations where every bug should create a ticket

**⚠️ Important**: If you have auto-create rules but they don't match a bug report, AND you have no manual (non-auto-create) rules configured, the system falls back to manual mode and creates a ticket anyway.

**To enforce strict rule-based filtering**:

1. Create at least one manual rule with a filter (e.g., `status = open`)
2. This prevents fallback to "create all tickets" mode
3. Only bugs matching your auto-create OR manual rules will create tickets

**Example Scenarios:**

```
Scenario 1: Only auto-create rules exist
- Rules: 3 auto-create rules with filters
- Bug matches Rule 1 → ✅ Ticket created
- Bug matches no rules → ✅ Ticket still created (fallback mode)

Scenario 2: Auto-create + manual rules exist
- Rules: 3 auto-create + 1 manual rule
- Bug matches auto-create Rule 1 → ✅ Ticket created via Rule 1
- Bug matches no auto-create rules → Check manual rules
  - Matches manual rule → ✅ Ticket created manually
  - Matches no rules → ❌ No ticket created

Scenario 3: No rules exist
- Rules: None configured
- Any bug → ✅ Ticket created (full backward compatibility)
```

---

## Integration Architecture

### Components

```
┌─────────────────────────────────────────────────────────────┐
│                    BugSpotter API                           │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Plugin Registry                          │  │
│  │  - Loads integration plugins dynamically              │  │
│  │  - Manages plugin lifecycle                           │  │
│  │  - Provides unified interface                         │  │
│  └───────────────────────────────────────────────────────┘  │
│                           │                                  │
│  ┌────────────┬──────────┴──────────┬───────────────────┐  │
│  │ Built-in   │  Generic HTTP       │  Custom Plugins   │  │
│  │ Plugins    │  Plugin             │  (Sandboxed)      │  │
│  │ (Jira,     │  (REST APIs)        │  (✅ Enabled)     │  │
│  │  GitHub)   │                     │                   │  │
│  └────────────┴─────────────────────┴───────────────────┘  │
│                           │                                  │
│  ┌───────────────────────┴────────────────────────────┐    │
│  │          Integration Worker Queue                  │    │
│  │  - Processes bug report creation events            │    │
│  │  - Handles webhook deliveries                      │    │
│  │  - Manages retry logic                             │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
        ┌──────────────────────────────────────┐
        │     External Platform (Jira, etc.)   │
        └──────────────────────────────────────┘
```

### Data Flow

1. **Bug Report Created** → Triggers notification system
2. **Notification Worker** → Checks for active integrations
3. **Integration Queue** → Processes integration job
4. **Plugin Execution** → Creates ticket in external platform
5. **Activity Logging** → Records success/failure
6. **Bug Report Update** → Stores external ticket reference

---

## User Integration Management

### Setting Up a Project Integration

**1. List Available Integrations**

```bash
curl -X GET 'https://api.bugspotter.com/api/v1/integrations/platforms' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN'
```

**2. Test Connection**

Before saving credentials, test the connection:

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/integrations/jira/test' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "url": "https://company.atlassian.net",
    "username": "api-user@company.com",
    "api_token": "ATATT3xFfGF0...",
    "project_key": "BUGS"
  }'
```

**3. Save Configuration**

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/integrations/jira/PROJECT_ID' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "config": {
      "url": "https://company.atlassian.net",
      "project_key": "BUGS"
    },
    "credentials": {
      "username": "api-user@company.com",
      "api_token": "ATATT3xFfGF0..."
    },
    "enabled": true
  }'
```

**Security**: Credentials are encrypted using AES-256-GCM before storage.

### Managing Integrations

**Get Current Configuration**:

```bash
curl -X GET 'https://api.bugspotter.com/api/v1/integrations/jira/PROJECT_ID' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN'
```

**Disable Integration**:

```bash
curl -X PATCH 'https://api.bugspotter.com/api/v1/integrations/jira/PROJECT_ID' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{"enabled": false}'
```

**Delete Integration**:

```bash
curl -X DELETE 'https://api.bugspotter.com/api/v1/integrations/jira/PROJECT_ID' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN'
```

---

## Admin Integration Management

### Creating Custom Integrations

Admins can create up to 10 custom integration types per instance.

**✨ Custom Plugin Per-Project Configuration** (Updated December 2025):

Custom code plugins now support **UI-based per-project configuration**. After creating a custom plugin:

1. Navigate to `/integrations/{plugin_type}` in the admin panel
2. Use the dynamic configuration form to add project-specific settings
3. Each project can have different configuration values for the same plugin type
4. Configuration is stored in `project_integrations` table with per-project isolation

This enables scenarios like:

- One Jira plugin configured for multiple team Jira instances
- Same custom tracker plugin with different API endpoints per project
- Reusable plugin templates with project-specific customization

**1. Analyze Plugin Code (Optional)**

Before creating a code-based plugin, analyze it for security violations:

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/admin/integrations/analyze-code' \
  -H 'Authorization: Bearer ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "code": "function createTicket(bugReport) { /* code */ }"
  }'
```

Response:

```json
{
  "success": true,
  "data": {
    "safe": true,
    "violations": [],
    "warnings": ["Uses HTTP requests - ensure credentials are secured"],
    "risk_level": "low",
    "code_hash": "sha256:abc123..."
  }
}
```

**Security Analysis Checks**:

- ❌ Forbidden: `eval()`, `Function()`, `require()`, filesystem access
- ⚠️ Warnings: HTTP requests, external dependencies, large code size
- ✅ Safe: Pure functions, controlled API usage

**Environment Configuration**:

- `PLUGIN_EXECUTION_TIMEOUT_MS` - VM execution timeout in milliseconds (default: 15000)
- Must be greater than HTTP fetch timeout (10s) to allow requests to complete

**2. Create Integration Type**

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/admin/integrations' \
  -H 'Authorization: Bearer ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "type": "custom_tracker",
    "name": "Custom Issue Tracker",
    "description": "Internal issue tracking system",
    "is_custom": true,
    "plugin_source": "generic_http",
    "trust_level": "custom",
    "config": {
      "base_url": "https://tracker.company.com"
    },
    "allow_code_execution": false
  }'
```

**Integration Properties**:

- **type**: Unique identifier (lowercase, alphanumeric + underscores)
- **plugin_source**: `generic_http`, `jira`, `github`, `linear`, `custom`
- **trust_level**: `trusted` (built-in), `verified` (audited), `custom` (admin-created)
- **allow_code_execution**: Enable custom plugin code (currently disabled globally)

### Managing Integration Types

**List All Integrations**:

```bash
curl -X GET 'https://api.bugspotter.com/api/v1/admin/integrations?status=active' \
  -H 'Authorization: Bearer ADMIN_TOKEN'
```

**Get Integration Status**:

```bash
curl -X GET 'https://api.bugspotter.com/api/v1/admin/integrations/jira/status' \
  -H 'Authorization: Bearer ADMIN_TOKEN'
```

Response includes sync statistics:

```json
{
  "type": "jira",
  "name": "Atlassian Jira",
  "status": "active",
  "last_sync_at": "2025-11-06T11:30:00.000Z",
  "stats": {
    "success": 150,
    "failed": 2,
    "pending": 0,
    "avg_duration_ms": 1250
  }
}
```

**Update Configuration**:

```bash
curl -X PUT 'https://api.bugspotter.com/api/v1/admin/integrations/custom_tracker/config' \
  -H 'Authorization: Bearer ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "Updated Tracker Name",
    "status": "active",
    "field_mappings": {
      "title": "summary",
      "description": "description",
      "priority": "priority"
    },
    "sync_rules": {
      "auto_sync": true,
      "sync_interval": 3600
    }
  }'
```

**Reset Configuration**:

```bash
curl -X DELETE 'https://api.bugspotter.com/api/v1/admin/integrations/custom_tracker/config' \
  -H 'Authorization: Bearer ADMIN_TOKEN'
```

**Delete Integration Type**:

```bash
curl -X DELETE 'https://api.bugspotter.com/api/v1/admin/integrations/custom_tracker' \
  -H 'Authorization: Bearer ADMIN_TOKEN'
```

### Testing Integrations

Test connection with live credentials:

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/admin/integrations/jira/test' \
  -H 'Authorization: Bearer ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "config": {
      "base_url": "https://test.company.com",
      "api_key": "test_key"
    }
  }'
```

**Test results are logged** in the activity log for audit purposes.

---

## Security Considerations

### Credential Encryption

All integration credentials are encrypted at rest using **AES-256-GCM** encryption:

1. **Encryption**: Credentials JSON → AES-256-GCM → Base64 → Database
2. **Decryption**: Database → Base64 decode → AES-256-GCM → Credentials JSON
3. **Key Management**: Encryption key stored in `ENCRYPTION_KEY` environment variable
4. **Rotation**: Keys can be rotated with zero downtime using dual-key strategy

**Never log or expose credentials** in API responses:

- ✅ `GET /integrations/{platform}/{projectId}` returns config without credentials
- ✅ `GET /admin/integrations/{type}/config` excludes oauth_tokens and webhook_secret
- ❌ Raw credentials are never returned via API

### Plugin Security

**Current Status**: Custom plugin execution is **enabled** with secure RPC bridge architecture (as of November 2025).

**Security Measures**:

1. **Static Analysis**: Babel AST parsing detects malicious patterns before execution
2. **Sandbox Execution**: Code runs in isolated-vm (separate V8 isolate, 128MB memory limit, 5s timeout)
3. **Global API Disabling**: `fetch`, `XMLHttpRequest`, `WebSocket`, `require`, `process` disabled in sandbox
4. **RPC Bridge**: Message-passing interface with whitelisted methods only
5. **Project Scoping**: All data access restricted to the plugin's project
6. **Field Restrictions**: Plugins can only update specific metadata fields

### Webhook Security

Webhooks use **HMAC-SHA256 signatures** for authenticity verification:

**1. Secret Generation**:

```javascript
const secret = `whsec_${randomBytes(32).toString('base64url')}`;
// Example: whsec_abc123def456...
```

**2. Signature Calculation**:

```javascript
// Server-side (BugSpotter) - uses raw body buffer
const signature = crypto.createHmac('sha256', secret).update(rawBodyBuffer).digest('hex');
```

**3. Verification** (in receiving system):

```javascript
const receivedSignature = request.headers['x-bugspotter-signature'];
const calculatedSignature = calculateSignature(request.body, secret);

if (!crypto.timingSafeEqual(Buffer.from(receivedSignature), Buffer.from(calculatedSignature))) {
  throw new Error('Invalid webhook signature');
}
```

**Best Practices**:

- Store webhook secrets securely (environment variables, secret manager)
- Rotate secrets periodically (create new webhook, delete old)
- Use HTTPS endpoints only
- Implement replay attack prevention (timestamp validation)

---

## Custom Plugin Development

**Status**: ✅ **ENABLED** with secure RPC bridge (as of November 2025)

Custom plugin execution is now enabled with a secure architecture that prevents sandbox escape attacks. Plugin code runs in an isolated V8 context and communicates with the host via a whitelisted RPC bridge.

**Timeout Configuration**: The VM execution timeout is configurable via the `PLUGIN_EXECUTION_TIMEOUT_MS` environment variable (default: 15000ms). This should be greater than the HTTP fetch timeout (10000ms) to allow external API requests to complete with overhead for processing.

### Security Architecture

#### Multi-Layer Protection

1. **Static Analysis** - Babel AST parsing detects malicious patterns before execution
2. **Sandbox Execution** - Code runs in isolated-vm (separate V8 isolate, 128MB memory limit, 15s default timeout, configurable via `PLUGIN_EXECUTION_TIMEOUT_MS`)
3. **Global API Disabling** - `fetch`, `XMLHttpRequest`, `WebSocket`, `require`, `process` disabled in sandbox
4. **RPC Bridge** - Message-passing interface with whitelisted methods only
5. **Project Scoping** - All data access is restricted to the plugin's project
6. **Field Restrictions** - Plugins can only update specific metadata fields

#### RPC Method Whitelist

Plugins can only call these methods via the RPC bridge:

- `db.bugReports.findById` - Get bug report data (sanitized, project-scoped)
- `db.bugReports.update` - Update bug report metadata only
- `db.projectIntegrations.findByProject` - List integrations (no credentials)
- `storage.getPresignedUrl` - Get read-only URLs (5-minute expiration, project-scoped)
- `http.fetch` - Make HTTP requests with SSRF prevention and timeout (10s limit)
- `log` - Log info messages to server logs (appears in admin audit trail)
- `logError` - Log error messages to server logs
- `logWarn` - Log warning messages to server logs

**Plugins CANNOT**:

- Use global `fetch()`, `XMLHttpRequest`, or `WebSocket` (disabled, must use `http.fetch` RPC)
- Execute SQL queries directly
- Access database outside their project
- Upload files or modify storage
- Call arbitrary Node.js APIs (`fs`, `child_process`, `net`, `require`, etc.)
- Access environment variables (`process.env`) or process memory
- Update bug report status, title, or other protected fields

### Implementation Status (November 2025)

**Custom plugin execution is fully functional.** Plugins execute in isolated-vm sandbox and can create external tickets in real-time via the secure RPC bridge.

**What Works**:

- ✅ Plugin metadata extraction in isolated-VM
- ✅ Security validation (static analysis + sandbox)
- ✅ Plugin registration and storage
- ✅ RPC bridge security guarantees (19/19 tests passing)
- ✅ All integration tests passing (42/42 plugin tests)
- ✅ Factory function execution in isolated-VM (runtime execution complete)
- ✅ Service method bridging with serialization (createFromBugReport working)
- ✅ Real-time ticket creation via plugin code (not stub responses)
- ✅ Per-project isolate disposal to prevent memory leaks

**Future Enhancements**:

- ⏳ Long-lived VM contexts vs. VM-per-call performance optimization
- ⏳ Plugin instance caching and state management
- ⏳ Template-based configuration system (field mapping, placeholders)

### Plugin Interface

All integration plugins must export a factory function that creates a service:

```typescript
// Plugin metadata - validated in sandbox, extracted via RPC
const pluginMetadata = {
  platform: 'my_tracker',
  name: 'My Issue Tracker Integration',
  version: '1.0.0',
  description: 'Custom integration for internal issue tracker',
  configSchema: {
    base_url: { type: 'string', required: true },
    api_token: { type: 'string', required: true, secret: true },
    project_key: { type: 'string', required: true },
  },
};

// Factory function - receives RPC bridge for safe host communication
function factory(context) {
  return {
    async createFromBugReport(bugReport, config) {
      // bugReport parameter contains: { id, title, description, priority, status, metadata, created_at }
      // NOTE: created_at is an ISO 8601 string (e.g., "2025-11-30T12:34:56.789Z"), not a Date object
      // To use as Date: const createdDate = new Date(bugReport.created_at);

      // Call RPC methods via context bridge
      const reportData = await context.rpcBridge.callMethod('db.bugReports.findById', [
        bugReport.id,
      ]);

      // Use secure http.fetch RPC method (provides SSRF prevention, timeout, logging)
      const response = await context.rpcBridge.callMethod('http.fetch', [
        `${config.base_url}/api/tickets`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${config.api_token}`,
          },
          body: JSON.stringify({
            title: reportData.title,
            description: reportData.description,
            priority: reportData.priority,
            labels: ['bugspotter'],
          }),
        },
      ]);

      // RPC returns { status, statusText, headers, body } not Response object
      // Always wrap JSON.parse in try/catch - API might return HTML error pages
      let ticket;
      try {
        ticket = JSON.parse(response.body);
      } catch (error) {
        throw new Error(`Invalid JSON response from API: ${error.message}`);
      }

      // Update bug report metadata via RPC (only metadata field allowed)
      await context.rpcBridge.callMethod('db.bugReports.update', [
        bugReport.id,
        {
          metadata: {
            external_ticket_id: ticket.id,
            external_ticket_url: ticket.url,
            external_platform: 'my_tracker',
          },
        },
      ]);

      // Log to server logs (appears in admin audit trail)
      await context.rpcBridge.callMethod('log', ['Created ticket:', ticket.id]);

      return {
        success: true,
        external_id: ticket.id,
        url: ticket.url,
      };
    },
  };
}

// Export both metadata and factory (required pattern)
module.exports = { metadata: pluginMetadata, factory };
```

### RPC Bridge API

The `context.rpcBridge` provides these methods:

#### `callMethod(method, args)` → `Promise<result>`

Call whitelisted host methods with project-scoped access:

```javascript
// Get bug report (sanitized, project-scoped)
const report = await context.rpcBridge.callMethod('db.bugReports.findById', ['bug-123']);
// Returns: { id, title, description, priority, status, metadata, created_at, updated_at }
// NOTE: created_at and updated_at are ISO 8601 strings (e.g., "2025-11-30T12:34:56.789Z"), not Date objects
// Omits: project_id, deleted_at, deleted_by, legal_hold, internal keys

// Update metadata only (merge with existing metadata)
await context.rpcBridge.callMethod('db.bugReports.update', [
  'bug-123',
  {
    metadata: {
      external_ticket_id: 'JIRA-456',
      external_ticket_url: 'https://jira.example.com/browse/JIRA-456',
    },
  },
]);

// Get integration configurations (no credentials)
const integrations = await context.rpcBridge.callMethod('db.projectIntegrations.findByProject', []);
// Returns: [{ type: 'jira', config: { url: 'https://jira.example.com' } }]

// Get presigned storage URL (5-minute expiration)
const url = await context.rpcBridge.callMethod('storage.getPresignedUrl', [
  'screenshots/project-123/bug-456/screenshot.png',
]);

// Make HTTP request to external API (SSRF protection, 10s timeout)
const response = await context.rpcBridge.callMethod('http.fetch', [
  'https://api.tracker.com/tickets',
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.api_token}`,
    },
    body: JSON.stringify({
      title: report.title,
      description: report.description,
      priority: report.priority,
    }),
  },
]);

// Check status before parsing
if (response.status < 200 || response.status >= 300) {
  throw new Error(`HTTP ${response.status}: ${response.statusText}`);
}

// Parse response with error handling
let ticket;
try {
  ticket = JSON.parse(response.body);
} catch (error) {
  throw new Error(`Invalid JSON response: ${error.message}`);
}

console.log(`Created ticket ${ticket.id} with status ${response.status}`);

// Log to server (appears in admin audit trail)
await context.rpcBridge.callMethod('log', ['Created ticket:', ticket.id]);
```

#### HTTP Fetch Security Controls

The `http.fetch` RPC method enforces these security controls:

**✅ Allowed:**

- HTTP and HTTPS protocols only
- Public internet domains
- 10-second timeout per request
- All standard HTTP methods (GET, POST, PUT, DELETE, etc.)

**❌ Blocked:**

- `localhost`, `127.0.0.1`, `0.0.0.0` (SSRF prevention)
- Private networks: `192.168.x.x`, `10.x.x.x`, `172.x.x.x`
- Non-HTTP protocols: `file://`, `ftp://`, `data://`
- Requests exceeding 10-second timeout
- Automatic redirects (set to `manual` to prevent open redirect attacks)

**Logging:**
All HTTP requests are logged with:

- URL and method
- Response status and size
- Project ID for audit trail
- Appears in admin activity logs

**Response Format:**

```typescript
{
  status: 200,
  statusText: 'OK',
  headers: { 'content-type': 'application/json' },
  body: '{"id":"TICKET-123","url":"https://..."}' // Raw string - plugin must parse
}
```

**⚠️ Important**: The `body` field is always a raw string. Plugins must:

1. Check `response.status` before parsing (4xx/5xx might return HTML error pages)
2. Wrap `JSON.parse()` in try/catch for malformed JSON
3. Validate response structure after parsing

```javascript
// ✅ GOOD: Check status and handle parse errors
const response = await context.rpcBridge.callMethod('http.fetch', [url, options]);

if (response.status < 200 || response.status >= 300) {
  throw new Error(`HTTP ${response.status}: ${response.statusText}`);
}

let data;
try {
  data = JSON.parse(response.body);
} catch (error) {
  throw new Error(`Invalid JSON response: ${error.message}`);
}

if (!data.id || !data.url) {
  throw new Error('Response missing required fields');
}

// ❌ BAD: Direct parse without validation
const ticket = JSON.parse(response.body); // Crashes on HTML error pages!
```

**Design Decision**: The RPC bridge returns raw response bodies (not pre-parsed JSON) because:

- Plugins might need non-JSON responses (XML, plain text, binary data)
- Parsing errors should be handled by plugin code with appropriate error messages
- Keeps RPC bridge simple and doesn't hide parsing failures
- Plugins have full control over error handling strategy

### Security Best Practices

#### ✅ DO

- Use RPC bridge for all database/storage access
- Use `http.fetch` RPC method for external API calls (provides SSRF prevention, timeout, logging)
- Check HTTP status codes before parsing response body
- Wrap `JSON.parse()` in try/catch (APIs might return HTML error pages)
- Validate response structure after parsing (check required fields exist)
- Store ticket IDs in bug report metadata
- Log important events via `log` RPC method
- Handle errors gracefully (try/catch)
- Validate config before using it
- Use environment-agnostic code (no `process.env`)

#### ❌ DON'T

- Use global `fetch()`, `axios`, or `request` libraries (bypasses security controls)
- Parse JSON without checking HTTP status first (error responses might be HTML)
- Use `JSON.parse()` without try/catch (malformed JSON will crash plugin)
- Assume response structure without validation (APIs change, fields might be missing)
- Try to access `db`, `storage`, or `fs` directly (not available)
- Try to access environment variables (not available)
- Try to execute system commands (not available)
- Store credentials in plugin code (use config from parameters)
- Assume specific Node.js version (use ES2017 only)
- Use `eval`, `Function`, or `require` (blocked by static analysis)

### Example: Complete Plugin with Error Handling

```javascript
const pluginMetadata = {
  platform: 'custom_tracker',
  name: 'Custom Issue Tracker',
  version: '1.0.0',
  description: 'Integration with custom issue tracker',
  configSchema: {
    base_url: { type: 'string', required: true },
    api_token: { type: 'string', required: true, secret: true },
  },
};

function factory(context) {
  return {
    async createFromBugReport(bugReport, config) {
      try {
        // 1. Get bug report data via RPC
        const report = await context.rpcBridge.callMethod('db.bugReports.findById', [bugReport.id]);

        // 2. Create ticket in external system using secure http.fetch RPC
        const response = await context.rpcBridge.callMethod('http.fetch', [
          `${config.base_url}/api/tickets`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${config.api_token}`,
            },
            body: JSON.stringify({
              title: report.title,
              description: report.description,
              priority: report.priority || 'medium',
            }),
          },
        ]);

        // RPC returns { status, statusText, headers, body } not Response object
        if (response.status < 200 || response.status >= 300) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        // Parse JSON response with error handling
        let ticket;
        try {
          ticket = JSON.parse(response.body);
        } catch (error) {
          throw new Error(`Invalid JSON response: ${error.message}`);
        }

        // Validate response structure
        if (!ticket.id) {
          throw new Error('Response missing ticket ID');
        }

        // 3. Update bug report metadata
        await context.rpcBridge.callMethod('db.bugReports.update', [
          bugReport.id,
          {
            metadata: {
              external_ticket_id: ticket.id,
              external_ticket_url: `${config.base_url}/tickets/${ticket.id}`,
              external_platform: 'custom_tracker',
              synced_at: new Date().toISOString(),
            },
          },
        ]);

        // 4. Log success
        await context.rpcBridge.callMethod('log', [
          `Created ticket ${ticket.id} for bug ${bugReport.id}`,
        ]);

        return {
          success: true,
          external_id: ticket.id,
          url: `${config.base_url}/tickets/${ticket.id}`,
        };
      } catch (error) {
        // Log error (will appear in admin audit trail)
        await context.rpcBridge.callMethod('logError', [
          `Failed to create ticket: ${error.message}`,
        ]);

        return {
          success: false,
          error: error.message,
        };
      }
    },
  };
}

module.exports = { metadata: pluginMetadata, factory };
```

---

## Step-by-Step: Creating a Custom Jira Plugin

> **✨ NEW: Plugin Utils Library Available!**  
> BugSpotter now provides a comprehensive **Plugin Utils library** with reusable helpers for authentication, HTTP requests, validation, and more. This guide shows both approaches:
>
> 1. **Recommended**: Using Plugin Utils (less code, best practices built-in)
> 2. Legacy: Manual implementation (for reference)
>
> 📖 **Full API Documentation**: See [Plugin Utils API](../packages/backend/src/integrations/plugin-utils/API.md)

This guide walks through creating a **production-ready Jira integration plugin** with full authentication support, error handling, and attachment capabilities.

### **Overview**

You'll create three functions:

1. **createTicket** - Creates Jira issues via REST API
2. **testConnection** - Validates credentials and project access
3. **validateConfig** - Client-side configuration validation

### **Quick Start with Plugin Utils**

Here's a complete, production-ready Jira plugin using the Plugin Utils library:

```javascript
module.exports = {
  metadata: {
    name: 'jira-integration',
    platform: 'jira',
    version: '1.0.0',
    description: 'Jira Cloud integration with plugin utils',
  },

  factory: (context) => ({
    async createTicket(bugReport, projectId, integrationId) {
      try {
        const { config } = context;

        // Get presigned URLs for attachments
        const urls = await utils.getResourceUrls(bugReport);

        // Extract environment and logs
        const env = await utils.extractEnvironment(bugReport.metadata);
        const consoleLogs = await utils.extractConsoleLogs(bugReport.metadata, 10);

        // Build description with Atlassian Document Format (ADF)
        const description = {
          type: 'doc',
          version: 1,
          content: [
            {
              type: 'heading',
              attrs: { level: 2 },
              content: [{ type: 'text', text: 'Bug Description' }],
            },
            {
              type: 'paragraph',
              content: [{ type: 'text', text: bugReport.description || 'No description provided' }],
            },
            // Add attachments section
            ...(urls.screenshot || urls.replay
              ? [
                  {
                    type: 'heading',
                    attrs: { level: 2 },
                    content: [{ type: 'text', text: 'Attachments' }],
                  },
                  {
                    type: 'paragraph',
                    content: [
                      ...(urls.screenshot
                        ? [
                            {
                              type: 'text',
                              text: '📸 Screenshot',
                              marks: [{ type: 'link', attrs: { href: urls.screenshot } }],
                            },
                            { type: 'text', text: ' | ' },
                          ]
                        : []),
                      ...(urls.replay
                        ? [
                            {
                              type: 'text',
                              text: '🎬 Session Replay',
                              marks: [{ type: 'link', attrs: { href: urls.replay } }],
                            },
                          ]
                        : []),
                    ],
                  },
                ]
              : []),
            // Add environment
            {
              type: 'heading',
              attrs: { level: 2 },
              content: [{ type: 'text', text: 'Environment' }],
            },
            {
              type: 'bulletList',
              content: [
                {
                  type: 'listItem',
                  content: [
                    {
                      type: 'paragraph',
                      content: [
                        { type: 'text', text: `Browser: ${env.browser} ${env.browserVersion}` },
                      ],
                    },
                  ],
                },
                {
                  type: 'listItem',
                  content: [
                    { type: 'paragraph', content: [{ type: 'text', text: `OS: ${env.os}` }] },
                  ],
                },
                {
                  type: 'listItem',
                  content: [
                    { type: 'paragraph', content: [{ type: 'text', text: `URL: ${env.url}` }] },
                  ],
                },
              ],
            },
            // Add console logs if present
            ...(consoleLogs.length > 0
              ? [
                  {
                    type: 'heading',
                    attrs: { level: 2 },
                    content: [{ type: 'text', text: 'Console Logs' }],
                  },
                  {
                    type: 'codeBlock',
                    content: [
                      {
                        type: 'text',
                        text: consoleLogs.map((log) => `[${log.level}] ${log.message}`).join('\n'),
                      },
                    ],
                  },
                ]
              : []),
          ],
        };

        // Build auth header
        const authHeader = await utils.buildAuthHeader({
          type: 'basic',
          username: config.jiraEmail,
          password: config.jiraApiToken,
        });

        // Create ticket
        const result = await utils.makeApiRequest({
          baseUrl: config.jiraUrl,
          endpoint: '/rest/api/3/issue',
          method: 'POST',
          authHeader,
          body: {
            fields: {
              project: { key: config.projectKey },
              summary: bugReport.title,
              description: description,
              issuetype: { name: 'Bug' },
              priority: { name: config.priority || 'Medium' },
            },
          },
          errorPrefix: 'Failed to create Jira ticket',
        });

        return {
          success: true,
          external_id: result.key,
          external_url: `${config.jiraUrl}/browse/${result.key}`,
        };
      } catch (error) {
        return { success: false, external_id: '', error: error.message };
      }
    },

    async testConnection(projectId) {
      try {
        const { config } = context;

        const authHeader = await utils.buildAuthHeader({
          type: 'basic',
          username: config.jiraEmail,
          password: config.jiraApiToken,
        });

        // Test auth
        await utils.makeApiRequest({
          baseUrl: config.jiraUrl,
          endpoint: '/rest/api/3/myself',
          authHeader,
        });

        // Test project access
        await utils.makeApiRequest({
          baseUrl: config.jiraUrl,
          endpoint: `/rest/api/3/project/${config.projectKey}`,
          authHeader,
        });

        return true;
      } catch (error) {
        return false;
      }
    },

    async validateConfig(config) {
      const errors = await utils.validateFields([
        { name: 'Jira URL', value: config.jiraUrl, validator: validators.required },
        { name: 'Jira URL', value: config.jiraUrl, validator: validators.url },
        { name: 'Project Key', value: config.projectKey, validator: validators.required },
        { name: 'Email', value: config.jiraEmail, validator: validators.required },
        { name: 'Email', value: config.jiraEmail, validator: validators.email },
        { name: 'API Token', value: config.jiraApiToken, validator: validators.required },
      ]);

      return await utils.createValidationResult(errors.length === 0, errors);
    },
  }),
};
```

**Benefits of Plugin Utils Approach:**

- ✅ **44% less code** - From ~320 lines to ~180 lines
- ✅ **Built-in SSRF protection** - `makeApiRequest` validates URLs
- ✅ **Automatic error handling** - Consistent error messages and codes
- ✅ **Reusable validators** - No manual validation logic
- ✅ **Cross-platform** - Same utils work for GitHub, Linear, Azure DevOps, etc.

---

### **Manual Implementation (Legacy)**

If you prefer to implement everything manually (not recommended for production), here's the detailed approach:

### **Configuration Structure**

Your plugin will accept this configuration:

```typescript
{
  instanceUrl: "https://company.atlassian.net",
  projectKey: "BUG",
  authentication: {
    type: "basic",              // "basic", "oauth2", or "pat"
    email: "api@company.com",   // Required for basic auth
    apiToken: "ATATT3xFfGF0..."  // Required for basic auth
    // OR
    // accessToken: "eyJhbGc..." // Required for oauth2/pat
  }
}
```

**Type Safety**: This matches the enhanced type guards in the admin panel:

- `isJiraConfig()` validates structure + field types
- `validateJiraConfig()` ensures non-empty values

---

### **Step 1: Plugin Metadata**

Define your plugin's identity and configuration schema:

```javascript
const pluginMetadata = {
  platform: 'jira_custom',
  name: 'Jira Integration (Custom)',
  version: '1.0.0',
  description: 'Production-ready Jira integration with full attachment support',
  configSchema: {
    instanceUrl: {
      type: 'string',
      required: true,
      description: 'Jira instance URL (e.g., https://company.atlassian.net)',
    },
    projectKey: {
      type: 'string',
      required: true,
      description: 'Project key (e.g., BUG, PROJ)',
    },
    authentication: {
      type: 'object',
      required: true,
      properties: {
        type: {
          type: 'string',
          enum: ['basic', 'oauth2', 'pat'],
          required: true,
        },
        email: {
          type: 'string',
          description: 'Email for basic auth',
        },
        apiToken: {
          type: 'string',
          secret: true,
          description: 'API token for basic auth',
        },
        accessToken: {
          type: 'string',
          secret: true,
          description: 'Access token for OAuth2/PAT',
        },
      },
    },
  },
};
```

---

### **Step 2: Authentication Helper**

Create a reusable function to build authentication headers:

```javascript
/**
 * Build Authorization header based on authentication type
 */
function buildAuthHeader(authConfig) {
  if (authConfig.type === 'basic') {
    // Basic Auth: Base64 encode email:apiToken
    const credentials = authConfig.email + ':' + authConfig.apiToken;
    const base64 = Buffer.from(credentials).toString('base64');
    return 'Basic ' + base64;
  } else if (authConfig.type === 'oauth2' || authConfig.type === 'pat') {
    // OAuth2/PAT: Use bearer token
    return 'Bearer ' + authConfig.accessToken;
  } else {
    throw new Error('Unsupported authentication type: ' + authConfig.type);
  }
}
```

---

### **Step 3: Ticket Creation Function**

Create Jira issues with full metadata and attachments:

```javascript
async function createTicket(context, bugReport, config) {
  try {
    // Build authentication header
    const authHeader = buildAuthHeader(config.authentication);

    // Format description with Atlassian Document Format (ADF)
    const description = {
      type: 'doc',
      version: 1,
      content: [
        // Main description
        {
          type: 'heading',
          attrs: { level: 2 },
          content: [{ type: 'text', text: 'Bug Description' }],
        },
        {
          type: 'paragraph',
          content: [
            {
              type: 'text',
              text: bugReport.description || 'No description provided',
            },
          ],
        },

        // Console logs section
        ...(bugReport.metadata?.console?.length > 0
          ? [
              {
                type: 'heading',
                attrs: { level: 3 },
                content: [{ type: 'text', text: '🐛 Console Logs' }],
              },
              {
                type: 'codeBlock',
                attrs: { language: 'javascript' },
                content: [
                  {
                    type: 'text',
                    text: bugReport.metadata.console
                      .slice(0, 50) // Limit to last 50 logs
                      .map((log) => '[' + log.level.toUpperCase() + '] ' + log.message)
                      .join('\n'),
                  },
                ],
              },
            ]
          : []),

        // Network activity section
        ...(bugReport.metadata?.network?.length > 0
          ? [
              {
                type: 'heading',
                attrs: { level: 3 },
                content: [{ type: 'text', text: '🌐 Network Activity' }],
              },
              {
                type: 'bulletList',
                content: bugReport.metadata.network
                  .filter((req) => req.status >= 400) // Only failed requests
                  .slice(0, 20) // Limit to 20 requests
                  .map((req) => ({
                    type: 'listItem',
                    content: [
                      {
                        type: 'paragraph',
                        content: [
                          {
                            type: 'text',
                            text:
                              req.method +
                              ' ' +
                              req.url +
                              ' → ' +
                              req.status +
                              ' (' +
                              req.duration +
                              'ms)',
                          },
                        ],
                      },
                    ],
                  })),
              },
            ]
          : []),

        // Attachments section with clickable links
        {
          type: 'heading',
          attrs: { level: 3 },
          content: [{ type: 'text', text: '📎 Attachments' }],
        },
        {
          type: 'bulletList',
          content: [
            ...(bugReport.screenshot_url
              ? [
                  {
                    type: 'listItem',
                    content: [
                      {
                        type: 'paragraph',
                        content: [
                          {
                            type: 'text',
                            text: '📸 Screenshot: ',
                            marks: [{ type: 'strong' }],
                          },
                          {
                            type: 'text',
                            text: bugReport.screenshot_url,
                            marks: [
                              {
                                type: 'link',
                                attrs: { href: bugReport.screenshot_url },
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ]
              : []),
            ...(bugReport.replay_url
              ? [
                  {
                    type: 'listItem',
                    content: [
                      {
                        type: 'paragraph',
                        content: [
                          {
                            type: 'text',
                            text: '🎥 Session Replay: ',
                            marks: [{ type: 'strong' }],
                          },
                          {
                            type: 'text',
                            text: bugReport.replay_url,
                            marks: [
                              {
                                type: 'link',
                                attrs: { href: bugReport.replay_url },
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ]
              : []),
          ],
        },

        // Environment details
        {
          type: 'heading',
          attrs: { level: 3 },
          content: [{ type: 'text', text: '💻 Environment' }],
        },
        {
          type: 'bulletList',
          content: [
            {
              type: 'listItem',
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text:
                        'Browser: ' +
                        (bugReport.metadata?.browser?.name || 'Unknown') +
                        ' ' +
                        (bugReport.metadata?.browser?.version || ''),
                    },
                  ],
                },
              ],
            },
            {
              type: 'listItem',
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text:
                        'OS: ' +
                        (bugReport.metadata?.os?.name || 'Unknown') +
                        ' ' +
                        (bugReport.metadata?.os?.version || ''),
                    },
                  ],
                },
              ],
            },
            {
              type: 'listItem',
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: 'URL: ' + (bugReport.metadata?.url || 'Not captured'),
                    },
                  ],
                },
              ],
            },
          ],
        },

        // Footer
        {
          type: 'rule', // Horizontal line
        },
        {
          type: 'paragraph',
          content: [
            {
              type: 'text',
              text: 'Created automatically by BugSpotter',
              marks: [{ type: 'em' }],
            },
          ],
        },
      ],
    };

    // Create Jira issue via REST API v3
    const response = await context.rpcBridge.callMethod('http.fetch', [
      config.instanceUrl + '/rest/api/3/issue',
      {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          fields: {
            // Required fields
            project: { key: config.projectKey },
            summary: bugReport.title,
            issuetype: { name: 'Bug' },
            description: description,

            // Optional fields with safe fallbacks
            priority: {
              name: bugReport.priority
                ? bugReport.priority.charAt(0).toUpperCase() + bugReport.priority.slice(1)
                : 'Medium',
            },

            labels: ['bugspotter', 'automated'],
          },
        }),
      },
    ]);

    // Handle API errors
    if (response.status < 200 || response.status >= 300) {
      const errorBody = response.body.substring(0, 500); // Truncate long errors
      throw new Error('Jira API error (' + response.status + '): ' + errorBody);
    }

    // Parse response
    let ticket;
    try {
      ticket = JSON.parse(response.body);
    } catch (error) {
      throw new Error('Invalid JSON response from Jira API: ' + error.message);
    }

    if (!ticket.key) {
      throw new Error('Jira API did not return ticket key');
    }

    // Update bug report with external ticket reference
    await context.rpcBridge.callMethod('db.bugReports.update', [
      bugReport.id,
      {
        metadata: {
          external_ticket_id: ticket.key,
          external_ticket_url: config.instanceUrl + '/browse/' + ticket.key,
          external_platform: 'jira',
          synced_at: new Date().toISOString(),
        },
      },
    ]);

    // Log success
    await context.rpcBridge.callMethod('log', [
      'Created Jira ticket ' + ticket.key + ' for bug ' + bugReport.id,
    ]);

    // Return standardized result
    return {
      success: true,
      external_id: ticket.key,
      url: config.instanceUrl + '/browse/' + ticket.key,
    };
  } catch (error) {
    // Log error for admin audit trail
    await context.rpcBridge.callMethod('logError', [
      'Failed to create Jira ticket: ' + error.message,
    ]);

    return {
      success: false,
      error: error.message,
    };
  }
}
```

---

### **Step 4: Test Connection Function**

Validate credentials, project access, and issue type availability:

```javascript
async function testConnection(context, config) {
  try {
    const authHeader = buildAuthHeader(config.authentication);

    // Test 1: Verify authentication by fetching current user
    const authResponse = await context.rpcBridge.callMethod('http.fetch', [
      config.instanceUrl + '/rest/api/3/myself',
      {
        headers: {
          Authorization: authHeader,
          Accept: 'application/json',
        },
      },
    ]);

    if (authResponse.status !== 200) {
      return {
        success: false,
        error: 'Authentication failed (' + authResponse.status + '): Check your credentials',
        details: { statusCode: authResponse.status },
      };
    }

    const currentUser = JSON.parse(authResponse.body);

    // Test 2: Verify project exists and user has access
    const projectResponse = await context.rpcBridge.callMethod('http.fetch', [
      config.instanceUrl + '/rest/api/3/project/' + config.projectKey,
      {
        headers: {
          Authorization: authHeader,
          Accept: 'application/json',
        },
      },
    ]);

    if (projectResponse.status === 404) {
      return {
        success: false,
        error: 'Project "' + config.projectKey + '" not found or you don\'t have access',
        details: { projectKey: config.projectKey, statusCode: 404 },
      };
    }

    if (projectResponse.status !== 200) {
      return {
        success: false,
        error: 'Project verification failed (' + projectResponse.status + ')',
        details: { statusCode: projectResponse.status },
      };
    }

    const project = JSON.parse(projectResponse.body);

    // Test 3: Verify Bug issue type exists
    const issueTypesResponse = await context.rpcBridge.callMethod('http.fetch', [
      config.instanceUrl + '/rest/api/3/project/' + config.projectKey + '/statuses',
      {
        headers: {
          Authorization: authHeader,
          Accept: 'application/json',
        },
      },
    ]);

    let hasBugType = false;
    if (issueTypesResponse.status === 200) {
      const issueTypes = JSON.parse(issueTypesResponse.body);
      hasBugType = issueTypes.some(function (it) {
        return it.name === 'Bug' || it.untranslatedName === 'Bug';
      });

      if (!hasBugType) {
        return {
          success: false,
          error: 'Project does not have a "Bug" issue type configured',
          details: {
            availableTypes: issueTypes
              .map(function (it) {
                return it.name;
              })
              .join(', '),
          },
        };
      }
    }

    // All tests passed!
    return {
      success: true,
      message: 'Successfully connected to ' + project.name,
      details: {
        projectName: project.name,
        projectKey: project.key,
        projectType: project.projectTypeKey,
        authenticatedUser: currentUser.displayName,
        userEmail: currentUser.emailAddress,
        instanceUrl: config.instanceUrl,
      },
    };
  } catch (error) {
    return {
      success: false,
      error: 'Connection test failed: ' + error.message,
      details: {
        errorType: error.name,
        message: error.message,
      },
    };
  }
}
```

---

### **Step 5: Validate Config Function**

Client-side validation for immediate feedback:

```javascript
function validateConfig(config) {
  const errors = [];

  // Validate instance URL
  if (!config.instanceUrl || !config.instanceUrl.trim()) {
    errors.push('Instance URL is required');
  } else {
    try {
      const url = new URL(config.instanceUrl);
      if (!url.protocol.match(/^https?:$/)) {
        errors.push('Instance URL must use HTTP or HTTPS protocol');
      }
      if (!url.hostname) {
        errors.push('Instance URL must include a hostname');
      }
    } catch (e) {
      errors.push('Instance URL must be a valid URL (e.g., https://company.atlassian.net)');
    }
  }

  // Validate project key
  if (!config.projectKey || !config.projectKey.trim()) {
    errors.push('Project Key is required');
  } else if (!config.projectKey.match(/^[A-Z][A-Z0-9_]*$/)) {
    errors.push(
      'Project Key must start with uppercase letter and contain only uppercase letters, numbers, and underscores'
    );
  } else if (config.projectKey.length > 10) {
    errors.push('Project Key must be 10 characters or less');
  }

  // Validate authentication object exists
  if (!config.authentication || typeof config.authentication !== 'object') {
    errors.push('Authentication configuration is required');
    return { valid: false, errors: errors };
  }

  // Validate authentication type
  const validAuthTypes = ['basic', 'oauth2', 'pat'];
  if (!validAuthTypes.includes(config.authentication.type)) {
    errors.push('Authentication type must be one of: basic, oauth2, pat');
    return { valid: false, errors: errors };
  }

  // Validate type-specific authentication fields
  if (config.authentication.type === 'basic') {
    // Basic authentication requires email + apiToken
    if (!config.authentication.email || !config.authentication.email.trim()) {
      errors.push('Email is required for Basic authentication');
    } else if (!config.authentication.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      errors.push('Email must be a valid email address');
    }

    if (!config.authentication.apiToken || !config.authentication.apiToken.trim()) {
      errors.push('API Token is required for Basic authentication');
    } else if (config.authentication.apiToken.length < 20) {
      errors.push('API Token appears invalid (too short - should be 24+ characters)');
    }
  } else if (config.authentication.type === 'oauth2' || config.authentication.type === 'pat') {
    // OAuth2 and PAT require accessToken
    if (!config.authentication.accessToken || !config.authentication.accessToken.trim()) {
      errors.push(
        'Access Token is required for ' +
          config.authentication.type.toUpperCase() +
          ' authentication'
      );
    } else if (config.authentication.accessToken.length < 20) {
      errors.push('Access Token appears invalid (too short)');
    }
  }

  return {
    valid: errors.length === 0,
    errors: errors,
    warnings:
      errors.length === 0
        ? []
        : ['Test the connection before saving to ensure credentials are correct'],
  };
}
```

---

### **Step 6: Factory Function**

Wire everything together:

```javascript
function factory(context) {
  return {
    async createFromBugReport(bugReport, config) {
      return await createTicket(context, bugReport, config);
    },

    async testConnection(config) {
      return await testConnection(context, config);
    },

    validateConfig: function (config) {
      return validateConfig(config);
    },
  };
}
```

---

### **Step 7: Export Plugin**

```javascript
module.exports = {
  metadata: pluginMetadata,
  factory: factory,
};
```

---

### **Complete Plugin (Production-Ready)**

Save as `jira-integration.js`:

```javascript
// ============================================================================
// JIRA INTEGRATION PLUGIN
// Production-ready Jira integration with full authentication support
// ============================================================================

const pluginMetadata = {
  platform: 'jira_custom',
  name: 'Jira Integration (Custom)',
  version: '1.0.0',
  description: 'Production-ready Jira integration with full attachment support',
  configSchema: {
    instanceUrl: {
      type: 'string',
      required: true,
      description: 'Jira instance URL (e.g., https://company.atlassian.net)',
    },
    projectKey: {
      type: 'string',
      required: true,
      description: 'Project key (e.g., BUG, PROJ)',
    },
    authentication: {
      type: 'object',
      required: true,
      properties: {
        type: {
          type: 'string',
          enum: ['basic', 'oauth2', 'pat'],
          required: true,
        },
        email: { type: 'string', description: 'Email for basic auth' },
        apiToken: { type: 'string', secret: true, description: 'API token for basic auth' },
        accessToken: { type: 'string', secret: true, description: 'Access token for OAuth2/PAT' },
      },
    },
  },
};

// [Include all helper functions and main functions from above]
// buildAuthHeader(), createTicket(), testConnection(), validateConfig(), factory()

module.exports = { metadata: pluginMetadata, factory: factory };
```

---

### **Deployment Steps**

#### **1. Analyze Code for Security**

```bash
POST /api/v1/admin/integrations/analyze-code
Content-Type: application/json
Authorization: Bearer <admin-token>

{
  "code": "/* paste entire plugin code */"
}
```

#### **2. Create Integration**

```bash
POST /api/v1/admin/integrations
Content-Type: application/json
Authorization: Bearer <admin-token>

{
  "type": "jira_custom",
  "name": "Jira Integration (Custom)",
  "description": "Production-ready Jira integration",
  "plugin_code": "/* paste validated plugin code */",
  "allow_code_execution": true
}
```

#### **3. Configure in Admin Panel**

Navigate to `/integrations/jira_custom` and configure:

```json
{
  "instanceUrl": "https://company.atlassian.net",
  "projectKey": "BUG",
  "authentication": {
    "type": "basic",
    "email": "api@company.com",
    "apiToken": "ATATT3xFfGF0..."
  }
}
```

#### **4. Test Connection**

Click "Test Connection" button - should show:

- ✅ Successfully connected to [Project Name]
- Authenticated user: [Your Name]
- Project type: software

#### **5. Enable Auto-Create Rules**

Create integration rule for automatic ticket creation:

```json
{
  "name": "Auto-create for high severity bugs",
  "auto_create": true,
  "filters": [
    {
      "field": "severity",
      "operator": "in",
      "value": ["high", "critical"]
    }
  ],
  "throttle": {
    "hourly_limit": 10,
    "daily_limit": 50
  }
}
```

---

### **Testing**

1. **Create test bug report** with high severity
2. **Check outbox table**: `SELECT * FROM ticket_creation_outbox WHERE status = 'pending'`
3. **Watch logs**: Background worker processes outbox entry within 1 minute
4. **Verify Jira**: Ticket created with full metadata and attachments
5. **Check bug report**: `metadata.external_ticket_id` and `metadata.external_ticket_url` populated

---

### **Troubleshooting**

**Authentication fails**:

- Verify API token hasn't expired (Atlassian tokens don't expire but can be revoked)
- Check email address is correct
- Ensure user has project access

**"Bug" issue type not found**:

- Go to Jira → Project Settings → Issue Types
- Enable "Bug" issue type for project

**Attachments not showing**:

- Verify `screenshot_url` and `replay_url` are not null
- Check presigned URLs haven't expired (5-minute expiry)
- Use shared replay links for longer expiry

**Plugin timeout**:

- Default timeout: 15 seconds (configurable via `PLUGIN_EXECUTION_TIMEOUT_MS`)
- Reduce attachment data (use `maxEntries` limits)
- Check Jira API response time

---

### **Advanced: True File Attachments**

To upload files as Jira attachments (not just links):

```javascript
// After creating issue, upload files
async function attachFiles(context, issueKey, bugReport, config) {
  const authHeader = buildAuthHeader(config.authentication);

  // Note: This requires downloading files from storage first
  // Then uploading to Jira's attachment API
  // Current implementation uses links for simplicity

  // Upload screenshot
  if (bugReport.screenshot_url) {
    const fileData = await downloadFile(context, bugReport.screenshot_url);

    await context.rpcBridge.callMethod('http.fetch', [
      config.instanceUrl + '/rest/api/3/issue/' + issueKey + '/attachments',
      {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'X-Atlassian-Token': 'no-check',
        },
        body: fileData, // FormData with file
      },
    ]);
  }
}
```

---

### **Summary**

You now have a **production-ready Jira integration plugin** with:

✅ Multiple authentication methods (Basic, OAuth2, PAT)
✅ Comprehensive error handling
✅ Full attachment support (screenshots, replays, logs)
✅ Connection testing
✅ Client-side validation
✅ Atlassian Document Format (ADF) descriptions
✅ Environment metadata
✅ Audit logging
✅ Type safety with admin panel

**Next Steps**: Customize field mappings, add custom fields, implement bidirectional sync, or add webhook support for status updates.

---

### Plugin Deployment

Custom plugin code is now enabled and can be deployed securely:

#### 1. **Analyze Code** (Security Check)

```bash
POST /api/v1/admin/integrations/analyze-code
Content-Type: application/json

{
  "code": "const pluginMetadata = { /* ... */ }; function factory(context) { /* ... */ }"
}
```

**Response**:

```json
{
  "safe": true,
  "metadata": {
    "platform": "my_tracker",
    "name": "My Issue Tracker",
    "version": "1.0.0"
  },
  "threats": [],
  "warnings": [],
  "codeHash": "sha256_abc123..."
}
```

Security analyzer checks for:

- Attempts to access `process`, `require`, `eval`, `Function`
- File system operations (`fs`, `child_process`)
- Network operations outside allowed APIs
- Attempts to escape sandbox
- Malicious patterns (obfuscation, encoding tricks)

#### 2. **Create Integration** with Plugin Code

```bash
POST /api/v1/admin/integrations
Content-Type: application/json
Authorization: Bearer <admin-token>

{
  "type": "my_tracker",
  "name": "My Issue Tracker",
  "description": "Custom integration for internal tracker",
  "plugin_code": "/* validated plugin code */",
  "allow_code_execution": true,
  "config": {
    "base_url": "https://tracker.company.com",
    "api_token": "secret-token"
  }
}
```

**Response**:

```json
{
  "id": "uuid",
  "type": "my_tracker",
  "name": "My Issue Tracker",
  "plugin_code": "/* code */",
  "code_hash": "sha256_abc123...",
  "allow_code_execution": true,
  "trust_level": "admin_reviewed",
  "created_at": "2025-11-30T..."
}
```

#### 3. **Enable for Project** (User Action)

Users can now enable the custom integration for their projects:

```bash
POST /api/v1/integrations
Content-Type: application/json
Authorization: Bearer <user-token>

{
  "project_id": "project-uuid",
  "platform": "my_tracker",
  "config": {
    "base_url": "https://tracker.company.com",
    "api_token": "user-specific-token",
    "project_key": "PROJ"
  }
}
```

#### 4. **Test Integration**

```bash
POST /api/v1/integrations/:id/test
Authorization: Bearer <user-token>
```

If code execution is enabled, this will trigger the plugin in sandbox mode.

#### 5. **Monitor Execution**

Plugin execution is logged in the admin activity logs:

```bash
GET /api/v1/admin/audit-logs?action=plugin_execution&integration_type=my_tracker
```

Logs include:

- Sandbox execution time
- RPC method calls made
- Memory usage
- Success/failure status
- Error messages (sanitized)

### Trust Levels

Custom plugins have trust levels:

- **`admin_reviewed`** - Manually reviewed and approved by admin (default)
- **`auto_approved`** - Passed security analyzer with no warnings (future)
- **`sandboxed`** - Runs in strict sandbox with minimal permissions (current)

All custom plugins run in `sandboxed` mode regardless of trust level.

---

## Webhook Configuration

Webhooks enable bidirectional communication between BugSpotter and external platforms.

### Use Cases

- **Status Sync**: External platform updates ticket status → BugSpotter updates bug report
- **Comment Sync**: External comments → BugSpotter activity log
- **Assignment**: External assignment → BugSpotter notification
- **Resolution**: External ticket closed → BugSpotter auto-resolves bug

### Creating a Webhook

```bash
curl -X POST 'https://api.bugspotter.com/api/v1/admin/integrations/jira/webhooks' \
  -H 'Authorization: Bearer ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "endpoint_url": "https://company.com/webhooks/jira",
    "events": ["issue.created", "issue.updated", "issue.resolved"],
    "active": true
  }'
```

**Response includes secret**:

```json
{
  "id": "uuid",
  "integration_type": "jira",
  "endpoint_url": "https://company.com/webhooks/jira",
  "secret": "whsec_abc123def456...",
  "events": ["issue.created", "issue.updated", "issue.resolved"],
  "active": true
}
```

**⚠️ Important**: Store the `secret` immediately. It cannot be retrieved later.

### Webhook Payload Format

BugSpotter sends webhooks in this format:

```json
{
  "event": "bug_report.created",
  "timestamp": "2025-11-06T12:00:00.000Z",
  "integration_type": "jira",
  "data": {
    "bug_report": {
      "id": "uuid",
      "title": "Login button not working",
      "priority": "high",
      "status": "open",
      "screenshot_url": "https://...",
      "replay_url": "https://..."
    },
    "project": {
      "id": "project_uuid",
      "name": "Production App"
    }
  }
}
```

**Headers**:

```
Content-Type: application/json
X-BugSpotter-Signature: sha256=abc123...
X-BugSpotter-Event: bug_report.created
X-BugSpotter-Delivery: uuid
```

### Verifying Webhook Signatures

**Node.js Example**:

```javascript
const crypto = require('crypto');

function verifyWebhook(rawBody, headers, secret) {
  const signature = headers['x-bugspotter-signature'];

  if (!signature) {
    throw new Error('Missing signature header');
  }

  const [algorithm, hash] = signature.split('=');

  if (algorithm !== 'sha256') {
    throw new Error('Unsupported signature algorithm');
  }

  // CRITICAL: Use raw request body, NOT JSON.stringify(request.body)
  // JSON.stringify property order is not guaranteed and will cause signature mismatches
  const calculatedHash = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');

  if (!crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(calculatedHash))) {
    throw new Error('Invalid signature');
  }

  return true;
}

// Express middleware with raw body capture
const express = require('express');
const app = express();

// CRITICAL: Capture raw body before JSON parsing for signature verification
app.post(
  '/webhooks/bugspotter',
  express.json({
    verify: (req, res, buf) => {
      // Store raw body for signature verification
      req.rawBody = buf;
    },
  }),
  (req, res) => {
    try {
      // Use raw body, not JSON.stringify(req.body)
      verifyWebhook(req.rawBody, req.headers, process.env.BUGSPOTTER_WEBHOOK_SECRET);

      // Process webhook
      const { event, data } = req.body;
      console.log(`Received ${event}:`, data);

      res.status(200).send({ received: true });
    } catch (error) {
      console.error('Webhook verification failed:', error);
      res.status(401).send({ error: 'Invalid signature' });
    }
  }
);
```

**Python Example**:

```python
import hmac
import hashlib
import json

def verify_webhook(request, secret):
    signature = request.headers.get('X-BugSpotter-Signature')

    # Validate signature exists and has correct format
    if not signature or '=' not in signature:
        raise ValueError('Missing or invalid signature')

    try:
        algorithm, hash_value = signature.split('=', 1)
    except ValueError:
        raise ValueError('Invalid signature format')

    if algorithm != 'sha256':
        raise ValueError('Unsupported signature algorithm')

    # Get raw request body for verification
    # CRITICAL: Use request.get_data() to get raw bytes, NOT json.dumps(request.json)
    # JSON serialization order is not guaranteed and will cause signature mismatches
    body = request.get_data()

    calculated_hash = hmac.new(
        secret.encode('utf-8'),
        body,
        hashlib.sha256
    ).hexdigest()

    # Use constant-time comparison to prevent timing attacks
    if not hmac.compare_digest(hash_value, calculated_hash):
        raise ValueError('Invalid signature')

    return True

# Flask route
@app.route('/webhooks/bugspotter', methods=['POST'])
def handle_webhook():
    try:
        verify_webhook(request, os.environ['BUGSPOTTER_WEBHOOK_SECRET'])

        event = request.json['event']
        data = request.json['data']
        print(f'Received {event}: {data}')

        return {'received': True}, 200
    except Exception as e:
        print(f'Webhook verification failed: {e}')
        return {'error': 'Invalid signature'}, 401
```

### Managing Webhooks

**List Webhooks**:

```bash
GET /api/v1/admin/integrations/{type}/webhooks
```

**Update Webhook**:

```bash
PUT /api/v1/admin/integrations/{type}/webhooks/{id}
{
  "endpoint_url": "https://new-url.com",
  "events": ["issue.created"],
  "active": false
}
```

**Delete Webhook**:

```bash
DELETE /api/v1/admin/integrations/{type}/webhooks/{id}
```

---

## Monitoring & Troubleshooting

### Activity Logs

All integration actions are logged with detailed metadata:

```bash
curl -X GET 'https://api.bugspotter.com/api/v1/admin/integrations/activity?integration_type=jira&status=failed&limit=50' \
  -H 'Authorization: Bearer ADMIN_TOKEN'
```

**Log Entry Structure**:

```json
{
  "id": "uuid",
  "integration_type": "jira",
  "bug_id": "bug_uuid",
  "action": "create",
  "status": "failed",
  "duration_ms": 5234,
  "error": "Connection timeout after 5000ms",
  "metadata": {
    "retry_count": 2,
    "http_status": 0
  },
  "created_at": "2025-11-06T11:30:00.000Z"
}
```

**Filter Options**:

- `integration_type`: Filter by integration
- `bug_id`: Find logs for specific bug report
- `status`: `success`, `failed`, `pending`, `skipped`
- `action`: `create`, `update`, `sync`, `test`, `error`

### Common Issues

**1. Connection Timeouts**

**Symptoms**: Integration fails with "Connection timeout"

**Causes**:

- Firewall blocking outbound connections
- External platform down
- Invalid endpoint URL

**Solutions**:

- Test connection manually: `curl https://external-platform.com/api/health`
- Check firewall rules for outbound HTTPS
- Verify endpoint URL in configuration

**2. Authentication Failures**

**Symptoms**: "401 Unauthorized" or "403 Forbidden"

**Causes**:

- Expired API tokens
- Incorrect credentials
- Insufficient permissions

**Solutions**:

- Regenerate API token in external platform
- Verify credentials with test endpoint
- Check user has permission to create issues

**3. Rate Limiting**

**Symptoms**: "429 Too Many Requests"

**Causes**:

- Exceeded external platform rate limits
- Burst of bug reports triggering mass integration

**Solutions**:

- Implement exponential backoff in worker
- Batch integration requests
- Contact external platform for rate limit increase

**4. Field Mapping Errors**

**Symptoms**: Integration succeeds but fields missing

**Causes**:

- Incorrect field mappings in configuration
- Required fields not mapped
- Field type mismatches

**Solutions**:

- Review field mappings: `GET /admin/integrations/{type}/config`
- Test with minimal required fields first
- Consult external platform API documentation

### Health Monitoring

**Integration Status Dashboard**:

```bash
GET /api/v1/admin/integrations
```

Monitors:

- Last sync timestamp
- Success/failure counts
- Average response time
- Current status (active, error, disabled)

**Alerting**:

Set up monitoring for:

- Integration error rate > 5%
- No successful sync in > 1 hour
- Average duration > 5 seconds
- Webhook delivery failures

---

## Best Practices

### Configuration Management

✅ **Do**:

- Store configuration in environment variables or secret manager
- Use separate credentials for development and production
- Rotate API tokens every 90 days
- Test integrations thoroughly before enabling for production

❌ **Don't**:

- Hardcode credentials in application code
- Share API tokens between multiple services
- Use production credentials for testing
- Enable integrations without testing

### Error Handling

✅ **Do**:

- Implement exponential backoff for retries
- Log detailed error messages with context
- Provide user-friendly error messages
- Set maximum retry limits

❌ **Don't**:

- Retry indefinitely without backoff
- Swallow errors silently
- Expose sensitive error details to users
- Block UI while waiting for integration

### Performance Optimization

✅ **Do**:

- Use async/background workers for integrations
- Batch requests when possible
- Cache frequently accessed data
- Monitor response times

❌ **Don't**:

- Make synchronous integration calls in request handlers
- Send individual requests for batch operations
- Fetch unnecessary data
- Ignore performance metrics

### Security Hardening

✅ **Do**:

- Validate all external responses
- Use HTTPS for all endpoints
- Implement request signing (HMAC)
- Audit integration access logs

❌ **Don't**:

- Trust external data without validation
- Use HTTP endpoints
- Skip signature verification for webhooks
- Ignore security warnings in code analysis

### Webhook Reliability

✅ **Do**:

- Implement idempotency using delivery IDs
- Return 2xx status codes quickly (< 3 seconds)
- Process webhooks asynchronously
- Validate signatures before processing

❌ **Don't**:

- Process duplicates without deduplication
- Perform long-running tasks in webhook handler
- Trust unverified webhook payloads
- Return 5xx errors for business logic failures

---

## Migration Guide

### From Legacy Integrations

If migrating from an older integration system:

**1. Export Existing Configurations**:

```bash
# Legacy system
GET /legacy/integrations
```

**2. Create New Integration Types**:

```bash
# BugSpotter
POST /api/v1/admin/integrations
```

**3. Migrate Project Configurations**:

```bash
# For each project
POST /api/v1/integrations/{platform}/{projectId}
```

**4. Test Thoroughly**:

```bash
POST /api/v1/admin/integrations/{type}/test
```

**5. Enable Gradually**:

- Start with non-production projects
- Monitor activity logs closely
- Roll out to production projects in phases

---

## API Reference

For complete API documentation, see [API_DOCUMENTATION.md](./API_DOCUMENTATION.md#integration-endpoints).

**Quick Links**:

- [User Integration Management](./API_DOCUMENTATION.md#user-integration-management)
- [Admin Integration Management](./API_DOCUMENTATION.md#admin-integration-management)
- [Webhook Configuration](./API_DOCUMENTATION.md#webhook-configuration)
- [Activity Logs](./API_DOCUMENTATION.md#get-integration-activity-log)

---

## Support

For integration support:

- **Documentation**: [docs.bugspotter.dev/integrations](https://docs.bugspotter.dev/integrations)
- **API Status**: [status.bugspotter.dev](https://status.bugspotter.dev)
- **GitHub Issues**: [github.com/bugspotter/bugspotter/issues](https://github.com/bugspotter/bugspotter/issues)
- **Email**: integrations@bugspotter.dev

---

**Last Updated**: December 1, 2025  
**Version**: 1.0.0
