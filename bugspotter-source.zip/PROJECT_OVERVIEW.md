# BugSpotter: Project Overview

**Version**: 0.3.0 (Pre-release)  
**Last Updated**: November 29, 2025  
**Test Coverage**: 1,238 tests (1,238 passing - 100%)  
**Architecture**: Production-grade pnpm workspace monorepo

---

## Table of Contents

- [Executive Overview](#executive-overview)
- [System Architecture](#system-architecture)
- [Core Features](#core-features)
- [Technology Stack](#technology-stack)
- [Security Architecture](#security-architecture)
- [Testing Strategy](#testing-strategy)
- [Project Structure](#project-structure)
- [Documentation Index](#documentation-index)
- [Quick Start](#quick-start)
- [Roadmap](#roadmap)

---

## Executive Overview

BugSpotter is a professional bug reporting SDK with session replay capabilities, designed to capture, store, and manage bug reports with rich contextual data. The system combines a lightweight browser SDK (~99KB) with a production-ready backend API, providing developers with comprehensive debugging context including screenshots, session recordings, console logs, network requests, and user metadata.

**Core Value Proposition**: Accelerate bug reproduction and resolution by capturing the complete user context at the moment an error occurs, with built-in PII protection and enterprise-grade security.

### Key Statistics

- **Bundle Size**: ~99KB minified (rrweb included)
- **Test Coverage**: 1,238 passing tests (893 backend + 345 SDK = 100%)
- **Browser Coverage**: 95%+ (ES2017 target: Chrome 60+, Firefox 55+, Safari 11+)
- **Response Times**: <200ms (p95) for bug report creation
- **Memory Footprint**: SDK ~15MB with 30-second replay buffer

---

## System Architecture

### High-Level Design

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Browser Environment                          │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  BugSpotter SDK (99KB)                                         │ │
│  │  • Screenshot Capture (html-to-image)                          │ │
│  │  • Session Replay (rrweb)                                      │ │
│  │  • Console/Network Monitoring                                  │ │
│  │  • PII Sanitization (10+ patterns)                             │ │
│  │  • Modal Widget UI                                             │ │
│  └────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │ HTTPS/REST API
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Fastify Backend (Node 20)                       │
│  ┌──────────────┬──────────────┬──────────────┬──────────────────┐ │
│  │ Auth Layer   │ API Routes   │ Middleware   │ Plugin System    │ │
│  │ • JWT        │ • Projects   │ • CORS       │ • Jira           │ │
│  │ • API Keys   │ • Reports    │ • Helmet     │ • GitHub (plan)  │ │
│  │ • RBAC       │ • Integr.    │ • Rate Limit │ • Linear (plan)  │ │
│  └──────────────┴──────────────┴──────────────┴──────────────────┘ │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │
            ┌────────────────────┼────────────────────┐
            ▼                    ▼                    ▼
    ┌──────────────┐     ┌──────────────┐    ┌──────────────┐
    │ PostgreSQL 16│     │   Redis 7    │    │  S3 Storage  │
    │ • Projects   │     │ • BullMQ     │    │ • Screenshots│
    │ • Reports    │     │ • 4 Queues   │    │ • Replays    │
    │ • Users      │     │ • Workers    │    │ • Attachments│
    │ • Sessions   │     │ • Jobs       │    │ (or Local FS)│
    └──────────────┘     └──────────────┘    └──────────────┘
```

### Architectural Patterns

**Repository Pattern** - Each entity has dedicated repository extending BaseRepository  
**Strategy Pattern** - Error handlers use matcher/processor pairs  
**Factory Pattern** - DatabaseClient uses private constructor + static factory  
**Facade Pattern** - Sanitizer/Modal coordinate multiple subsystems  
**Template Method Pattern** - Base storage defines algorithm, subclasses implement specifics

See: [.github/copilot-instructions.md](./.github/copilot-instructions.md#core-architectural-patterns) for detailed pattern documentation

---

## Core Features

### 1. Bug Report Capture (SDK)

**Screenshot Capture**

- CSP-safe DOM-to-image using html-to-image
- Full-page capture as Base64 PNG (~500ms average)
- Shadow DOM and web component support

**Session Replay** (rrweb Integration)

- Records DOM mutations, mouse movements, clicks, scrolls
- Circular buffer maintains last 15-30 seconds (configurable)
- Performance-optimized event sampling (mousemove: 50ms, scroll: 100ms)
- Compressed storage (~1MB per 60-second session)

**Console & Network Monitoring**

- All console levels: log, warn, error, info, debug
- Fetch API and XMLHttpRequest interception
- Request/response timing, status codes, headers
- Circular reference handling

**Browser Metadata**

- Auto-detects browser, OS, viewport
- User agent, URL, timestamp
- Custom field support

### 2. PII Sanitization (SDK)

Automatic detection and redaction before transmission:

**Built-in Patterns**

- Email addresses → `[REDACTED-EMAIL]`
- Phone numbers (international) → `[REDACTED-PHONE]`
- Credit cards (Visa, MC, Amex, Discover) → `[REDACTED-CREDITCARD]`
- Social Security Numbers → `[REDACTED-SSN]`
- Kazakhstan IIN/BIN → `[REDACTED-IIN]`
- IP addresses (IPv4/IPv6) → `[REDACTED-IP]`

**Coverage**: Console logs, network data, error stack traces, DOM text, metadata

**Performance**: <10ms overhead per bug report

### 3. Backend API (REST)

**Project Management** - Create/update/delete projects, API key generation/rotation  
**Bug Report Management** - CRUD operations, soft delete (30-day recovery), full-text search, pagination  
**User Authentication** - JWT (1h access + 7d refresh), httpOnly cookies, RBAC  
**Integration System** - Plugin architecture for Jira, GitHub, Linear, Slack (roadmap)

### 4. Storage Layer

**Template Method Pattern**

- `BaseStorageService` defines upload algorithm
- Subclasses implement storage-specific logic (S3, local filesystem)

**S3 Storage** (Production)

- Multipart uploads (5MB chunks, 4 concurrent)
- True streaming (constant ~5MB memory)
- Retry logic with exponential backoff

**Local Storage** (Development)

- Filesystem operations with `fs/promises`
- Streaming with `pipeline()` for large files

**Defense in Depth Security**

1. Whitelist validation (storage types)
2. ID validation (UUID format + path traversal check)
3. Filename sanitization (basename extraction)
4. Final key sanitization (S3 key format)

### 5. Background Job Processing (BullMQ)

**4 Queues**

- `screenshots`: Image optimization (concurrency: 5)
- `replays`: Session replay chunking (concurrency: 3)
- `integrations`: External platform sync (concurrency: 10)
- `notifications`: Email, Slack, webhooks (concurrency: 5)

**Features**: Concurrent processing, automatic retries (3 attempts), job status tracking, health checks

**Performance**: ~2,500 jobs/second throughput

---

## Technology Stack

### Frontend SDK (Browser)

- **Language**: TypeScript (ES2017 target for 95%+ coverage)
- **Build**: Webpack 5
- **Key Libraries**: rrweb 2.0.0-alpha.4, html-to-image 1.11.13
- **Bundle Size**: ~99KB minified

### Backend API (Server)

- **Runtime**: Node.js 20+ (ES2023 features)
- **Framework**: Fastify 5.6.1
- **Database**: PostgreSQL 16
- **Queue**: BullMQ 5.x (Redis-backed)
- **Storage**: AWS S3 SDK v3
- **Security**: Helmet, CORS, rate limiting, AES-256-GCM encryption
- **Authentication**: JWT + API keys (`bgs_` prefix)

### Development & Testing

- **Monorepo**: pnpm workspaces (4 packages + 2 apps)
- **Testing**: Vitest + Testcontainers + Playwright
- **CI/CD**: GitHub Actions
- **Code Quality**: ESLint, Prettier, TypeScript strict mode

---

## Security Architecture

### Authentication & Authorization

**Dual Authentication**

- **API Keys**: `bgs_` prefix, no expiration, project-scoped (SDK→backend)
- **JWT Tokens**: 1h access + 7d refresh, user-scoped (user→backend)

**httpOnly Cookie Security** ✅

- Refresh tokens in httpOnly cookies (JavaScript-inaccessible)
- Access tokens in memory only (React state)
- Cookie options: `httpOnly: true`, `secure: true`, `sameSite: 'strict'`
- XSS attack protection

**RBAC**: Admin (full access), Viewer (read-only), Owner (project-specific)

### Security Best Practices

**SQL Injection Protection** (Three-Layer Defense)

1. Parameterized queries (`$1`, `$2` placeholders)
2. Identifier validation (`^[a-zA-Z0-9_]+$` regex)
3. Input validation (pagination 1-1000, batch max 1000)

**Path Traversal Prevention**

1. Whitelist validation
2. UUID format validation
3. `path.basename()` extraction
4. Control character removal
5. URL decoding safety
6. Final key sanitization

**Encryption**

- **Credentials**: AES-256-GCM (Jira tokens, OAuth secrets)
- **Passwords**: bcrypt (cost factor 10)
- **Master Key**: scrypt key derivation (N=16384)

**HTTP Security Headers** (Helmet)

- Content Security Policy (no `unsafe-inline`, explicit sources)
- Cross-Origin Embedder Policy: `require-corp`
- X-Frame-Options: `DENY`
- Strict-Transport-Security

**Rate Limiting**: 100 requests per 15 minutes per IP

---

## Testing Strategy

### Test Distribution

**Total: 1,238 tests (100% passing)**

- **Backend**: 893 tests (unit + integration + storage + queue + auth + notifications + API)
- **SDK**: 345 tests (unit + E2E + Playwright browser tests)

### Test Infrastructure

**Testcontainers** (Zero Manual Setup)

- Automatically launches PostgreSQL 16 and Redis 7 containers
- Runs migrations and seeds test data
- Executes all test suites
- Cleanup after completion
- **Requirement**: Docker must be running

**Test Types**

1. Unit Tests (pure logic, mocked dependencies)
2. Integration Tests (real database + Redis + storage)
3. E2E Tests (full API server + all services)
4. Load Tests (100+ concurrent operations)
5. Browser Tests (Playwright: Chrome, Firefox, Safari)

### CI/CD

**GitHub Actions** (`.github/workflows/ci.yml`)

- **Triggers**: Push to `main`/`develop`, PRs to protected branches
- **Jobs**: Lint, typecheck, unit tests, integration tests, build
- **Feature Branches**: Only run on PR (prevent duplicate runs)

---

## Project Structure

```
bugspotter/
├── .github/
│   ├── copilot-instructions.md  # AI assistant coding standards
│   └── workflows/ci.yml         # GitHub Actions CI/CD
├── packages/
│   ├── backend/                 # Fastify API (893 tests)
│   │   ├── src/
│   │   │   ├── api/             # Routes, middleware, schemas
│   │   │   ├── db/              # Repositories, migrations
│   │   │   ├── integrations/    # Plugin system, Jira
│   │   │   ├── queue/           # BullMQ jobs, workers
│   │   │   ├── retention/       # Data retention policies
│   │   │   └── storage/         # S3/local storage
│   │   └── tests/               # Unit + integration tests
│   ├── sdk/                     # Browser SDK (345 tests)
│   │   ├── src/
│   │   │   ├── capture/         # Screenshot, console, network
│   │   │   ├── core/            # BugSpotter class, transport
│   │   │   ├── session-replay/  # rrweb integration
│   │   │   ├── utils/           # Sanitizer, helpers
│   │   │   └── widget/          # Modal, button UI
│   │   └── tests/               # Unit + E2E + Playwright
│   ├── types/                   # Shared TypeScript types
│   └── backend-mock/            # Development mock server
├── apps/
│   ├── admin/                   # React admin panel (Docker + nginx)
│   │   ├── src/                 # React + TypeScript + Tailwind
│   │   ├── Dockerfile           # Multi-stage nginx build
│   │   └── nginx.conf           # Security headers + API proxy
│   └── demo/                    # Interactive demo application
├── README.md                    # Project overview
├── PROJECT_OVERVIEW.md          # This comprehensive document
└── pnpm-workspace.yaml          # Monorepo configuration
```

---

## Documentation Index

### Essential Documentation

**Root Level**

- [README.md](./README.md) - Project overview and quick start
- [PROJECT_OVERVIEW.md](./PROJECT_OVERVIEW.md) - This comprehensive guide
- [DOCKER.md](./DOCKER.md) - Docker deployment guide
- [CONTRIBUTING.md](./CONTRIBUTING.md) - Contribution guidelines
- [CHANGELOG.md](./CHANGELOG.md) - Version history
- [WORKFLOWS.md](./WORKFLOWS.md) - Development workflows and CI/CD

**Setup & Testing**

- [SETUP_TEST_SERVICES.md](./SETUP_TEST_SERVICES.md) - Third-party service setup (Gmail, Slack, Discord)
- [TESTING_SCRIPTS.md](./TESTING_SCRIPTS.md) - Test script usage
- [ACT_GUIDE.md](./ACT_GUIDE.md) - Running GitHub Actions locally
- [ROLES_AND_PERMISSIONS.md](./ROLES_AND_PERMISSIONS.md) - User roles and RBAC

**GitHub Actions / CI**

- [.github/copilot-instructions.md](./.github/copilot-instructions.md) - AI coding guidelines
- [.github/NOTIFICATION_INTEGRATION_SETUP.md](./.github/NOTIFICATION_INTEGRATION_SETUP.md) - CI notification setup

### Package Documentation

**Admin Panel** (apps/admin/)

- [README.md](./apps/admin/README.md) - Admin panel overview
- [SECURITY.md](./apps/admin/SECURITY.md) - Security best practices (tokens, CSP)
- [REACT_PATTERNS.md](./apps/admin/REACT_PATTERNS.md) - React anti-patterns guide
- [E2E_TESTING.md](./apps/admin/E2E_TESTING.md) - Comprehensive E2E test guide (consolidated)
- [TESTING_STRATEGY.md](./apps/admin/TESTING_STRATEGY.md) - React Testing Library patterns
- [DEPLOYMENT.md](./apps/admin/DEPLOYMENT.md) - Deployment guide

**Backend** (packages/backend/)

- [README.md](./packages/backend/README.md) - Backend API documentation
- [TESTING.md](./packages/backend/TESTING.md) - Testing infrastructure
- [docs/API_KEY_MANAGEMENT.md](./packages/backend/docs/API_KEY_MANAGEMENT.md) - API key system
- [docs/EMAIL_INTEGRATION.md](./packages/backend/docs/EMAIL_INTEGRATION.md) - Email providers
- [tests/integration/E2E_TEST_FLOW_GUIDE.md](./packages/backend/tests/integration/E2E_TEST_FLOW_GUIDE.md) - Backend E2E architecture

**Module Documentation**

- [src/queue/README.md](./packages/backend/src/queue/README.md) - Queue system
- [src/storage/README.md](./packages/backend/src/storage/README.md) - Storage layer
- [src/retention/README.md](./packages/backend/src/retention/README.md) - Retention policies
- [src/integrations/PLUGIN_SYSTEM.md](./packages/backend/src/integrations/PLUGIN_SYSTEM.md) - Plugin architecture
- [src/integrations/jira/README.md](./packages/backend/src/integrations/jira/README.md) - Jira integration

**SDK** (packages/sdk/)

- [README.md](./packages/sdk/README.md) - SDK API reference
- [docs/SESSION_REPLAY.md](./packages/sdk/docs/SESSION_REPLAY.md) - rrweb integration
- [docs/PUBLISHING.md](./packages/sdk/docs/PUBLISHING.md) - npm publishing guide
- [docs/FRAMEWORK_INTEGRATION.md](./packages/sdk/docs/FRAMEWORK_INTEGRATION.md) - Framework guides

---

## Quick Start

### Prerequisites

- **Node.js 20+** with pnpm installed
- **Docker Desktop** running (for PostgreSQL + Redis)
- **Git** for version control

### Development Setup

```bash
# Clone and install
git clone git@github.com:apexbridge-tech/bugspotter.git
cd bugspotter
pnpm install

# Start backend (requires Docker for PostgreSQL + Redis)
pnpm --filter @bugspotter/backend dev

# Start SDK dev server
pnpm --filter @bugspotter/sdk dev

# Run demo app
cd apps/demo && python -m http.server 8080
```

### Common Commands

```bash
# Development
pnpm dev              # Start all packages in dev mode
pnpm --filter @bugspotter/backend dev  # Backend only

# Building
pnpm build            # Build all packages
pnpm --filter @bugspotter/sdk build    # SDK only

# Testing
pnpm test             # Run all tests (requires Docker)
pnpm test:watch       # Watch mode
pnpm test:coverage    # Coverage report

# Code Quality
pnpm lint             # Lint all packages
pnpm format           # Format with Prettier
pnpm format:check     # Check formatting
```

---

## Roadmap

### Current Phase: Pre-Release (v0.3.0)

✅ **Completed**

- Core features (bug reporting, screenshots, session replay)
- Admin control panel (React + TypeScript)
- httpOnly cookie authentication
- Email integration guide (5 providers)
- Jira integration plugin (v1.0.0)
- Plugin architecture with auto-discovery
- Comprehensive test coverage (1,238 tests, 100%)
- PII sanitization (10+ patterns)
- Docker deployment infrastructure

⏳ **In Progress**

- npm publication preparation
- Documentation consolidation

### Post-Release (v1.0)

- [ ] GitHub integration plugin
- [ ] Linear integration plugin
- [ ] Slack notifications plugin
- [ ] Email notifications (implement chosen provider)
- [ ] Webhook system for custom integrations
- [ ] Bug report dashboard in admin panel
- [ ] Session replay viewer in admin panel

### Future Enhancements

- [ ] Machine learning for duplicate detection
- [ ] Automatic bug categorization
- [ ] Performance monitoring integration
- [ ] Mobile SDK (React Native)
- [ ] Chrome/Firefox browser extension
- [ ] Framework integrations (React, Vue, Angular)

---

## Quick Navigation by Role

### For New Users

1. Start with [README.md](./README.md)
2. Follow [DOCKER.md](./DOCKER.md) for deployment
3. Review this PROJECT_OVERVIEW.md for architecture

### For Developers

1. Read this PROJECT_OVERVIEW.md
2. Review [CONTRIBUTING.md](./CONTRIBUTING.md)
3. Check [.github/copilot-instructions.md](./.github/copilot-instructions.md) for coding standards
4. Review package-specific READMEs

### For Testers

1. [SETUP_TEST_SERVICES.md](./SETUP_TEST_SERVICES.md) - Third-party service setup
2. [apps/admin/E2E_TESTING.md](./apps/admin/E2E_TESTING.md) - E2E test guide
3. [packages/backend/TESTING.md](./packages/backend/TESTING.md) - Backend tests
4. [TESTING_SCRIPTS.md](./TESTING_SCRIPTS.md) - Test script usage

### For DevOps/Admins

1. [DOCKER.md](./DOCKER.md) - Docker deployment
2. [ROLES_AND_PERMISSIONS.md](./ROLES_AND_PERMISSIONS.md) - RBAC system
3. [apps/admin/SECURITY.md](./apps/admin/SECURITY.md) - Security guidelines
4. [ACT_GUIDE.md](./ACT_GUIDE.md) - Local CI testing

---

## Support & Contact

- **Issues**: https://github.com/apexbridge-tech/bugspotter/issues
- **Discussions**: https://github.com/apexbridge-tech/bugspotter/discussions
- **Email**: support@apexbridge.tech

---

**Copyright © 2025 ApexBridge Technologies**  
**License**: MIT

---

**Last Updated**: November 29, 2025 | **Test Status**: 1,238/1,238 passing (100%)
