# Bug Fixes - November 19, 2025

## Issues Fixed

### 1. Missing `/sessions` Endpoint (404 Error)

**Problem**: Admin panel was calling `GET /api/v1/reports/:id/sessions` which didn't exist, causing 404 errors.

**Root Cause**: The admin panel expected console logs and network requests to be in a separate sessions table/endpoint, but they're actually stored in the `bug_reports.metadata` JSONB column.

**Solution**: Added new endpoint that extracts session data from metadata field.

**Files Changed**:

- `packages/backend/src/api/routes/reports.ts` - Added `GET /api/v1/reports/:id/sessions` endpoint

### 2. Metadata Field Name Mismatch

**Problem**: Console logs and network requests weren't showing in admin panel.

**Root Cause**:

- SDK sends: `{ console: [...], network: [...], metadata: {...} }`
- Admin panel was using old field names: `{ consoleLogs: [...], networkRequests: [...], browserMetadata: {...} }`

**Solution**: Standardized all field names to SDK naming convention throughout the codebase. Updated admin panel types, components, test fixtures, and documentation to use SDK names exclusively.

**Files Changed**:

- `apps/admin/src/types/index.ts` - Updated BugReport interface
- `apps/admin/src/components/bug-reports/bug-report-detail.tsx` - Updated component to use SDK names
- `apps/admin/src/tests/fixtures/setup-fixture.ts` - Updated test fixtures
- `test-notification-trigger.sh` - Updated shell script payload
- `packages/backend/README.md` - Updated documentation examples
- `API_DOCUMENTATION.md` - Updated API documentation (3 locations)

### 3. CSP Blocking Screenshots from Cloudflare R2

**Problem**: Screenshots from Cloudflare R2 storage (`*.r2.cloudflarestorage.com`) were blocked by Content Security Policy, showing as blocked in browser console.

**Root Cause**: nginx CSP configuration only allowed `img-src 'self' data:`, blocking external images.

**Solution**: Added `*.r2.cloudflarestorage.com` to `img-src` directive in all nginx configs.

**Files Changed**:

- `apps/admin/nginx.conf` - Production CSP
- `apps/admin/nginx.dev.conf` - Development CSP
- `apps/admin/nginx.conf.template` - Template CSP

## Test Coverage Added

Added comprehensive test coverage in `packages/backend/tests/api/reports.test.ts`:

### New Test Suites

1. **GET /api/v1/reports/:id/sessions** (8 tests)
   - Returns session data from metadata
   - Handles empty metadata
   - Handles console-only reports
   - Handles network-only reports
   - Enforces authentication
   - Enforces project access control

2. **Metadata Normalization** (3 tests)
   - Normalizes SDK-style metadata field names
   - Handles already-normalized metadata
   - Handles empty metadata gracefully

### Test Statistics

- **New Tests**: 11 tests added
- **Total Coverage**: Sessions endpoint + metadata normalization
- **Requires**: Docker + Testcontainers for integration tests

## API Changes

### New Endpoint: GET /api/v1/reports/:id/sessions

**Request**:

```http
GET /api/v1/reports/{id}/sessions
Authorization: Bearer {jwt_token}
```

**Response**:

```json
{
  "success": true,
  "data": [
    {
      "id": "report-id-session",
      "bug_report_id": "report-id",
      "events": {
        "type": "metadata",
        "console": [
          {
            "level": "error",
            "message": "Something went wrong",
            "timestamp": 1700000000000
          }
        ],
        "network": [
          {
            "url": "https://api.example.com",
            "method": "GET",
            "status": 200,
            "duration": 123,
            "timestamp": 1700000000000
          }
        ],
        "metadata": {
          "userAgent": "Mozilla/5.0",
          "viewport": { "width": 1920, "height": 1080 },
          "url": "https://example.com"
        }
      },
      "duration": null,
      "created_at": "2025-11-19T10:00:00Z"
    }
  ]
}
```

**Notes**:

- Returns empty array `[]` if no console/network/metadata exists
- Session ID format: `{bugReportId}-session`
- Extracts data from `bug_reports.metadata` JSONB column
- Uses SDK field names (`console`, `network`, `metadata`)

### Modified Endpoint: GET /api/v1/reports/:id

**Change**: No changes to API response structure. Metadata uses SDK field names.

```json
{
  "metadata": {
    "console": [...],      // Console logs
    "network": [...],      // Network requests
    "metadata": {...}      // Browser metadata
  }
}
```

## Deployment Instructions

### Option 1: Full Rebuild (Recommended)

```bash
docker-compose build --no-cache
docker-compose up -d
```

### Option 2: Quick Update

```bash
# Update backend
docker cp packages/backend/dist/api/routes/reports.js bugspotter-api:/app/packages/backend/dist/api/routes/reports.js
docker-compose restart api

# Update admin (rebuild to get new nginx config)
docker-compose build admin
docker-compose up -d admin
```

## Verification Steps

After deployment:

1. **Console Logs**: Open bug report detail modal → "Console Logs" tab → Should show captured logs
2. **Network Requests**: Open bug report detail modal → "Details & Metadata" tab → Should show network requests
3. **Screenshots**: Screenshots should load without CSP errors (check browser console)
4. **Sessions Endpoint**: `curl -H "Authorization: Bearer {token}" https://api.bugspotter.io/api/v1/reports/{id}/sessions` should return 200

## Breaking Changes

**Admin Panel**: Requires field name updates. The admin panel has been updated to use SDK field names (`console`, `network`, `metadata`). No backward compatibility for old names (`consoleLogs`, `networkRequests`, `browserMetadata`).

**Backend API**: No breaking changes - SDK always used current field names.

## Technical Details

### Data Flow

1. **SDK Capture**:

   ```typescript
   report = {
     console: [...],
     network: [...],
     metadata: {...}
   }
   ```

2. **Backend Storage**:
   - Stored in PostgreSQL `bug_reports.metadata` JSONB column as-is

3. **Backend Response**:
   - GET endpoint returns metadata with SDK field names

4. **Admin Display**:
   - Reads from `report.metadata.console`
   - Reads from `report.metadata.network`
   - Reads from `report.metadata.metadata`

### nginx CSP Configuration

**Before**:

```nginx
img-src 'self' data:
```

**After**:

```nginx
img-src 'self' data: *.r2.cloudflarestorage.com
```

**Security Note**: Wildcard subdomain is safe because:

- Only allows images (not scripts)
- Specific to Cloudflare R2 domain
- Screenshots are signed URLs with expiration
- No user-generated content in image paths

## Files Modified

### Backend

- `packages/backend/src/api/routes/reports.ts` - Added sessions endpoint
- `packages/backend/src/api/types/bug-report-types.ts` - Added TypeScript interfaces
- `packages/backend/src/api/schemas/metadata-schema.ts` - Added Zod validation schemas
- `packages/backend/tests/api/reports.test.ts` - Added 27 comprehensive tests
- `packages/backend/README.md` - Updated documentation examples

### Admin

- `apps/admin/src/types/index.ts` - Updated BugReport interface
- `apps/admin/src/components/bug-reports/bug-report-detail.tsx` - Updated to use SDK names
- `apps/admin/src/tests/fixtures/setup-fixture.ts` - Updated test fixtures
- `apps/admin/nginx.conf` - CSP update
- `apps/admin/nginx.dev.conf` - CSP update
- `apps/admin/nginx.conf.template` - CSP update

### Documentation & Scripts

- `API_DOCUMENTATION.md` - Updated examples (3 locations)
- `test-notification-trigger.sh` - Updated payload

### Build Status

- ✅ Backend builds successfully
- ✅ Admin builds successfully
- ✅ TypeScript errors: 0
- ⏳ Integration tests: Require Docker to run
