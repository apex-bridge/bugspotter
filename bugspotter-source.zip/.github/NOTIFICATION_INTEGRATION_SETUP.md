# Setting Up Automated Notification Integration Tests

This guide explains how to configure automated integration tests for notification channels in your GitHub repository.

---

## Overview

The notification integration tests run automatically:

- **Daily**: At 2 AM UTC via scheduled workflow
- **Manual**: Triggered from GitHub Actions UI
- **Per-channel**: Can enable/disable individual channels

Tests verify real notification delivery to external services (Email, Slack, Discord, Teams, Webhooks).

---

## Quick Setup (5 minutes)

### 1. Create Test Accounts

Create dedicated test accounts for each notification channel you want to test:

- **Email**: Gmail or Outlook test account
- **Slack**: Test workspace with webhook
- **Discord**: Test server with webhook
- **Teams**: Test team with webhook
- **Webhook**: Use webhook.site or your own endpoint

### 2. Configure GitHub Secrets

Go to your repository: **Settings → Secrets and variables → Actions → New repository secret**

Add secrets for each channel you want to test:

#### Email (SMTP) - Required secrets:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=bugspotter-test@gmail.com
SMTP_PASS=your-16-character-app-password
EMAIL_FROM_ADDRESS=bugspotter-test@gmail.com
EMAIL_RECIPIENTS=recipient1@gmail.com,recipient2@gmail.com  # Supports multiple recipients
```

#### Slack - Required secrets:

```
SLACK_TEST_WEBHOOK_URL=https://hooks.slack.com/services/T00/B00/XXX
SLACK_TEST_CHANNEL=#bugspotter-test
```

#### Discord - Required secrets:

```
DISCORD_TEST_WEBHOOK_URL=https://discord.com/api/webhooks/123/abc
```

#### Microsoft Teams - Required secrets:

```
TEAMS_TEST_WEBHOOK_URL=https://outlook.office.com/webhook/xxx
```

#### Generic Webhook - Required secrets:

```
WEBHOOK_TEST_URL=https://webhook.site/your-unique-id
```

### 3. Run Tests

**Automatic**: Tests run daily at 2 AM UTC automatically

**Manual**: Go to **Actions → Notification Integration Tests → Run workflow**

---

## Detailed Setup Instructions

### Email (Gmail with App Password)

1. **Create Gmail test account**:
   - Go to https://accounts.google.com
   - Create account: `bugspotter-test@gmail.com`

2. **Enable 2-Factor Authentication**:
   - Account settings → Security → 2-Step Verification
   - Follow the setup wizard

3. **Generate App Password**:
   - Account settings → Security → App passwords
   - Select "Mail" and "Other (Custom name)"
   - Name it "BugSpotter Integration Tests"
   - Copy the 16-character password

4. **Add to GitHub Secrets**:
   ```
   SMTP_HOST = smtp.gmail.com
   SMTP_PORT = 587
   SMTP_SECURE = false
   SMTP_USER = bugspotter-test@gmail.com
   SMTP_PASS = xxxx xxxx xxxx xxxx (16 chars, remove spaces)
   EMAIL_FROM_ADDRESS = bugspotter-test@gmail.com
   ```

### Slack Webhook

1. **Create test workspace** (or use existing):
   - Go to https://slack.com/create
   - Create workspace: "BugSpotter Tests"

2. **Create channel**:
   - Create channel `#bugspotter-test`

3. **Create Incoming Webhook**:
   - Go to https://api.slack.com/apps
   - Create New App → From scratch
   - Name: "BugSpotter Integration Tests"
   - Select workspace
   - Features → Incoming Webhooks → Activate
   - Add New Webhook to Workspace
   - Select `#bugspotter-test` channel
   - Copy webhook URL

4. **Add to GitHub Secrets**:
   ```
   SLACK_TEST_WEBHOOK_URL = https://hooks.slack.com/services/T.../B.../...
   SLACK_TEST_CHANNEL = #bugspotter-test
   ```

### Discord Webhook

1. **Create test server** (or use existing):
   - Discord → + icon → Create My Own → For me and my friends
   - Name: "BugSpotter Tests"

2. **Create channel**:
   - Right-click server → Create Channel
   - Name: "bugspotter-test"

3. **Create webhook**:
   - Right-click channel → Edit Channel
   - Integrations → Webhooks → New Webhook
   - Name: "BugSpotter Integration Tests"
   - Copy Webhook URL

4. **Add to GitHub Secrets**:
   ```
   DISCORD_TEST_WEBHOOK_URL = https://discord.com/api/webhooks/123.../abc...
   ```

### Microsoft Teams Webhook

1. **Create test team** (or use existing):
   - Teams → Join or create a team → Create team
   - Name: "BugSpotter Tests"

2. **Create channel**:
   - Team → + → Channel
   - Name: "bugspotter-test"

3. **Create webhook**:
   - Channel → ⋯ → Connectors
   - Add → Incoming Webhook → Configure
   - Name: "BugSpotter Integration Tests"
   - Create → Copy URL

4. **Add to GitHub Secrets**:
   ```
   TEAMS_TEST_WEBHOOK_URL = https://outlook.office.com/webhook/xxx...
   ```

### Generic Webhook (webhook.site)

1. **Get test endpoint**:
   - Go to https://webhook.site
   - Copy your unique URL (refreshes automatically)

2. **Add to GitHub Secrets**:
   ```
   WEBHOOK_TEST_URL = https://webhook.site/your-unique-id
   ```

**Note**: webhook.site URLs expire after inactivity. For permanent testing, use your own endpoint.

---

## Running Tests Manually

### From GitHub UI

1. Go to **Actions** tab
2. Select **Notification Integration Tests**
3. Click **Run workflow**
4. Check/uncheck channels to test
5. Click **Run workflow**

### From Local Machine

```bash
# Set environment variables
export RUN_INTEGRATION_TESTS=true
export SMTP_HOST=smtp.gmail.com
export SMTP_USER=your-test@gmail.com
export SMTP_PASS=your-app-password
# ... add other variables

# Run all integration tests
pnpm --filter @bugspotter/backend run test:notifications

# Run specific channel test
pnpm --filter @bugspotter/backend run test:notifications -- --grep "Email"
pnpm --filter @bugspotter/backend run test:notifications -- --grep "Slack"
```

---

## Monitoring Test Results

### View Test Results

1. **Actions tab**: See workflow run status
2. **Artifacts**: Download detailed test reports (retained 30 days)
3. **Issues**: Automatic issue created on failure

### Test Artifacts

Each test run uploads:

- Test results markdown report
- Coverage reports
- Test logs

Download from: **Actions → Workflow run → Artifacts**

### Failure Alerts

When scheduled tests fail, an issue is automatically created with:

- Run ID and link
- Timestamp
- Potential causes
- Troubleshooting steps

---

## Troubleshooting

### Tests Not Running

**Issue**: Workflow shows "skipped"

**Cause**: Secrets not configured

**Fix**: Verify secrets are set in repository settings. Secrets must match exact names shown above.

---

### Email Tests Failing

**Common Issues**:

1. **Invalid credentials**:
   - ❌ Used account password instead of app password
   - ✅ Generate app password with 2FA enabled

2. **Port blocked**:
   - ❌ Port 587 blocked by firewall
   - ✅ GitHub Actions runners have port 587 open

3. **Rate limiting**:
   - ❌ Too many requests
   - ✅ Tests run daily, well within limits

---

### Webhook Tests Failing

**Common Issues**:

1. **Expired webhook**:
   - ❌ Webhook deleted or expired
   - ✅ Regenerate webhook in service settings

2. **Invalid URL**:
   - ❌ Typo in webhook URL
   - ✅ Copy-paste directly from service

3. **Service outage**:
   - ❌ External service down
   - ✅ Check service status page

---

## Security Best Practices

### ✅ DO

- Use dedicated test accounts
- Rotate credentials every 90 days
- Use minimal permissions
- Monitor test account activity
- Delete old test data regularly

### ❌ DON'T

- Use production credentials
- Share test account credentials
- Commit credentials to repository
- Leave unused webhooks active
- Use personal accounts for testing

---

## Scheduling

### Current Schedule

- **Daily at 2 AM UTC** (automatic)
- **Manual trigger** (on-demand)

### Customize Schedule

Edit `.github/workflows/notification-integration-tests.yml`:

```yaml
schedule:
  # Daily at 2 AM UTC
  - cron: '0 2 * * *'

  # Twice daily (2 AM and 2 PM UTC)
  # - cron: '0 2,14 * * *'

  # Weekly on Monday at 2 AM UTC
  # - cron: '0 2 * * 1'

  # Hourly
  # - cron: '0 * * * *'
```

---

## Advanced Configuration

### Conditional Testing

Test only specific channels by setting secrets:

- **Email only**: Set only `SMTP_*` secrets
- **Webhooks only**: Set only webhook URL secrets
- **All channels**: Set all secrets

Tests automatically skip channels without configured secrets.

### Custom Test Endpoints

Replace webhook.site with your own endpoint:

```bash
# Deploy simple webhook receiver
# Example: https://github.com/webhookrelay/webhookrelay
# Or use: https://beeceptor.com

WEBHOOK_TEST_URL=https://your-domain.com/webhook-test
```

### Integration with Monitoring

Export test results to monitoring systems:

```yaml
# Add to workflow
- name: Send results to Datadog
  run: |
    curl -X POST https://api.datadoghq.com/api/v1/events \
      -H "DD-API-KEY: ${{ secrets.DATADOG_API_KEY }}" \
      -d @test-results.json
```

---

## Cost Considerations

### Free Tier Limits

All test services have generous free tiers:

- **GitHub Actions**: 2,000 minutes/month (free for public repos)
- **Gmail**: Unlimited (with app password)
- **Slack**: 10 webhooks in free plan
- **Discord**: Unlimited webhooks
- **Teams**: Included in Microsoft 365
- **webhook.site**: Free with limitations

### Estimated Usage

- **Per test run**: ~2-5 minutes
- **Daily schedule**: 60-150 minutes/month
- **Well within free tier**: ✅

---

## Support

### Documentation

- [apps/admin/NOTIFICATION_E2E_TESTS.md](../apps/admin/NOTIFICATION_E2E_TESTS.md) - Complete E2E test setup
- [SETUP_TEST_SERVICES.md](../SETUP_TEST_SERVICES.md) - Service setup guide
- [EMAIL_INTEGRATION.md](../packages/backend/docs/EMAIL_INTEGRATION.md) - Email setup guide
- [GitHub Actions Docs](https://docs.github.com/en/actions) - Workflow syntax

### Getting Help

1. Check workflow logs in Actions tab
2. Review test artifacts for detailed errors
3. Consult troubleshooting section above
4. Create issue with workflow run link

---

## Summary Checklist

Setup automated notification integration tests:

- [ ] Create test accounts for each channel
- [ ] Configure GitHub repository secrets
- [ ] Verify secrets in GitHub settings
- [ ] Trigger manual test run to verify
- [ ] Monitor first scheduled run (2 AM UTC next day)
- [ ] Review test results in Actions tab
- [ ] Set up failure alerts (automatic)
- [ ] Schedule credential rotation (every 90 days)

**Setup time**: ~15-30 minutes  
**Maintenance**: ~15 minutes every 3 months  
**Value**: Continuous confidence in notification delivery ✨
