# GitHub Secrets for Notification Integration Tests

This document describes how to configure GitHub Actions secrets for notification integration testing.

## Overview

The `notification-tests.yml` workflow runs integration tests that verify actual delivery to Email, Slack, and Discord services. These tests require real service credentials stored as GitHub repository secrets.

**Security**: Secrets are only exposed to workflows running on protected branches (`main`, `develop`).

## Required Secrets

Navigate to your repository → Settings → Secrets and variables → Actions → New repository secret

### Email (SMTP/Gmail)

**Required for email-delivery.test.ts**

| Secret Name           | Description                   | Example                |
| --------------------- | ----------------------------- | ---------------------- |
| `SMTP_HOST`           | SMTP server hostname          | `smtp.gmail.com`       |
| `SMTP_PORT`           | SMTP server port              | `587`                  |
| `SMTP_USER`           | SMTP username (email)         | `your-email@gmail.com` |
| `SMTP_PASS`           | SMTP password or app password | `your-app-password`    |
| `SMTP_FROM`           | From email address            | `your-email@gmail.com` |
| `SMTP_TEST_RECIPIENT` | Test recipient email          | `test@example.com`     |

**Gmail App Password Setup**:

1. Enable 2-Step Verification on your Google account
2. Go to https://myaccount.google.com/apppasswords
3. Generate an app password for "Mail"
4. Use the 16-character password as `SMTP_PASS`

### Slack

**Required for slack-delivery.test.ts**

| Secret Name              | Description                     | Example                                                                     |
| ------------------------ | ------------------------------- | --------------------------------------------------------------------------- |
| `SLACK_TEST_WEBHOOK_URL` | Incoming webhook URL            | `https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX` |
| `SLACK_BOT_TOKEN`        | Bot user OAuth token (optional) | `xoxb-your-bot-token`                                                       |
| `SLACK_TEST_CHANNEL_ID`  | Channel ID for verification     | `C0123456789`                                                               |

**Webhook Setup**:

1. Go to https://api.slack.com/apps
2. Create a new app or select existing
3. Enable Incoming Webhooks → Add New Webhook to Workspace
4. Select a test channel → Copy webhook URL

**Bot Token Setup** (optional, for message verification):

1. In your Slack app settings → OAuth & Permissions
2. Add bot token scope: `channels:history`
3. Install app to workspace → Copy Bot User OAuth Token

### Discord

**Required for discord-delivery.test.ts**

| Secret Name                | Description                 | Example                                              |
| -------------------------- | --------------------------- | ---------------------------------------------------- |
| `DISCORD_TEST_WEBHOOK_URL` | Webhook URL                 | `https://discord.com/api/webhooks/123456789/abcdefg` |
| `DISCORD_BOT_TOKEN`        | Bot token (optional)        | `your-bot-token`                                     |
| `DISCORD_TEST_CHANNEL_ID`  | Channel ID for verification | `1234567890123456789`                                |

**Webhook Setup**:

1. Open Discord server → Select channel
2. Channel Settings → Integrations → Webhooks → New Webhook
3. Copy webhook URL

**Bot Token Setup** (optional, for message verification):

1. Go to https://discord.com/developers/applications
2. Create or select application → Bot → Copy token

## Workflow Behavior

### When Secrets Are Not Configured

The workflow will **skip** automatically if `SMTP_HOST` secret is not set:

```yaml
if: ${{ secrets.SMTP_HOST != '' }}
```

This prevents workflow failures on forks or repositories without notification services configured.

### When to Run

**Automatic triggers**:

- Push to `main` branch
- Push to `develop` branch

**Manual trigger**:

- Go to Actions tab → Notification Integration Tests → Run workflow

### Test Execution

The workflow:

1. Creates `.env.integration` file from GitHub secrets
2. Runs three integration test files:
   - `email-delivery.test.ts` (4 tests)
   - `slack-delivery.test.ts` (4 tests)
   - `discord-delivery.test.ts` (4 tests)
3. Uploads test results as artifacts (retained for 7 days)

**Expected duration**: 1-3 minutes (depends on network latency)

## Security Best Practices

### Protect Your Secrets

1. **Use app-specific passwords** for Gmail (not your main password)
2. **Create dedicated test channels** for Slack/Discord (isolate from production)
3. **Limit bot permissions** to read/write in test channels only
4. **Rotate secrets regularly** (every 90 days)
5. **Never commit `.env.integration`** to git (listed in `.gitignore`)

### Branch Protection

Configure branch protection rules for `main` and `develop`:

1. Go to Settings → Branches → Add rule
2. Branch name pattern: `main` or `develop`
3. Enable "Require pull request reviews"
4. Enable "Require status checks to pass"
5. Enable "Do not allow bypassing the above settings"

This prevents unauthorized code from accessing secrets.

### Audit Secret Access

**Monitor secret usage**:

- Check Actions tab for workflow runs
- Review workflow logs (secrets are masked with `***`)
- Enable notifications for failed workflows

**Revoke access if compromised**:

1. Delete the GitHub secret
2. Regenerate service credentials (app passwords, webhooks, bot tokens)
3. Update the secret with new credentials

## Troubleshooting

### Workflow Doesn't Run

**Symptom**: Workflow skipped on push to `main`/`develop`

**Solution**: Check that `SMTP_HOST` secret is configured. The workflow condition requires this secret to be set.

### Tests Fail with "Missing credentials"

**Symptom**: Tests skip with "Skipping: RUN_INTEGRATION_TESTS not enabled"

**Solution**: Verify all required secrets are configured. The workflow creates `.env.integration` from secrets at runtime.

### Timeout Errors

**Symptom**: Tests fail with "Request timed out after 50000ms"

**Solution**:

- Check service status (Gmail SMTP, Slack API, Discord API)
- Verify webhook URLs are still valid
- Consider increasing `TIMEOUT_MS` constants in handlers (currently 50s)

### Invalid Webhook URLs

**Symptom**: Tests fail with "Invalid webhook URL"

**Solution**:

- Verify webhook URLs haven't expired
- Check webhook format matches expected pattern
- Regenerate webhooks if deleted from service

## Local Testing vs CI

### Local Testing

Uses `.env.integration` file (not committed):

```bash
# packages/backend/.env.integration
RUN_INTEGRATION_TESTS=true
SMTP_HOST=smtp.gmail.com
# ... other credentials
```

Run tests:

```bash
cd packages/backend
pnpm test tests/integration/email-delivery.test.ts
```

### CI Testing

Uses GitHub Actions secrets → creates `.env.integration` at runtime:

```yaml
- name: Create .env.integration from secrets
  run: |
    cat > packages/backend/.env.integration << EOF
    SMTP_HOST=${{ secrets.SMTP_HOST }}
    # ... other secrets
    EOF
```

**Key difference**: Local `.env.integration` is persistent, CI version is ephemeral (deleted after workflow).

## Cost Considerations

### Email (Gmail)

- **Free tier**: 500 emails/day
- **Cost per test run**: 4 emails sent
- **Monthly estimate**: ~120 emails (assuming 30 test runs)
- **Within free tier**: ✅ Yes

### Slack

- **Free tier**: Unlimited webhooks
- **Cost per test run**: 4 messages posted
- **Rate limits**: ~1 message/second recommended
- **Within free tier**: ✅ Yes

### Discord

- **Free tier**: Unlimited webhooks
- **Cost per test run**: 4 messages posted
- **Rate limits**: 5 requests/second per webhook
- **Within free tier**: ✅ Yes

**Total cost**: $0/month (all services within free tiers)

## Alternative: Skip in CI

If you prefer not to configure secrets, the workflow will automatically skip. Integration tests can run locally only:

1. Don't configure GitHub secrets
2. Workflow skips automatically on CI
3. Developers run integration tests locally with `.env.integration`

This approach:

- ✅ Simpler setup (no secret management)
- ✅ Faster CI (skip network-dependent tests)
- ❌ No automated verification of notification delivery
- ❌ Requires manual testing before production deploys

## Support

For questions or issues:

1. Check workflow logs in Actions tab
2. Review test files in `packages/backend/tests/integration/`
3. Consult `SETUP_TEST_SERVICES.md` for local testing setup
