# Step-by-Step Setup for Test Notification Services

Using test account: **bugspotter.test@gmail.com**

---

## ✅ Gmail - DONE

You've already completed:

- ✅ Created account: bugspotter.test@gmail.com
- ✅ Enabled 2FA with authenticator app
- ✅ Generated app password: uomgtzdodowxbgwy
- ✅ Added to .env.integration

**Test it:**

```bash
cd packages/backend
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Email"
```

---

## 1️⃣ Slack Setup (3 minutes)

### Step 1: Create Slack Workspace

1. **Go to:** https://slack.com/create
2. **Enter email:** bugspotter.test@gmail.com
3. **Check email** for verification code
4. **Enter code** from email
5. **Company name:** BugSpotter Tests
6. **Project name:** Integration Testing
7. **Skip** adding teammates
8. **Workspace URL:** Choose something like `bugspotter-tests` or `bugspotter-integration`
   - Final URL: `https://bugspotter-tests.slack.com`

### Step 2: Create Channel

1. **In Slack sidebar,** click the + next to "Channels"
2. **Channel name:** integration-tests
3. **Description:** Automated notification integration tests
4. **Make it public** (easier for testing)
5. **Click Create**

### Step 3: Create Incoming Webhook

**Method A - Quick (Recommended):**

1. **Go to:** https://bugspotter-tests.slack.com/apps (replace with your workspace name)
2. **Search:** "Incoming Webhooks"
3. **Click:** "Incoming Webhooks" app
4. **Click:** "Add to Slack"
5. **Select channel:** #integration-tests
6. **Click:** "Add Incoming Webhooks Integration"
7. **Customize:**
   - Name: BugSpotter Test Notifications
   - Icon: 🐛 or upload image
8. **Copy webhook URL** - looks like:
   ```
   https://hooks.slack.com/services/YOUR_WORKSPACE/YOUR_CHANNEL/YOUR_SECRET_KEY
   ```
9. **Save Settings**

**Method B - Custom App (Alternative):**

1. **Go to:** https://api.slack.com/apps
2. **Click:** "Create New App"
3. **Choose:** "From scratch"
4. **App Name:** BugSpotter Notifications
5. **Workspace:** Select your bugspotter-tests workspace
6. **Click:** "Create App"
7. **In left sidebar:** Click "Incoming Webhooks"
8. **Toggle:** "Activate Incoming Webhooks" to ON
9. **Click:** "Add New Webhook to Workspace"
10. **Select channel:** #integration-tests
11. **Click:** "Allow"
12. **Copy webhook URL**

### Step 4: Test Webhook

```bash
# Test with curl (replace URL with yours)
curl -X POST https://hooks.slack.com/services/YOUR_WORKSPACE/YOUR_CHANNEL/YOUR_SECRET \
  -H 'Content-Type: application/json' \
  -d '{
    "text": "🧪 Test from BugSpotter",
    "blocks": [
      {
        "type": "section",
        "text": {
          "type": "mrkdwn",
          "text": "*Test Notification*\nIf you see this in #integration-tests, webhook is working! ✅"
        }
      }
    ]
  }'
```

**Expected result:** Message appears in #integration-tests channel

### Step 5: Add to .env.integration

```bash
# Open file
code packages/backend/.env.integration

# Replace this line:
SLACK_TEST_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL

# With your actual webhook URL:
SLACK_TEST_WEBHOOK_URL=https://hooks.slack.com/services/YOUR_WORKSPACE/YOUR_CHANNEL/YOUR_SECRET
```

### Step 6: Test Integration

```bash
cd packages/backend
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Slack"
```

**Check Slack:** You should see test message in #integration-tests

---

## 2️⃣ Discord Setup (2 minutes)

### Step 1: Create Discord Account (if needed)

1. **Go to:** https://discord.com/register
2. **Email:** bugspotter.test@gmail.com
3. **Username:** BugSpotterTest (or similar)
4. **Password:** [Create strong password, save in password manager]
5. **Date of birth:** [Enter valid date]
6. **Verify email** from bugspotter.test@gmail.com inbox

### Step 2: Create Discord Server

1. **Open Discord** (web or app)
2. **Click** the + icon in left sidebar
3. **Click** "Create My Own"
4. **Click** "For me and my friends"
5. **Server name:** BugSpotter Tests
6. **Upload icon** (optional): 🐛 emoji or image
7. **Click** "Create"

### Step 3: Create Channel

1. **Right-click** server name at top
2. **Click** "Create Channel"
3. **Channel type:** Text
4. **Channel name:** integration-tests
5. **Private channel:** Leave OFF (public is fine for tests)
6. **Click** "Create Channel"

### Step 4: Create Webhook

1. **Right-click** on #integration-tests channel
2. **Click** "Edit Channel"
3. **Click** "Integrations" in left sidebar
4. **Click** "Webhooks"
5. **Click** "New Webhook"
6. **Customize:**
   - Name: BugSpotter Test Bot
   - Channel: #integration-tests (should be pre-selected)
   - Avatar: Upload 🐛 image or emoji (optional)
7. **Click** "Copy Webhook URL" - looks like:
   ```
   https://discord.com/api/webhooks/1234567890123456789/abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJK
   ```
8. **Click** "Save Changes"

### Step 5: Test Webhook

```bash
# Test with curl (replace URL with yours)
curl -X POST "https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "content": "🧪 Test from BugSpotter",
    "embeds": [{
      "title": "Integration Test",
      "description": "If you see this in #integration-tests, webhook is working! ✅",
      "color": 65280,
      "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%S.000Z)'"
    }]
  }'
```

**Expected result:** Message appears in #integration-tests channel

### Step 6: Add to .env.integration

```bash
# Open file
code packages/backend/.env.integration

# Replace this line:
DISCORD_TEST_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_TOKEN

# With your actual webhook URL:
DISCORD_TEST_WEBHOOK_URL=https://discord.com/api/webhooks/1234567890123456789/abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJK
```

### Step 7: Test Integration

```bash
cd packages/backend
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Discord"
```

**Check Discord:** You should see test message in #integration-tests

---

## 3️⃣ Microsoft Teams Setup (3 minutes)

### Step 1: Create Microsoft Account (if needed)

**You can use existing bugspotter.test@gmail.com:**

1. **Go to:** https://signup.live.com
2. **Click:** "Get a new email address"
3. **Or** use existing: bugspotter.test@outlook.com
4. **Create password** and complete signup

**OR use Gmail directly:**
You can sign up for Teams with bugspotter.test@gmail.com

### Step 2: Access Microsoft Teams

1. **Go to:** https://teams.microsoft.com
2. **Sign in** with bugspotter.test@gmail.com or bugspotter.test@outlook.com
3. **Skip** "Get the app" (web version is fine for testing)

### Step 3: Create Team

1. **Click** "Join or create a team" at bottom left
2. **Click** "Create team"
3. **Click** "From scratch"
4. **Privacy:** Private
5. **Team name:** BugSpotter Tests
6. **Description:** Automated notification testing
7. **Skip** adding members
8. **Click** "Create"

### Step 4: Create Channel

1. **Click** the ••• next to your team name
2. **Click** "Add channel"
3. **Channel name:** Integration Tests
4. **Description:** Automated test notifications
5. **Privacy:** Standard - Accessible to everyone on the team
6. **Click** "Add"

### Step 5: Create Incoming Webhook

1. **Click** the ••• next to "Integration Tests" channel name
2. **Click** "Connectors" (or "Manage channel" → "Connectors")
3. **Search:** "Incoming Webhook"
4. **Click** "Configure" on Incoming Webhook
5. **Name:** BugSpotter Test Notifications
6. **Upload image** (optional): 🐛
7. **Click** "Create"
8. **⚠️ IMPORTANT:** Copy the webhook URL immediately - you won't see it again!
   ```
   https://outlook.office.com/webhook/12345678-1234-1234-1234-123456789012@12345678-1234-1234-1234-123456789012/IncomingWebhook/abcdefg1234567890/12345678-1234-1234-1234-123456789012
   ```
9. **Click** "Done"

### Step 6: Test Webhook

```bash
# Test with curl (replace URL with yours)
curl -X POST "YOUR_TEAMS_WEBHOOK_URL" \
  -H 'Content-Type: application/json' \
  -d '{
    "@type": "MessageCard",
    "@context": "https://schema.org/extensions",
    "summary": "BugSpotter Test",
    "themeColor": "00FF00",
    "title": "🧪 Integration Test",
    "sections": [{
      "activityTitle": "BugSpotter Notification Test",
      "text": "If you see this in Integration Tests channel, webhook is working! ✅",
      "facts": [
        {
          "name": "Status:",
          "value": "Success"
        },
        {
          "name": "Timestamp:",
          "value": "'$(date)'"
        }
      ]
    }]
  }'
```

**Expected result:** Card appears in Integration Tests channel

### Step 7: Add to .env.integration

```bash
# Open file
code packages/backend/.env.integration

# Replace this line:
TEAMS_TEST_WEBHOOK_URL=https://outlook.office.com/webhook/YOUR_WEBHOOK_URL

# With your actual webhook URL (it's very long ~200 chars):
TEAMS_TEST_WEBHOOK_URL=https://outlook.office.com/webhook/12345678-1234-1234-1234-123456789012@...
```

### Step 8: Test Integration

```bash
cd packages/backend
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Teams"
```

**Check Teams:** You should see test message in Integration Tests channel

---

## 4️⃣ Generic Webhook Setup (30 seconds)

### Option A: webhook.site (Easiest)

1. **Go to:** https://webhook.site
2. **Copy** your unique URL (auto-generated) - looks like:
   ```
   https://webhook.site/12345678-1234-1234-1234-123456789012
   ```
3. **Keep the tab open** to see incoming requests in real-time

### Option B: RequestBin (Self-hosted alternative)

```bash
# Run with Docker
docker run -p 8080:8080 requestbin/requestbin

# Your webhook URL:
http://localhost:8080
```

### Option C: Beeceptor

1. **Go to:** https://beeceptor.com
2. **Enter subdomain:** bugspotter-tests
3. **Click** "Create Endpoint"
4. **Your URL:** https://bugspotter-tests.free.beeceptor.com

### Add to .env.integration

```bash
# Open file
code packages/backend/.env.integration

# Replace this line:
WEBHOOK_TEST_URL=https://webhook.site/your-unique-id

# With your actual URL:
WEBHOOK_TEST_URL=https://webhook.site/12345678-1234-1234-1234-123456789012
```

### Test Integration

```bash
cd packages/backend
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Webhook"
```

**Check webhook.site:** You should see the POST request with test payload

---

## 🧪 Run All Tests

Once you've set up all services:

```bash
cd packages/backend

# Run all integration tests
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts

# Or individual tests:
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Email"
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Slack"
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Discord"
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Teams"
RUN_INTEGRATION_TESTS=true pnpm test tests/integration/notification-delivery.test.ts -t "Webhook"
```

---

## 📝 Save Credentials

**Update your password manager with:**

```
Entry: BugSpotter Test Services
Email: bugspotter.test@gmail.com
Gmail App Password: uomgtzdodowxbgwy

Slack:
- Workspace: https://bugspotter-tests.slack.com
- Webhook: https://hooks.slack.com/services/...
- Channel: #integration-tests

Discord:
- Server: BugSpotter Tests
- Username: BugSpotterTest
- Webhook: https://discord.com/api/webhooks/...
- Channel: #integration-tests

Teams:
- Team: BugSpotter Tests
- Email: bugspotter.test@gmail.com (or @outlook.com)
- Webhook: https://outlook.office.com/webhook/...
- Channel: Integration Tests

Webhooks:
- webhook.site: https://webhook.site/12345678-1234-...
```

---

## 🔐 Add to GitHub Secrets (for CI/CD)

When ready to automate in GitHub Actions:

1. **Go to:** https://github.com/apexbridge-tech/bugspotter/settings/secrets/actions
2. **Add secrets:**
   - `SMTP_HOST` = smtp.gmail.com
   - `SMTP_PORT` = 587
   - `SMTP_SECURE` = false
   - `SMTP_USER` = bugspotter.test@gmail.com
   - `SMTP_PASS` = uomgtzdodowxbgwy
   - `EMAIL_FROM_ADDRESS` = bugspotter.test@gmail.com
   - `SLACK_TEST_WEBHOOK_URL` = https://hooks.slack.com/services/...
   - `DISCORD_TEST_WEBHOOK_URL` = https://discord.com/api/webhooks/...
   - `TEAMS_TEST_WEBHOOK_URL` = https://outlook.office.com/webhook/...
   - `WEBHOOK_TEST_URL` = https://webhook.site/...

---

## ⏱️ Time Estimate

- ✅ Gmail: Done (5 min)
- 🔵 Slack: 3 minutes
- 🟣 Discord: 2 minutes
- 🟡 Teams: 3 minutes
- 🟢 Webhook: 30 seconds

**Total remaining: ~9 minutes** to complete all setups!

---

## 🚨 Troubleshooting

### Slack webhook not working

- Verify webhook URL starts with `https://hooks.slack.com/services/`
- Check channel exists and you have access
- Webhook might be deleted - recreate it

### Discord webhook not working

- Verify URL format: `https://discord.com/api/webhooks/{id}/{token}`
- Check channel permissions
- Webhook might be deleted - recreate it

### Teams webhook not working

- Copy webhook URL carefully (very long ~200 chars)
- Webhook is shown only once - if lost, delete and recreate
- Check connector is still active in channel settings

### webhook.site not working

- URL expires after 7 days of inactivity
- Get a new URL at https://webhook.site
- Or use alternative like Beeceptor

---

**Ready to start? Pick a service and follow the steps! 🚀**
