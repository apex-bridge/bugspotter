# Running CI Locally with act

This guide explains how to run GitHub Actions workflows locally using [act](https://github.com/nektos/act), which emulates GitHub Actions in Docker containers.

## Why Run CI Locally?

- **Faster feedback**: Test CI changes without pushing to GitHub
- **Debug failures**: Inspect containers and logs interactively
- **Cost-effective**: No GitHub Actions minutes consumed
- **Offline development**: Work without internet (after initial setup)

## Prerequisites

### 1. Install act

**Linux/macOS:**

```bash
curl -s https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash
```

**macOS (Homebrew):**

```bash
brew install act
```

**Verify installation:**

```bash
act --version
```

### 2. Docker Required

act runs workflows in Docker containers. Ensure Docker is running:

```bash
docker info
```

### 3. Configure Environment

Copy the example environment file:

```bash
cp .env.act.example .env.act
```

Edit `.env.act` with your local values (it's gitignored, so safe to customize).

## Quick Start

### List Available Jobs

```bash
./run-ci-local.sh --list
```

Output:

```
Stage  Job ID             Job name           Workflow name  Workflow file  Events
0      lint               Lint               CI             ci.yml         push,pull_request
0      test               Test               CI             ci.yml         push,pull_request
0      test-backend       Backend Tests      CI             ci.yml         push,pull_request
1      playwright         Playwright Tests   CI             ci.yml         push,pull_request
1      playwright-admin   Admin E2E Tests    CI             ci.yml         push,pull_request
2      build              Build              CI             ci.yml         push,pull_request
2      test-coverage      Test Coverage      CI             ci.yml         push,pull_request
```

### Run Specific Jobs

**Linting (fastest):**

```bash
./run-ci-local.sh lint
```

**SDK Tests:**

```bash
./run-ci-local.sh test
```

**Backend Tests:**

```bash
./run-ci-local.sh test-backend
```

**Admin E2E (requires Docker-in-Docker, ~10-15 min first run):**

```bash
./run-ci-local.sh playwright-admin
```

**All Jobs (full CI):**

```bash
./run-ci-local.sh
```

## Configuration

### act Configuration File: `.actrc`

The `.actrc` file configures act's behavior:

- **Runner image**: Uses `catthehacker/ubuntu:act-latest` (includes Docker)
- **Docker socket**: Binds to host Docker for docker-compose commands
- **Environment**: Loads from `.env.act`
- **Artifacts**: Saves to `/tmp/act-artifacts`
- **Reuse containers**: Speeds up repeated runs

### Environment Variables: `.env.act`

Required variables for services:

- **Database**: PostgreSQL credentials
- **Storage**: MinIO/S3 credentials
- **Security**: JWT secret, encryption key
- **Optional**: GitHub token (for API rate limits)

## Common Workflows

### Test a Specific Change

1. Make code changes
2. Run relevant job:
   ```bash
   ./run-ci-local.sh lint              # Code style
   ./run-ci-local.sh test              # SDK tests
   ./run-ci-local.sh test-backend      # Backend tests
   ```
3. Fix issues and re-run

### Debug a Failing Job

```bash
# Run with verbose output
./run-ci-local.sh test-backend --verbose

# Keep containers after failure
act -j test-backend --rm=false

# Inspect logs
docker logs <container-id>

# Enter container for debugging
docker exec -it <container-id> /bin/bash
```

### Dry Run (show what would execute)

```bash
./run-ci-local.sh test --dryrun
```

## Job-Specific Notes

### `lint` and `test` Jobs

- **Fast**: ~2-5 minutes
- **No Docker services needed**: Pure Node.js tests
- **Best for quick validation**

### `test-backend` Job

- **Uses Testcontainers**: Spins up PostgreSQL in Docker
- **Duration**: ~3-5 minutes
- **Requires**: Docker daemon access

### `playwright` Job

- **Browser tests**: Chromium automation
- **Builds SDK bundle first**
- **Duration**: ~5-7 minutes

### `playwright-admin` Job (Most Complex)

- **Docker-in-Docker**: Runs docker-compose inside act container
- **Services started**: Postgres, Redis, MinIO, API, Admin
- **First run**: Downloads images (~500MB), takes 10-15 minutes
- **Subsequent runs**: ~5-7 minutes (cached images)
- **Debugging**: Check logs with `docker compose logs` inside container

### `build` Job

- **Builds all packages**: types, backend, SDK
- **Creates artifacts**: SDK bundle, backend dist
- **Duration**: ~3-5 minutes

## Troubleshooting

### act Not Found

```bash
# Install act
curl -s https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash

# Verify
act --version
```

### Docker Not Running

```bash
# Start Docker
sudo systemctl start docker  # Linux
open -a Docker              # macOS

# Verify
docker info
```

### Slow First Run

The first run downloads large Docker images (~2GB):

- `catthehacker/ubuntu:act-latest` (~500MB)
- `node:20-alpine` (~100MB)
- PostgreSQL, Redis, MinIO images (~500MB)

**Solution**: Wait for initial download, then runs are fast.

### playwright-admin Fails

Common causes:

1. **Docker-in-Docker issues**: Ensure Docker socket is accessible
2. **Memory limits**: Requires ~4GB RAM for all services
3. **Port conflicts**: Ports 3000, 3001, 5432, 6379, 9000 must be free

**Debug:**

```bash
# Run with verbose output
./run-ci-local.sh playwright-admin --verbose

# Check Docker logs
docker compose logs api
docker compose logs admin
```

### Permission Denied Errors

```bash
# Fix script permissions
chmod +x run-ci-local.sh

# Fix Docker socket permissions (Linux)
sudo chmod 666 /var/run/docker.sock
```

## Advanced Usage

### Run on Specific Event

```bash
# Simulate push event
act push -j lint

# Simulate pull request
act pull_request -j test
```

### Use Custom Secrets

Create `.secrets` file:

```
GITHUB_TOKEN=ghp_your_token
OTHER_SECRET=value
```

Run with secrets:

```bash
act -j test --secret-file .secrets
```

### Run Specific Step

```bash
# List workflow steps
act -j test --list

# Run specific step (experimental)
act -j test --step "Run unit tests"
```

### Custom Runner Image

Edit `.actrc` to use different image:

```bash
# For smaller image (no Docker support)
-P ubuntu-latest=catthehacker/ubuntu:runner-latest

# For larger image (more tools)
-P ubuntu-latest=catthehacker/ubuntu:full-latest
```

## Comparison: act vs GitHub Actions

| Feature   | act (local)        | GitHub Actions      |
| --------- | ------------------ | ------------------- |
| Speed     | 🚀 Faster (cached) | ⏱️ Network overhead |
| Cost      | 💰 Free            | 💳 Consumes minutes |
| Debugging | 🐛 Interactive     | 📝 Logs only        |
| Setup     | 🔧 Requires Docker | ☁️ Zero setup       |
| Accuracy  | ⚠️ 95% compatible  | ✅ 100% official    |
| Secrets   | 🔒 Local only      | 🔐 Encrypted        |

## Best Practices

1. **Run locally before pushing**: Catch issues early
2. **Use `--list` frequently**: Know what jobs are available
3. **Start with fast jobs**: `lint` and `test` are quick
4. **Keep `.env.act` private**: Contains local credentials
5. **Update act regularly**: `brew upgrade act` or re-run install script
6. **Clean up periodically**: `docker system prune` to free disk space

## Resources

- **act Documentation**: https://github.com/nektos/act
- **GitHub Actions Docs**: https://docs.github.com/en/actions
- **Troubleshooting Guide**: https://github.com/nektos/act#known-issues

## Quick Reference

```bash
# List jobs
./run-ci-local.sh --list

# Run single job
./run-ci-local.sh [job-name]

# Run all jobs
./run-ci-local.sh

# Verbose output
./run-ci-local.sh [job-name] --verbose

# Dry run
./run-ci-local.sh [job-name] --dryrun

# Help
./run-ci-local.sh --help
```
