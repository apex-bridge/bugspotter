# BugSpotter: Complete Project Overview

## What is BugSpotter?

BugSpotter is a **professional bug reporting SDK** that captures rich debugging context when users encounter issues. Think of it as a "flight recorder" for web applications - it continuously records user interactions, and when a bug is reported, it captures everything developers need to reproduce and fix the issue.

## Core Problem It Solves

**Traditional bug reports are often useless:**

- "It's broken" (no context)
- "I clicked something and got an error" (can't reproduce)
- Screenshots without context (what led to this state?)

**BugSpotter captures everything automatically:**

- Screenshot of the current page
- Last 30 seconds of user interactions (session replay)
- Console logs and errors
- Network requests/responses
- Browser and device information
- User context and metadata

## How It Works (End-to-End Flow)

### 1. **SDK Integration (Browser)**

Developers add BugSpotter to their website:

```html
<script src="bugspotter.min.js"></script>
<script>
  BugSpotter.init({
    apiKey: 'bgs_your_api_key',
    endpoint: 'https://api.bugspotter.com',
    showWidget: true, // Shows "Report Bug" button
    replay: { enabled: true, duration: 30 }, // Records last 30 seconds
  });
</script>
```

### 2. **Background Recording**

Once initialized, BugSpotter runs in the background:

- **rrweb** records DOM mutations, clicks, scrolls, mouse movements
- Console interceptor captures all `console.log/error/warn` calls
- Network monitor intercepts `fetch()` and `XMLHttpRequest`
- Maintains a circular buffer (last 30 seconds only)
- **Memory footprint: ~15MB** (minimal impact)

### 3. **User Reports a Bug**

When something goes wrong, user clicks "Report Bug" button:

1. SDK captures current screenshot (html-to-image)
2. Grabs last 30 seconds of session replay from buffer
3. Collects all console logs and network requests
4. Sanitizes PII (emails, phone numbers, credit cards automatically redacted)
5. Opens modal for user to describe the issue

### 4. **Data Submission**

SDK sends data to backend API:

```
POST /api/v1/reports
Headers: x-api-key: bgs_...
Body: {
  title: "Checkout button not working",
  description: "Clicked checkout, got white screen",
  report: {
    screenshot: "data:image/png;base64,...",  // ~500KB
    sessionReplay: { events: [...] },          // ~2MB uncompressed
    consoleLogs: [...],
    networkRequests: [...],
    browserMetadata: { browser: "Chrome 120", OS: "macOS" }
  }
}
```

### 5. **Backend Processing**

**Fastify API receives the report:**

```
API Server (Node.js + Fastify)
    ↓
1. Authenticate API key
2. Create bug report in PostgreSQL (status: pending)
3. Queue background jobs (Redis + BullMQ)
4. Return bug report ID immediately
```

**Background Workers process media:**

```
Screenshot Worker:
  - Optimize image with Sharp (reduce size 50-70%)
  - Generate 200x200 thumbnail
  - Upload to S3 (or local storage)
  - Update database with URLs

Replay Worker:
  - Chunk events into 30-second segments
  - Compress each chunk with gzip (80-90% reduction)
  - Upload chunks to S3
  - Create manifest file (metadata.json)
  - Update database with manifest URL
```

### 6. **Admin Panel Access**

Developers view reports in React admin panel:

```
Admin Dashboard (React + TypeScript)
    ↓
- List all bug reports (filters: status, priority, date)
- View screenshot
- Play session replay (rrweb-player)
- Read console logs
- Inspect network requests
- Update status (open → in_progress → resolved)
- Create Jira ticket with one click
```

### 7. **Integration System**

**Jira Integration Example:**

```
Developer clicks "Create Jira Ticket"
    ↓
1. Admin panel calls: POST /api/integrations/jira/:projectId
2. Backend plugin converts bug report to Jira issue
3. Uploads screenshot as attachment
4. Creates ticket in Jira
5. Stores Jira ticket ID in database
6. Links ticket to bug report
```

## Architecture Deep Dive

### Frontend SDK (Browser Side)

**Technology:**

- TypeScript (ES2017 for 95%+ browser support)
- Webpack 5 (bundle size: 99KB minified)
- rrweb 2.0 (session replay engine)
- html-to-image (screenshot capture)

**Key Components:**

```
src/
├── core/
│   ├── bugspotter.ts          # Main SDK class
│   └── transport.ts           # HTTP client with retry logic
├── capture/
│   ├── screenshot.ts          # DOM → PNG conversion
│   ├── console.ts             # Console log interceptor
│   └── network.ts             # Fetch/XHR interceptor
├── collectors/
│   └── dom.ts                 # rrweb integration (session replay)
├── utils/
│   ├── sanitize.ts            # PII redaction (10+ patterns)
│   └── compress.ts            # Client-side compression
└── widget/
    ├── modal.ts               # Bug report modal UI
    ├── button.ts              # Floating report button
    └── styles/                # CSS-in-JS styles
```

**PII Sanitization:**

- Regex patterns for emails, phones, credit cards, SSNs, IPs
- Kazakhstan IIN/BIN detection with date validation
- Runs on all captured data before transmission
- Custom patterns support for API keys, tokens
- **Performance: <10ms overhead**

### Backend API (Server Side)

**Technology:**

- Node.js 20+ (ES2023 features)
- Fastify 5.6.1 (faster than Express)
- PostgreSQL 16 (primary database)
- Redis 7 (queue + cache)
- BullMQ (job processing)
- AWS S3 SDK v3 (file storage)

**Architecture Patterns:**

**1. Repository Pattern (Database Access):**

```typescript
// Separation of concerns
class BugReportRepository extends BaseRepository {
  async create(data: CreateBugReportData): Promise<BugReport> {
    // Pure SQL, no business logic
    const result = await this.pool.query(
      'INSERT INTO bug_reports (...) VALUES ($1, $2, $3) RETURNING *',
      [data.title, data.description, data.projectId]
    );
    return result.rows[0];
  }
}

// Service layer adds business logic
class BugReportService {
  async createReport(data: BugReportData): Promise<BugReport> {
    // Validation
    validateBugReportData(data);

    // Create in database
    const report = await this.bugReportRepo.create(data);

    // Queue background jobs
    await this.queueManager.addJob('screenshots', {...});

    // Audit logging
    await this.auditLog.log('bug_report_created', {...});

    return report;
  }
}
```

**2. Strategy Pattern (Error Handling):**

```typescript
// Easy to extend without modifying existing code
const errorHandlers = [
  { matcher: isValidationError, processor: processValidationError },
  { matcher: isAuthError, processor: processAuthError },
  { matcher: isDatabaseError, processor: processDatabaseError },
  { matcher: isStorageError, processor: processStorageError },
];

for (const { matcher, processor } of errorHandlers) {
  if (matcher(error)) return processor(error, request);
}
```

**3. Plugin Registry (Integrations):**

```typescript
// Auto-discovers plugins from /integrations/*/plugin.ts
class PluginRegistry {
  async loadPlugins() {
    const pluginDirs = await fs.readdir('src/integrations');
    for (const dir of pluginDirs) {
      const pluginPath = `./integrations/${dir}/plugin`;
      const plugin = await import(pluginPath);
      this.register(plugin.default);
    }
  }
}

// Adding new integration = drop file in folder, no code changes
```

**4. Template Method Pattern (Storage):**

```typescript
// Base class defines algorithm
abstract class BaseStorageService {
  async uploadScreenshot(projectId, bugId, buffer) {
    // 1. Validate IDs (UUID format, path traversal check)
    validateProjectId(projectId);
    validateBugId(bugId);

    // 2. Build storage key
    const key = `screenshots/${projectId}/${bugId}/original.png`;

    // 3. Sanitize key (defense in depth)
    const sanitizedKey = sanitizeS3Key(key);

    // 4. Delegate to subclass
    return await this.uploadBuffer(sanitizedKey, buffer);
  }

  // Subclass implements storage-specific logic
  protected abstract uploadBuffer(key: string, buffer: Buffer): Promise<UploadResult>;
}

// S3 implementation
class StorageService extends BaseStorageService {
  protected async uploadBuffer(key, buffer) {
    // Multipart upload with retry logic
    const upload = new Upload({
      client: this.s3Client,
      params: { Bucket: this.bucket, Key: key, Body: buffer },
      partSize: 5 * 1024 * 1024, // 5MB chunks
      queueSize: 4, // 4 concurrent uploads
    });
    return await upload.done();
  }
}
```

**Directory Structure:**

```
packages/backend/src/
├── api/
│   ├── middleware/
│   │   ├── auth.ts            # JWT + API key authentication
│   │   ├── error.ts           # Strategy pattern error handling
│   │   └── audit.ts           # Automatic activity logging
│   ├── routes/
│   │   ├── reports.ts         # Bug report CRUD
│   │   ├── projects.ts        # Project management
│   │   ├── integrations.ts    # Plugin system API
│   │   ├── uploads.ts         # Presigned URL generation
│   │   └── admin-*.ts         # Admin-only routes
│   └── schemas/               # Fastify validation schemas
├── db/
│   ├── client.ts              # Database facade (factory pattern)
│   ├── repositories/          # 7 repositories (one per table)
│   │   ├── bug-report.repository.ts
│   │   ├── project.repository.ts
│   │   ├── user.repository.ts
│   │   ├── session.repository.ts
│   │   ├── api-key.repository.ts
│   │   └── audit-log.repository.ts
│   ├── migrations/            # SQL migration files
│   └── query-builder.ts       # SQL injection prevention
├── queue/
│   ├── worker-manager.ts      # Worker lifecycle management
│   └── workers/
│       ├── screenshot-worker.ts   # Image optimization
│       ├── replay-worker.ts       # Replay compression
│       ├── integration-worker.ts  # External platform sync
│       └── notification-worker.ts # Email/Slack/Discord
├── storage/
│   ├── base-storage-service.ts    # Template method base
│   ├── storage-service.ts         # S3 implementation
│   ├── local-storage.ts           # Filesystem implementation
│   └── path-utils.ts              # Path traversal prevention
├── integrations/
│   ├── plugin-registry.ts         # Plugin discovery + loading
│   └── jira/
│       ├── plugin.ts              # Plugin definition
│       ├── jira-service.ts        # Jira API client
│       └── adf-converter.ts       # Atlassian Document Format
├── retention/
│   └── retention-service.ts       # Data retention policies
└── utils/
    ├── encryption.ts          # AES-256-GCM for credentials
    └── sanitize.ts            # Filename sanitization
```

### Database Schema

**7 Core Tables:**

```sql
-- Projects (one per application)
CREATE TABLE projects (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  api_key TEXT UNIQUE,  -- bgs_xxxxx
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
);

-- Bug Reports (main entity)
CREATE TABLE bug_reports (
  id UUID PRIMARY KEY,
  project_id UUID REFERENCES projects(id),
  title VARCHAR(500) NOT NULL,
  description TEXT,
  screenshot_url TEXT,      -- S3 presigned URL
  screenshot_key TEXT,      -- Storage key for direct access
  replay_url TEXT,          -- Replay manifest URL
  replay_key TEXT,
  metadata JSONB,           -- Browser, OS, custom fields
  status VARCHAR(50),       -- open, in_progress, resolved, closed
  priority VARCHAR(50),     -- low, medium, high, critical
  upload_status VARCHAR(50), -- pending, completed, failed
  deleted_at TIMESTAMPTZ,   -- Soft delete
  legal_hold BOOLEAN,       -- Retention protection
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
);

-- Session Replay Events
CREATE TABLE sessions (
  id UUID PRIMARY KEY,
  bug_report_id UUID REFERENCES bug_reports(id),
  events JSONB,           -- rrweb event array
  duration_ms INTEGER,
  created_at TIMESTAMPTZ
);

-- Users (admin panel access)
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE,
  password_hash TEXT,     -- bcrypt
  role VARCHAR(50),       -- admin, viewer, owner
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
);

-- Project Members (RBAC)
CREATE TABLE project_members (
  project_id UUID REFERENCES projects(id),
  user_id UUID REFERENCES users(id),
  role VARCHAR(50),       -- admin, developer, viewer
  PRIMARY KEY (project_id, user_id)
);

-- External Tickets (Jira, GitHub, Linear)
CREATE TABLE tickets (
  id UUID PRIMARY KEY,
  bug_report_id UUID REFERENCES bug_reports(id),
  external_platform TEXT,  -- jira, github, linear
  external_id TEXT,
  external_url TEXT,
  status VARCHAR(50),
  created_at TIMESTAMPTZ
);

-- Integration Configurations
CREATE TABLE project_integrations (
  id UUID PRIMARY KEY,
  project_id UUID REFERENCES projects(id),
  platform TEXT,                    -- jira, github, linear
  enabled BOOLEAN,
  config JSONB,                     -- host, project key, etc.
  encrypted_credentials TEXT,       -- AES-256-GCM encrypted
  created_at TIMESTAMPTZ,
  UNIQUE(project_id, platform)
);

-- Audit Log (compliance)
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  action TEXT,              -- bug_report_created, project_updated
  resource_type TEXT,       -- bug_report, project, user
  resource_id UUID,
  project_id UUID,
  ip_address INET,
  user_agent TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ
);
```

**Key Indexes:**

- `bug_reports(project_id)` - Fast filtering by project
- `bug_reports(status)` - Fast status filtering
- `bug_reports(created_at DESC)` - Sorting by date
- `projects(api_key)` - Authentication lookups
- `users(email)` - Login lookups

### Queue System (BullMQ + Redis)

**4 Queues with Different Priorities:**

```typescript
// Queue configuration
const QUEUES = {
  screenshots: { concurrency: 5, priority: 2 },
  replays: { concurrency: 3, priority: 2 },
  integrations: { concurrency: 10, priority: 1 },
  notifications: { concurrency: 5, priority: 3 },
};

// Worker processing
class ScreenshotWorker {
  async process(job: Job) {
    const { bugReportId, projectId, screenshotData } = job.data;

    try {
      // 1. Decode base64 → Buffer
      const buffer = Buffer.from(screenshotData, 'base64');

      // 2. Optimize with Sharp
      const optimized = await sharp(buffer).png({ quality: 80, compressionLevel: 9 }).toBuffer();

      // 3. Generate thumbnail (200x200)
      const thumbnail = await sharp(buffer)
        .resize(200, 200, { fit: 'cover' })
        .jpeg({ quality: 85 })
        .toBuffer();

      // 4. Upload to S3 (parallel)
      const [screenshotUrl, thumbnailUrl] = await Promise.all([
        storage.uploadScreenshot(projectId, bugReportId, optimized),
        storage.uploadThumbnail(projectId, bugReportId, thumbnail),
      ]);

      // 5. Update database
      await db.bugReports.update(bugReportId, {
        screenshot_url: screenshotUrl,
        thumbnail_url: thumbnailUrl,
        upload_status: 'completed',
      });

      return { success: true };
    } catch (error) {
      // Retry logic (3 attempts with exponential backoff)
      throw error;
    }
  }
}
```

**Job Flow:**

```
API creates job → Redis queue → Worker picks up → Processing → Update DB → Done
                                      ↓ (on failure)
                                 Retry (3 attempts)
                                      ↓ (all failed)
                                   Dead letter queue
```

### Admin Panel (React)

**Technology:**

- React 18.3.1 + TypeScript
- Vite 5 (build tool)
- Tailwind CSS 3 (styling)
- TanStack Query 5 (data fetching)
- React Router 6 (routing)
- Playwright (E2E testing)

**Key Features:**

1. **Authentication:**

```typescript
// Memory-only token storage (XSS protection)
const [accessToken, setAccessToken] = useState<string | null>(null);

// Refresh tokens in httpOnly cookies (JavaScript can't access)
await fetch('/api/auth/login', {
  method: 'POST',
  credentials: 'include', // Send cookies
  body: JSON.stringify({ email, password }),
});

// Token refresh on 401
axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      const newToken = await refreshAccessToken();
      setAccessToken(newToken);
      // Retry original request
    }
  }
);
```

2. **Bug Report Management:**

```typescript
// List with filters + pagination
const { data, isLoading } = useQuery({
  queryKey: ['bugReports', filters, page],
  queryFn: () =>
    api.getBugReports({
      status: filters.status,
      priority: filters.priority,
      search: filters.search,
      page,
      limit: 25,
    }),
});

// Update status with optimistic updates
const updateStatus = useMutation({
  mutationFn: (id, status) => api.updateBugReport(id, { status }),
  onMutate: async ({ id, status }) => {
    // Optimistic update (instant UI feedback)
    queryClient.setQueryData(['bugReports'], (old) =>
      old.map((r) => (r.id === id ? { ...r, status } : r))
    );
  },
});
```

3. **Session Replay Player:**

```typescript
// Load replay chunks and play
useEffect(() => {
  async function loadReplay() {
    // 1. Fetch manifest
    const manifest = await fetch(bugReport.replay_url);

    // 2. Download all chunks (gzipped)
    const chunks = await Promise.all(
      manifest.chunks.map((c) => fetch(c.url).then((r) => r.arrayBuffer()))
    );

    // 3. Decompress chunks
    const events = chunks.flatMap((chunk) => {
      const decompressed = pako.ungzip(chunk, { to: 'string' });
      return JSON.parse(decompressed).events;
    });

    // 4. Initialize rrweb player
    new rrwebPlayer({
      target: playerRef.current,
      props: { events, autoPlay: false },
    });
  }

  loadReplay();
}, [bugReport]);
```

**Directory Structure:**

```
apps/admin/src/
├── components/
│   ├── ui/                    # Reusable components (Button, Input, Card)
│   ├── bug-reports/
│   │   ├── bug-report-list.tsx
│   │   ├── bug-report-detail.tsx
│   │   └── session-replay-player.tsx
│   └── settings/              # Feature-specific components
├── contexts/
│   └── auth-context.tsx       # Authentication state
├── lib/
│   └── api-client.ts          # Axios instance + interceptors
├── pages/
│   ├── login.tsx
│   ├── dashboard.tsx
│   ├── bug-reports.tsx
│   ├── settings.tsx
│   └── audit-logs.tsx
└── services/
    └── api.ts                 # API function wrappers
```

## Security Implementation

### 1. **Authentication (Dual System)**

**API Keys (SDK → Backend):**

```typescript
// Format: bgs_xxxxx (32 bytes random, base64url)
const apiKey = `bgs_${crypto.randomBytes(32).toString('base64url')}`;

// Stored hashed in database (SHA-256)
const hash = crypto.createHash('sha256').update(apiKey).digest('hex');

// Middleware validates on every request
async function authenticateApiKey(request) {
  const apiKey = request.headers['x-api-key'];
  const hash = sha256(apiKey);
  const project = await db.projects.findByApiKeyHash(hash);
  if (!project) throw new AuthError('Invalid API key');
  request.authProject = project;
}
```

**JWT Tokens (User → Backend):**

```typescript
// Access token (1 hour, memory only)
const accessToken = jwt.sign({ userId, email, role }, process.env.JWT_SECRET, { expiresIn: '1h' });

// Refresh token (7 days, httpOnly cookie)
const refreshToken = jwt.sign({ userId }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });

response.setCookie('refreshToken', refreshToken, {
  httpOnly: true,
  secure: true, // HTTPS only
  sameSite: 'strict',
  maxAge: 7 * 24 * 60 * 60 * 1000,
});
```

### 2. **SQL Injection Prevention**

```typescript
// ✅ ALWAYS use parameterized queries
await client.query(
  'SELECT * FROM bug_reports WHERE project_id = $1 AND status = $2',
  [projectId, status] // Values safely escaped
);

// ✅ Validate SQL identifiers (column names)
function validateSqlIdentifier(identifier: string): string {
  if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
    throw new ValidationError('Invalid column name');
  }
  return identifier;
}

// Usage
const sortBy = validateSqlIdentifier(req.query.sort_by);
await query(`SELECT * FROM bugs ORDER BY ${sortBy}`);
```

### 3. **Path Traversal Prevention**

```typescript
// Multiple layers of defense
function sanitizeFilename(filename: string): string {
  // 1. Decode URL encoding (prevent %2e%2e%2f)
  filename = decodeURIComponent(filename);

  // 2. Remove control characters (null bytes)
  filename = filename.replace(/[\x00-\x1F\x7F]/g, '');

  // 3. Extract basename (defeats ../)
  filename = path.basename(filename);

  // 4. Validate pattern
  if (/[<>:"|?*]/.test(filename)) {
    throw new ValidationError('Invalid filename');
  }

  return filename;
}

// Storage key building
function buildStorageKey(type, projectId, bugId, filename) {
  // Validate type (whitelist)
  if (!['screenshots', 'replays', 'attachments'].includes(type)) {
    throw new Error('Invalid storage type');
  }

  // Validate UUIDs (format check + no path traversal)
  validateUuid(projectId);
  validateUuid(bugId);

  // Sanitize filename
  const safe = sanitizeFilename(filename);

  // Build key
  return `${type}/${projectId}/${bugId}/${safe}`;
}
```

### 4. **Encryption (AES-256-GCM)**

```typescript
// Encrypt integration credentials
function encrypt(plaintext: string): string {
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);

  // Derive key from master key + salt (scrypt)
  const key = crypto.scryptSync(masterKey, salt, 32, {
    N: 16384,
    r: 8,
    p: 1,
  });

  // Encrypt with AES-256-GCM (authenticated encryption)
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let encrypted = cipher.update(plaintext, 'utf8', 'base64');
  encrypted += cipher.final('base64');

  // Get auth tag (tamper detection)
  const authTag = cipher.getAuthTag();

  // Format: salt:iv:authTag:ciphertext
  return [
    salt.toString('base64'),
    iv.toString('base64'),
    authTag.toString('base64'),
    encrypted,
  ].join(':');
}

// Decrypt with verification
function decrypt(encrypted: string): string {
  const [saltB64, ivB64, authTagB64, ciphertext] = encrypted.split(':');

  const salt = Buffer.from(saltB64, 'base64');
  const iv = Buffer.from(ivB64, 'base64');
  const authTag = Buffer.from(authTagB64, 'base64');

  // Derive same key
  const key = crypto.scryptSync(masterKey, salt, 32, { N: 16384, r: 8, p: 1 });

  // Decrypt and verify
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag); // Verify integrity

  let decrypted = decipher.update(ciphertext, 'base64', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}
```

## Testing Infrastructure

**2,705 Total Tests (99.9% passing)**

### Backend Tests (2,197 tests, all passing)

**Testcontainers (Zero Manual Setup):**

```typescript
// tests/setup.ts
let postgresContainer: PostgreSqlContainer;
let redisContainer: GenericContainer;

beforeAll(async () => {
  // Start PostgreSQL 16 container
  postgresContainer = await new PostgreSqlContainer('postgres:16')
    .withDatabase('bugspotter_test')
    .withUsername('test')
    .withPassword('test')
    .start();

  // Start Redis 7 container
  redisContainer = await new GenericContainer('redis:7').withExposedPorts(6379).start();

  // Run migrations
  await runMigrations(postgresContainer.getConnectionUri());

  // Initialize database client
  globalThis.db = createDatabaseClient({
    connectionString: postgresContainer.getConnectionUri(),
  });
});

afterAll(async () => {
  await postgresContainer.stop();
  await redisContainer.stop();
});
```

**Test Categories:**

- **Unit tests (1,200+):** Pure logic, mocked dependencies
- **Integration tests (700+):** Real database + Redis
- **Storage tests (100+):** S3 + local filesystem
- **Queue tests (150+):** BullMQ job processing
- **API tests (47+):** Full HTTP endpoints

### SDK Tests (414 tests, 412 passing)

- **Unit tests:** PII sanitization, screenshot capture, transport logic
- **E2E tests:** Real browser automation with Playwright
- **Performance tests:** Memory leaks, bundle size validation

### Admin Tests (94 tests, all passing)

- **Component tests:** React components with Vitest
- **E2E tests:** Playwright (login, bug reports, settings, audit logs)

## Performance Characteristics

### Benchmarks

**API Response Times (p95):**

- Bug report creation: 180ms
- List reports (25 items): 85ms
- Screenshot upload (1MB): 450ms
- Session replay upload (500KB): 280ms

**Database Queries:**

- Single SELECT by ID: 3-8ms
- Filtered list with pagination: 25-80ms
- Batch insert (50 records): 120-400ms

**Queue Processing:**

- Screenshot optimization: 1-3s per job
- Replay compression: 2-5s per job
- Queue throughput: 2,500 jobs/sec (insertion)

**Memory Usage:**

- Backend baseline: 100MB
- Backend under load: 150MB
- SDK runtime: 5-15MB
- Streaming uploads: Constant 5MB (not linear)

## Deployment (Docker)

**docker-compose.yml:**

```yaml
version: '3.8'
services:
  # API server
  api:
    build: ./packages/backend
    ports: ['3000:3000']
    environment:
      DATABASE_URL: postgresql://postgres:password@postgres:5432/bugspotter
      REDIS_URL: redis://redis:6379
      AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID}
      AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY}
      JWT_SECRET: ${JWT_SECRET}
    depends_on: [postgres, redis, minio]

  # Background worker (same image, different entrypoint)
  worker:
    build: ./packages/backend
    command: node dist/worker.js
    environment: [same as api]
    depends_on: [postgres, redis, minio]

  # PostgreSQL 16
  postgres:
    image: postgres:16
    volumes: ['postgres-data:/var/lib/postgresql/data']
    environment:
      POSTGRES_DB: bugspotter
      POSTGRES_PASSWORD: password

  # Redis 7 (queue)
  redis:
    image: redis:7
    volumes: ['redis-data:/data']

  # MinIO (S3-compatible storage)
  minio:
    image: minio/minio
    command: server /data --console-address ":9001"
    ports: ['9000:9000', '9001:9001']
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    volumes: ['minio-data:/data']

  # Admin panel (nginx)
  admin:
    build: ./apps/admin
    ports: ['8080:80']
    environment:
      API_URL: http://api:3000

volumes:
  postgres-data:
  redis-data:
  minio-data:
```

**Scaling:**

- Horizontal: Add more `api` and `worker` containers
- Database: Connection pooling (max 20 connections per instance)
- Redis: Cluster mode for queue distribution
- Storage: S3 handles unlimited scale

## Current Status & Roadmap

### ✅ Complete (v0.3.0)

- Core SDK with session replay
- PII sanitization (10+ patterns)
- Backend API with PostgreSQL
- Admin panel (React + TypeScript)
- httpOnly cookie authentication
- Jira integration plugin
- Comprehensive test coverage (2,705 tests)
- Docker deployment setup
- API key management system
- Notification system (Email, Slack, Discord)
- Presigned URL uploads
- Data retention policies

### 🚧 In Progress

- NPM package publication
- Production deployment guides
- Performance optimization

### ⏳ Planned (v1.0+)

- GitHub integration
- Linear integration
- Real-time dashboard (WebSockets)
- Advanced search (Elasticsearch)
- Machine learning for duplicate detection
- Mobile SDK (React Native)
- Framework integrations (React, Vue, Angular)

---

**That's BugSpotter!** A production-ready bug reporting system built with modern architecture, security best practices, and comprehensive testing. The codebase follows SOLID principles, uses proven design patterns, and prioritizes developer experience.
