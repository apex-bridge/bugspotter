/**
 * Type declarations for Fastify extensions
 * Using custom properties to avoid conflicts with Fastify's built-in properties
 */

import type { Project, User, ApiKey } from '../db/types.js';

declare module 'fastify' {
  interface FastifyRequest {
    authProject?: Project;
    authUser?: User;
    apiKey?: ApiKey;
    authShareToken?: { bug_report_id: string };
    jwtVerify(): Promise<{ userId: string }>;
  }

  interface FastifyContextConfig {
    public?: boolean;
  }
}

export {};
