/**
 * Upload API Schemas
 * Validation schemas for file upload endpoints
 */

export const VALID_FILE_TYPES = ['screenshot', 'replay', 'attachment'] as const;

export const generatePresignedUrlSchema = {
  body: {
    type: 'object',
    required: ['projectId', 'bugId', 'fileType', 'filename'],
    properties: {
      projectId: { type: 'string', format: 'uuid' },
      bugId: { type: 'string', format: 'uuid' },
      fileType: { type: 'string', enum: VALID_FILE_TYPES },
      filename: { type: 'string', minLength: 1, maxLength: 255 },
      contentType: { type: 'string' },
    },
  },
} as const;

export const confirmUploadSchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string', format: 'uuid' },
    },
  },
  body: {
    type: 'object',
    required: ['fileType'],
    properties: {
      fileType: { type: 'string', enum: VALID_FILE_TYPES },
    },
  },
} as const;

export const bugReportIdParamsSchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string', format: 'uuid' },
    },
  },
} as const;
