import type { DatabaseClient } from '../../db/client.js';
import type { IStorageService } from '../../storage/types.js';
import type { BugReport } from '../../db/types.js';

// Presigned URL expiration time (1 hour in seconds)
const PRESIGNED_URL_EXPIRATION_SECONDS = 3600;

type UploadTypes = 'screenshot' | 'replay';

type UploadParameters = {
  fileName: string;
  uploadType: UploadTypes;
  keyColumn: 'screenshot_key' | 'replay_key';
  uploadStatusField: 'upload_status' | 'replay_upload_status';
};

const uploadParametersMap: Record<UploadTypes, UploadParameters> = {
  screenshot: {
    fileName: 'screenshot.png',
    uploadType: 'screenshot',
    keyColumn: 'screenshot_key',
    uploadStatusField: 'upload_status',
  },
  replay: {
    fileName: 'replay.gz',
    uploadType: 'replay',
    keyColumn: 'replay_key',
    uploadStatusField: 'replay_upload_status',
  },
};

/**
 * Generate presigned URL for upload
 *
 * @param key - Storage key
 * @param storage - Storage service instance
 * @returns Upload URL and storage key
 */
async function generatePresignedUrl(
  key: string,
  storage: IStorageService
): Promise<{ uploadUrl: string; storageKey: string }> {
  const uploadUrl = await storage.getPresignedUploadUrl(key, PRESIGNED_URL_EXPIRATION_SECONDS);
  return {
    uploadUrl,
    storageKey: key,
  };
}

/**
 * Prepare presigned URL and update bug report in database
 *
 * Updates database BEFORE generating presigned URL to prevent race condition
 * where URL is sent but DB update fails.
 *
 * @param parameters - Upload parameters (file name, type, columns)
 * @param db - Database client
 * @param storage - Storage service
 * @param bugReport - Bug report to update (mutated in place)
 * @returns Upload URL and storage key
 */
async function preparePresignedUrlAndUpdateBugReport(
  parameters: UploadParameters,
  db: DatabaseClient,
  storage: IStorageService,
  bugReport: BugReport
): Promise<{ uploadUrl: string; storageKey: string }> {
  const key = `${parameters.uploadType}s/${bugReport.project_id}/${bugReport.id}/${parameters.fileName}`;

  // Update database with storage key BEFORE generating presigned URL
  // This prevents race condition where URL is sent but DB update fails
  await db.bugReports.initiateUpload(
    bugReport.id,
    key,
    parameters.keyColumn,
    parameters.uploadStatusField
  );

  const url = await generatePresignedUrl(key, storage);

  // Update local object to match database state
  bugReport[parameters.keyColumn] = key;
  bugReport[parameters.uploadStatusField] = 'pending';

  return url;
}

/**
 * Prepare upload URLs for screenshot and/or replay
 *
 * Consolidates duplicate upload logic for screenshot and replay files.
 * Generates presigned URLs and updates bug report in database atomically.
 *
 * @param bugReport - Bug report to prepare uploads for (mutated in place)
 * @param hasScreenshot - Whether to prepare screenshot upload
 * @param hasReplay - Whether to prepare replay upload
 * @param db - Database client
 * @param storage - Storage service
 * @returns Record of upload URLs by type
 *
 * @example
 * const presignedUrls = await prepareUploadUrls(
 *   bugReport,
 *   true,  // hasScreenshot
 *   false, // hasReplay
 *   db,
 *   storage
 * );
 * // Returns: { screenshot: { uploadUrl, storageKey } }
 */
export async function prepareUploadUrls(
  bugReport: BugReport,
  hasScreenshot: boolean,
  hasReplay: boolean,
  db: DatabaseClient,
  storage: IStorageService
): Promise<Record<string, { uploadUrl: string; storageKey: string }>> {
  const presignedUrls: Record<string, { uploadUrl: string; storageKey: string }> = {};

  if (hasScreenshot) {
    presignedUrls['screenshot'] = await preparePresignedUrlAndUpdateBugReport(
      uploadParametersMap['screenshot'],
      db,
      storage,
      bugReport
    );
  }

  if (hasReplay) {
    presignedUrls['replay'] = await preparePresignedUrlAndUpdateBugReport(
      uploadParametersMap['replay'],
      db,
      storage,
      bugReport
    );
  }

  return presignedUrls;
}
