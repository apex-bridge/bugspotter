/**
 * Authentication response helpers
 * Standardized error responses for auth failures
 */

import type { FastifyReply } from 'fastify';
import { HTTP_STATUS } from './constants.js';

export function sendUnauthorized(reply: FastifyReply, message: string) {
  return reply.code(HTTP_STATUS.UNAUTHORIZED).send({
    success: false,
    error: 'Unauthorized',
    message,
    statusCode: HTTP_STATUS.UNAUTHORIZED,
    timestamp: new Date().toISOString(),
  });
}

export function sendForbidden(reply: FastifyReply, message: string) {
  return reply.code(HTTP_STATUS.FORBIDDEN).send({
    success: false,
    error: 'Forbidden',
    message,
    statusCode: HTTP_STATUS.FORBIDDEN,
    timestamp: new Date().toISOString(),
  });
}

export function sendRateLimitExceeded(reply: FastifyReply, window: string, retryAfter: number) {
  return reply.code(HTTP_STATUS.TOO_MANY_REQUESTS).send({
    success: false,
    error: 'TooManyRequests',
    message: `Rate limit exceeded for ${window} window. Try again in ${retryAfter}s`,
    retryAfter,
    statusCode: HTTP_STATUS.TOO_MANY_REQUESTS,
    timestamp: new Date().toISOString(),
  });
}

export function sendInternalError(reply: FastifyReply, message: string) {
  return reply.code(HTTP_STATUS.INTERNAL_SERVER_ERROR).send({
    success: false,
    error: 'InternalServerError',
    message,
    statusCode: HTTP_STATUS.INTERNAL_SERVER_ERROR,
    timestamp: new Date().toISOString(),
  });
}
