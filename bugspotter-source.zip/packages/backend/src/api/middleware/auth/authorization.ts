/**
 * Authorization middleware functions
 * Role-based and permission-based access control
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import { sendUnauthorized, sendForbidden } from './responses.js';

/**
 * Role-based authorization middleware factory
 * Requires JWT authentication and checks user role
 */
export function requireRole(...allowedRoles: Array<'admin' | 'user' | 'viewer'>) {
  return async function roleMiddleware(request: FastifyRequest, reply: FastifyReply) {
    if (!request.authUser) {
      return sendUnauthorized(reply, 'User authentication required');
    }

    if (!allowedRoles.includes(request.authUser.role)) {
      return sendForbidden(
        reply,
        `Insufficient permissions. Required role: ${allowedRoles.join(' or ')}`
      );
    }
  };
}

/**
 * Require project authentication (API key)
 * Supports both legacy project API keys and new API keys with allowed_projects
 */
export async function requireProject(request: FastifyRequest, reply: FastifyReply) {
  // Check legacy project authentication
  if (request.authProject) {
    return;
  }

  // Check new API key system with allowed_projects
  if (
    request.apiKey &&
    request.apiKey.allowed_projects &&
    request.apiKey.allowed_projects.length > 0
  ) {
    return;
  }

  // No project access
  return sendUnauthorized(reply, 'Project API key required (X-API-Key header)');
}

/**
 * Require user authentication (JWT)
 */
export async function requireUser(request: FastifyRequest, reply: FastifyReply) {
  if (!request.authUser) {
    return sendUnauthorized(reply, 'User authentication required (Authorization Bearer token)');
  }
}

/**
 * Require API key authentication (not user JWT)
 */
export async function requireApiKey(request: FastifyRequest, reply: FastifyReply) {
  if (!request.apiKey) {
    return sendUnauthorized(reply, 'API key required (X-API-Key header)');
  }
}
