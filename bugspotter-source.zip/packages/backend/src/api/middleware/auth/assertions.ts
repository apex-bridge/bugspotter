/**
 * Authentication Assertion Helpers
 * Type-safe authentication checks
 */

import type { FastifyRequest } from 'fastify';
import type { User } from '../../../db/types.js';
import { AppError } from '../error.js';

/**
 * Assert that the user is authenticated
 * Throws 401 if not authenticated
 */
export function assertAuthUser(
  request: FastifyRequest
): asserts request is FastifyRequest & { authUser: User } {
  if (!request.authUser) {
    throw new AppError('User authentication required', 401, 'Unauthorized');
  }
}

/**
 * Assert that the user is an admin
 * Throws 401 if not authenticated, 403 if not admin
 */
export function assertAdmin(
  request: FastifyRequest
): asserts request is FastifyRequest & { authUser: User } {
  assertAuthUser(request);
  if (request.authUser.role !== 'admin') {
    throw new AppError('Admin access required', 403, 'Forbidden');
  }
}

/**
 * Check if user is admin (for conditional logic)
 */
export function isAdmin(request: FastifyRequest): boolean {
  return request.authUser?.role === 'admin';
}
