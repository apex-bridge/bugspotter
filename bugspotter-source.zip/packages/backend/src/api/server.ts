/**
 * Fastify Server Setup
 * Configures Fastify with all plugins, middleware, and routes
 */

import Fastify, { type FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import multipart from '@fastify/multipart';
import cookie from '@fastify/cookie';
import { gunzip } from 'zlib';
import { promisify } from 'util';
import { config } from '../config.js';
import { getLogger } from '../logger.js';
import type { DatabaseClient } from '../db/client.js';
import { errorHandler, notFoundHandler } from './middleware/error.js';
import { REQUEST_BODY_LIMIT } from './utils/constants.js';
import { convertCorsOriginsToRegex } from './utils/cors.js';
import { healthRoutes } from './routes/health.js';
import { bugReportRoutes } from './routes/reports.js';
import { projectRoutes } from './routes/projects.js';
import { authRoutes } from './routes/auth.js';
import { shareTokenRoutes } from './routes/share-tokens.js';
import { retentionRoutes } from './routes/retention.js';
import { jobRoutes } from './routes/jobs.js';
import { registerIntegrationRoutes } from './routes/integrations.js';
import { registerIntegrationRuleRoutes } from './routes/integration-rules.js';
import { registerAdminIntegrationRoutes } from './routes/admin-integrations.js';
import { adminRoutes } from './routes/admin.js';
import { adminJobsRoutes } from './routes/admin-jobs.js';

const gunzipAsync = promisify(gunzip);
import { setupRoutes } from './routes/setup.js';
import { userRoutes } from './routes/users.js';
import { analyticsRoutes } from './routes/analytics.js';
import { notificationRoutes } from './routes/notifications.js';
import { apiKeyRoutes } from './routes/api-keys.js';
import { NotificationService } from '../services/notifications/notification-service.js';
import { logCriticalRedisError } from '../utils/redis-utils.js';
import type { RetentionService } from '../retention/retention-service.js';
import type { RetentionScheduler } from '../retention/retention-scheduler.js';
import type { QueueManager } from '../queue/queue-manager.js';
import type { IStorageService } from '../storage/types.js';
import type { PluginRegistry } from '../integrations/plugin-registry.js';

export interface ServerOptions {
  db: DatabaseClient;
  storage: IStorageService;
  pluginRegistry: PluginRegistry;
  retentionService?: RetentionService;
  retentionScheduler?: RetentionScheduler;
  queueManager?: QueueManager;
}

/**
 * Validate critical services before starting server
 */
async function validateServices(options: ServerOptions): Promise<void> {
  const logger = getLogger();

  // Validate database connection
  try {
    await options.db.testConnection();
    logger.info('✓ Database connection validated');
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[CRITICAL] Database connection failed during startup:', {
      error: errorMessage,
      timestamp: new Date().toISOString(),
    });
    throw new Error(`Database validation failed: ${errorMessage}`);
  }

  // Validate Redis connection if queue manager is provided
  if (options.queueManager) {
    try {
      const isHealthy = await options.queueManager.healthCheck();
      if (!isHealthy) {
        throw new Error('Redis health check returned false');
      }
      logger.info('✓ Redis connection validated');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logCriticalRedisError(errorMessage, process.env.REDIS_URL, 'startup');
      throw new Error(`Redis validation failed: ${errorMessage}`);
    }
  }

  // Validate storage if provided
  try {
    const isHealthy = await options.storage.healthCheck();
    if (!isHealthy) {
      throw new Error('Storage health check returned false');
    }
    logger.info('✓ Storage connection validated');
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[WARNING] Storage health check failed:', {
      error: errorMessage,
      timestamp: new Date().toISOString(),
      note: 'Server will start but file uploads may fail',
    });
    // Don't throw - storage issues shouldn't block startup
  }
}

/**
 * Create and configure Fastify server
 */
export async function createServer(options: ServerOptions): Promise<FastifyInstance> {
  const { db } = options;
  const logger = getLogger();

  // Validate critical services before proceeding
  await validateServices(options);

  // Create Fastify instance with logging
  const fastify = Fastify({
    logger: {
      level: config.server.logLevel,
    },
    requestIdHeader: 'x-request-id',
    requestIdLogLabel: 'requestId',
    disableRequestLogging: false,
    // Global body size limit - protects against DoS attacks via large JSON payloads
    // Multipart uploads use separate limit (config.server.maxUploadSize)
    bodyLimit: REQUEST_BODY_LIMIT,
    genReqId: () => {
      return `req_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    },
  });

  // Register cookie plugin for httpOnly cookies
  await fastify.register(cookie, {
    secret: config.jwt.secret, // Sign cookies for additional security
    parseOptions: {},
  });

  // Register CORS plugin with wildcard pattern support
  // Convert user-friendly wildcard patterns (e.g., "https://*.example.com") to RegExp
  const corsOrigins = convertCorsOriginsToRegex(config.server.corsOrigins);
  await fastify.register(cors, {
    origin: corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'Content-Encoding'],
    exposedHeaders: ['Content-Type', 'Content-Encoding'],
  });

  // Add content-type parser for gzipped payloads (DRY: shared decompression logic)
  const parseGzipPayload = async (_req: unknown, body: unknown) => {
    try {
      const decompressed = await gunzipAsync(body as Buffer);
      return JSON.parse(decompressed.toString('utf-8'));
    } catch (error) {
      throw new Error(
        `Failed to decompress gzipped payload: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  };

  fastify.addContentTypeParser('application/gzip', { parseAs: 'buffer' }, parseGzipPayload);
  fastify.addContentTypeParser('application/x-gzip', { parseAs: 'buffer' }, parseGzipPayload);

  // Register Helmet for security headers
  await fastify.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'"],
        scriptSrc: ["'self'"],
        imgSrc: config.server.cspImgSrc,
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        upgradeInsecureRequests: [],
      },
    },
    crossOriginEmbedderPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginResourcePolicy: { policy: 'same-site' },
  });

  // Register rate limiting
  await fastify.register(rateLimit, {
    max: process.env.NODE_ENV === 'test' ? 10000 : config.rateLimit.maxRequests,
    timeWindow: config.rateLimit.windowMs,
    hook: 'onRequest',
    errorResponseBuilder: (_request, _context) => {
      return {
        success: false,
        error: 'TooManyRequests',
        message: 'Rate limit exceeded. Please try again later',
        statusCode: 429,
        timestamp: new Date().toISOString(),
      };
    },
  });

  // Register JWT plugin
  if (config.jwt.secret) {
    await fastify.register(jwt, {
      secret: config.jwt.secret,
    });
  } else {
    logger.warn('JWT_SECRET not configured. JWT authentication will not work.');
  }

  // Register multipart for file uploads
  await fastify.register(multipart, {
    limits: {
      fileSize: config.server.maxUploadSize,
      files: 1,
    },
  });

  // Global hooks for request logging
  fastify.addHook('onRequest', async (request, _reply) => {
    request.log.info(
      {
        url: request.url,
        method: request.method,
        headers: {
          'user-agent': request.headers['user-agent'],
          'x-api-key': request.headers['x-api-key'] ? '[REDACTED]' : undefined,
          authorization: request.headers.authorization ? '[REDACTED]' : undefined,
        },
      },
      'Incoming request'
    );
  });

  fastify.addHook('onResponse', async (request, reply) => {
    request.log.info(
      {
        url: request.url,
        method: request.method,
        statusCode: reply.statusCode,
        responseTime: reply.elapsedTime,
      },
      'Request completed'
    );
  });

  // Register authentication middleware (before routes, runs early)
  const { createAuthMiddleware, createBodyAuthMiddleware } = await import('./middleware/auth.js');
  const authMiddleware = createAuthMiddleware(db);
  const bodyAuthMiddleware = createBodyAuthMiddleware(db);

  // onRequest: Check query params and headers (before body parsing)
  fastify.addHook('onRequest', authMiddleware);

  // preValidation: Check POST body for share tokens (after body parsing)
  fastify.addHook('preValidation', bodyAuthMiddleware);

  // Register audit logging middleware (after auth, logs admin actions)
  const { createAuditMiddleware } = await import('./middleware/audit.js');
  const auditMiddleware = createAuditMiddleware(db);
  fastify.addHook('onResponse', auditMiddleware);

  // Register routes (await async functions)
  await healthRoutes(fastify, db);

  // Register settings routes (requires API key authentication)
  const { settingsRoutes } = await import('./routes/settings.js');
  await settingsRoutes(fastify, db);

  // Create notification service if queue manager is available
  const notificationService = options.queueManager
    ? new NotificationService(db, options.queueManager)
    : undefined;

  bugReportRoutes(
    fastify,
    db,
    options.storage,
    notificationService,
    options.queueManager,
    options.pluginRegistry
  );
  shareTokenRoutes(fastify, db, options.storage);
  projectRoutes(fastify, db, options.pluginRegistry);
  authRoutes(fastify, db);
  await adminRoutes(fastify, db, options.pluginRegistry);
  await adminJobsRoutes(fastify);
  await setupRoutes(fastify, db);
  userRoutes(fastify, db.users);
  apiKeyRoutes(fastify, db);
  analyticsRoutes(fastify, db.analytics);

  // Register upload routes (presigned URL generation and confirmation)
  const { uploadsRoutes } = await import('./routes/uploads.js');
  if (options.queueManager) {
    uploadsRoutes(fastify, db, options.storage, options.queueManager);
  } else {
    logger.warn('Queue manager not provided - upload routes will have limited functionality');
  }

  // Register audit log routes
  const { auditLogRoutes } = await import('./routes/audit-logs.js');
  auditLogRoutes(fastify, db);

  // Register storage URL generation routes
  const { storageUrlRoutes } = await import('./routes/storage-urls.js');
  storageUrlRoutes(fastify, db, options.storage);

  // Register screenshot proxy routes (clean URLs for screenshots)
  const { registerScreenshotRoutes } = await import('./routes/screenshots.js');
  await registerScreenshotRoutes(fastify, db, options.storage);

  // Register notification routes
  notificationRoutes(fastify, db);

  // Register job/queue routes if queue manager is provided
  logger.info('Checking queue manager for job routes', {
    queueManagerProvided: !!options.queueManager,
    queueManagerType: options.queueManager ? typeof options.queueManager : 'undefined',
  });

  if (options.queueManager) {
    jobRoutes(fastify, db, options.queueManager);
  } else {
    logger.warn('Queue manager not provided - job routes will not be registered');
  }

  // Register retention routes if services are provided
  if (options.retentionService && options.retentionScheduler) {
    retentionRoutes(fastify, db, options.retentionService, options.retentionScheduler);
  }

  // Register integration routes
  await registerIntegrationRoutes(fastify, db, options.pluginRegistry);

  // Register integration rules routes
  await registerIntegrationRuleRoutes(fastify, db, options.pluginRegistry);

  // Register admin integration management routes
  await registerAdminIntegrationRoutes(fastify, db, options.pluginRegistry);

  // Register error handlers
  fastify.setErrorHandler(errorHandler);
  fastify.setNotFoundHandler(notFoundHandler);

  // Root endpoint (public)
  fastify.get('/', { config: { public: true } }, async (_request, reply) => {
    return reply.send({
      name: 'BugSpotter API',
      version: '1.0.0',
      status: 'running',
      documentation: '/api/v1/docs',
      timestamp: new Date().toISOString(),
    });
  });

  return fastify;
}

/**
 * Start the Fastify server
 */
export async function startServer(fastify: FastifyInstance): Promise<void> {
  const logger = getLogger();

  try {
    const address = await fastify.listen({
      port: config.server.port,
      host: '0.0.0.0', // Listen on all interfaces for Docker compatibility
    });

    logger.info('BugSpotter API Server started successfully');
    logger.info(`Listening on port ${config.server.port}`);
    logger.info(`Environment: ${config.server.env}`);
    logger.info(`Storage backend: ${config.storage.backend}`);
    logger.info(`Address: ${address}`);

    if (config.server.env === 'development') {
      logger.info(`Local URL: http://localhost:${config.server.port}`);
      logger.info(`Network URL: http://0.0.0.0:${config.server.port}`);
    }

    logger.info('Server details', {
      address,
      port: config.server.port,
      host: '0.0.0.0',
      env: config.server.env,
      nodeEnv: process.env.NODE_ENV || 'development',
      storage: config.storage.backend,
      corsOrigins: config.server.corsOrigins,
    });
  } catch (error) {
    logger.error('Failed to start server', { error });
    throw error;
  }
}

/**
 * Gracefully shutdown the server
 */
export async function shutdownServer(
  fastify: FastifyInstance,
  db: DatabaseClient,
  queueManager?: QueueManager
): Promise<void> {
  const logger = getLogger();

  logger.info('Shutting down server...');

  try {
    // Stop accepting new requests
    await fastify.close();
    logger.info('Server closed');

    // Shutdown queue manager
    if (queueManager) {
      await queueManager.shutdown();
      logger.info('Queue manager shut down');
    }

    // Close database connections
    await db.close();
    logger.info('Database connections closed');

    logger.info('Shutdown complete');
  } catch (error) {
    logger.error('Error during shutdown', { error });
    throw error;
  }
}
