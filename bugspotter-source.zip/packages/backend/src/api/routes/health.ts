/**
 * Health check routes
 * Provides liveness and readiness endpoints for monitoring
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Read build timestamp from package.json or use current timestamp
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let buildInfo: { version: string; buildTime: string };

try {
  const packageJson = JSON.parse(readFileSync(join(__dirname, '../../../package.json'), 'utf-8'));
  buildInfo = {
    version: packageJson.version || '0.1.0',
    buildTime: new Date().toISOString(), // Will be set at container build time
  };
} catch {
  buildInfo = {
    version: '0.1.0',
    buildTime: new Date().toISOString(),
  };
}

export async function healthRoutes(fastify: FastifyInstance, db: DatabaseClient) {
  await Promise.resolve(); // Make function actually async
  /**
   * GET /health
   * Simple liveness check - returns 200 if server is running
   */
  fastify.get('/health', { config: { public: true } }, async (_request, reply) => {
    return reply.code(200).send({
      status: 'ok',
      timestamp: new Date().toISOString(),
      build: buildInfo,
    });
  });

  /**
   * GET /ready
   * Readiness check - verifies database connectivity and plugin execution capability
   */
  fastify.get('/ready', { config: { public: true } }, async (request, reply) => {
    try {
      const dbHealthy = await db.testConnection();

      // Check isolated-vm availability for plugin execution
      let isolatedVmAvailable = false;
      try {
        await import('isolated-vm');
        isolatedVmAvailable = true;
      } catch {
        request.log.warn('isolated-vm module not available - plugin execution will fail');
      }

      if (!dbHealthy) {
        return reply.code(503).send({
          status: 'unavailable',
          timestamp: new Date().toISOString(),
          checks: {
            database: 'unhealthy',
            plugins: isolatedVmAvailable ? 'healthy' : 'degraded',
          },
        });
      }

      return reply.code(200).send({
        status: 'ready',
        timestamp: new Date().toISOString(),
        checks: {
          database: 'healthy',
          plugins: isolatedVmAvailable ? 'healthy' : 'degraded',
        },
      });
    } catch (error) {
      request.log.error({ error }, 'Readiness check failed');
      return reply.code(503).send({
        status: 'unavailable',
        timestamp: new Date().toISOString(),
        checks: {
          database: 'unhealthy',
          plugins: 'unknown',
        },
      });
    }
  });
}
