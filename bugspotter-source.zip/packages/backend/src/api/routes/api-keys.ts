/**
 * API Key Management Routes
 * Endpoints for managing API keys with RBAC
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import type { ApiKeyFilters, PermissionScope } from '../../db/types.js';
import { requireUser } from '../middleware/auth.js';
import { assertAuthUser, isAdmin } from '../middleware/auth/assertions.js';
import { AppError } from '../middleware/error.js';
import { sendSuccess, sendCreated, sendPaginated } from '../utils/response.js';
import { RATE_LIMITS } from '../utils/constants.js';
import { ApiKeyService } from '../../services/api-key/index.js';
import { mapUpdateFields, getRateLimitStatus } from '../utils/api-key-helpers.js';
import {
  createApiKeySchema,
  listApiKeysSchema,
  getApiKeySchema,
  updateApiKeySchema,
  revokeApiKeySchema,
  rotateApiKeySchema,
  getApiKeyUsageSchema,
  getApiKeyAuditSchema,
} from '../schemas/api-key-schema.js';

/**
 * Helper function to fetch and authorize access to an API key
 * Non-admin users can only access their own keys
 *
 * @throws {AppError} 404 if key not found
 * @throws {AppError} 403 if user doesn't have access
 */
async function authorizeApiKeyAccess(
  apiKeyService: ApiKeyService,
  keyId: string,
  userId: string,
  isAdminUser: boolean
) {
  const apiKey = await apiKeyService.getKeyById(keyId);

  if (!apiKey) {
    throw new AppError('API key not found', 404, 'NotFound');
  }

  // Non-admin users can only access their own keys
  if (!isAdminUser && apiKey.created_by !== userId) {
    throw new AppError('Access denied', 403, 'Forbidden');
  }

  return apiKey;
}

export function apiKeyRoutes(fastify: FastifyInstance, db: DatabaseClient) {
  const apiKeyService = new ApiKeyService(db);

  // Create new API key
  fastify.post(
    '/api/v1/api-keys',
    {
      preHandler: requireUser,
      schema: createApiKeySchema,
    },
    async (request, reply) => {
      assertAuthUser(request);

      const {
        name,
        type,
        permission_scope,
        permissions = [],
        allowed_projects = [],
        allowed_origins = [],
        rate_limit_per_minute,
        rate_limit_per_hour,
        rate_limit_per_day,
        expires_at,
      } = request.body as {
        name: string;
        type: 'development' | 'test' | 'production';
        permission_scope: PermissionScope;
        permissions?: string[];
        allowed_projects?: string[];
        allowed_origins?: string[];
        rate_limit_per_minute?: number;
        rate_limit_per_hour?: number;
        rate_limit_per_day?: number;
        expires_at?: string;
      };

      // Authorization: System admins can create keys for any projects
      // Project owners/admins can only create keys for their own projects
      if (!isAdmin(request)) {
        // Non-admin users can only create keys for projects they own/admin
        if (allowed_projects.length === 0) {
          throw new AppError('Non-admin users must specify at least one project', 403, 'Forbidden');
        }

        // Verify user has owner or admin role for ALL specified projects (batched query)
        const roleMap = await db.projects.getUserRolesForProjects(
          allowed_projects,
          request.authUser.id
        );

        for (const projectId of allowed_projects) {
          const role = roleMap.get(projectId);

          if (role !== 'owner' && role !== 'admin') {
            throw new AppError(
              `Access denied: You must be owner or admin of project ${projectId}`,
              403,
              'Forbidden'
            );
          }
        }
      }

      // Create API key (validation handled in service)
      const result = await apiKeyService.createKey({
        name,
        type,
        permission_scope,
        permissions,
        created_by: request.authUser.id,
        allowed_projects: allowed_projects.length > 0 ? allowed_projects : undefined,
        allowed_origins: allowed_origins.length > 0 ? allowed_origins : undefined,
        rate_limit_per_minute: rate_limit_per_minute ?? RATE_LIMITS.DEFAULT_PER_MINUTE,
        rate_limit_per_hour: rate_limit_per_hour ?? RATE_LIMITS.DEFAULT_PER_HOUR,
        rate_limit_per_day: rate_limit_per_day ?? RATE_LIMITS.DEFAULT_PER_DAY,
        expires_at: expires_at ? new Date(expires_at) : undefined,
      });

      return sendCreated(reply, {
        api_key: result.plaintext,
        key_details: result.key,
      });
    }
  );

  // List API keys with filtering and pagination
  fastify.get(
    '/api/v1/api-keys',
    {
      preHandler: requireUser,
      schema: listApiKeysSchema,
    },
    async (request, reply) => {
      assertAuthUser(request);

      const {
        page = 1,
        limit = 20,
        type,
        status,
        created_by,
        sort_by = 'created_at',
        sort_order = 'desc',
      } = request.query as {
        page?: number;
        limit?: number;
        type?: 'development' | 'test' | 'production';
        status?: 'active' | 'revoked' | 'expired';
        permission_scope?: PermissionScope;
        created_by?: string;
        sort_by?: 'created_at' | 'updated_at' | 'last_used_at' | 'name';
        sort_order?: 'asc' | 'desc';
      };

      // Build filters with proper type
      const filters: Partial<ApiKeyFilters> = {};
      if (type) {
        filters.type = type;
      }
      if (status) {
        filters.status = status;
      }

      // Non-admin users can only see their own keys
      if (!isAdmin(request)) {
        filters.created_by = request.authUser.id;
      } else if (created_by) {
        filters.created_by = created_by;
      }

      const result = await apiKeyService.listKeys(
        filters,
        { sort_by, order: sort_order },
        { page, limit }
      );

      return sendPaginated(reply, result.data, result.pagination);
    }
  );

  // Get single API key
  fastify.get(
    '/api/v1/api-keys/:id',
    {
      preHandler: requireUser,
      schema: getApiKeySchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };

      const apiKey = await authorizeApiKeyAccess(
        apiKeyService,
        id,
        request.authUser.id,
        isAdmin(request)
      );

      return sendSuccess(reply, apiKey);
    }
  );

  // Update API key
  fastify.patch(
    '/api/v1/api-keys/:id',
    {
      preHandler: requireUser,
      schema: updateApiKeySchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };
      const requestBody = request.body as {
        name?: string;
        permission_scope?: PermissionScope;
        permissions?: string[];
        allowed_projects?: string[];
        allowed_origins?: string[];
        rate_limit_per_minute?: number | null;
        rate_limit_per_hour?: number | null;
        rate_limit_per_day?: number | null;
        expires_at?: string | null;
      };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      // Map request body to updates object
      const updates = mapUpdateFields(requestBody);

      // Validation handled in service
      const updated = await apiKeyService.updateKey(id, updates, request.authUser.id);

      return sendSuccess(reply, updated);
    }
  );

  // Delete API key (soft delete)
  fastify.delete(
    '/api/v1/api-keys/:id',
    {
      preHandler: requireUser,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      await apiKeyService.deleteKey(id, request.authUser.id);

      return sendSuccess(reply, { message: 'API key deleted successfully' });
    }
  );

  // Revoke API key
  fastify.post(
    '/api/v1/api-keys/:id/revoke',
    {
      preHandler: requireUser,
      schema: revokeApiKeySchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };
      const { reason } = request.body as { reason?: string };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      await apiKeyService.revokeKey(id, request.authUser.id, reason);

      return sendSuccess(reply, { message: 'API key revoked successfully' });
    }
  );

  // Rotate API key
  fastify.post(
    '/api/v1/api-keys/:id/rotate',
    {
      preHandler: requireUser,
      schema: rotateApiKeySchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      const result = await apiKeyService.rotateKey(id, request.authUser.id);

      return sendSuccess(reply, {
        new_api_key: result.plaintext,
        key_details: result.key,
      });
    }
  );

  // Get usage logs
  fastify.get(
    '/api/v1/api-keys/:id/usage',
    {
      preHandler: requireUser,
      schema: getApiKeyUsageSchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };
      const { limit = 100, offset = 0 } = request.query as { limit?: number; offset?: number };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      const logs = await apiKeyService.getUsageLogs(id, limit, offset);

      return sendSuccess(reply, logs);
    }
  );

  // Get audit logs
  fastify.get(
    '/api/v1/api-keys/:id/audit',
    {
      preHandler: requireUser,
      schema: getApiKeyAuditSchema,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };
      const { limit = 100, offset = 0 } = request.query as { limit?: number; offset?: number };

      await authorizeApiKeyAccess(apiKeyService, id, request.authUser.id, isAdmin(request));

      const logs = await apiKeyService.getAuditLogs(id, limit, offset);

      return sendSuccess(reply, logs);
    }
  );

  // Get rate limit status
  fastify.get(
    '/api/v1/api-keys/:id/rate-limits',
    {
      preHandler: requireUser,
    },
    async (request, reply) => {
      assertAuthUser(request);
      const { id } = request.params as { id: string };

      const apiKey = await authorizeApiKeyAccess(
        apiKeyService,
        id,
        request.authUser.id,
        isAdmin(request)
      );

      const rateLimitStatus = await getRateLimitStatus(apiKeyService, id, apiKey);

      return sendSuccess(reply, rateLimitStatus);
    }
  );
}
