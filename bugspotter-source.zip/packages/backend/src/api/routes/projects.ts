/**
 * Project routes
 * CRUD operations for projects and API key management
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import type { PluginRegistry } from '../../integrations/plugin-registry.js';
import {
  createProjectSchema,
  getProjectSchema,
  updateProjectSchema,
  deleteProjectSchema,
} from '../schemas/project-schema.js';
import {
  listProjectMembersSchema,
  addProjectMemberSchema,
  updateProjectMemberSchema,
  removeProjectMemberSchema,
} from '../schemas/project-member-schema.js';
import { requireUser, requireRole } from '../middleware/auth.js';
import { sendSuccess, sendCreated } from '../utils/response.js';
import { findOrThrow, checkProjectAccess } from '../utils/resource.js';
import { AppError } from '../middleware/error.js';

interface CreateProjectBody {
  name: string;
  settings?: Record<string, unknown>;
}

interface UpdateProjectBody {
  name?: string;
  settings?: Record<string, unknown>;
}

export function projectRoutes(
  fastify: FastifyInstance,
  db: DatabaseClient,
  registry: PluginRegistry
) {
  /**
   * GET /api/v1/projects
   * Get all projects for the authenticated user
   */
  fastify.get(
    '/api/v1/projects',
    {
      preHandler: [requireUser],
    },
    async (request, reply) => {
      // Admin users see all projects
      if (request.authUser?.role === 'admin') {
        const projects = await db.projects.findAll();
        return sendSuccess(reply, projects);
      }

      // Regular users see projects they created or are members of
      const projects = await db.projects.getUserAccessibleProjects(request.authUser!.id);
      return sendSuccess(reply, projects);
    }
  );

  /**
   * POST /api/v1/projects
   * Create a new project (requires user authentication)
   */
  fastify.post<{ Body: CreateProjectBody }>(
    '/api/v1/projects',
    {
      schema: createProjectSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { name, settings } = request.body;

      const project = await db.projects.create({
        name,
        settings: settings ?? {},
        created_by: request.authUser?.id,
      });

      return sendCreated(reply, project);
    }
  );

  /**
   * GET /api/v1/projects/:id
   * Get a project by ID
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/projects/:id',
    {
      schema: getProjectSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      return sendSuccess(reply, project);
    }
  );

  /**
   * PATCH /api/v1/projects/:id
   * Update a project
   */
  fastify.patch<{ Params: { id: string }; Body: UpdateProjectBody }>(
    '/api/v1/projects/:id',
    {
      schema: updateProjectSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;
      const updates = request.body;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Update the project
      const updated = await db.projects.update(id, updates);

      return sendSuccess(reply, updated);
    }
  );

  /**
   * DELETE /api/v1/projects/:id
   * Delete a project (admin only)
   */
  fastify.delete<{ Params: { id: string } }>(
    '/api/v1/projects/:id',
    {
      schema: deleteProjectSchema,
      preHandler: [requireUser, requireRole('admin')],
    },
    async (request, reply) => {
      const { id } = request.params;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project (admin-only endpoint via requireRole)
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Delete the project
      await db.projects.delete(id);

      request.log.info({ project_id: id, user_id: request.authUser?.id }, 'Project deleted');

      return sendSuccess(reply, { message: 'Project deleted successfully' });
    }
  );

  /**
   * GET /api/v1/projects/:id/members
   * List all members of a project
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/projects/:id/members',
    {
      schema: listProjectMembersSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Get project members with user details (including owner)
      const members = await db.projects.getProjectMembers(id);

      return sendSuccess(reply, members);
    }
  );

  /**
   * POST /api/v1/projects/:id/members
   * Add a member to a project
   */
  fastify.post<{ Params: { id: string }; Body: { user_id: string; role: string } }>(
    '/api/v1/projects/:id/members',
    {
      schema: addProjectMemberSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;
      const { user_id, role } = request.body;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has admin access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Verify requesting user has admin or owner role on this project
      const requesterRole = await db.projects.getUserRole(id, request.authUser!.id);
      if (requesterRole !== 'admin' && requesterRole !== 'owner') {
        throw new AppError('Only project owners and admins can add members', 403, 'Forbidden');
      }

      // Check if target user exists
      await findOrThrow(() => db.users.findById(user_id), 'User');

      // Check if user is already a member (including owner)
      const existingMembers = await db.projects.getProjectMembers(id);
      if (existingMembers.some((m) => m.user_id === user_id)) {
        throw new AppError('User is already a member of this project', 409, 'Conflict');
      }

      // Add member
      const member = await db.projectMembers.addMember(
        id,
        user_id,
        role as 'admin' | 'member' | 'viewer'
      );

      request.log.info(
        { project_id: id, user_id, role, added_by: request.authUser?.id },
        'Project member added'
      );

      return sendCreated(reply, member);
    }
  );

  /**
   * PATCH /api/v1/projects/:id/members/:userId
   * Update a project member's role
   */
  fastify.patch<{ Params: { id: string; userId: string }; Body: { role: string } }>(
    '/api/v1/projects/:id/members/:userId',
    {
      schema: updateProjectMemberSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id, userId } = request.params;
      const { role } = request.body;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Verify requesting user has admin or owner role on this project
      const requesterRole = await db.projects.getUserRole(id, request.authUser!.id);
      if (requesterRole !== 'admin' && requesterRole !== 'owner') {
        throw new AppError(
          'Only project owners and admins can update member roles',
          403,
          'Forbidden'
        );
      }

      // Check if target is the project owner (stored in projects table, not in members)
      if (userId === project.created_by) {
        throw new AppError('Cannot change owner role', 403, 'Forbidden');
      }

      // Get current member
      const member = await db.projectMembers.getMemberByUserId(id, userId);
      if (!member) {
        throw new AppError('User is not a member of this project', 404, 'NotFound');
      }

      // Prevent non-owners from changing FROM admin roles
      if (member.role === 'admin' && requesterRole !== 'owner') {
        throw new AppError('Only project owners can change admin roles', 403, 'Forbidden');
      }

      // Prevent non-owners from changing TO admin roles
      if (role === 'admin' && requesterRole !== 'owner') {
        throw new AppError('Only project owners can promote users to admin', 403, 'Forbidden');
      }

      // Prevent users from changing their own role
      if (userId === request.authUser!.id) {
        throw new AppError('Cannot change your own role', 403, 'Forbidden');
      }

      // Validate role is one of the allowed values
      if (!['admin', 'member', 'viewer'].includes(role)) {
        throw new AppError('Invalid role', 400, 'BadRequest');
      }

      // Update member role using atomic UPDATE query
      const updated = await db.projectMembers.updateMemberRole(
        id,
        userId,
        role as 'admin' | 'member' | 'viewer'
      );

      if (!updated) {
        throw new AppError('Failed to update member role', 500, 'InternalServerError');
      }

      request.log.info(
        {
          project_id: id,
          user_id: userId,
          old_role: member.role,
          new_role: role,
          updated_by: request.authUser?.id,
        },
        'Project member role updated'
      );

      return sendSuccess(reply, updated);
    }
  );

  /**
   * DELETE /api/v1/projects/:id/members/:userId
   * Remove a member from a project
   */
  fastify.delete<{ Params: { id: string; userId: string } }>(
    '/api/v1/projects/:id/members/:userId',
    {
      schema: removeProjectMemberSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id, userId } = request.params;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Verify requesting user has admin or owner role on this project
      const requesterRole = await db.projects.getUserRole(id, request.authUser!.id);
      if (requesterRole !== 'admin' && requesterRole !== 'owner') {
        throw new AppError('Only project owners and admins can remove members', 403, 'Forbidden');
      }

      // Check if removing the project owner (stored in projects table, not in members)
      if (userId === project.created_by) {
        throw new AppError('Cannot remove project owner', 403, 'Forbidden');
      }

      // Get current member
      const member = await db.projectMembers.getMemberByUserId(id, userId);
      if (!member) {
        throw new AppError('User is not a member of this project', 404, 'NotFound');
      }

      // Prevent non-owners from removing admins
      if (member.role === 'admin' && requesterRole !== 'owner') {
        throw new AppError('Only project owners can remove admins', 403, 'Forbidden');
      }

      // Prevent users from removing themselves
      if (userId === request.authUser!.id) {
        throw new AppError('Cannot remove yourself from the project', 403, 'Forbidden');
      }

      // Remove member
      await db.projectMembers.removeMember(id, userId);

      request.log.info(
        { project_id: id, user_id: userId, role: member.role, removed_by: request.authUser?.id },
        'Project member removed'
      );

      return reply.send({
        success: true,
        message: 'Member removed successfully',
      });
    }
  );

  /**
   * GET /api/v1/projects/:id/integrations
   * List all available integrations for a project
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/projects/:id/integrations',
    {
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      // Check if project exists
      const project = await findOrThrow(() => db.projects.findById(id), 'Project');

      // Check if user has access to this project
      await checkProjectAccess(project.id, request.authUser, request.authProject, db, 'Project');

      // Get all available integrations from PluginRegistry (built-in plugins)
      const plugins = registry.listPlugins();

      // Build available integrations list from registry (built-in)
      const builtInIntegrations = plugins.map((plugin) => ({
        platform: plugin.platform,
        name: plugin.name,
        description: plugin.description || `${plugin.name} integration`,
        hasRules: true, // Plugins support rules by default
      }));

      // Get custom integrations from database
      const customIntegrations = await db.integrations.findAll();

      // Only include integrations that have plugins OR are custom (user-created)
      const supportedPlatforms = new Set(registry.getSupportedPlatforms());
      const customIntegrationsList = customIntegrations
        .filter((integration) => integration.is_custom || supportedPlatforms.has(integration.type))
        .map((integration) => ({
          platform: integration.type,
          name: integration.name,
          description: integration.description || `${integration.name} integration`,
          hasRules: true,
        }));

      // Merge built-in and custom integrations using Map to prevent duplicates
      // Custom integrations override built-in ones with the same platform
      const integrationsMap = new Map();
      builtInIntegrations.forEach((integration) => {
        integrationsMap.set(integration.platform, integration);
      });
      customIntegrationsList.forEach((integration) => {
        integrationsMap.set(integration.platform, integration);
      });
      const availableIntegrations = Array.from(integrationsMap.values());

      // Get configured integrations for this project
      const projectIntegrations = await db.projectIntegrations.findAllByProjectWithType(id);

      // Map configured integrations to platform → config
      const configuredMap = new Map(
        projectIntegrations.map((pi) => [
          pi.integration_type,
          { enabled: pi.enabled, config: pi.config },
        ])
      );

      // Merge available integrations with configured status
      const integrations = availableIntegrations.map((integration) => {
        const configured = configuredMap.get(integration.platform);
        return {
          ...integration,
          enabled: configured?.enabled ?? false,
          config: configured?.config,
        };
      });

      return sendSuccess(reply, integrations);
    }
  );
}
