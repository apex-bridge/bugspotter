/**
 * Upload routes
 * Presigned URL generation and upload confirmation for direct client-to-storage uploads
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import type { IStorageService } from '../../storage/types.js';
import type { QueueManager } from '../../queue/queue-manager.js';
import { AppError } from '../middleware/error.js';
import { sendSuccess } from '../utils/response.js';
import { sanitizeS3Key } from '../../storage/path-utils.js';
import { checkProjectAccess } from '../utils/resource.js';
import { getLogger } from '../../logger.js';
import {
  generatePresignedUrlSchema,
  confirmUploadSchema,
  bugReportIdParamsSchema,
  VALID_FILE_TYPES,
} from '../schemas/uploads-schema.js';

const logger = getLogger();

type FileType = (typeof VALID_FILE_TYPES)[number];

/**
 * Content type mappings for different file types
 */
const CONTENT_TYPE_MAP: Record<FileType, string> = {
  screenshot: 'image/png',
  replay: 'application/gzip', // Compressed replay data
  attachment: 'application/octet-stream', // Generic for user attachments
};

/**
 * Storage path prefixes for different file types
 */
const STORAGE_PREFIX_MAP: Record<FileType, string> = {
  screenshot: 'screenshots',
  replay: 'replays',
  attachment: 'attachments',
};

/**
 * Request body for presigned URL generation
 */
interface GenerateUploadUrlBody {
  projectId: string;
  bugId: string;
  fileType: FileType;
  filename: string;
  contentType?: string;
}

/**
 * Request body for upload confirmation
 */
interface ConfirmUploadBody {
  fileType: FileType;
}

/**
 * Build storage key for file upload
 * Format: {type}/{projectId}/{bugId}/{filename}
 */
function buildStorageKey(
  fileType: FileType,
  projectId: string,
  bugId: string,
  filename: string
): string {
  const prefix = STORAGE_PREFIX_MAP[fileType];
  const rawKey = `${prefix}/${projectId}/${bugId}/${filename}`;

  // Sanitize the key (defense in depth)
  return sanitizeS3Key(rawKey);
}

export function uploadsRoutes(
  fastify: FastifyInstance,
  db: DatabaseClient,
  storage: IStorageService,
  queueManager: QueueManager
) {
  /**
   * POST /api/v1/uploads/presigned-url
   * Generate presigned URL for direct client upload
   */
  fastify.post<{ Body: GenerateUploadUrlBody }>(
    '/api/v1/uploads/presigned-url',
    {
      schema: generatePresignedUrlSchema,
    },
    async (request, reply) => {
      const { projectId, bugId, fileType, filename, contentType } = request.body;

      // Schema already validates UUID format
      const bugReport = await db.bugReports.findById(bugId);
      if (!bugReport) {
        throw new AppError('Bug report not found', 404);
      }
      if (bugReport.project_id !== projectId) {
        throw new AppError('Bug report does not belong to specified project', 403);
      }

      // Enforce authentication and project access
      await checkProjectAccess(
        bugReport.project_id,
        request.authUser,
        request.authProject,
        db,
        'Upload URL generation'
      );

      const storageKey = buildStorageKey(fileType, projectId, bugId, filename);
      const finalContentType = contentType ?? CONTENT_TYPE_MAP[fileType];

      // Update database FIRST for screenshot/replay to ensure atomicity
      // Attachments don't require database tracking, so skip for those
      if (fileType !== 'attachment') {
        const initiateUpload =
          fileType === 'screenshot'
            ? db.bugReports.initiateScreenshotUpload
            : db.bugReports.initiateReplayUpload;
        const rowsAffected = await initiateUpload.call(db.bugReports, bugId, storageKey);
        if (rowsAffected === 0) {
          throw new AppError('Failed to initiate upload - bug report may have been deleted', 409);
        }
      }

      // Generate presigned URL after successful DB update (or immediately for attachments)
      let uploadUrl: string;
      if (
        'getPresignedUploadUrl' in storage &&
        typeof storage.getPresignedUploadUrl === 'function'
      ) {
        uploadUrl = await storage.getPresignedUploadUrl(storageKey, 3600);
      } else {
        throw new AppError(
          'Presigned uploads not supported by current storage provider',
          501,
          'NotImplemented'
        );
      }

      logger.info('Generated presigned upload URL', {
        bugId,
        projectId,
        fileType,
        storageKey,
        filename,
      });

      return sendSuccess(reply, {
        uploadUrl,
        storageKey,
        expiresIn: 3600,
        contentType: finalContentType,
      });
    }
  );

  /**
   * POST /api/v1/reports/:id/confirm-upload
   * Confirm successful upload and update bug report status
   */
  fastify.post<{
    Params: { id: string };
    Body: ConfirmUploadBody;
  }>(
    '/api/v1/reports/:id/confirm-upload',
    {
      schema: confirmUploadSchema,
    },
    async (request, reply) => {
      const { id: bugId } = request.params;
      const { fileType } = request.body;

      // Schema already validates UUID format
      const bugReport = await db.bugReports.findById(bugId);
      if (!bugReport) {
        throw new AppError('Bug report not found', 404);
      }

      await checkProjectAccess(
        bugReport.project_id,
        request.authUser,
        request.authProject,
        db,
        'Upload confirmation'
      );

      const storageKey =
        fileType === 'screenshot' ? bugReport.screenshot_key : bugReport.replay_key;

      if (!storageKey) {
        throw new AppError(
          `No ${fileType} upload initiated - request presigned URL first`,
          400,
          'BadRequest'
        );
      }

      const currentStatus =
        fileType === 'screenshot' ? bugReport.upload_status : bugReport.replay_upload_status;

      if (currentStatus !== 'pending') {
        throw new AppError(
          `Upload cannot be confirmed - current status: ${currentStatus}`,
          400,
          'BadRequest'
        );
      }

      const fileMetadata = await storage.headObject(storageKey);
      if (!fileMetadata) {
        throw new AppError(`Upload file not found in storage at key: ${storageKey}`, 400);
      }

      const statusColumn = fileType === 'screenshot' ? 'upload_status' : 'replay_upload_status';
      const result = await db.query(
        `UPDATE bug_reports 
         SET ${statusColumn} = $1 
         WHERE id = $2 AND ${statusColumn} = 'pending'
         RETURNING id`,
        ['completed', bugId]
      );

      if (result.rowCount === 0) {
        throw new AppError('Upload confirmation failed - status may have changed', 409);
      }

      // Queue worker to process the uploaded file
      if (fileType === 'screenshot') {
        await queueManager.addJob('screenshots', 'process-screenshot', {
          bugReportId: bugId,
          projectId: bugReport.project_id,
          screenshotKey: storageKey,
        });
      } else if (fileType === 'replay') {
        await queueManager.addJob('replays', 'process-replay', {
          bugReportId: bugId,
          projectId: bugReport.project_id,
          replayKey: storageKey,
        });
      }

      logger.info('Upload confirmed and processing queued', {
        bugId,
        fileType,
        storageKey,
        fileSize: fileMetadata.size,
      });

      // Fetch updated bug report to get the new status
      const updatedReport = await db.bugReports.findById(bugId);
      if (!updatedReport) {
        throw new AppError('Bug report not found after update', 500);
      }

      // Build response with appropriate status field name
      const responseData: Record<string, unknown> = {
        message: 'Upload confirmed successfully',
        bugId,
        fileType,
        storageKey,
        fileSize: fileMetadata.size,
      };

      // Add status field based on file type
      if (fileType === 'screenshot') {
        responseData.upload_status = updatedReport.upload_status;
      } else if (fileType === 'replay') {
        responseData.replay_upload_status = updatedReport.replay_upload_status;
      }

      return sendSuccess(reply, responseData);
    }
  );

  /**
   * GET /api/v1/reports/:id/screenshot-url
   * Get presigned URL for viewing screenshot
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/reports/:id/screenshot-url',
    {
      schema: bugReportIdParamsSchema,
    },
    async (request, reply) => {
      const { id: bugId } = request.params;

      // Schema already validates UUID format
      const bugReport = await db.bugReports.findById(bugId);
      if (!bugReport) {
        throw new AppError('Bug report not found', 404);
      }

      await checkProjectAccess(
        bugReport.project_id,
        request.authUser,
        request.authProject,
        db,
        'Screenshot access'
      );

      const screenshotKey = bugReport.screenshot_key;
      if (!screenshotKey) {
        if (bugReport.screenshot_url) {
          return sendSuccess(reply, { url: bugReport.screenshot_url });
        }
        throw new AppError('Screenshot not available', 404, 'NotFound');
      }

      const url = await storage.getSignedUrl(screenshotKey, { expiresIn: 900 });

      return sendSuccess(reply, { url, expiresIn: 900 });
    }
  );

  /**
   * GET /api/v1/reports/:id/replay-url
   * Get presigned URL for viewing session replay
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/reports/:id/replay-url',
    {
      schema: bugReportIdParamsSchema,
    },
    async (request, reply) => {
      const { id: bugId } = request.params;

      // Schema already validates UUID format
      const bugReport = await db.bugReports.findById(bugId);
      if (!bugReport) {
        throw new AppError('Bug report not found', 404);
      }

      await checkProjectAccess(
        bugReport.project_id,
        request.authUser,
        request.authProject,
        db,
        'Replay access'
      );

      const replayKey = bugReport.replay_key;
      if (!replayKey) {
        if (bugReport.replay_url) {
          return sendSuccess(reply, { url: bugReport.replay_url });
        }
        throw new AppError('Session replay not available', 404, 'NotFound');
      }

      const url = await storage.getSignedUrl(replayKey, { expiresIn: 900 });

      return sendSuccess(reply, { url, expiresIn: 900 });
    }
  );
}
