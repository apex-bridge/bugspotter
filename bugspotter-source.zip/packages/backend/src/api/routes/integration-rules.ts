/**
 * Integration Rules API Routes
 * CRUD endpoints for managing integration filtering rules
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import { sendSuccess, sendCreated } from '../utils/response.js';
import { checkProjectAccess } from '../utils/resource.js';
import { AppError } from '../middleware/error.js';
import { getLogger } from '../../logger.js';
import type { PluginRegistry } from '../../integrations/plugin-registry.js';
import type { FilterCondition, ThrottleConfig } from '../../types/notifications.js';
import type { FieldMappings, AttachmentConfig } from '@bugspotter/types';
import {
  createIntegrationRuleSchema,
  updateIntegrationRuleSchema,
  listIntegrationRulesSchema,
  deleteIntegrationRuleSchema,
} from '../schemas/integration-rule-schema.js';

const logger = getLogger();

/**
 * Load integration plugin dynamically
 * @param platform - Platform identifier
 * @param registry - Plugin registry
 * @throws AppError with detailed message if plugin cannot be loaded
 */
async function loadIntegrationPlugin(platform: string, registry: PluginRegistry): Promise<void> {
  try {
    await registry.loadDynamicPlugin(platform);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new AppError(
      `Integration platform '${platform}' not supported: ${errorMessage}`,
      400,
      'BadRequest'
    );
  }
}

interface CreateRuleBody {
  name: string;
  enabled?: boolean;
  priority?: number;
  filters: FilterCondition[];
  throttle?: ThrottleConfig | null;
  auto_create?: boolean;
  field_mappings?: FieldMappings | null;
  description_template?: string | null;
  attachment_config?: AttachmentConfig | null;
}

interface UpdateRuleBody {
  name?: string;
  enabled?: boolean;
  priority?: number;
  filters?: FilterCondition[];
  throttle?: ThrottleConfig | null;
  auto_create?: boolean;
  field_mappings?: FieldMappings | null;
  description_template?: string | null;
  attachment_config?: AttachmentConfig | null;
}

/**
 * Register integration rules routes
 */
export async function registerIntegrationRuleRoutes(
  server: FastifyInstance,
  db: DatabaseClient,
  registry: PluginRegistry
): Promise<void> {
  /**
   * List all rules for an integration
   * GET /api/v1/integrations/:platform/:projectId/rules
   */
  server.get<{ Params: { platform: string; projectId: string } }>(
    '/api/v1/integrations/:platform/:projectId/rules',
    { schema: listIntegrationRulesSchema },
    async (request, reply) => {
      if (!request.authUser) {
        throw new AppError('Authentication required', 401, 'Unauthorized');
      }

      const { platform, projectId } = request.params;

      // Load plugin dynamically (supports both built-in and custom plugins)
      await loadIntegrationPlugin(platform, registry);

      // Check project access
      await checkProjectAccess(projectId, request.authUser, request.authProject, db, 'Project');

      // Get integration
      const integration = await db.projectIntegrations.findByProjectAndPlatform(
        projectId,
        platform
      );

      if (!integration) {
        throw new AppError(`${platform} integration not found for project`, 404, 'NotFound');
      }

      // List rules for integration (including disabled rules for management UI)
      const rules = await db.integrationRules.findByProjectAndPlatform(
        projectId,
        integration.id,
        true // Include disabled rules so users can manage them
      );

      logger.debug('Listed integration rules', {
        platform,
        projectId,
        integrationId: integration.id,
        rulesCount: rules.length,
        userId: request.authUser.id,
      });

      return sendSuccess(reply, rules);
    }
  );

  /**
   * Create a new integration rule
   * POST /api/v1/integrations/:platform/:projectId/rules
   */
  server.post<{ Params: { platform: string; projectId: string }; Body: CreateRuleBody }>(
    '/api/v1/integrations/:platform/:projectId/rules',
    { schema: createIntegrationRuleSchema },
    async (request, reply) => {
      if (!request.authUser) {
        throw new AppError('Authentication required', 401, 'Unauthorized');
      }

      const { platform, projectId } = request.params;
      const {
        name,
        enabled = true,
        priority = 0,
        filters,
        throttle = null,
        auto_create = false,
        field_mappings = null,
        description_template = null,
        attachment_config = null,
      } = request.body;

      // Load plugin dynamically (supports both built-in and custom plugins)
      await loadIntegrationPlugin(platform, registry);

      // Check project access
      await checkProjectAccess(projectId, request.authUser, request.authProject, db, 'Project');

      // Get integration
      const integration = await db.projectIntegrations.findByProjectAndPlatform(
        projectId,
        platform
      );

      if (!integration) {
        throw new AppError(`${platform} integration not found for project`, 404, 'NotFound');
      }

      logger.info('Creating integration rule', {
        platform,
        projectId,
        integrationId: integration.id,
        name,
        filtersCount: filters.length,
        userId: request.authUser.id,
      });

      // Create rule with validation
      const rule = await db.integrationRules.createWithValidation({
        project_id: projectId,
        integration_id: integration.id,
        name,
        enabled,
        priority,
        filters,
        throttle,
        auto_create,
        field_mappings,
        description_template,
        attachment_config,
      });

      return sendCreated(reply, rule);
    }
  );

  /**
   * Update an integration rule
   * PATCH /api/v1/integrations/:platform/:projectId/rules/:ruleId
   */
  server.patch<{
    Params: { platform: string; projectId: string; ruleId: string };
    Body: UpdateRuleBody;
  }>(
    '/api/v1/integrations/:platform/:projectId/rules/:ruleId',
    { schema: updateIntegrationRuleSchema },
    async (request, reply) => {
      if (!request.authUser) {
        throw new AppError('Authentication required', 401, 'Unauthorized');
      }

      const { platform, projectId, ruleId } = request.params;
      const updateData = request.body;

      // Load plugin dynamically (supports both built-in and custom plugins)
      await loadIntegrationPlugin(platform, registry);

      // Check project access
      await checkProjectAccess(projectId, request.authUser, request.authProject, db, 'Project');

      // Get integration
      const integration = await db.projectIntegrations.findByProjectAndPlatform(
        projectId,
        platform
      );

      if (!integration) {
        throw new AppError(`${platform} integration not found for project`, 404, 'NotFound');
      }

      logger.info('Updating integration rule', {
        platform,
        projectId,
        integrationId: integration.id,
        ruleId,
        updateFields: Object.keys(updateData),
        userId: request.authUser.id,
      });

      // Update rule with validation
      const updatedRule = await db.integrationRules.updateWithValidation(ruleId, updateData);

      if (!updatedRule) {
        throw new AppError('Integration rule not found', 404, 'NotFound');
      }

      // Verify rule belongs to this integration
      if (updatedRule.integration_id !== integration.id) {
        throw new AppError('Rule does not belong to this integration', 403, 'Forbidden');
      }

      return sendSuccess(reply, updatedRule);
    }
  );

  /**
   * Delete an integration rule
   * DELETE /api/v1/integrations/:platform/:projectId/rules/:ruleId
   */
  server.delete<{ Params: { platform: string; projectId: string; ruleId: string } }>(
    '/api/v1/integrations/:platform/:projectId/rules/:ruleId',
    { schema: deleteIntegrationRuleSchema },
    async (request, reply) => {
      if (!request.authUser) {
        throw new AppError('Authentication required', 401, 'Unauthorized');
      }

      const { platform, projectId, ruleId } = request.params;

      // Load plugin dynamically (supports both built-in and custom plugins)
      await loadIntegrationPlugin(platform, registry);

      // Check project access
      await checkProjectAccess(projectId, request.authUser, request.authProject, db, 'Project');

      // Get integration
      const integration = await db.projectIntegrations.findByProjectAndPlatform(
        projectId,
        platform
      );

      if (!integration) {
        throw new AppError(`${platform} integration not found for project`, 404, 'NotFound');
      }

      // Get rule to verify ownership
      const rule = await db.integrationRules.findById(ruleId);

      if (!rule) {
        throw new AppError('Integration rule not found', 404, 'NotFound');
      }

      // Verify rule belongs to this integration
      if (rule.integration_id !== integration.id) {
        throw new AppError('Rule does not belong to this integration', 403, 'Forbidden');
      }

      logger.info('Deleting integration rule', {
        platform,
        projectId,
        integrationId: integration.id,
        ruleId,
        ruleName: rule.name,
        userId: request.authUser.id,
      });

      // Delete rule
      await db.integrationRules.delete(ruleId);

      return reply.code(200).send({
        success: true,
        message: `Integration rule '${rule.name}' deleted successfully`,
      });
    }
  );

  logger.info('Integration rules routes registered');
}
