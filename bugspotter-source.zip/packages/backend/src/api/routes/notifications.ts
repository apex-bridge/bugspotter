/**
 * Notification routes
 * CRUD operations for notification channels, rules, templates, and history
 */

import type { FastifyInstance } from 'fastify';
import Handlebars from 'handlebars';
import type { DatabaseClient } from '../../db/client.js';
import type {
  ChannelType,
  ChannelConfig,
  CreateRuleInput,
  UpdateRuleInput,
  CreateTemplateInput,
  UpdateTemplateInput,
} from '../../types/notifications.js';
import {
  listChannelsSchema,
  createChannelSchema,
  getChannelSchema,
  updateChannelSchema,
  deleteChannelSchema,
  testChannelSchema,
  listRulesSchema,
  createRuleSchema,
  getRuleSchema,
  updateRuleSchema,
  deleteRuleSchema,
  listTemplatesSchema,
  createTemplateSchema,
  getTemplateSchema,
  updateTemplateSchema,
  deleteTemplateSchema,
  previewTemplateSchema,
  listHistorySchema,
  getHistoryItemSchema,
} from '../schemas/notification-schema.js';
import { requireUser, requireRole } from '../middleware/auth.js';
import { sendSuccess, sendCreated } from '../utils/response.js';
import { findOrThrow, checkProjectAccess } from '../utils/resource.js';
import { buildPagination } from '../utils/query-builder.js';
import { getLogger } from '../../logger.js';
import {
  EmailChannelHandler,
  SlackChannelHandler,
  WebhookChannelHandler,
  DiscordChannelHandler,
  TeamsChannelHandler,
} from '../../services/notifications/index.js';

const logger = getLogger();

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface ChannelQuerystring {
  project_id?: string;
  type?: ChannelType;
  active?: boolean;
  page?: number;
  limit?: number;
}

interface CreateChannelBody {
  project_id: string;
  name: string;
  type: ChannelType;
  config: Record<string, unknown>;
  active?: boolean;
}

interface UpdateChannelBody {
  name?: string;
  config?: Record<string, unknown>;
  active?: boolean;
}

interface TestChannelBody {
  test_message?: string;
}

interface RuleQuerystring {
  project_id?: string;
  enabled?: boolean;
  page?: number;
  limit?: number;
}

interface CreateRuleBody {
  project_id: string;
  name: string;
  enabled?: boolean;
  triggers: Array<Record<string, unknown>>;
  filters?: Array<Record<string, unknown>>;
  throttle?: Record<string, unknown>;
  schedule?: Record<string, unknown>;
  priority?: number;
  channel_ids: string[];
}

interface UpdateRuleBody {
  name?: string;
  enabled?: boolean;
  triggers?: Array<Record<string, unknown>>;
  filters?: Array<Record<string, unknown>>;
  throttle?: Record<string, unknown>;
  schedule?: Record<string, unknown>;
  priority?: number;
  channel_ids?: string[];
}

interface TemplateQuerystring {
  channel_type?: string;
  trigger_type?: string;
  is_active?: boolean;
  page?: number;
  limit?: number;
}

interface CreateTemplateBody {
  name: string;
  channel_type: string;
  trigger_type: string;
  subject?: string;
  body: string;
  variables?: Array<Record<string, unknown>>;
}

interface UpdateTemplateBody {
  name?: string;
  subject?: string;
  body?: string;
  variables?: Array<Record<string, unknown>>;
  is_active?: boolean;
}

interface PreviewTemplateBody {
  template_body: string;
  subject?: string;
  context: Record<string, unknown>;
}

interface HistoryQuerystring {
  channel_id?: string;
  rule_id?: string;
  bug_id?: string;
  status?: string;
  created_after?: string;
  created_before?: string;
  page?: number;
  limit?: number;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Channel handler registry
 * Maps channel types to their handler classes
 */
const CHANNEL_HANDLERS = {
  email: EmailChannelHandler,
  slack: SlackChannelHandler,
  webhook: WebhookChannelHandler,
  discord: DiscordChannelHandler,
  teams: TeamsChannelHandler,
} as const;

/**
 * Test channel delivery by actually sending a test notification
 */
async function testChannelDelivery(
  channelId: string,
  testMessage: string,
  db: DatabaseClient
): Promise<{ delivered: boolean; message: string; response?: unknown; error?: string }> {
  try {
    const channel = await findOrThrow(() => db.notificationChannels.findById(channelId), 'Channel');

    if (!channel.active) {
      return {
        delivered: false,
        message: 'Channel is inactive',
        error: 'Channel must be active to test delivery',
      };
    }

    logger.info('Testing channel delivery', { channelId, type: channel.type });

    // Get handler class for channel type
    const HandlerClass = CHANNEL_HANDLERS[channel.type];

    if (!HandlerClass) {
      return {
        delivered: false,
        message: `Unsupported channel type: ${channel.type}`,
        error: `Channel type '${channel.type}' is not supported`,
      };
    }

    // Create handler and test delivery with custom message
    const handler = new HandlerClass();
    const result = await handler.test(channel.config as never, testMessage);

    // Return standardized result
    if (result.success) {
      return {
        delivered: true,
        message: 'Test notification sent successfully',
        response: {
          message_id: result.message_id,
          ...result.response,
        },
      };
    } else {
      return {
        delivered: false,
        message: 'Test notification failed',
        error: result.error || 'Unknown error',
      };
    }
  } catch (error) {
    logger.error('Channel test failed', { channelId, error });
    return {
      delivered: false,
      message: 'Channel test failed',
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

/**
 * Render template preview using Handlebars
 *
 * Security considerations:
 * - Template size limits to prevent DoS
 * - Context limits to prevent resource exhaustion
 * - Handlebars auto-escapes HTML by default (prevents XSS)
 * - NoEscape option disabled (always escape)
 * - Strict mode enabled (throws on missing properties)
 */
function renderTemplatePreview(
  templateBody: string,
  subject: string | undefined,
  context: Record<string, unknown>
): { rendered_body: string; rendered_subject?: string } {
  // Security: Enforce template size limits to prevent DoS
  const MAX_TEMPLATE_SIZE = 100_000; // 100KB
  const MAX_CONTEXT_KEYS = 100; // Limit number of variables
  const MAX_CONTEXT_VALUE_SIZE = 10_000; // 10KB per value

  if (templateBody.length > MAX_TEMPLATE_SIZE) {
    throw new Error('Template body exceeds maximum size limit (100KB)');
  }

  if (subject && subject.length > MAX_TEMPLATE_SIZE) {
    throw new Error('Template subject exceeds maximum size limit (100KB)');
  }

  // Security: Limit number of context variables to prevent resource exhaustion
  const contextKeys = Object.keys(context);
  if (contextKeys.length > MAX_CONTEXT_KEYS) {
    throw new Error(`Context exceeds maximum number of variables (${MAX_CONTEXT_KEYS})`);
  }

  // Security: Validate and sanitize context values
  const sanitizedContext: Record<string, unknown> = {};
  for (const key of contextKeys) {
    const value = context[key];

    // Skip null/undefined
    if (value === null || value === undefined) {
      continue;
    }

    // Convert to string and check size
    const stringValue = String(value);
    if (stringValue.length > MAX_CONTEXT_VALUE_SIZE) {
      throw new Error(`Context value for '${key}' exceeds maximum size limit (10KB)`);
    }

    sanitizedContext[key] = value;
  }

  try {
    // Compile templates with strict mode (throws on missing properties)
    // Handlebars automatically escapes HTML to prevent XSS
    const bodyTemplate = Handlebars.compile(templateBody, {
      strict: true,
      noEscape: false, // Always escape HTML
    });

    const renderedBody = bodyTemplate(sanitizedContext);

    // Compile subject if provided
    let renderedSubject: string | undefined;
    if (subject) {
      const subjectTemplate = Handlebars.compile(subject, {
        strict: true,
        noEscape: false,
      });
      renderedSubject = subjectTemplate(sanitizedContext);
    }

    return {
      rendered_body: renderedBody,
      ...(renderedSubject && { rendered_subject: renderedSubject }),
    };
  } catch (error) {
    // Handle template compilation/rendering errors
    const errorMessage = error instanceof Error ? error.message : 'Unknown template error';
    logger.error('Template rendering failed', { error: errorMessage });
    throw new Error(`Template rendering failed: ${errorMessage}`);
  }
}

// ============================================================================
// NOTIFICATION CHANNEL ROUTES
// ============================================================================

export function notificationRoutes(fastify: FastifyInstance, db: DatabaseClient) {
  /**
   * GET /api/v1/notifications/channels
   * List notification channels with filtering and pagination
   */
  fastify.get<{ Querystring: ChannelQuerystring }>(
    '/api/v1/notifications/channels',
    {
      schema: listChannelsSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { project_id, type, active, page, limit } = request.query;
      const pagination = buildPagination(page, limit);

      // If filtering by project, verify access
      if (project_id) {
        await checkProjectAccess(project_id, request.authUser, request.authProject, db, 'Project');
      }

      const filters: Record<string, unknown> = {};
      if (project_id) {
        filters.project_id = project_id;
      }
      if (type) {
        filters.type = type;
      }
      if (active !== undefined) {
        filters.active = active;
      }

      const result = await db.notificationChannels.list(filters, pagination);

      return sendSuccess(reply, {
        channels: result.data,
        pagination: result.pagination,
      });
    }
  );

  /**
   * POST /api/v1/notifications/channels
   * Create a new notification channel
   */
  fastify.post<{ Body: CreateChannelBody }>(
    '/api/v1/notifications/channels',
    {
      schema: createChannelSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { project_id, name, type, config, active = true } = request.body;

      // Verify project access
      await checkProjectAccess(project_id, request.authUser, request.authProject, db, 'Project');

      const channel = await db.notificationChannels.create({
        project_id,
        name,
        type,
        config: config as unknown as ChannelConfig, // Schema validates structure
        active,
      });

      logger.info('Notification channel created', {
        channelId: channel.id,
        projectId: project_id,
        type,
        userId: request.authUser?.id,
      });

      return sendCreated(reply, channel);
    }
  );

  /**
   * GET /api/v1/notifications/channels/:id
   * Get a specific notification channel
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/notifications/channels/:id',
    {
      schema: getChannelSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const channel = await findOrThrow(() => db.notificationChannels.findById(id), 'Channel');

      // Verify project access
      await checkProjectAccess(
        channel.project_id,
        request.authUser,
        request.authProject,
        db,
        'Channel'
      );

      return sendSuccess(reply, channel);
    }
  );

  /**
   * PATCH /api/v1/notifications/channels/:id
   * Update a notification channel
   */
  fastify.patch<{ Params: { id: string }; Body: UpdateChannelBody }>(
    '/api/v1/notifications/channels/:id',
    {
      schema: updateChannelSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;
      const updates = request.body;

      const channel = await findOrThrow(() => db.notificationChannels.findById(id), 'Channel');

      // Verify project access
      await checkProjectAccess(
        channel.project_id,
        request.authUser,
        request.authProject,
        db,
        'Channel'
      );

      const updatedChannel = await db.notificationChannels.update(id, {
        ...updates,
        config: updates.config as unknown as ChannelConfig | undefined,
      });

      logger.info('Notification channel updated', {
        channelId: id,
        userId: request.authUser?.id,
        updates: Object.keys(updates),
      });

      return sendSuccess(reply, updatedChannel);
    }
  );

  /**
   * DELETE /api/v1/notifications/channels/:id
   * Delete a notification channel
   */
  fastify.delete<{ Params: { id: string } }>(
    '/api/v1/notifications/channels/:id',
    {
      schema: deleteChannelSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const channel = await findOrThrow(() => db.notificationChannels.findById(id), 'Channel');

      // Verify project access
      await checkProjectAccess(
        channel.project_id,
        request.authUser,
        request.authProject,
        db,
        'Channel'
      );

      await db.notificationChannels.delete(id);

      logger.info('Notification channel deleted', {
        channelId: id,
        userId: request.authUser?.id,
      });

      return sendSuccess(reply, {
        message: 'Notification channel deleted successfully',
      });
    }
  );

  /**
   * POST /api/v1/notifications/channels/:id/test
   * Test a notification channel delivery
   */
  fastify.post<{ Params: { id: string }; Body: TestChannelBody }>(
    '/api/v1/notifications/channels/:id/test',
    {
      schema: testChannelSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;
      const { test_message = 'Test notification from BugSpotter' } = request.body;

      const channel = await findOrThrow(() => db.notificationChannels.findById(id), 'Channel');

      // Verify project access
      await checkProjectAccess(
        channel.project_id,
        request.authUser,
        request.authProject,
        db,
        'Channel'
      );

      const result = await testChannelDelivery(id, test_message, db);

      return sendSuccess(reply, result);
    }
  );

  // ============================================================================
  // NOTIFICATION RULE ROUTES
  // ============================================================================

  /**
   * GET /api/v1/notifications/rules
   * List notification rules with filtering and pagination
   */
  fastify.get<{ Querystring: RuleQuerystring }>(
    '/api/v1/notifications/rules',
    {
      schema: listRulesSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { project_id, enabled, page, limit } = request.query;
      const pagination = buildPagination(page, limit);

      // If filtering by project, verify access
      if (project_id) {
        await checkProjectAccess(project_id, request.authUser, request.authProject, db, 'Project');
      }

      const filters: Record<string, unknown> = {};
      if (project_id) {
        filters.project_id = project_id;
      }
      if (enabled !== undefined) {
        filters.enabled = enabled;
      }

      const result = await db.notificationRules.list(filters, pagination);

      return sendSuccess(reply, {
        rules: result.data,
        pagination: result.pagination,
      });
    }
  );

  /**
   * POST /api/v1/notifications/rules
   * Create a new notification rule
   */
  fastify.post<{ Body: CreateRuleBody }>(
    '/api/v1/notifications/rules',
    {
      schema: createRuleSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { project_id, channel_ids, ...ruleData } = request.body;

      // Verify project access
      await checkProjectAccess(project_id, request.authUser, request.authProject, db, 'Project');

      // Create rule with channel associations
      const rule = await db.notificationRules.createWithChannels({
        project_id,
        ...ruleData,
        enabled: ruleData.enabled ?? true,
        priority: ruleData.priority ?? 5,
        channel_ids,
      } as unknown as CreateRuleInput);

      logger.info('Notification rule created', {
        ruleId: rule.id,
        projectId: project_id,
        channelCount: channel_ids.length,
        userId: request.authUser?.id,
      });

      return sendCreated(reply, rule);
    }
  );

  /**
   * GET /api/v1/notifications/rules/:id
   * Get a specific notification rule
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/notifications/rules/:id',
    {
      schema: getRuleSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const rule = await findOrThrow(() => db.notificationRules.findByIdWithChannels(id), 'Rule');

      // Verify project access
      await checkProjectAccess(rule.project_id, request.authUser, request.authProject, db, 'Rule');

      return sendSuccess(reply, rule);
    }
  );

  /**
   * PATCH /api/v1/notifications/rules/:id
   * Update a notification rule
   */
  fastify.patch<{ Params: { id: string }; Body: UpdateRuleBody }>(
    '/api/v1/notifications/rules/:id',
    {
      schema: updateRuleSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;
      const { channel_ids, ...updates } = request.body;

      const rule = await findOrThrow(() => db.notificationRules.findById(id), 'Rule');

      // Verify project access
      await checkProjectAccess(rule.project_id, request.authUser, request.authProject, db, 'Rule');

      // Update rule and channels if provided
      const updatedRule = await db.notificationRules.updateWithChannels(id, {
        ...updates,
        ...(channel_ids && { channel_ids }),
      } as unknown as UpdateRuleInput);

      logger.info('Notification rule updated', {
        ruleId: id,
        userId: request.authUser?.id,
        updates: Object.keys(updates),
      });

      return sendSuccess(reply, updatedRule);
    }
  );

  /**
   * DELETE /api/v1/notifications/rules/:id
   * Delete a notification rule
   */
  fastify.delete<{ Params: { id: string } }>(
    '/api/v1/notifications/rules/:id',
    {
      schema: deleteRuleSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const rule = await findOrThrow(() => db.notificationRules.findById(id), 'Rule');

      // Verify project access
      await checkProjectAccess(rule.project_id, request.authUser, request.authProject, db, 'Rule');

      await db.notificationRules.delete(id);

      logger.info('Notification rule deleted', {
        ruleId: id,
        userId: request.authUser?.id,
      });

      return sendSuccess(reply, {
        message: 'Notification rule deleted successfully',
      });
    }
  );

  // ============================================================================
  // NOTIFICATION TEMPLATE ROUTES
  // ============================================================================

  /**
   * GET /api/v1/notifications/templates
   * List notification templates with filtering and pagination
   */
  fastify.get<{ Querystring: TemplateQuerystring }>(
    '/api/v1/notifications/templates',
    {
      schema: listTemplatesSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const { channel_type, trigger_type, is_active, page, limit } = request.query;
      const pagination = buildPagination(page, limit);

      const filters: Record<string, unknown> = {};
      if (channel_type) {
        filters.channel_type = channel_type;
      }
      if (trigger_type) {
        filters.trigger_type = trigger_type;
      }
      if (is_active !== undefined) {
        filters.is_active = is_active;
      }

      const result = await db.notificationTemplates.list(filters, pagination);

      return sendSuccess(reply, {
        templates: result.data,
        pagination: result.pagination,
      });
    }
  );

  /**
   * POST /api/v1/notifications/templates
   * Create a new notification template
   */
  fastify.post<{ Body: CreateTemplateBody }>(
    '/api/v1/notifications/templates',
    {
      schema: createTemplateSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const templateData = request.body;

      const template = await db.notificationTemplates.create(
        templateData as unknown as CreateTemplateInput
      );

      logger.info('Notification template created', {
        templateId: template.id,
        channelType: templateData.channel_type,
        triggerType: templateData.trigger_type,
        userId: request.authUser?.id,
      });

      return sendCreated(reply, template);
    }
  );

  /**
   * GET /api/v1/notifications/templates/:id
   * Get a specific notification template
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/notifications/templates/:id',
    {
      schema: getTemplateSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const { id } = request.params;

      const template = await findOrThrow(() => db.notificationTemplates.findById(id), 'Template');

      return sendSuccess(reply, template);
    }
  );

  /**
   * PATCH /api/v1/notifications/templates/:id
   * Update a notification template
   */
  fastify.patch<{ Params: { id: string }; Body: UpdateTemplateBody }>(
    '/api/v1/notifications/templates/:id',
    {
      schema: updateTemplateSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const { id } = request.params;
      const updates = request.body;

      await findOrThrow(() => db.notificationTemplates.findById(id), 'Template');

      const updatedTemplate = await db.notificationTemplates.update(
        id,
        updates as unknown as UpdateTemplateInput
      );

      logger.info('Notification template updated', {
        templateId: id,
        userId: request.authUser?.id,
        updates: Object.keys(updates),
      });

      return sendSuccess(reply, updatedTemplate);
    }
  );

  /**
   * DELETE /api/v1/notifications/templates/:id
   * Delete a notification template
   */
  fastify.delete<{ Params: { id: string } }>(
    '/api/v1/notifications/templates/:id',
    {
      schema: deleteTemplateSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const { id } = request.params;

      await findOrThrow(() => db.notificationTemplates.findById(id), 'Template');

      await db.notificationTemplates.delete(id);

      logger.info('Notification template deleted', {
        templateId: id,
        userId: request.authUser?.id,
      });

      return sendSuccess(reply, {
        message: 'Notification template deleted successfully',
      });
    }
  );

  /**
   * POST /api/v1/notifications/templates/preview
   * Preview a notification template with test data
   */
  fastify.post<{ Body: PreviewTemplateBody }>(
    '/api/v1/notifications/templates/preview',
    {
      schema: previewTemplateSchema,
      preHandler: [requireRole('admin')],
    },
    async (request, reply) => {
      const { template_body, subject, context } = request.body;

      const rendered = renderTemplatePreview(template_body, subject, context);

      return sendSuccess(reply, rendered);
    }
  );

  // ============================================================================
  // NOTIFICATION HISTORY ROUTES
  // ============================================================================

  /**
   * GET /api/v1/notifications/history
   * List notification delivery history with filtering and pagination
   */
  fastify.get<{ Querystring: HistoryQuerystring }>(
    '/api/v1/notifications/history',
    {
      schema: listHistorySchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { channel_id, rule_id, bug_id, status, created_after, created_before, page, limit } =
        request.query;

      const pagination = buildPagination(page, limit);

      const filters: Record<string, unknown> = {};
      if (channel_id) {
        filters.channel_id = channel_id;
      }
      if (rule_id) {
        filters.rule_id = rule_id;
      }
      if (bug_id) {
        filters.bug_id = bug_id;
      }
      if (status) {
        filters.status = status;
      }
      if (created_after) {
        filters.created_after = new Date(created_after);
      }
      if (created_before) {
        filters.created_before = new Date(created_before);
      }

      const result = await db.notificationHistory.findAll(filters, pagination);

      return sendSuccess(reply, {
        history: result.data,
        pagination: result.pagination,
      });
    }
  );

  /**
   * GET /api/v1/notifications/history/:id
   * Get a specific notification history entry
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/notifications/history/:id',
    {
      schema: getHistoryItemSchema,
      preHandler: [requireUser],
    },
    async (request, reply) => {
      const { id } = request.params;

      const historyItem = await findOrThrow(
        () => db.notificationHistory.findByIdWithDetails(id),
        'History entry'
      );

      return sendSuccess(reply, historyItem);
    }
  );
}
