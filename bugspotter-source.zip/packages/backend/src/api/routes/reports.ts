/**
 * Bug Report routes
 * CRUD operations for bug reports
 * Single Responsibility: HTTP request/response handling for bug reports
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import type { IStorageService } from '../../storage/types.js';
import {
  createBugReportSchema,
  listBugReportsSchema,
  getBugReportSchema,
  updateBugReportSchema,
  BugStatus,
  BugPriority,
} from '../schemas/bug-report-schema.js';
import { requireProject } from '../middleware/auth.js';
import { sendSuccess, sendCreated, sendPaginated } from '../utils/response.js';
import { buildPagination, buildSort, parseDateFilter } from '../utils/query-builder.js';
import { buildAccessFilters, validateProjectAccess } from '../utils/bug-report-access.js';
import { triggerBugReportNotification } from '../utils/notification-trigger.js';
import { triggerBugReportIntegrations } from '../utils/integration-trigger.js';
import { prepareUploadUrls } from '../utils/upload-batch-handler.js';
import { findReportWithAccess } from '../utils/bug-report-helpers.js';
import type { NotificationService } from '../../services/notifications/notification-service.js';
import { SessionService } from '../../services/session-service.js';
import type {
  CreateReportBody,
  UpdateReportBody,
  ListReportsQuery,
  BugReportMetadata,
} from '../types/bug-report-types.js';
import { getLogger } from '../../logger.js';
import type { QueueManager } from '../../queue/queue-manager.js';
import type { PluginRegistry } from '../../integrations/plugin-registry.js';

const logger = getLogger();

export function bugReportRoutes(
  fastify: FastifyInstance,
  db: DatabaseClient,
  storage: IStorageService,
  notificationService?: NotificationService,
  queueManager?: QueueManager,
  pluginRegistry?: PluginRegistry
) {
  // Initialize session service
  const sessionService = new SessionService(storage);

  /**
   * POST /api/v1/reports
   * Create a new bug report
   */
  fastify.post<{ Body: CreateReportBody }>(
    '/api/v1/reports',
    {
      schema: createBugReportSchema,
      preHandler: requireProject,
    },
    async (request, reply) => {
      const { title, description, priority, report, hasScreenshot, hasReplay } = request.body;

      const projectId = request.authProject!.id;

      // Log key request details with metadata counts for diagnostics
      logger.info('Creating bug report', {
        title,
        priority,
        hasScreenshot,
        hasReplay,
        consoleCount: report.console?.length ?? 0,
        networkCount: report.network?.length ?? 0,
        hasMetadata: !!report.metadata,
        metadataKeys: report.metadata ? Object.keys(report.metadata) : [],
      });

      // Debug: Log first console entry to verify data structure
      if (report.console && report.console.length > 0) {
        logger.debug('Sample console log', {
          first: report.console[0],
          total: report.console.length,
        });
      }

      // Create bug report with appropriate status and keys
      // Note: upload_status starts as 'none' and will be set to 'pending' by initiateUpload
      const bugReport = await db.bugReports.create({
        project_id: projectId,
        title,
        description: description || null,
        priority: priority || BugPriority.MEDIUM,
        status: BugStatus.OPEN,
        metadata: {
          console: report.console,
          network: report.network,
          metadata: report.metadata,
        },
        screenshot_url: null,
        replay_url: null,
        screenshot_key: null,
        upload_status: 'none',
        replay_key: null,
        replay_upload_status: 'none',
      });

      // Debug: Verify metadata was saved correctly
      const metadata = bugReport.metadata as BugReportMetadata;
      logger.debug('Bug report created with metadata', {
        bugId: bugReport.id,
        metadataConsoleCount: metadata.console?.length ?? 0,
        metadataNetworkCount: metadata.network?.length ?? 0,
        metadataKeys: metadata.metadata ? Object.keys(metadata.metadata) : [],
      });

      // Generate presigned URLs if requested
      const presignedUrls = await prepareUploadUrls(
        bugReport,
        hasScreenshot || false,
        hasReplay || false,
        db,
        storage
      );

      // Trigger notification (non-blocking, logs errors)
      await triggerBugReportNotification(
        bugReport,
        request.authProject as unknown as Record<string, unknown>,
        notificationService
      );

      // Trigger integrations if configured (non-blocking, logs errors)
      await triggerBugReportIntegrations(bugReport, projectId, queueManager, db, pluginRegistry);

      // Return bug report with presigned URLs if generated
      const response =
        Object.keys(presignedUrls).length > 0 ? { ...bugReport, presignedUrls } : bugReport;

      return sendCreated(reply, response);
    }
  );

  /**
   * GET /api/v1/reports
   * List bug reports with filtering, sorting, and pagination
   */
  fastify.get<{ Querystring: ListReportsQuery }>(
    '/api/v1/reports',
    {
      schema: listBugReportsSchema,
    },
    async (request, reply) => {
      const {
        page,
        limit,
        status,
        priority,
        project_id,
        created_after,
        created_before,
        sort_by,
        order,
      } = request.query;

      // Parse date filters with validation
      const createdAfterDate = parseDateFilter(created_after, 'created_after');
      const createdBeforeDate = parseDateFilter(created_before, 'created_before');

      // Build access control filters based on authentication type
      const { filters, requiresValidation } = buildAccessFilters(
        request.authUser,
        request.authProject,
        project_id,
        {
          status,
          priority,
          created_after: createdAfterDate,
          created_before: createdBeforeDate,
        }
      );

      // Validate project access if required (regular user + specific project_id)
      if (requiresValidation && project_id && request.authUser) {
        await validateProjectAccess(project_id, request.authUser.id, db);
      }

      const sort = buildSort(sort_by, order, 'created_at' as const);
      const pagination = buildPagination(page, limit);
      const result = await db.bugReports.list(filters, sort, pagination);

      return sendPaginated(reply, result.data, result.pagination);
    }
  );

  /**
   * GET /api/v1/reports/:id
   * Get a single bug report by ID
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/reports/:id',
    {
      schema: getBugReportSchema,
    },
    async (request, reply) => {
      const { id } = request.params;

      const bugReport = await findReportWithAccess(id, request.authUser, request.authProject, db);

      // Type assertion for metadata field
      const typedReport = {
        ...bugReport,
        metadata: bugReport.metadata as BugReportMetadata,
      };

      return sendSuccess(reply, typedReport);
    }
  );

  /**
   * PATCH /api/v1/reports/:id
   * Update a bug report (status, priority, description)
   */
  fastify.patch<{ Params: { id: string }; Body: UpdateReportBody }>(
    '/api/v1/reports/:id',
    {
      schema: updateBugReportSchema,
    },
    async (request, reply) => {
      const { id } = request.params;
      const updates = request.body;

      await findReportWithAccess(id, request.authUser, request.authProject, db);
      const updated = await db.bugReports.update(id, updates);

      return sendSuccess(reply, updated);
    }
  );

  /**
   * GET /api/v1/reports/:id/sessions
   * Get session data (console logs, network requests, replay events) for a bug report
   */
  fastify.get<{ Params: { id: string } }>(
    '/api/v1/reports/:id/sessions',
    async (request, reply) => {
      const { id } = request.params;

      const bugReport = await findReportWithAccess(id, request.authUser, request.authProject, db);

      // Delegate to SessionService for data aggregation
      const sessions = await sessionService.getSessions(bugReport);

      return sendSuccess(reply, sessions);
    }
  );
}
