/**
 * Admin routes
 * System health monitoring and settings management
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import type {
  WorkerHealth,
  QueueHealth,
  PluginHealth,
  ServiceHealth,
  HealthStatus,
} from '@bugspotter/types';
import { sendSuccess } from '../utils/response.js';
import { requireRole } from '../middleware/auth.js';
import { parseTimeString } from '../utils/constants.js';
import { getBooleanSettingWithEnv, getNumberSettingWithEnv } from '../utils/settings-helpers.js';
import { getLogger } from '../../logger.js';
import fs from 'fs/promises';
import os from 'os';
import { config } from '../../config.js';

const logger = getLogger();

/**
 * Health check thresholds for determining system issues
 */
const MIN_JOBS_FOR_FAILURE_RATE = 10; // Minimum jobs before calculating failure rate
const FAILURE_RATE_THRESHOLD = 0.1; // 10% failure rate triggers issue flag
const WAITING_JOBS_BACKLOG_THRESHOLD = 20; // Jobs waiting with no active processing

interface InstanceSettings {
  instance_name: string;
  instance_url: string;
  support_email: string;
  storage_type: 'minio' | 's3';
  storage_endpoint?: string;
  storage_bucket: string;
  storage_region?: string;
  jwt_access_expiry: number;
  jwt_refresh_expiry: number;
  rate_limit_max: number;
  rate_limit_window: number;
  cors_origins: string[];
  retention_days: number;
  max_reports_per_project: number;
  session_replay_enabled: boolean;
  replay_duration: number;
  replay_inline_stylesheets: boolean;
  replay_inline_images: boolean;
  replay_collect_fonts: boolean;
  replay_record_canvas: boolean;
  replay_record_cross_origin_iframes: boolean;
  replay_sampling_mousemove: number;
  replay_sampling_scroll: number;
}

/**
 * Check database health
 */
async function checkDatabaseHealth(db: DatabaseClient): Promise<ServiceHealth> {
  const start = Date.now();
  try {
    await db.query('SELECT 1');
    return {
      status: 'up',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: 'down',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

/**
 * Check Redis health
 */
async function checkRedisHealth(): Promise<ServiceHealth> {
  const start = Date.now();
  try {
    // Import dynamically to avoid circular dependencies
    const { getQueueManager } = await import('../../queue/index.js');
    const queueManager = getQueueManager();

    // Simple ping to verify Redis connection
    await queueManager.getConnection().ping();

    return {
      status: 'up',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';

    // Log critical Redis errors for alerting
    if (errorMessage.includes('suspended') || errorMessage.includes('ECONNREFUSED')) {
      logger.error('[CRITICAL] Redis service unavailable:', {
        error: errorMessage,
        timestamp: new Date().toISOString(),
        message: errorMessage.includes('suspended')
          ? 'Redis database has been suspended - check provider dashboard'
          : 'Redis connection refused - service may be down',
      });
    }

    return {
      status: 'down',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
      error: errorMessage,
    };
  }
}

/**
 * Check storage health
 */
async function checkStorageHealth(): Promise<ServiceHealth> {
  const start = Date.now();
  try {
    // Check based on storage backend
    if (config.storage.backend === 'local') {
      await fs.access(config.storage.local.baseDirectory);
    } else {
      // S3-compatible storage (s3, minio, r2)
      const { createStorageFromEnv } = await import('../../storage/index.js');
      const storage = createStorageFromEnv();
      const healthy = await storage.healthCheck();

      if (!healthy) {
        throw new Error('Storage health check failed');
      }
    }

    return {
      status: 'up',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: 'down',
      response_time: Date.now() - start,
      last_check: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

/**
 * Get disk space information
 */
async function getDiskSpace(): Promise<{ available: number; total: number }> {
  try {
    // Check disk space for /app directory (where application runs in Docker)
    // This gives more accurate container storage vs host system disk
    const diskUsage = await fs.statfs('/app');
    return {
      available: diskUsage.bavail * diskUsage.bsize,
      total: diskUsage.blocks * diskUsage.bsize,
    };
  } catch {
    // Fallback for non-Docker environments (development, Windows)
    // Use current working directory or root
    const fallbackPath = process.cwd();
    const diskUsage = await fs.statfs(fallbackPath);
    return {
      available: diskUsage.bavail * diskUsage.bsize,
      total: diskUsage.blocks * diskUsage.bsize,
    };
  }
}

/**
 * Get total worker queue depth across all queues
 */
async function getWorkerQueueDepth(): Promise<number> {
  try {
    const { getQueueManager } = await import('../../queue/index.js');
    const queueManager = getQueueManager();
    const stats = await queueManager.getQueueStats();

    // Sum waiting and active jobs across all queues
    return Object.values(stats).reduce(
      (total, queueMetrics) => total + queueMetrics.waiting + queueMetrics.active,
      0
    );
  } catch {
    // If queue manager isn't initialized, return 0
    return 0;
  }
}

/**
 * Get worker health status
 * Reads from Redis heartbeats (sent by worker process every 10s)
 * Falls back to queue stats if heartbeats unavailable
 */
async function getWorkerHealth(): Promise<WorkerHealth[]> {
  try {
    const { getQueueConfig, WORKER_NAMES } = await import('../../config/queue.config.js');
    const { getQueueManager } = await import('../../queue/index.js');
    const { getAllWorkerHeartbeats } = await import('../../queue/heartbeat.js');

    const queueConfig = getQueueConfig();
    const queueManager = getQueueManager();
    const connection = queueManager.getConnection();

    // Define all worker types to check (derived from WORKER_NAMES - single source of truth)
    const workerTypes = Object.values(WORKER_NAMES);

    // Get heartbeats from Redis (workers send these every 10 seconds)
    const heartbeats = await getAllWorkerHeartbeats(connection, [...workerTypes]);

    // Get queue stats for fallback
    const queueStats = await queueManager.getQueueStats();

    // Map heartbeats to worker health
    const workers: WorkerHealth[] = workerTypes
      .filter((workerType) => queueConfig.workers[workerType].enabled)
      .map((workerType) => {
        const heartbeat = heartbeats.get(workerType);

        // If heartbeat exists, use it (most accurate)
        if (heartbeat) {
          return {
            name: workerType,
            enabled: true,
            running: heartbeat.status !== 'stopped',
            jobs_processed: heartbeat.jobs_processed,
            jobs_failed: heartbeat.jobs_failed,
            avg_processing_time_ms: heartbeat.avg_processing_time_ms,
            last_processed_at: undefined, // Not tracked yet
            last_error: heartbeat.last_error,
          };
        }

        // Fallback to queue stats if heartbeat missing (worker might not have started yet)
        const workerQueueStats = queueStats[workerType];

        let isRunning = false;
        let lastError: string | undefined;

        if (workerQueueStats) {
          if (workerQueueStats.active > 0) {
            // Worker is actively processing jobs
            isRunning = true;
          } else if (workerQueueStats.waiting > 0) {
            // Jobs waiting but none active - worker appears to be down
            isRunning = false;
            lastError = `${workerQueueStats.waiting} job(s) waiting but worker not processing`;
          } else {
            // No jobs waiting or active - worker status unknown without heartbeat
            isRunning = false;
            lastError = 'No heartbeat received (worker may not be running)';
          }
        } else {
          lastError = 'No heartbeat or queue stats available';
        }

        return {
          name: workerType,
          enabled: true,
          running: isRunning,
          jobs_processed: workerQueueStats?.completed || 0,
          jobs_failed: workerQueueStats?.failed || 0,
          avg_processing_time_ms: 0,
          last_processed_at: undefined,
          last_error: lastError,
        };
      });

    return workers;
  } catch (error) {
    logger.error('[HEALTH] Failed to get worker health:', {
      error: error instanceof Error ? error.message : String(error),
      timestamp: new Date().toISOString(),
    });
    return [];
  }
}

/**
 * Get queue health status
 */
async function getQueueHealth(): Promise<QueueHealth[]> {
  try {
    const { getQueueManager } = await import('../../queue/index.js');
    const queueManager = getQueueManager();
    const stats = await queueManager.getQueueStats();

    return Object.entries(stats).map(([name, metrics]) => ({
      name,
      waiting: metrics.waiting,
      active: metrics.active,
      completed: metrics.completed,
      failed: metrics.failed,
      delayed: metrics.delayed,
      paused: metrics.paused,
    }));
  } catch (error) {
    logger.error('[HEALTH] Failed to get queue health:', {
      error: error instanceof Error ? error.message : String(error),
      timestamp: new Date().toISOString(),
    });
    return [];
  }
}

/**
 * Get plugin registry health from request context
 * Shows loaded plugins from registry AND custom plugins from database
 */
async function getPluginHealth(
  pluginRegistry: import('../../integrations/plugin-registry.js').PluginRegistry | undefined,
  db: DatabaseClient
): Promise<PluginHealth[]> {
  const pluginsMap = new Map<string, PluginHealth>();

  // Get loaded plugins from registry
  if (pluginRegistry) {
    try {
      const platforms = pluginRegistry.getSupportedPlatforms();

      for (const platform of platforms) {
        const plugin = pluginRegistry.get(platform);
        const metadata = pluginRegistry.getPluginMetadata(platform);
        const isCustom = metadata?.isBuiltIn === false;

        pluginsMap.set(platform, {
          platform,
          enabled: !!plugin,
          type: isCustom ? ('custom' as const) : ('built-in' as const),
        });
      }
    } catch (error) {
      logger.error('[HEALTH] Failed to get plugin registry health:', {
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // Get custom plugins from database (may not be loaded yet)
  try {
    const customPlugins = await db.integrations.getCustomPluginsPlatforms();

    for (const row of customPlugins) {
      // If not in registry, add as custom plugin
      if (!pluginsMap.has(row.platform)) {
        pluginsMap.set(row.platform, {
          platform: row.platform,
          enabled: row.enabled,
          type: 'custom' as const,
        });
      }
    }
  } catch (error) {
    logger.error('[HEALTH] Failed to get custom plugins from database:', {
      error: error instanceof Error ? error.message : String(error),
    });
  }

  return Array.from(pluginsMap.values());
}

/**
 * Writable settings keys that can be stored in database
 */
const WRITABLE_SETTINGS = new Set([
  'instance_name',
  'instance_url',
  'support_email',
  'retention_days',
  'max_reports_per_project',
  'session_replay_enabled',
  'replay_duration',
  'replay_inline_stylesheets',
  'replay_inline_images',
  'replay_collect_fonts',
  'replay_record_canvas',
  'replay_record_cross_origin_iframes',
  'replay_sampling_mousemove',
  'replay_sampling_scroll',
]);

export async function adminRoutes(
  fastify: FastifyInstance,
  db: DatabaseClient,
  pluginRegistry?: import('../../integrations/plugin-registry.js').PluginRegistry
): Promise<void> {
  /**
   * Get instance settings from database
   */
  async function getInstanceSettings(): Promise<Record<string, unknown>> {
    try {
      const config = await db.systemConfig.get('instance_settings');
      return config?.value || {};
    } catch {
      return {};
    }
  }

  /**
   * Update instance settings in database
   */
  async function updateInstanceSettings(
    updates: Partial<InstanceSettings>,
    userId: string
  ): Promise<void> {
    // Filter to only writable settings
    const filteredUpdates = Object.entries(updates).reduce(
      (acc, [key, value]) => {
        if (WRITABLE_SETTINGS.has(key)) {
          acc[key] = value;
        }
        return acc;
      },
      {} as Record<string, unknown>
    );

    if (Object.keys(filteredUpdates).length === 0) {
      return;
    }

    // Get current settings
    const currentSettings = await getInstanceSettings();

    // Merge with updates
    const newSettings = { ...currentSettings, ...filteredUpdates };

    // Update in database using repository
    await db.systemConfig.set(
      'instance_settings',
      newSettings,
      'Instance-wide configuration settings (admin panel)',
      userId
    );
  }

  /**
   * Type-safe helper to get string setting
   */
  function getStringSetting(
    settings: Record<string, unknown>,
    key: string,
    envKey: string,
    defaultValue: string
  ): string {
    const value = settings[key];
    if (typeof value === 'string') {
      return value;
    }
    return process.env[envKey] || defaultValue;
  }

  /**
   * Build complete InstanceSettings object from database settings
   * Combines writable settings from database with read-only settings from config
   */
  function buildInstanceSettings(dbSettings: Record<string, unknown>): InstanceSettings {
    return {
      instance_name: getStringSetting(dbSettings, 'instance_name', 'INSTANCE_NAME', 'BugSpotter'),
      instance_url: getStringSetting(
        dbSettings,
        'instance_url',
        'INSTANCE_URL',
        'http://localhost:3000'
      ),
      support_email: getStringSetting(
        dbSettings,
        'support_email',
        'SUPPORT_EMAIL',
        'support@bugspotter.dev'
      ),
      storage_type: config.storage.backend === 's3' ? 's3' : 'minio',
      storage_endpoint: config.storage.s3.endpoint,
      storage_bucket: config.storage.s3.bucket || 'bugspotter',
      storage_region: config.storage.s3.region,
      jwt_access_expiry: parseTimeString(config.jwt.expiresIn),
      jwt_refresh_expiry: parseTimeString(config.jwt.refreshExpiresIn),
      rate_limit_max: config.rateLimit.maxRequests,
      rate_limit_window: Math.floor(config.rateLimit.windowMs / 1000),
      cors_origins: config.server.corsOrigins,
      retention_days: getNumberSettingWithEnv(dbSettings, 'retention_days', 'RETENTION_DAYS', 90),
      max_reports_per_project: getNumberSettingWithEnv(
        dbSettings,
        'max_reports_per_project',
        'MAX_REPORTS_PER_PROJECT',
        10000
      ),
      session_replay_enabled: getBooleanSettingWithEnv(
        dbSettings,
        'session_replay_enabled',
        'SESSION_REPLAY_ENABLED',
        true
      ),
      replay_duration: getNumberSettingWithEnv(
        dbSettings,
        'replay_duration',
        'REPLAY_DURATION',
        15
      ),
      replay_inline_stylesheets: getBooleanSettingWithEnv(
        dbSettings,
        'replay_inline_stylesheets',
        null,
        true
      ),
      replay_inline_images: getBooleanSettingWithEnv(
        dbSettings,
        'replay_inline_images',
        null,
        false
      ),
      replay_collect_fonts: getBooleanSettingWithEnv(
        dbSettings,
        'replay_collect_fonts',
        null,
        true
      ),
      replay_record_canvas: getBooleanSettingWithEnv(
        dbSettings,
        'replay_record_canvas',
        null,
        false
      ),
      replay_record_cross_origin_iframes: getBooleanSettingWithEnv(
        dbSettings,
        'replay_record_cross_origin_iframes',
        null,
        false
      ),
      replay_sampling_mousemove: getNumberSettingWithEnv(
        dbSettings,
        'replay_sampling_mousemove',
        null,
        50
      ),
      replay_sampling_scroll: getNumberSettingWithEnv(
        dbSettings,
        'replay_sampling_scroll',
        null,
        100
      ),
    };
  }

  /**
   * GET /api/v1/admin/health
   * Get comprehensive system health status
   * Includes services, workers, queues, plugins, and system metrics
   * Requires: admin role
   */
  fastify.get(
    '/api/v1/admin/health',
    { onRequest: [requireRole('admin')] },
    async (_request, reply) => {
      const [databaseHealth, redisHealth, storageHealth, diskSpace, workers, queues, plugins] =
        await Promise.all([
          checkDatabaseHealth(db),
          checkRedisHealth(),
          checkStorageHealth(),
          getDiskSpace(),
          getWorkerHealth(),
          getQueueHealth(),
          getPluginHealth(pluginRegistry, db),
        ]);

      // Determine overall status based on comprehensive health indicators
      const servicesDown = [databaseHealth, redisHealth, storageHealth].filter(
        (s) => s.status === 'down'
      ).length;

      // Workers with issues (down or high failure rate)
      const workersWithIssues = workers.filter((w) => {
        if (!w.enabled) {
          return false;
        }

        // Worker is down
        if (!w.running) {
          return true;
        }

        // Worker has high failure rate (>10% failures)
        const totalJobs = w.jobs_processed + w.jobs_failed;
        if (
          totalJobs > MIN_JOBS_FOR_FAILURE_RATE &&
          w.jobs_failed / totalJobs > FAILURE_RATE_THRESHOLD
        ) {
          return true;
        }

        return false;
      }).length;

      // Queues with issues (paused or high failure rate)
      const queuesWithIssues = queues.filter((q) => {
        // Queue is paused (operational issue)
        if (q.paused) {
          return true;
        }

        // High failure rate (>10% failures)
        const totalJobs = q.completed + q.failed;
        if (
          totalJobs > MIN_JOBS_FOR_FAILURE_RATE &&
          q.failed / totalJobs > FAILURE_RATE_THRESHOLD
        ) {
          return true;
        }

        // Jobs piling up (>20 waiting, none active)
        if (q.waiting > WAITING_JOBS_BACKLOG_THRESHOLD && q.active === 0) {
          return true;
        }

        return false;
      }).length;

      const totalIssues = servicesDown + workersWithIssues + queuesWithIssues;

      let overallStatus: 'healthy' | 'degraded' | 'unhealthy';
      if (totalIssues === 0) {
        overallStatus = 'healthy';
      } else if (totalIssues === 1) {
        overallStatus = 'degraded';
      } else {
        overallStatus = 'unhealthy';
      }

      // Get memory usage (RSS for total process memory footprint vs total system memory)
      const memUsage = process.memoryUsage();

      const health: HealthStatus = {
        status: overallStatus,
        timestamp: new Date().toISOString(),
        services: {
          database: databaseHealth,
          redis: redisHealth,
          storage: storageHealth,
        },
        workers,
        queues,
        plugins,
        system: {
          disk_space_available: diskSpace.available,
          disk_space_total: diskSpace.total,
          worker_queue_depth: await getWorkerQueueDepth(),
          uptime: process.uptime(),
          node_version: process.version,
          process_memory_mb: Math.round(memUsage.rss / 1024 / 1024),
          system_memory_mb: Math.round(os.totalmem() / 1024 / 1024),
        },
      };

      return sendSuccess(reply, health);
    }
  );

  /**
   * GET /api/v1/admin/settings
   * Get instance settings
   * Note: Writable settings from database, read-only from environment
   * Requires: admin role
   */
  fastify.get(
    '/api/v1/admin/settings',
    { onRequest: [requireRole('admin')] },
    async (_request, reply) => {
      // Fetch writable settings from database
      const dbSettings = await getInstanceSettings();

      // Build complete settings object
      const settings = buildInstanceSettings(dbSettings);

      return sendSuccess(reply, settings);
    }
  );

  /**
   * PATCH /api/v1/admin/settings
   * Update instance settings
   * Stores writable settings in database (no restart required)
   * Requires: admin role
   */
  fastify.patch<{ Body: Partial<InstanceSettings> }>(
    '/api/v1/admin/settings',
    { onRequest: [requireRole('admin')] },
    async (request, reply) => {
      const updates = request.body;
      const userId = request.authUser!.id;

      // Validate updates
      if (
        'instance_name' in updates &&
        (!updates.instance_name || updates.instance_name.length < 1)
      ) {
        return reply.code(400).send({ error: 'Instance name cannot be empty' });
      }

      // Write changes to database
      try {
        await updateInstanceSettings(updates, userId);
        request.log.info({ updates, userId }, 'Settings updated in database');
      } catch (error) {
        request.log.error({ error, updates }, 'Failed to update settings');
        return reply.code(500).send({ error: 'Failed to update settings' });
      }

      // Fetch updated settings from database
      const dbSettings = await getInstanceSettings();

      // Build complete settings object
      const settings = buildInstanceSettings(dbSettings);

      return sendSuccess(reply, settings);
    }
  );
}
