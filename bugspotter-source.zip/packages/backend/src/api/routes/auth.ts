/**
 * Authentication routes
 * User registration, login, and token refresh
 */

import type { FastifyInstance } from 'fastify';
import type { DatabaseClient } from '../../db/client.js';
import bcrypt from 'bcrypt';
import {
  loginSchema,
  registerSchema,
  refreshTokenSchema,
  magicLoginSchema,
} from '../schemas/auth-schema.js';
import { AppError } from '../middleware/error.js';
import { config } from '../../config.js';
import { sendSuccess, sendCreated } from '../utils/response.js';
import { findOrThrow, omitFields } from '../utils/resource.js';
import { PASSWORD, parseTimeString, DEFAULT_TOKEN_EXPIRY_SECONDS } from '../utils/constants.js';

interface LoginBody {
  email: string;
  password: string;
}

interface RegisterBody {
  email: string;
  password: string;
  role?: 'admin' | 'user' | 'viewer';
}

interface RefreshTokenBody {
  refresh_token: string;
}

/**
 * Generate JWT tokens for a user
 */
function generateTokens(fastify: FastifyInstance, userId: string, role: string) {
  const payload = { userId, role };

  const access_token = fastify.jwt.sign(payload, {
    expiresIn: config.jwt.expiresIn,
  });

  const refresh_token = fastify.jwt.sign(payload, {
    expiresIn: config.jwt.refreshExpiresIn,
  });

  // Calculate expiry time in seconds
  const expiresIn = parseTimeString(config.jwt.expiresIn, DEFAULT_TOKEN_EXPIRY_SECONDS);
  const refreshExpiresIn = parseTimeString(
    config.jwt.refreshExpiresIn,
    DEFAULT_TOKEN_EXPIRY_SECONDS
  );

  return {
    access_token,
    refresh_token,
    expires_in: expiresIn,
    refresh_expires_in: refreshExpiresIn,
    token_type: 'Bearer' as const,
  };
}

/**
 * Generate a magic token for passwordless authentication
 * Used for demo users and email-based login links
 *
 * @param fastify - Fastify instance with JWT plugin
 * @param userId - User ID to generate token for
 * @param role - User role
 * @param expiresIn - Token expiration (default: '24h')
 * @returns Magic token string that can be used in URL query parameter
 *
 * @example
 * const magicToken = generateMagicToken(fastify, user.id, user.role, '48h');
 * const loginUrl = `https://demo.bugspotter.io/login?token=${magicToken}`;
 */
export function generateMagicToken(
  fastify: FastifyInstance,
  userId: string,
  role: string,
  expiresIn: string = '24h'
): string {
  const payload = {
    userId,
    role,
    type: 'magic', // Distinguishes from regular access tokens
  };

  return fastify.jwt.sign(payload, { expiresIn });
}

/**
 * Validate JWT payload structure
 * Ensures payload has required userId (or sub) and role fields with correct types
 * Accepts both 'userId' (custom) and 'sub' (standard JWT claim) for flexibility
 *
 * @param decoded - Decoded JWT payload
 * @throws AppError if payload structure is invalid
 */
function validateJwtPayload(decoded: unknown): asserts decoded is { userId: string; role: string } {
  if (!decoded || typeof decoded !== 'object') {
    throw new AppError('Invalid token payload', 401, 'Unauthorized');
  }

  const payload = decoded as Record<string, unknown>;

  // Accept either 'userId' (custom) or 'sub' (standard JWT claim)
  const userId = payload.userId || payload.sub;
  if (!userId || typeof userId !== 'string') {
    throw new AppError('Invalid token: missing or invalid user identifier', 401, 'Unauthorized');
  }

  if (!payload.role || typeof payload.role !== 'string') {
    throw new AppError('Invalid token: missing or invalid role', 401, 'Unauthorized');
  }

  // Normalize to 'userId' for consistent downstream usage
  if (payload.sub && !payload.userId) {
    payload.userId = payload.sub as string;
  }
}

export function authRoutes(fastify: FastifyInstance, db: DatabaseClient) {
  /**
   * POST /api/v1/auth/register
   * Create a new user account
   */
  fastify.post<{ Body: RegisterBody }>(
    '/api/v1/auth/register',
    {
      schema: registerSchema,
      config: { public: true },
    },
    async (request, reply) => {
      const { email, password, role } = request.body;

      // Check if user already exists
      const existing = await db.users.findByEmail(email);
      if (existing) {
        throw new AppError('User with this email already exists', 409, 'Conflict');
      }

      // Hash password
      const password_hash = await bcrypt.hash(password, PASSWORD.SALT_ROUNDS);

      // Create user
      const user = await db.users.create({
        email,
        password_hash,
        role: role || 'user',
      });

      // Generate tokens
      const tokens = generateTokens(fastify, user.id, user.role);

      // Set refresh token in httpOnly cookie
      reply.setCookie('refresh_token', tokens.refresh_token, {
        httpOnly: true,
        secure: config.server.env === 'production',
        sameSite: 'strict',
        maxAge: tokens.refresh_expires_in,
        path: '/',
      });

      // Remove password hash from response
      const userWithoutPassword = omitFields(user, 'password_hash');

      return sendCreated(reply, {
        user: userWithoutPassword,
        access_token: tokens.access_token,
        expires_in: tokens.expires_in,
        token_type: tokens.token_type,
      });
    }
  );

  /**
   * POST /api/v1/auth/login
   * Authenticate user with email and password
   */
  fastify.post<{ Body: LoginBody }>(
    '/api/v1/auth/login',
    {
      schema: loginSchema,
      config: { public: true },
    },
    async (request, reply) => {
      const { email, password } = request.body;

      // Find user by email
      const user = await db.users.findByEmail(email);
      if (!user) {
        throw new AppError('Invalid email or password', 401, 'Unauthorized');
      }

      // Verify password
      if (!user.password_hash) {
        throw new AppError('Password login not available for this account', 401, 'Unauthorized');
      }

      const isValidPassword = await bcrypt.compare(password, user.password_hash);
      if (!isValidPassword) {
        throw new AppError('Invalid email or password', 401, 'Unauthorized');
      }

      // Generate tokens
      const tokens = generateTokens(fastify, user.id, user.role);

      // Set refresh token in httpOnly cookie
      reply.setCookie('refresh_token', tokens.refresh_token, {
        httpOnly: true,
        secure: config.server.env === 'production',
        sameSite: 'strict',
        maxAge: tokens.refresh_expires_in,
        path: '/',
      });

      // Remove password hash from response
      const userWithoutPassword = omitFields(user, 'password_hash');

      return sendSuccess(reply, {
        user: userWithoutPassword,
        access_token: tokens.access_token,
        expires_in: tokens.expires_in,
        token_type: tokens.token_type,
      });
    }
  );

  /**
   * POST /api/v1/auth/refresh
   * Refresh access token using refresh token from httpOnly cookie
   */
  fastify.post<{ Body: RefreshTokenBody }>(
    '/api/v1/auth/refresh',
    {
      schema: refreshTokenSchema,
      config: { public: true },
    },
    async (request, reply) => {
      // Try to get refresh token from cookie first (new secure method)
      let refresh_token = request.cookies.refresh_token;

      // Fallback to request body for backward compatibility
      if (!refresh_token && request.body?.refresh_token) {
        refresh_token = request.body.refresh_token;
      }

      if (!refresh_token) {
        throw new AppError('Refresh token not provided', 401, 'Unauthorized');
      }

      try {
        // Verify refresh token
        const decoded = fastify.jwt.verify(refresh_token);

        // Validate payload structure
        validateJwtPayload(decoded);

        // Verify user still exists
        const user = await findOrThrow(() => db.users.findById(decoded.userId), 'User');

        // Generate new tokens
        const tokens = generateTokens(fastify, user.id, user.role);

        // Set new refresh token in httpOnly cookie
        reply.setCookie('refresh_token', tokens.refresh_token, {
          httpOnly: true,
          secure: config.server.env === 'production',
          sameSite: 'strict',
          maxAge: tokens.refresh_expires_in,
          path: '/',
        });

        return sendSuccess(reply, {
          access_token: tokens.access_token,
          expires_in: tokens.expires_in,
          token_type: tokens.token_type,
        });
      } catch {
        throw new AppError('Invalid or expired refresh token', 401, 'Unauthorized');
      }
    }
  );

  /**
   * POST /api/v1/auth/magic-login
   * Authenticate user with a magic token (JWT-based passwordless login)
   * Used for demo environments and email-based login links
   */
  fastify.post<{ Body: { token: string } }>(
    '/api/v1/auth/magic-login',
    {
      schema: magicLoginSchema,
      config: { public: true },
    },
    async (request, reply) => {
      // Check if magic login is enabled
      if (!config.auth.magicLoginEnabled) {
        throw new AppError('Magic login is not enabled', 403, 'Forbidden');
      }

      const { token } = request.body;

      try {
        // Verify and decode magic token
        const decoded = fastify.jwt.verify(token) as {
          type?: string;
          userId: string;
          role: string;
        };

        // Validate payload structure
        validateJwtPayload(decoded);

        // Ensure this is actually a magic token (not a regular access token)
        if (decoded.type !== 'magic') {
          throw new AppError('Invalid token type', 401, 'Unauthorized');
        }

        // Verify user still exists and is not deleted
        const user = await findOrThrow(() => db.users.findById(decoded.userId), 'User');

        // Generate regular access/refresh tokens for the session
        const tokens = generateTokens(fastify, user.id, user.role);

        // Set refresh token in httpOnly cookie
        reply.setCookie('refresh_token', tokens.refresh_token, {
          httpOnly: true,
          secure: config.server.env === 'production',
          sameSite: 'strict',
          maxAge: tokens.refresh_expires_in,
          path: '/',
        });

        // Remove password hash from response
        const userWithoutPassword = omitFields(user, 'password_hash');

        return sendSuccess(reply, {
          user: userWithoutPassword,
          access_token: tokens.access_token,
          expires_in: tokens.expires_in,
          token_type: tokens.token_type,
        });
      } catch (error) {
        // Handle JWT verification errors
        if (error instanceof Error && error.name === 'TokenExpiredError') {
          throw new AppError('Magic token has expired', 401, 'Unauthorized');
        }
        if (error instanceof Error && error.name === 'JsonWebTokenError') {
          throw new AppError('Invalid magic token', 401, 'Unauthorized');
        }
        throw error;
      }
    }
  );

  /**
   * POST /api/v1/auth/logout
   * Logout user and clear refresh token cookie
   */
  fastify.post(
    '/api/v1/auth/logout',
    {
      config: { public: true },
    },
    async (_request, reply) => {
      // Clear refresh token cookie
      reply.clearCookie('refresh_token', {
        httpOnly: true,
        secure: config.server.env === 'production',
        sameSite: 'strict',
        path: '/',
      });

      return sendSuccess(reply, { message: 'Logged out successfully' });
    }
  );
}
