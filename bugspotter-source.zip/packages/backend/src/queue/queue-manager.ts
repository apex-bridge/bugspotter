/**
 * Queue Manager
 * Centralized management for BullMQ job queues
 */

import { Queue, QueueEvents } from 'bullmq';
import { Redis } from 'ioredis';
import { getLogger } from '../logger.js';
import { getQueueConfig } from '../config/queue.config.js';
import { getConnectionPool } from './redis-connection-pool.js';
import type {
  QueueName,
  JobOptions,
  JobStatus,
  JobState,
  JobProgress,
  QueueMetrics,
  QueueStats,
} from './types.js';
import { QUEUE_NAMES } from './types.js';
import { QueueNotFoundError } from './errors.js';

const logger = getLogger();

export class QueueManager {
  private connection: Redis;
  private queues: Map<QueueName, Queue>;
  private queueEvents: Map<QueueName, QueueEvents>;
  private isShuttingDown = false;
  private isInitialized = false;

  constructor() {
    const startTime = Date.now();
    logger.info('QueueManager constructor started');

    const config = getQueueConfig();

    // Use connection pool to limit concurrent connections
    logger.info('Initializing Redis connection from pool', {
      url: config.redis.url.replace(/\/\/[^@]+@/, '//***@'),
    });

    // Temporary placeholder - will be initialized async in initialize()
    this.connection = null as unknown as Redis;

    this.queues = new Map();
    this.queueEvents = new Map();

    logger.info('QueueManager constructor completed', {
      duration: Date.now() - startTime,
    });
  }

  /**
   * Initialize all queues
   */
  async initialize(): Promise<void> {
    const startTime = Date.now();
    logger.info('QueueManager.initialize() started');

    if (this.isInitialized) {
      logger.warn('Queue manager already initialized');
      return;
    }

    // Get connection from pool
    const pool = getConnectionPool();
    this.connection = await pool.getMainConnection();

    logger.info('Redis connection obtained from pool', {
      activeConnections: pool.getConnectionCount(),
    });

    // Handle connection events with detailed timing
    this.connection.on('connect', () => {
      const elapsed = Date.now() - startTime;
      logger.info('✅ QueueManager Redis connection established', { elapsed });
    });

    this.connection.on('ready', () => {
      const elapsed = Date.now() - startTime;
      logger.info('✅ QueueManager Redis ready', { elapsed });
    });

    this.connection.on('error', (error: Error) => {
      logger.error('❌ QueueManager Redis connection error', {
        error: error.message,
        code: (error as NodeJS.ErrnoException).code,
        elapsed: Date.now() - startTime,
      });
    });

    this.connection.on('close', () => {
      if (!this.isShuttingDown) {
        logger.warn('⚠️ QueueManager Redis connection closed unexpectedly', {
          elapsed: Date.now() - startTime,
        });
      }
    });

    const queueNames = Object.values(QUEUE_NAMES);
    logger.info('Creating queues', { count: queueNames.length, names: queueNames });

    for (const queueName of queueNames) {
      const queueStartTime = Date.now();
      await this.createQueue(queueName);
      logger.info('Queue created', {
        name: queueName,
        duration: Date.now() - queueStartTime,
      });
    }

    this.isInitialized = true;

    logger.info('Queue manager initialized successfully', {
      queues: Array.from(this.queues.keys()),
      totalDuration: Date.now() - startTime,
      activeConnections: pool.getConnectionCount(),
    });
  }

  /**
   * Create a queue and its event listeners
   */
  private async createQueue(queueName: QueueName): Promise<void> {
    const config = getQueueConfig();

    // Create queue
    const queue = new Queue(queueName, {
      connection: this.connection,
      defaultJobOptions: {
        attempts: config.jobs.maxRetries,
        backoff: {
          type: 'exponential',
          delay: config.jobs.backoffDelay,
        },
        removeOnComplete: {
          age: config.jobs.retentionDays * 24 * 60 * 60, // Convert days to seconds
          count: 1000,
        },
        removeOnFail: {
          age: config.jobs.retentionDays * 24 * 60 * 60,
          count: 5000,
        },
      },
    });

    // Create queue events listener
    // Each QueueEvents needs its own connection for proper event isolation
    const queueEvents = new QueueEvents(queueName, {
      connection: this.connection.duplicate(),
    });

    // Set up event listeners
    this.attachQueueEventHandlers(queueEvents, queueName);

    this.queues.set(queueName, queue);
    this.queueEvents.set(queueName, queueEvents);
  }

  /**
   * Attach standard event handlers to queue events
   * Extracted to eliminate duplication and improve maintainability
   */
  private attachQueueEventHandlers(queueEvents: QueueEvents, queueName: QueueName): void {
    queueEvents.on('completed', ({ jobId }) => {
      logger.debug('Job completed', { queue: queueName, jobId });
    });

    queueEvents.on('failed', ({ jobId, failedReason }) => {
      logger.error('Job failed', { queue: queueName, jobId, reason: failedReason });
    });

    queueEvents.on('progress', ({ jobId, data }) => {
      logger.debug('Job progress', { queue: queueName, jobId, progress: data });
    });
  }

  /**
   * Get queue or throw error if not found
   * Eliminates duplication across 6+ methods
   */
  private getQueueOrThrow(queueName: QueueName): Queue {
    const queue = this.queues.get(queueName);
    if (!queue) {
      throw new QueueNotFoundError(queueName);
    }
    return queue;
  }

  /**
   * Get managed queue instance (for admin/inspection operations)
   * Returns the existing queue instance to avoid creating duplicate connections
   */
  getQueue(queueName: QueueName): Queue {
    return this.getQueueOrThrow(queueName);
  }

  /**
   * Add a job to a queue
   */
  async addJob<TData>(
    queueName: QueueName,
    jobName: string,
    data: TData,
    options?: JobOptions
  ): Promise<string> {
    const queue = this.getQueueOrThrow(queueName);

    logger.info('🔵 [QUEUE MANAGER] Adding job to queue', {
      queue: queueName,
      jobName,
      dataKeys: Object.keys(data as object),
      options: options ? Object.keys(options) : [],
    });

    const job = await queue.add(jobName, data, options);

    logger.info('✅ [QUEUE MANAGER] Job added successfully', {
      queue: queueName,
      jobId: job.id,
      jobName,
      timestamp: new Date().toISOString(),
    });

    return job.id!;
  }

  /**
   * Get a job by ID
   */
  async getJob<TData = unknown, TResult = unknown>(
    queueName: QueueName,
    jobId: string
  ): Promise<JobStatus<TData, TResult> | null> {
    const queue = this.getQueueOrThrow(queueName);

    const job = await queue.getJob(jobId);
    if (!job) {
      return null;
    }

    // BullMQ's getState() already returns JobState | 'unknown', so no validation needed
    const state = (await job.getState()) as JobState;

    return {
      id: job.id!,
      name: job.name,
      data: job.data as TData,
      progress: job.progress as JobProgress | null,
      returnValue: job.returnvalue as TResult,
      failedReason: job.failedReason ?? null,
      stacktrace: job.stacktrace ?? null,
      attemptsMade: job.attemptsMade,
      timestamp: job.timestamp,
      processedOn: job.processedOn ?? null,
      finishedOn: job.finishedOn ?? null,
      state,
    };
  }

  /**
   * Get job status
   */
  async getJobStatus(queueName: QueueName, jobId: string): Promise<string | null> {
    const queue = this.getQueueOrThrow(queueName);

    const job = await queue.getJob(jobId);
    if (!job) {
      return null;
    }

    return await job.getState();
  }

  /**
   * Get queue statistics
   */
  async getQueueStats(): Promise<QueueStats> {
    const stats: QueueStats = {};

    for (const [queueName, queue] of this.queues.entries()) {
      const counts = await queue.getJobCounts();
      const isPaused = await queue.isPaused();

      stats[queueName] = {
        waiting: counts.waiting || 0,
        active: counts.active || 0,
        completed: counts.completed || 0,
        failed: counts.failed || 0,
        delayed: counts.delayed || 0,
        paused: isPaused,
      };
    }

    return stats;
  }

  /**
   * Get metrics for a specific queue
   */
  async getQueueMetrics(queueName: QueueName): Promise<QueueMetrics> {
    const queue = this.getQueueOrThrow(queueName);

    const counts = await queue.getJobCounts();
    const isPaused = await queue.isPaused();

    return {
      waiting: counts.waiting || 0,
      active: counts.active || 0,
      completed: counts.completed || 0,
      failed: counts.failed || 0,
      delayed: counts.delayed || 0,
      paused: isPaused,
    };
  }

  /**
   * Pause a queue
   */
  async pauseQueue(queueName: QueueName): Promise<void> {
    const queue = this.getQueueOrThrow(queueName);

    await queue.pause();
    logger.info('Queue paused', { queue: queueName });
  }

  /**
   * Resume a queue
   */
  async resumeQueue(queueName: QueueName): Promise<void> {
    const queue = this.getQueueOrThrow(queueName);

    await queue.resume();
    logger.info('Queue resumed', { queue: queueName });
  }

  /**
   * Graceful shutdown
   */
  async shutdown(): Promise<void> {
    if (this.isShuttingDown) {
      logger.warn('Queue manager shutdown already in progress');
      return;
    }

    this.isShuttingDown = true;
    logger.info('Starting queue manager shutdown');

    try {
      // Close all queue event listeners
      for (const [queueName, queueEvents] of this.queueEvents.entries()) {
        await queueEvents.close();
        logger.debug('Queue events closed', { queue: queueName });
      }

      // Close all queues
      for (const [queueName, queue] of this.queues.entries()) {
        await queue.close();
        logger.debug('Queue closed', { queue: queueName });
      }

      // Close Redis connection (may already be closed during cleanup)
      if (this.connection.status === 'ready' || this.connection.status === 'connecting') {
        await this.connection.quit();
        logger.debug('Redis connection closed');
      } else {
        logger.debug('Redis connection already closed', { status: this.connection.status });
      }
    } catch (error) {
      logger.warn('Error during queue manager shutdown', {
        error: error instanceof Error ? error.message : String(error),
      });
    } finally {
      this.isInitialized = false;
      logger.info('Queue manager shutdown complete');
    }
  }

  /**
   * Health check - ping Redis
   */
  async healthCheck(): Promise<boolean> {
    try {
      await this.connection.ping();
      return true;
    } catch (error) {
      logger.error('Redis health check failed', {
        error: error instanceof Error ? error.message : String(error),
      });
      return false;
    }
  }

  /**
   * Get Redis connection for workers
   */
  getConnection(): Redis {
    return this.connection;
  }
}

// Export singleton instance
let queueManagerInstance: QueueManager | null = null;

export function getQueueManager(): QueueManager {
  if (!queueManagerInstance) {
    queueManagerInstance = new QueueManager();
  }
  return queueManagerInstance;
}
