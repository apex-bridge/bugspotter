/**
 * Notification Service
 * Core service for processing and delivering notifications based on rules
 */

import type { DatabaseClient } from '../../db/client.js';
import type { QueueManager } from '../../queue/queue-manager.js';
import { RuleMatcher } from '../rule-matcher.js';
import { EmailChannelHandler } from './email-handler.js';
import { SlackChannelHandler } from './slack-handler.js';
import { WebhookChannelHandler } from './webhook-handler.js';
import { DiscordChannelHandler } from './discord-handler.js';
import { TeamsChannelHandler } from './teams-handler.js';
import type {
  ChannelHandler,
  ChannelConfig,
  NotificationJob,
  TriggerEvent,
  NotificationPayload,
  FilterCondition,
  ThrottleConfig,
  ScheduleConfig,
} from '../../types/notifications.js';
import { getLogger } from '../../logger.js';
import { buildTemplateContext, renderTemplate } from './template-renderer.js';

const logger = getLogger();

// ============================================================================
// CONSTANTS
// ============================================================================

const NOTIFICATION_RETRY_CONFIG = {
  MAX_ATTEMPTS: 3,
  BACKOFF_DELAY_MS: 2000,
} as const;

// Filter operators and field mapping moved to RuleMatcher service
// for code reuse with integrations

// ============================================================================
// NOTIFICATION SERVICE
// ============================================================================

export class NotificationService {
  private handlers: Map<string, ChannelHandler>;

  constructor(
    private db: DatabaseClient,
    private queueManager?: QueueManager
  ) {
    logger.info('🔔 [NotificationService] Constructor called', {
      dbProvided: !!db,
      dbType: typeof db,
      hasProjects: !!(db && db.projects),
      hasNotificationRules: !!(db && db.notificationRules),
      dbKeys: db ? Object.keys(db).slice(0, 10) : [],
    });

    // Initialize channel handlers
    this.handlers = new Map<string, ChannelHandler>();
    this.handlers.set('email', new EmailChannelHandler());
    this.handlers.set('slack', new SlackChannelHandler());
    this.handlers.set('webhook', new WebhookChannelHandler());
    this.handlers.set('discord', new DiscordChannelHandler());
    this.handlers.set('teams', new TeamsChannelHandler());
  }

  /**
   * Process a new bug report and queue notifications
   */
  async processNewBug(
    bug: Record<string, unknown>,
    project: Record<string, unknown>
  ): Promise<void> {
    // Validate required fields
    if (!bug.id || typeof bug.id !== 'string') {
      throw new Error('Bug ID is required');
    }
    if (!project.id || typeof project.id !== 'string') {
      throw new Error('Project ID is required');
    }

    await this.processTrigger('new_bug', { bug, project });
  }

  /**
   * Process a trigger event and queue matching notifications
   */
  async processTrigger(
    event: TriggerEvent,
    context: { bug?: Record<string, unknown>; project: Record<string, unknown> }
  ): Promise<void> {
    try {
      // Get all enabled rules that match this trigger
      const allRules = await this.db.notificationRules.findAllWithChannels({ enabled: true });
      const matchingRules = allRules.filter((rule) => {
        return rule.triggers.some((trigger) => this.matchesTrigger(trigger, event, context));
      });

      logger.info('Processing trigger', {
        event,
        totalRules: allRules.length,
        matchingRules: matchingRules.length,
      });

      for (const rule of matchingRules) {
        // Check if context matches rule filters
        if (rule.filters && rule.filters.length > 0) {
          if (!context.bug) {
            logger.debug('Rule has filters but bug context missing', {
              ruleId: rule.id,
              ruleName: rule.name,
            });
            continue;
          }
          if (!this.matchesFilters(context.bug, rule.filters)) {
            logger.debug('Bug does not match rule filters', {
              ruleId: rule.id,
              ruleName: rule.name,
            });
            continue;
          }
        }

        // Check throttle limits
        if (rule.throttle && (await this.isThrottled(rule.id, rule.throttle, context))) {
          logger.info('Notification throttled', { ruleId: rule.id, ruleName: rule.name });
          continue;
        }

        // Check schedule
        if (rule.schedule && !this.isInSchedule(rule.schedule)) {
          logger.debug('Outside scheduled time', { ruleId: rule.id, ruleName: rule.name });
          continue;
        }

        // Queue notification
        if (this.queueManager) {
          await this.queueManager.addJob(
            'notifications',
            `notification-${rule.id}-${Date.now()}`,
            {
              rule_id: rule.id,
              bug_id: context.bug?.id as string,
              channel_ids: rule.channels,
              trigger_event: event,
              timestamp: new Date(),
            } as NotificationJob,
            {
              priority: rule.priority,
              attempts: NOTIFICATION_RETRY_CONFIG.MAX_ATTEMPTS,
              backoff: {
                type: 'exponential',
                delay: NOTIFICATION_RETRY_CONFIG.BACKOFF_DELAY_MS,
              },
            }
          );
          logger.info('Notification queued', { ruleId: rule.id, channels: rule.channels.length });
        } else {
          // Send immediately if no queue
          const bugId = context.bug?.id;
          await this.sendNotification({
            rule_id: rule.id,
            bug_id: typeof bugId === 'string' ? bugId : undefined,
            channel_ids: rule.channels,
            trigger_event: event,
            timestamp: new Date(),
          });
        }
      }
    } catch (error) {
      logger.error('Failed to process trigger', { event, error });
      throw error;
    }
  }

  /**
   * Send notification for a job (called by worker or immediately)
   */
  async sendNotification(job: NotificationJob): Promise<void> {
    try {
      // Validate and fetch required data
      const { rule, bug, project } = await this.fetchNotificationData(job);
      if (!rule || !bug || !project) {
        return; // Error already logged in fetchNotificationData
      }

      // Send to each channel
      for (const channelId of job.channel_ids) {
        await this.sendToChannel(channelId, rule, bug, project, job.trigger_event);
      }
    } catch (error) {
      logger.error('Failed to send notification', { job, error });
      throw error;
    }
  }

  /**
   * Fetch and validate data required for notification
   */
  private async fetchNotificationData(job: NotificationJob): Promise<{
    rule: Record<string, unknown> | null;
    bug: Record<string, unknown> | null;
    project: Record<string, unknown> | null;
  }> {
    const rule = await this.db.notificationRules.findByIdWithChannels(job.rule_id);
    if (!rule) {
      logger.error('Rule not found', { ruleId: job.rule_id });
      return { rule: null, bug: null, project: null };
    }

    if (!job.bug_id) {
      logger.error('Bug ID missing in job', { ruleId: job.rule_id });
      return { rule: null, bug: null, project: null };
    }

    const bug = await this.db.bugReports.findById(job.bug_id);
    if (!bug) {
      logger.error('Bug not found', { bugId: job.bug_id });
      return { rule: null, bug: null, project: null };
    }

    const project = await this.db.projects.findById(bug.project_id);
    if (!project) {
      logger.error('Project not found', { projectId: bug.project_id });
      return { rule: null, bug: null, project: null };
    }

    return {
      rule: rule as unknown as Record<string, unknown>,
      bug: bug as unknown as Record<string, unknown>,
      project: project as unknown as Record<string, unknown>,
    };
  }

  /**
   * Send notification to a specific channel
   */
  private async sendToChannel(
    channelId: string,
    rule: Record<string, unknown>,
    bug: Record<string, unknown>,
    project: Record<string, unknown>,
    triggerEvent: TriggerEvent
  ): Promise<void> {
    try {
      // Validate channel and get template
      const { channel, template } = await this.prepareChannelDelivery(channelId, triggerEvent);

      // Render template and send
      const context = buildTemplateContext(bug, project);
      const payload = renderTemplate(template as unknown as Record<string, unknown>, context);

      // Create history entry with complete data
      // Store recipients as array for efficient querying
      const recipients = Array.isArray(payload.to) ? payload.to : [payload.to];
      const historyId = await this.createHistoryEntry(
        channelId,
        rule.id as string,
        template.id as string,
        bug.id as string,
        recipients,
        payload,
        'pending'
      );

      try {
        const result = await this.deliverToChannel(channel, payload);

        // Update history and channel health
        await this.recordDeliveryResult(historyId, channelId, result);
      } catch (deliveryError) {
        await this.recordDeliveryFailure(historyId, channelId, deliveryError);
        throw deliveryError;
      }
    } catch (error) {
      // If history creation or preparation fails, log but don't create incomplete history
      logger.error('Failed to send to channel', {
        channelId,
        ruleId: rule.id,
        bugId: bug.id,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Validate channel and load template
   */
  private async prepareChannelDelivery(
    channelId: string,
    triggerEvent: TriggerEvent
  ): Promise<{ channel: Record<string, unknown>; template: Record<string, unknown> }> {
    const channel = await this.db.notificationChannels.findById(channelId);
    if (!channel || !channel.active) {
      throw new Error(`Channel ${channelId} not found or inactive`);
    }

    const template = await this.db.notificationTemplates.findActiveTemplate(
      channel.type,
      triggerEvent
    );
    if (!template) {
      throw new Error(`No active template for ${channel.type}/${triggerEvent}`);
    }

    return {
      channel: channel as unknown as Record<string, unknown>,
      template: template as unknown as Record<string, unknown>,
    };
  }

  /**
   * Deliver notification to channel using appropriate handler
   */
  private async deliverToChannel(
    channel: Record<string, unknown>,
    payload: NotificationPayload
  ): Promise<{ success: boolean; response?: unknown; error?: string }> {
    const channelType = channel.type as string;
    const handler = this.handlers.get(channelType);
    if (!handler) {
      throw new Error(`No handler for channel type: ${channelType}`);
    }

    // Channel config is validated by repository layer during creation/update
    // Cast to ChannelConfig since we trust repository validation
    return await handler.send(channel.config as ChannelConfig, payload);
  }

  /**
   * Record successful delivery
   */
  private async recordDeliveryResult(
    historyId: string,
    channelId: string,
    result: { success: boolean; response?: unknown; error?: string }
  ): Promise<void> {
    if (result.success) {
      await this.db.notificationHistory.update(historyId, {
        status: 'sent',
        response: result.response as Record<string, unknown> | undefined,
        delivered_at: new Date(),
      });
      await this.db.notificationChannels.updateHealth(channelId, true);
      logger.info('Notification sent successfully', { channelId, historyId });
    } else {
      throw new Error(result.error || 'Unknown error');
    }
  }

  /**
   * Record delivery failure
   */
  private async recordDeliveryFailure(
    historyId: string,
    channelId: string,
    error: unknown
  ): Promise<void> {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await this.db.notificationHistory.update(historyId, {
      status: 'failed',
      error: errorMessage,
    });
    await this.db.notificationChannels.updateHealth(channelId, false);
    logger.error('Failed to send to channel', { channelId, error: errorMessage });
  }

  /**
   * Test a channel configuration
   */
  async testChannel(channelId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const channel = await this.db.notificationChannels.findById(channelId);
      if (!channel) {
        return { success: false, error: 'Channel not found' };
      }

      const handler = this.handlers.get(channel.type);
      if (!handler) {
        return { success: false, error: `No handler for channel type: ${channel.type}` };
      }

      const result = await handler.test(channel.config);
      return {
        success: result.success,
        error: result.error,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Check if bug matches rule filters
   * Delegates to shared RuleMatcher service
   */
  private matchesFilters(bug: Record<string, unknown>, filters: FilterCondition[]): boolean {
    return RuleMatcher.matchesFilters(bug, filters);
  }

  /**
   * Check if trigger matches event and parameters
   */
  private matchesTrigger(
    trigger: { event: TriggerEvent; params?: Record<string, unknown> },
    event: TriggerEvent,
    context: { bug?: Record<string, unknown>; project: Record<string, unknown> }
  ): boolean {
    // Event must match
    if (trigger.event !== event) {
      return false;
    }

    // If no params specified, trigger matches
    if (!trigger.params) {
      return true;
    }

    // Check trigger-specific parameters
    const bug = context.bug;
    if (!bug && trigger.params) {
      // Trigger has params but no bug context to check against
      return false;
    }

    // Check priority parameter
    if (trigger.params.priority && bug) {
      const bugPriority = bug.priority as string | undefined;
      if (bugPriority !== trigger.params.priority) {
        return false;
      }
    }

    // Check priority change parameters (for priority_change event)
    if (event === 'priority_change' && bug) {
      if (trigger.params.from_priority || trigger.params.to_priority) {
        const currentPriority = bug.priority as string | undefined;
        const previousPriority = bug.previous_priority as string | undefined;

        if (trigger.params.from_priority && previousPriority !== trigger.params.from_priority) {
          return false;
        }
        if (trigger.params.to_priority && currentPriority !== trigger.params.to_priority) {
          return false;
        }
      }
    }

    // Additional params (threshold, time_window, spike_multiplier) would need
    // more complex logic with historical data - can be implemented when needed

    return true;
  }

  // matchesFilter, normalizeFilterValue, and getFieldValue removed
  // All filter logic now handled by RuleMatcher service

  /**
   * Check if notification is throttled
   * Delegates to throttle repository for rate limiting checks
   */
  private async isThrottled(
    ruleId: string,
    throttle: ThrottleConfig,
    context: Record<string, unknown>
  ): Promise<boolean> {
    try {
      // Determine which throttle limit to use
      const maxPerHour = throttle.max_per_hour;
      const maxPerDay = throttle.max_per_day;

      if (!maxPerHour && !maxPerDay) {
        return false; // No throttle configured
      }

      // Build group key from throttle configuration
      const groupKey = this.buildThrottleGroupKey(throttle.group_by || 'none', context);

      // Check hourly limit first
      if (maxPerHour) {
        const isThrottled = await this.db.notificationThrottle.isThrottled(
          ruleId,
          groupKey,
          maxPerHour,
          60 // 1 hour window
        );
        if (isThrottled) {
          return true;
        }
      }

      // Check daily limit
      if (maxPerDay) {
        const isThrottled = await this.db.notificationThrottle.isThrottled(
          ruleId,
          groupKey,
          maxPerDay,
          1440 // 24 hour window
        );
        if (isThrottled) {
          return true;
        }
      }

      return false; // Not throttled
    } catch (error) {
      logger.error('Error checking throttle', {
        error: error instanceof Error ? error.message : String(error),
        ruleId,
      });
      // On error, allow notification to prevent silent failures
      return false;
    }
  }

  /**
   * Build throttle group key based on grouping strategy
   * Delegates to shared RuleMatcher service
   */
  private buildThrottleGroupKey(groupBy: string, context: Record<string, unknown>): string {
    return RuleMatcher.buildThrottleGroupKey(
      groupBy as 'error_signature' | 'project' | 'user' | 'none',
      context
    );
  }

  /**
   * Check if current time is within schedule
   */
  private isInSchedule(schedule: ScheduleConfig): boolean {
    if (schedule.type === 'immediate') {
      return true;
    }

    if (schedule.type === 'business_hours' && schedule.business_hours) {
      const now = new Date();
      const day = now.getDay(); // 0 = Sunday
      const time = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      if (!schedule.business_hours.days.includes(day)) {
        return false;
      }

      if (time < schedule.business_hours.start || time > schedule.business_hours.end) {
        return false;
      }
    }

    return true;
  }

  /**
   * Create history entry with complete notification data
   */
  private async createHistoryEntry(
    channelId: string,
    ruleId: string,
    templateId: string,
    bugId: string,
    recipients: string[],
    payload: NotificationPayload,
    status: 'pending' | 'sent' | 'failed'
  ): Promise<string> {
    const history = await this.db.notificationHistory.create({
      channel_id: channelId,
      rule_id: ruleId,
      template_id: templateId,
      bug_id: bugId,
      recipients,
      payload: payload as unknown as Record<string, unknown>,
      status,
    });
    return history.id;
  }
}
