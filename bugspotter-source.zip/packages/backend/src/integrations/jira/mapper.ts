/**
 * Jira Bug Report Mapper
 * Converts BugReport to Jira issue format
 */

import type { BugReport } from '../../db/types.js';
import type {
  JiraConfig,
  JiraIssueFields,
  JiraPriority,
  JiraDescription,
  JiraDescriptionNode,
  JiraTemplateConfig,
} from './types.js';
import { SHARE_TOKEN_EXPIRATION_HOURS } from './types.js';
import { ADFFormatter, PlainTextFormatter } from './formatters/index.js';
import { getLogger } from '../../logger.js';
import md2adf from 'md-to-adf';

const logger = getLogger();
import type { ConsoleLogEntry, NetworkLogEntry } from './formatters/index.js';
import { isConsoleLogEntry, isNetworkLogEntry } from './formatters/index.js';

/**
 * Add dynamic metadata fields to variables map
 *
 * Supports 2 levels of nesting:
 * - Top-level: {{metadata.request_id}} for metadata.request_id = "123"
 * - Nested: {{metadata.user.email}} for metadata.user.email = "user@example.com"
 *
 * For deeper nesting (3+ levels), either:
 * 1. Flatten your metadata structure before sending
 * 2. Add predefined variables using getNestedMeta() in renderCustomTemplate()
 *
 * Example: metadata.user.profile.id won't work automatically, but you can add:
 * variables['user.profile.id'] = getNestedMeta('user.profile.id');
 */
function addMetadataVariables(
  metadata: Record<string, unknown>,
  variables: Record<string, string>
): void {
  Object.entries(metadata).forEach(([key, value]) => {
    if (typeof value === 'string' || typeof value === 'number') {
      // Top-level metadata fields: {{metadata.request_id}}
      variables[`metadata.${key}`] = String(value);
    } else if (value && typeof value === 'object' && !Array.isArray(value)) {
      // Nested metadata objects: {{metadata.error.message}}
      // Arrays are skipped to avoid creating variables like metadata.tags.0, metadata.tags.1
      Object.entries(value).forEach(([nestedKey, nestedValue]) => {
        if (typeof nestedValue === 'string' || typeof nestedValue === 'number') {
          variables[`metadata.${key}.${nestedKey}`] = String(nestedValue);
        }
      });
    }
  });
}

/**
 * Render custom description template with variable substitution
 * Supports variables like {{error.message}}, {{user_email}}, {{browser}}, {{replay_url}}, {{screenshot_url}}, etc.
 */
function renderCustomTemplate(
  template: string,
  bugReport: BugReport,
  shareReplayUrl?: string
): string {
  let rendered = template;

  // Helper to safely get metadata values
  const getMeta = (key: string): string => {
    if (!bugReport.metadata) {
      return '';
    }
    const value = bugReport.metadata[key];
    if (typeof value === 'string') {
      return value;
    }
    if (typeof value === 'number') {
      return String(value);
    }
    return '';
  };

  // Helper to safely get nested metadata values (e.g., error.message)
  const getNestedMeta = (path: string): string => {
    if (!bugReport.metadata) {
      return '';
    }
    const parts = path.split('.');
    let current: unknown = bugReport.metadata;

    for (const part of parts) {
      if (current && typeof current === 'object' && part in current) {
        current = (current as Record<string, unknown>)[part];
      } else {
        return '';
      }
    }

    if (typeof current === 'string' || typeof current === 'number') {
      return String(current);
    }
    return '';
  };

  // Build variable map from bug report data
  const variables: Record<string, string> = {
    // Error information (from metadata.error object)
    'error.message': getNestedMeta('error.message'),
    'error.type': getNestedMeta('error.type'),
    stack_trace: getNestedMeta('error.stack'),

    // User and session (from metadata)
    user_email: getMeta('user_email') || 'Unknown',
    session_id: getMeta('session_id') || 'N/A',

    // Browser and device (from metadata)
    browser: getMeta('browser') || 'Unknown',
    browser_version: getMeta('browser_version'),
    os: getMeta('os') || 'Unknown',
    viewport_width: getMeta('viewport_width'),
    viewport_height: getMeta('viewport_height'),

    // Location (from metadata)
    url: getMeta('url'),
    referrer: getMeta('referrer'),

    // Bug report direct fields
    priority: bugReport.priority || 'medium',
    timestamp: bugReport.created_at.toISOString(),
    title: bugReport.title || '',
    description: bugReport.description || '',

    // Replay and screenshot URLs
    replay_url: shareReplayUrl || bugReport.replay_url || '',
    screenshot_url: bugReport.screenshot_url || '',
  };

  // Add all metadata fields dynamically (e.g., {{metadata.request_id}})
  if (bugReport.metadata && typeof bugReport.metadata === 'object') {
    addMetadataVariables(bugReport.metadata, variables);
  }

  // Replace all {{variable}} occurrences
  Object.entries(variables).forEach(([key, value]) => {
    rendered = rendered.replaceAll(`{{${key}}}`, value);
  });

  // Remove any unmatched variables (replace with empty string)
  rendered = rendered.replace(/\{\{[^}]+\}\}/g, '');

  // Clean up empty Markdown links (e.g., [Watch Session Replay]())
  // Pattern: [text]() or [](url) (empty URL or empty text)
  rendered = rendered.replace(/\[([^\]]+)\]\(\s*\)/g, ''); // [text]() -> remove
  rendered = rendered.replace(/\[\s*\]\([^)]+\)/g, ''); // [](url) -> remove

  return rendered;
}

/**
 * Add spacing between sections
 */
function addSpacing(content: JiraDescriptionNode[]): void {
  content.push({
    type: 'paragraph',
    content: [],
  });
}

/**
 * Default template configuration
 * Console/network logs disabled by default to avoid CONTENT_LIMIT_EXCEEDED errors
 * All data is available via the shared replay link
 */
const DEFAULT_TEMPLATE_CONFIG: Required<JiraTemplateConfig> = {
  includeConsoleLogs: false, // Available in shared replay
  consoleLogLimit: 10, // Reduced limit if enabled
  includeNetworkLogs: false, // Available in shared replay
  networkLogFilter: 'failures',
  networkLogLimit: 10, // Reduced limit if enabled
  includeShareReplay: true,
  shareReplayExpiration: SHARE_TOKEN_EXPIRATION_HOURS,
  shareReplayPassword: null,
};

/**
 * Map BugSpotter priority to Jira priority
 */
function mapPriorityToJira(priority?: string): JiraPriority {
  const priorityMap: Record<string, JiraPriority> = {
    critical: 'Highest',
    high: 'High',
    medium: 'Medium',
    low: 'Low',
    minor: 'Lowest',
  };

  return priorityMap[priority?.toLowerCase() || 'medium'] || 'Medium';
}

/**
 * Format console logs for Jira description
 */
function formatConsoleLogs(
  metadata: Record<string, unknown>,
  config: Required<JiraTemplateConfig>
): { entries: ConsoleLogEntry[]; errorCount: number; warningCount: number } {
  const consoleData = metadata?.console;

  // Validate that console is an array
  if (!Array.isArray(consoleData)) {
    return { entries: [], errorCount: 0, warningCount: 0 };
  }

  // Filter out invalid entries using type guard
  const consoleLogs = consoleData.filter(isConsoleLogEntry);

  if (!consoleLogs.length) {
    return { entries: [], errorCount: 0, warningCount: 0 };
  }

  // Count errors and warnings
  const errorCount = consoleLogs.filter((log) => log.level === 'error').length;
  const warningCount = consoleLogs.filter((log) => log.level === 'warn').length;

  // Apply limit (take last N entries)
  const entries = consoleLogs.slice(-config.consoleLogLimit);

  return { entries, errorCount, warningCount };
}

/**
 * Format network logs for Jira description
 */
function formatNetworkLogs(
  metadata: Record<string, unknown>,
  config: Required<JiraTemplateConfig>
): NetworkLogEntry[] {
  const networkData = metadata?.network;

  // Validate that network is an array
  if (!Array.isArray(networkData)) {
    return [];
  }

  // Filter out invalid entries using type guard
  const networkLogs = networkData.filter(isNetworkLogEntry);

  if (!networkLogs.length) {
    return [];
  }

  // Filter based on config
  let filtered = networkLogs;
  if (config.networkLogFilter === 'failures') {
    filtered = networkLogs.filter((log) => log.status && log.status >= 400);
  }

  // Apply limit (take last N entries)
  return filtered.slice(-config.networkLogLimit);
}

/**
 * Create Jira Atlassian Document Format (ADF) description
 * Used in newer Jira Cloud instances for rich text
 */
function createADFDescription(
  bugReport: BugReport,
  config: Required<JiraTemplateConfig>,
  shareReplayUrl?: string
): JiraDescription {
  const sections: JiraDescriptionNode[][] = [];
  const formatter = new ADFFormatter();

  // Collect all sections (methods now return pure content without spacing)
  if (bugReport.description) {
    sections.push(formatter.addDescription(bugReport.description) as JiraDescriptionNode[]);
  }

  if (config.includeConsoleLogs && bugReport.metadata) {
    const { entries, errorCount, warningCount } = formatConsoleLogs(bugReport.metadata, config);
    const consoleContent = formatter.formatConsoleLogs(
      entries,
      errorCount,
      warningCount
    ) as JiraDescriptionNode[];
    if (consoleContent.length > 0) {
      sections.push(consoleContent);
    }
  }

  if (config.includeNetworkLogs && bugReport.metadata) {
    const networkEntries = formatNetworkLogs(bugReport.metadata, config);
    const networkContent = formatter.formatNetworkLogs(networkEntries) as JiraDescriptionNode[];
    if (networkContent.length > 0) {
      sections.push(networkContent);
    }
  }

  sections.push(formatter.formatBugReportDetails(bugReport) as JiraDescriptionNode[]);

  // Only pass shareReplayUrl if replay sharing is enabled
  const effectiveShareUrl = config.includeShareReplay ? shareReplayUrl : undefined;
  const attachments = formatter.formatAttachments(
    bugReport,
    effectiveShareUrl
  ) as JiraDescriptionNode[];
  if (attachments.length > 0) {
    sections.push(attachments);
  }

  sections.push(formatter.addFooter() as JiraDescriptionNode[]);

  // Orchestrator owns spacing: add spacing between all sections
  const content: JiraDescriptionNode[] = [];
  sections.forEach((section, index) => {
    content.push(...section);
    if (index < sections.length - 1) {
      // Add spacing after each section except the last
      addSpacing(content);
    }
  });

  return {
    type: 'doc',
    version: 1,
    content,
  };
}

/**
 * Create plain text description (fallback for older Jira versions)
 */
function createPlainTextDescription(
  bugReport: BugReport,
  config: Required<JiraTemplateConfig>,
  shareReplayUrl?: string
): string {
  const parts: string[] = [];
  const formatter = new PlainTextFormatter();

  // Add description
  if (bugReport.description) {
    parts.push(formatter.addDescription(bugReport.description) as string);
  }

  // Add console logs if enabled
  if (config.includeConsoleLogs && bugReport.metadata) {
    const { entries, errorCount, warningCount } = formatConsoleLogs(bugReport.metadata, config);
    const consoleContent = formatter.formatConsoleLogs(entries, errorCount, warningCount) as string;
    if (consoleContent) {
      parts.push(consoleContent);
    }
  }

  // Add network logs if enabled
  if (config.includeNetworkLogs && bugReport.metadata) {
    const networkEntries = formatNetworkLogs(bugReport.metadata, config);
    const networkContent = formatter.formatNetworkLogs(networkEntries) as string;
    if (networkContent) {
      parts.push(networkContent);
    }
  }

  // Add bug report details
  parts.push(formatter.formatBugReportDetails(bugReport) as string);

  // Add attachments (only include shared replay URL if enabled)
  const effectiveShareUrl = config.includeShareReplay ? shareReplayUrl : undefined;
  const attachments = formatter.formatAttachments(bugReport, effectiveShareUrl) as string;
  if (attachments) {
    parts.push(attachments);
  }

  // Add footer
  parts.push(formatter.addFooter() as string);

  return parts.join('');
}

/**
 * Apply field mappings from integration rules to Jira issue fields
 * Supports: assignee, components, labels, priority, custom fields, etc.
 */
function applyFieldMappings(
  issueFields: JiraIssueFields,
  fieldMappings: Record<string, unknown>
): void {
  Object.entries(fieldMappings).forEach(([fieldName, fieldValue]) => {
    // Only skip null/undefined - allow falsy values like false, 0, "" which are valid
    if (fieldValue === null || fieldValue === undefined) {
      return;
    }

    switch (fieldName) {
      case 'assignee': {
        // Handle assignee: { accountId: string }
        if (typeof fieldValue === 'object') {
          const accountId = (fieldValue as Record<string, unknown>).accountId;
          if (typeof accountId === 'string') {
            issueFields.assignee = { accountId };
          }
        }
        break;
      }

      case 'components': {
        // Handle components: [{ name: string }] or [{ id: string }]
        if (Array.isArray(fieldValue)) {
          issueFields.components = fieldValue
            .filter((c) => c && typeof c === 'object')
            .map((c) => {
              const comp = c as Record<string, unknown>;
              return comp.id ? { id: String(comp.id) } : { name: String(comp.name) };
            });
        }
        break;
      }

      case 'labels': {
        // Handle labels: string[] (append to existing)
        if (Array.isArray(fieldValue)) {
          const newLabels = fieldValue.filter((l) => typeof l === 'string') as string[];
          issueFields.labels = [...(issueFields.labels || []), ...newLabels];
        }
        break;
      }

      case 'priority': {
        // Handle priority: { name: string }
        // Standard Jira Cloud priority values: 'Highest', 'High', 'Medium', 'Low', 'Lowest'
        // Custom Jira instances may have different priority schemes
        // Invalid priority names will be rejected by Jira API with a descriptive error
        if (typeof fieldValue === 'object') {
          const priorityName = (fieldValue as Record<string, unknown>).name;
          if (typeof priorityName === 'string') {
            issueFields.priority = { name: priorityName };
          }
        }
        break;
      }

      case 'description': {
        // Handle description override: string (plain text only for overrides)
        if (typeof fieldValue === 'string') {
          issueFields.description = fieldValue;
        }
        break;
      }

      default: {
        // Handle custom fields: customfield_* or any other Jira field
        // Pass through as-is (Jira will validate on their end)
        if (fieldName.startsWith('customfield_') || fieldName.startsWith('custom_')) {
          (issueFields as Record<string, unknown>)[fieldName] = fieldValue;
        }
        break;
      }
    }
  });
}

/**
 * Jira Bug Report Mapper
 * Converts BugReport to Jira issue format
 */
export class JiraBugReportMapper {
  private config: JiraConfig;
  private useADF: boolean;
  private templateConfig: Required<JiraTemplateConfig>;

  constructor(config: JiraConfig, useADF = true, templateConfig?: Partial<JiraTemplateConfig>) {
    this.config = config;
    this.useADF = useADF;
    this.templateConfig = { ...DEFAULT_TEMPLATE_CONFIG, ...templateConfig };
  }

  /**
   * Convert BugReport to Jira issue fields
   */
  toJiraIssue(
    bugReport: BugReport,
    shareReplayUrl?: string,
    fieldMappings?: Record<string, unknown> | null,
    descriptionTemplate?: string | null
  ): JiraIssueFields {
    // Truncate title to Jira's 255 character limit
    const summary =
      bugReport.title.length > 255 ? bugReport.title.substring(0, 252) + '...' : bugReport.title;

    // Use custom description template if provided, otherwise use default formatting
    let description: string | JiraDescription;
    if (descriptionTemplate) {
      // Render custom template with variable substitution
      const renderedTemplate = renderCustomTemplate(descriptionTemplate, bugReport, shareReplayUrl);

      // For ADF format, convert Markdown to ADF using md-to-adf library
      if (this.useADF) {
        try {
          // md-to-adf returns a complete ADF document
          description = md2adf(renderedTemplate) as JiraDescription;
        } catch (error) {
          // Recoverable error: fallback to plain text ADF paragraph
          // Use warn level so it's visible in production (helps identify template syntax issues)
          logger.warn(
            'Markdown to ADF conversion failed (recoverable - using plain text fallback)',
            {
              bugReportId: bugReport.id,
              recoverable: true,
              error: error instanceof Error ? error.message : String(error),
              stack: error instanceof Error ? error.stack : undefined,
              template: renderedTemplate.substring(0, 200), // Log first 200 chars
              suggestion: 'Check custom template syntax for Markdown compatibility',
            }
          );
          // Fallback to plain text wrapped in paragraph if conversion fails
          description = {
            type: 'doc',
            version: 1,
            content: [
              {
                type: 'paragraph',
                content: [
                  {
                    type: 'text',
                    text: renderedTemplate,
                  },
                ],
              },
            ],
          };
        }
      } else {
        // Plain text format (Markdown as-is for testing)
        description = renderedTemplate;
      }

      logger.debug('Using custom description template', {
        bugReportId: bugReport.id,
        templateLength: descriptionTemplate.length,
        renderedLength: renderedTemplate.length,
      });
    } else {
      // Use default template configuration
      description = this.useADF
        ? createADFDescription(bugReport, this.templateConfig, shareReplayUrl)
        : createPlainTextDescription(bugReport, this.templateConfig, shareReplayUrl);

      logger.debug('Using default description template', {
        bugReportId: bugReport.id,
        useADF: this.useADF,
      });
    }

    const issueFields: JiraIssueFields = {
      project: {
        key: this.config.projectKey,
      },
      issuetype: {
        name: this.config.issueType || 'Bug',
      },
      summary,
      description,
      priority: {
        name: mapPriorityToJira(bugReport.priority),
      },
      labels: ['bugspotter', 'automated'],
    };

    // Apply field mappings from integration rule (if present)
    // This allows per-rule customization of any Jira field
    if (fieldMappings && typeof fieldMappings === 'object') {
      logger.debug('Applying field mappings to Jira issue', {
        bugReportId: bugReport.id,
        fieldMappings,
        mappingKeys: Object.keys(fieldMappings),
      });
      applyFieldMappings(issueFields, fieldMappings);
    } else {
      logger.debug('No field mappings to apply', {
        bugReportId: bugReport.id,
        hasFieldMappings: !!fieldMappings,
        fieldMappingsType: typeof fieldMappings,
      });
    }

    return issueFields;
  }

  /**
   * Format description for Jira (convenience method)
   */
  formatDescription(bugReport: BugReport, shareReplayUrl?: string): string | JiraDescription {
    return this.useADF
      ? createADFDescription(bugReport, this.templateConfig, shareReplayUrl)
      : createPlainTextDescription(bugReport, this.templateConfig, shareReplayUrl);
  }
}
