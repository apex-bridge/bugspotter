/**
 * Type declarations for @babel/traverse
 */

declare module '@babel/traverse' {
  export default function traverse(ast: any, visitors: any): void;
  export function traverse(ast: any, visitors: any): void;
}
