/**
 * Database types for PostgreSQL schema
 */

import { BugStatus, BugPriority } from '@bugspotter/types';
import type {
  ApiKeyType,
  ApiKeyStatus,
  PermissionScope,
  RateLimitWindow,
  ApiKeyAuditAction,
} from '@bugspotter/types';
import type { Session } from '../services/session-service.js';

/**
 * Upload status values for both screenshot and replay uploads
 * Matches database CHECK constraints in migration 001_initial_schema.sql
 */
export const UPLOAD_STATUS = {
  NONE: 'none',
  PENDING: 'pending',
  UPLOADING: 'uploading',
  COMPLETED: 'completed',
  FAILED: 'failed',
} as const;

export type UploadStatus = (typeof UPLOAD_STATUS)[keyof typeof UPLOAD_STATUS];

// Alias for backward compatibility
export const REPLAY_UPLOAD_STATUS = UPLOAD_STATUS;
export type ReplayUploadStatus = UploadStatus;

export interface Project {
  id: string;
  name: string;
  settings: Record<string, unknown>;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
}

export interface ProjectMember {
  id: string;
  project_id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  created_at: Date;
}

export interface User {
  id: string;
  email: string;
  name: string | null;
  password_hash: string | null;
  role: 'admin' | 'user' | 'viewer';
  oauth_provider: string | null;
  oauth_id: string | null;
  created_at: Date;
}

export interface BugReport {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  screenshot_url: string | null;
  replay_url: string | null;
  metadata: Record<string, unknown>;
  status: BugStatus;
  priority: BugPriority;
  deleted_at: Date | null;
  deleted_by: string | null;
  legal_hold: boolean;
  created_at: Date;
  updated_at: Date;
  // Presigned URL columns
  screenshot_key: string | null;
  thumbnail_key: string | null;
  replay_key: string | null;
  upload_status: UploadStatus;
  replay_upload_status: ReplayUploadStatus;
}

/**
 * Ticket status values
 */
export const TICKET_STATUS = {
  OPEN: 'open',
  IN_PROGRESS: 'in_progress',
  RESOLVED: 'resolved',
  CLOSED: 'closed',
  REOPENED: 'reopened',
} as const;

export type TicketStatus = (typeof TICKET_STATUS)[keyof typeof TICKET_STATUS];

/**
 * Result of an attachment upload attempt for auto-created tickets
 */
export interface AttachmentResult {
  type: 'screenshot' | 'consoleLogs' | 'networkLogs' | 'replay';
  success: boolean;
  filename?: string;
  error?: string;
  size?: number;
}

export const TICKET_SYNC_STATUS = {
  PENDING: 'pending',
  SYNCED: 'synced',
  FAILED: 'failed',
} as const;

export type TicketSyncStatus = (typeof TICKET_SYNC_STATUS)[keyof typeof TICKET_SYNC_STATUS];

export interface Ticket {
  id: string;
  bug_report_id: string;
  external_id: string;
  platform: string;
  status: TicketStatus | null;
  created_at: Date;
  // Auto-ticket creation fields
  integration_id: string | null;
  rule_id: string | null;
  created_automatically: boolean;
  external_url: string | null;
  sync_status: TicketSyncStatus;
  last_sync_error: string | null;
  attachment_results: AttachmentResult[] | null;
}

/**
 * Share Token for public replay access
 * Enables time-limited, optionally password-protected sharing of session replays
 */
export interface ShareToken {
  id: string;
  bug_report_id: string;
  token: string;
  expires_at: Date;
  password_hash: string | null;
  view_count: number;
  created_by: string | null;
  created_at: Date;
  deleted_at: Date | null;
}

export type ShareTokenInsert = Omit<
  ShareToken,
  'id' | 'created_at' | 'view_count' | 'deleted_at'
> & {
  id?: string;
  created_at?: Date;
  view_count?: number;
};

export type ShareTokenUpdate = Partial<
  Omit<ShareToken, 'id' | 'token' | 'bug_report_id' | 'created_at' | 'created_by'>
>;

export interface AuditLog {
  id: string;
  timestamp: Date;
  user_id: string | null;
  action: string;
  resource: string;
  resource_id: string | null;
  ip_address: string | null;
  user_agent: string | null;
  details: Record<string, unknown> | null;
  success: boolean;
  error_message: string | null;
}

export type AuditLogInsert = {
  id?: string;
  user_id?: string | null;
  action: string;
  resource: string;
  resource_id?: string | null;
  ip_address?: string | null;
  user_agent?: string | null;
  details?: Record<string, unknown> | null;
  success?: boolean;
  error_message?: string | null;
};

export interface Permission {
  id: string;
  role: string;
  resource: string;
  action: string;
  created_at: Date;
}

export interface ArchivedBugReport {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  screenshot_url: string | null;
  replay_url: string | null;
  metadata: Record<string, unknown>;
  status: BugStatus;
  priority: BugPriority;
  original_created_at: Date;
  original_updated_at: Date;
  deleted_at: Date;
  deleted_by: string | null;
  archived_at: Date;
  archived_reason: string | null;
}

export interface MigrationHistory {
  id: number;
  migration_name: string;
  applied_at: Date;
}

// Insert/Update types (without auto-generated fields)
export type ProjectInsert = {
  id?: string;
  name: string;
  settings?: Record<string, unknown>;
  created_by?: string | null;
};

export type ProjectUpdate = Partial<Omit<Project, 'id' | 'created_at' | 'updated_at'>>;

export type ProjectMemberInsert = {
  id?: string;
  project_id: string;
  user_id: string;
  role?: 'owner' | 'admin' | 'member' | 'viewer';
};

export type BugReportInsert = {
  project_id: string;
  title: string;
  id?: string;
  description?: string | null;
  screenshot_url?: string | null;
  replay_url?: string | null;
  metadata?: Record<string, unknown>;
  status?: BugStatus;
  priority?: BugPriority;
  deleted_at?: Date | null;
  deleted_by?: string | null;
  legal_hold?: boolean;
  // Presigned URL columns
  screenshot_key?: string | null;
  thumbnail_key?: string | null;
  replay_key?: string | null;
  upload_status?: UploadStatus;
  replay_upload_status?: ReplayUploadStatus;
};

export type BugReportUpdate = Partial<
  Omit<BugReport, 'id' | 'project_id' | 'created_at' | 'updated_at'>
>;

export type UserInsert = {
  id?: string;
  email: string;
  name?: string | null;
  password_hash?: string | null;
  role?: 'admin' | 'user' | 'viewer';
  oauth_provider?: string | null;
  oauth_id?: string | null;
};

// Query result types with relationships
export interface BugReportWithProject extends BugReport {
  project: Project;
}

export interface BugReportWithSessions extends BugReport {
  sessions: Session[];
}

export interface BugReportWithTickets extends BugReport {
  tickets: Ticket[];
}

// ============================================================================
// API KEY MANAGEMENT TYPES
// ============================================================================

// Re-export shared types from @bugspotter/types
export {
  API_KEY_TYPE,
  API_KEY_STATUS,
  PERMISSION_SCOPE,
  RATE_LIMIT_WINDOW,
  API_KEY_AUDIT_ACTION,
  type ApiKeyType,
  type ApiKeyStatus,
  type PermissionScope,
  type RateLimitWindow,
  type ApiKeyAuditAction,
} from '@bugspotter/types';

/**
 * API Key entity
 */
export interface ApiKey {
  id: string;
  key_hash: string;
  key_prefix: string;
  key_suffix: string;
  name: string;
  description: string | null;
  type: ApiKeyType;
  status: ApiKeyStatus;

  // Permissions
  permission_scope: PermissionScope;
  permissions: string[];
  allowed_projects: string[] | null;
  allowed_environments: string[] | null;

  // Rate Limiting
  rate_limit_per_minute: number;
  rate_limit_per_hour: number;
  rate_limit_per_day: number;
  burst_limit: number;
  per_endpoint_limits: Record<string, number> | null;

  // Security
  ip_whitelist: string[] | null;
  allowed_origins: string[] | null;
  user_agent_pattern: string | null;

  // Lifecycle
  expires_at: Date | null;
  rotate_at: Date | null;
  grace_period_days: number;
  rotated_from: string | null;

  // Audit
  created_by: string | null;
  team_id: string | null;
  tags: string[] | null;

  // Timestamps
  created_at: Date;
  updated_at: Date;
  last_used_at: Date | null;
  revoked_at: Date | null;
}

/**
 * API Key usage tracking
 */
export interface ApiKeyUsage {
  id: string;
  api_key_id: string;
  endpoint: string;
  method: string;
  status_code: number | null;
  response_time_ms: number | null;
  ip_address: string | null;
  user_agent: string | null;
  error_message: string | null;
  error_type: string | null;
  timestamp: Date;
}

/**
 * Rate limit tracking
 */
export interface ApiKeyRateLimit {
  api_key_id: string;
  window_type: RateLimitWindow;
  window_start: Date;
  request_count: number;
}

/**
 * API Key audit log
 */
export interface ApiKeyAuditLog {
  id: string;
  api_key_id: string | null;
  action: ApiKeyAuditAction;
  performed_by: string | null;
  ip_address: string | null;
  changes: Record<string, unknown> | null;
  timestamp: Date;
}

// Insert types (without auto-generated fields)
export type ApiKeyInsert = {
  id?: string;
  key_hash: string;
  key_prefix: string;
  key_suffix: string;
  name: string;
  description?: string | null;
  type?: ApiKeyType;
  status?: ApiKeyStatus;
  permission_scope?: PermissionScope;
  permissions?: string[];
  allowed_projects?: string[] | null;
  allowed_environments?: string[] | null;
  rate_limit_per_minute?: number;
  rate_limit_per_hour?: number;
  rate_limit_per_day?: number;
  burst_limit?: number;
  per_endpoint_limits?: Record<string, number> | null;
  ip_whitelist?: string[] | null;
  allowed_origins?: string[] | null;
  user_agent_pattern?: string | null;
  expires_at?: Date | null;
  rotate_at?: Date | null;
  grace_period_days?: number;
  rotated_from?: string | null;
  created_by?: string | null;
  team_id?: string | null;
  tags?: string[] | null;
};

export type ApiKeyUpdate = Partial<
  Omit<ApiKey, 'id' | 'key_hash' | 'created_at' | 'updated_at' | 'created_by'>
>;

export type ApiKeyUsageInsert = {
  id?: string;
  api_key_id: string;
  endpoint: string;
  method: string;
  status_code?: number | null;
  response_time_ms?: number | null;
  ip_address?: string | null;
  user_agent?: string | null;
  error_message?: string | null;
  error_type?: string | null;
  timestamp?: Date;
};

export type ApiKeyAuditLogInsert = {
  id?: string;
  api_key_id?: string | null;
  action: ApiKeyAuditAction;
  performed_by?: string | null;
  ip_address?: string | null;
  changes?: Record<string, unknown> | null;
  timestamp?: Date;
};

// Query types
export interface ApiKeyWithUsageStats extends ApiKey {
  usage_stats: {
    total_requests: number;
    requests_today: number;
    requests_this_month: number;
    last_request_at: Date | null;
    unique_ips: number;
    client_error_rate: number; // 4xx errors (client mistakes)
    server_error_rate: number; // 5xx errors (server failures)
  };
}

export interface ApiKeyFilters {
  status?: ApiKeyStatus;
  type?: ApiKeyType;
  team_id?: string;
  created_by?: string;
  tag?: string;
  expires_before?: Date;
  expires_after?: Date;
  search?: string; // Search by name or description
}

// API Key sort fields (single source of truth)
export const API_KEY_SORT_FIELDS = [
  'created_at',
  'updated_at',
  'last_used_at',
  'name',
  'expires_at',
] as const;

export interface ApiKeySortOptions {
  sort_by?: (typeof API_KEY_SORT_FIELDS)[number];
  order?: 'asc' | 'desc';
}

// ============================================================================
// PAGINATION & FILTER TYPES
// ============================================================================

export interface PaginationOptions {
  page?: number;
  limit?: number;
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Filter types
export interface BugReportFilters {
  project_id?: string;
  project_ids?: string[]; // For filtering by multiple projects (user access control)
  user_id?: string; // For filtering by user's accessible projects (via JOIN to project_members)
  status?: BugStatus;
  priority?: BugPriority;
  created_after?: Date;
  created_before?: Date;
}

export interface BugReportSortOptions {
  sort_by?: 'created_at' | 'updated_at' | 'priority';
  order?: 'asc' | 'desc';
}
