/**
 * Project Repository
 */

import type { Pool, PoolClient } from 'pg';
import { BaseRepository } from './base-repository.js';
import { SINGLE_ROW_LIMIT } from '../constants.js';
import type { Project, ProjectInsert, ProjectUpdate } from '../types.js';

export class ProjectRepository extends BaseRepository<Project, ProjectInsert, ProjectUpdate> {
  constructor(pool: Pool | PoolClient) {
    super(pool, 'projects', ['settings']);
  }

  /**
   * Check if user has access to project
   * Returns true if user is the owner, an admin, or member of the project
   */
  async hasAccess(projectId: string, userId: string): Promise<boolean> {
    const query = `
      SELECT 1 FROM projects p
      WHERE p.id = $1
        AND (
          p.created_by = $2
          OR EXISTS (
            SELECT 1 FROM project_members pm
            WHERE pm.project_id = p.id
              AND pm.user_id = $2
          )
        )
      LIMIT ${SINGLE_ROW_LIMIT}
    `;

    const result = await this.getClient().query(query, [projectId, userId]);
    return result.rows.length > 0;
  }

  /**
   * Get user's role in project
   * Returns 'owner', 'admin', 'member', 'viewer', or null if no access
   */
  async getUserRole(projectId: string, userId: string): Promise<string | null> {
    // Check if owner
    const ownerQuery = `
      SELECT 'owner' as role FROM projects
      WHERE id = $1 AND created_by = $2
      LIMIT ${SINGLE_ROW_LIMIT}
    `;
    const ownerResult = await this.getClient().query(ownerQuery, [projectId, userId]);
    if (ownerResult.rows.length > 0) {
      return 'owner';
    }

    // Check project membership
    const memberQuery = `
      SELECT role FROM project_members
      WHERE project_id = $1 AND user_id = $2
      LIMIT ${SINGLE_ROW_LIMIT}
    `;
    const memberResult = await this.getClient().query(memberQuery, [projectId, userId]);
    if (memberResult.rows.length > 0) {
      return memberResult.rows[0].role;
    }

    return null;
  }

  /**
   * Get user roles for multiple projects in a single query
   * Returns a map of projectId -> role ('owner', 'admin', 'member', 'viewer', or null)
   */
  async getUserRolesForProjects(
    projectIds: string[],
    userId: string
  ): Promise<Map<string, string | null>> {
    if (projectIds.length === 0) {
      return new Map();
    }

    const query = `
      SELECT 
        p.id as project_id,
        CASE 
          WHEN p.created_by = $1 THEN 'owner'
          ELSE pm.role
        END as role
      FROM projects p
      LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = $1
      WHERE p.id = ANY($2)
    `;

    const result = await this.getClient().query(query, [userId, projectIds]);

    const roleMap = new Map<string, string | null>();

    // Initialize all projects with null
    for (const projectId of projectIds) {
      roleMap.set(projectId, null);
    }

    // Fill in roles from query results
    for (const row of result.rows) {
      roleMap.set(row.project_id, row.role);
    }

    return roleMap;
  }

  /**
   * Find all projects (for retention service)
   */
  async findAll(): Promise<Project[]> {
    const query = `SELECT * FROM ${this.tableName} ORDER BY created_at DESC`;
    const result = await this.getClient().query(query);
    return this.deserializeMany(result.rows);
  }

  /**
   * Get all projects a user has access to (created or member of)
   * Returns projects where user is owner or has membership
   */
  async getUserAccessibleProjects(userId: string): Promise<Project[]> {
    const query = `
      SELECT DISTINCT p.* FROM projects p
      LEFT JOIN project_members pm ON p.id = pm.project_id
      WHERE p.created_by = $1 OR pm.user_id = $1
      ORDER BY p.created_at DESC
    `;
    const result = await this.getClient().query(query, [userId]);
    return this.deserializeMany(result.rows);
  }

  /**
   * Get all members of a project (including owner)
   * Uses project_roles table for proper role hierarchy ordering
   */
  async getProjectMembers(projectId: string): Promise<
    Array<{
      id: string | null;
      project_id: string;
      user_id: string;
      role: string;
      created_at: Date;
      user_email: string;
      user_name: string | null;
    }>
  > {
    const query = `
      SELECT 
        pm.id,
        pm.project_id,
        pm.user_id,
        pm.role,
        pm.created_at,
        u.email as user_email,
        u.name as user_name,
        pr.rank as role_rank
      FROM project_members pm
      JOIN users u ON pm.user_id = u.id
      JOIN project_roles pr ON pm.role = pr.name
      WHERE pm.project_id = $1
      
      UNION ALL
      
      SELECT 
        NULL as id,
        p.id as project_id,
        p.created_by as user_id,
        'owner'::text as role,
        p.created_at,
        u.email as user_email,
        u.name as user_name,
        pr.rank as role_rank
      FROM projects p
      JOIN users u ON p.created_by = u.id
      JOIN project_roles pr ON pr.name = 'owner'
      WHERE p.id = $1
      AND NOT EXISTS (
        SELECT 1 FROM project_members pm2 
        WHERE pm2.project_id = p.id 
        AND pm2.user_id = p.created_by
      )
      
      ORDER BY role_rank ASC, created_at ASC
    `;

    const result = await this.getClient().query(query, [projectId]);
    // Remove role_rank from returned data (internal use only)
    return result.rows.map((row) => {
      const { role_rank: _role_rank, ...member } = row;
      return member;
    });
  }
}
