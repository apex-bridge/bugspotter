# Email Integration Options for BugSpotter

## Overview

**SMTP email delivery is already implemented and functional.** BugSpotter uses Nodemailer with SMTP support out of the box. This document shows the current implementation and alternative email providers for enhanced features (better deliverability, analytics, templates).

---

## ✅ Currently Implemented: Nodemailer + SMTP

**Status**: Fully functional email delivery via SMTP

**Best for**: Self-hosted deployments, using existing SMTP servers, full control

### What's Included

- ✅ SMTP email delivery with Nodemailer
- ✅ HTML and plain text email templates
- ✅ Support for any SMTP server (Gmail, Outlook, custom)
- ✅ Automatic fallback to text-only emails
- ✅ Email templating with bug report details
- ✅ Test email functionality

### Configuration

Set these environment variables:

```bash
EMAIL_NOTIFICATIONS_ENABLED=true
EMAIL_FROM_ADDRESS=notifications@yourdomain.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-specific-password
```

### How It Works

1. **EmailNotifier** (`email-notifier.ts`) loads config from environment
2. **EmailChannelHandler** (`email-handler.ts`) creates Nodemailer transporter
3. Emails sent with both HTML and plain text versions
4. Bug report context automatically formatted into email template

### Gmail Setup Example

1. Enable 2-factor authentication on your Google account
2. Generate an App Password: https://myaccount.google.com/apppasswords
3. Use these settings:
   ```bash
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-16-char-app-password
   ```

### Testing

Test email delivery via the admin panel:

1. Navigate to Notifications → Channels
2. Create an email channel with your SMTP settings
3. Click "Test" to send a test email

---

## Alternative Providers (Optional Enhancements)

The following options provide enhanced features like better deliverability, analytics, and templates. You can implement these as alternatives to SMTP if needed.

---

## Option 1: SendGrid (Easy Setup) ⭐

**Best for**: Quick setup, reliable delivery, no infrastructure management

### Pros

- ✅ Generous free tier (100 emails/day)
- ✅ Simple REST API (no SMTP configuration)
- ✅ Excellent deliverability (industry leader)
- ✅ Built-in analytics and tracking
- ✅ Official Node.js SDK

### Cons

- ❌ Requires Twilio/SendGrid account
- ❌ Paid plans start at $15/month for 50k emails

### Setup

```bash
pnpm add @sendgrid/mail
```

### Implementation

```typescript
// packages/backend/src/queue/workers/notifications/email-notifier.ts

import sgMail from '@sendgrid/mail';

export class EmailNotifier implements INotifier {
  readonly type = 'email';
  private readonly config: EmailNotifierConfig;

  constructor(config: EmailNotifierConfig) {
    this.config = config;
    // Initialize SendGrid
    if (config.sendgrid_api_key) {
      sgMail.setApiKey(config.sendgrid_api_key);
    }
  }

  async send(
    recipient: string,
    context: NotificationContext,
    event: string
  ): Promise<NotificationResult> {
    if (!this.config.sendgrid_api_key) {
      throw new Error('SendGrid API key not configured');
    }

    const subject = this.getSubject(event, context);
    const htmlBody = await this.buildHtmlEmail(context, event);
    const textBody = this.buildTextEmail(context, event);

    try {
      await sgMail.send({
        to: recipient,
        from: this.config.from, // Must be verified in SendGrid
        subject,
        text: textBody,
        html: htmlBody,
      });

      return { success: true, timestamp: new Date() };
    } catch (error) {
      logger.error('SendGrid delivery failed', { error, recipient, event });
      return {
        success: false,
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

### Environment Variables

```bash
# .env
EMAIL_NOTIFICATIONS_ENABLED=true
EMAIL_FROM_ADDRESS=notifications@yourdomain.com
EMAIL_PROVIDER=sendgrid
EMAIL_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Config Interface Update

```typescript
export interface EmailNotifierConfig extends BaseNotifierConfig {
  type: 'email';
  from: string;
  provider?: 'sendgrid';
  apiKey?: string;
}

static loadConfig(): EmailNotifierConfig | null {
  if (process.env.EMAIL_NOTIFICATIONS_ENABLED !== 'true') {
    return null;
  }

  return {
    type: 'email',
    enabled: true,
    from: process.env.EMAIL_FROM_ADDRESS || 'noreply@bugspotter.dev',
    provider: 'sendgrid',
    apiKey: process.env.EMAIL_API_KEY,
  };
}
```

---

## Option 2: AWS SES (Best for Scale)

**Best for**: High volume, cost optimization, AWS infrastructure

### Pros

- ✅ Extremely cost-effective ($0.10 per 1,000 emails)
- ✅ Integrates with AWS infrastructure
- ✅ Built-in bounce/complaint handling
- ✅ High sending limits (can request increases)

### Cons

- ❌ Requires AWS account and setup
- ❌ Production access requires verification (takes 24-48h)
- ❌ More complex configuration

### Setup

```bash
pnpm add @aws-sdk/client-ses
```

### Implementation

```typescript
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';

export class EmailNotifier implements INotifier {
  readonly type = 'email';
  private readonly config: EmailNotifierConfig;
  private readonly sesClient: SESClient;

  constructor(config: EmailNotifierConfig) {
    this.config = config;

    // Initialize SES client
    this.sesClient = new SESClient({
      region: config.aws_region || 'us-east-1',
      credentials:
        config.aws_access_key && config.aws_secret_key
          ? {
              accessKeyId: config.aws_access_key,
              secretAccessKey: config.aws_secret_key,
            }
          : undefined, // Use IAM role if running on EC2/ECS
    });
  }

  async send(
    recipient: string,
    context: NotificationContext,
    event: string
  ): Promise<NotificationResult> {
    const subject = this.getSubject(event, context);
    const htmlBody = await this.buildHtmlEmail(context, event);
    const textBody = this.buildTextEmail(context, event);

    const command = new SendEmailCommand({
      Source: this.config.from,
      Destination: { ToAddresses: [recipient] },
      Message: {
        Subject: { Data: subject, Charset: 'UTF-8' },
        Body: {
          Html: { Data: htmlBody, Charset: 'UTF-8' },
          Text: { Data: textBody, Charset: 'UTF-8' },
        },
      },
    });

    try {
      await this.sesClient.send(command);
      return { success: true, timestamp: new Date() };
    } catch (error) {
      logger.error('SES delivery failed', { error, recipient, event });
      return {
        success: false,
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

### Environment Variables

```bash
EMAIL_NOTIFICATIONS_ENABLED=true
EMAIL_FROM_ADDRESS=notifications@yourdomain.com
EMAIL_PROVIDER=ses
AWS_SES_REGION=us-east-1
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
```

---

## Option 3: Postmark (Best Developer Experience)

**Best for**: Transactional emails, great deliverability, developer-friendly

### Pros

- ✅ Focused on transactional emails (not marketing)
- ✅ Excellent deliverability rates (99%+)
- ✅ Simple API with great documentation
- ✅ Free trial (100 emails)
- ✅ Built-in templates

### Cons

- ❌ More expensive than SES ($10/month for 10k emails)
- ❌ Requires account setup

### Setup

```bash
pnpm add postmark
```

### Implementation

```typescript
import { ServerClient } from 'postmark';

export class EmailNotifier implements INotifier {
  readonly type = 'email';
  private readonly config: EmailNotifierConfig;
  private readonly client: ServerClient;

  constructor(config: EmailNotifierConfig) {
    this.config = config;
    if (!config.postmark_token) {
      throw new Error('Postmark token not configured');
    }
    this.client = new ServerClient(config.postmark_token);
  }

  async send(
    recipient: string,
    context: NotificationContext,
    event: string
  ): Promise<NotificationResult> {
    const subject = this.getSubject(event, context);
    const htmlBody = await this.buildHtmlEmail(context, event);
    const textBody = this.buildTextEmail(context, event);

    try {
      await this.client.sendEmail({
        From: this.config.from,
        To: recipient,
        Subject: subject,
        HtmlBody: htmlBody,
        TextBody: textBody,
        MessageStream: 'outbound',
      });

      return { success: true, timestamp: new Date() };
    } catch (error) {
      logger.error('Postmark delivery failed', { error, recipient, event });
      return {
        success: false,
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

### Environment Variables

```bash
EMAIL_NOTIFICATIONS_ENABLED=true
EMAIL_FROM_ADDRESS=notifications@yourdomain.com
EMAIL_PROVIDER=postmark
EMAIL_API_KEY=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

---

## Option 4: Resend (Modern Choice)

**Best for**: Modern API, React email templates, developer experience

### Pros

- ✅ Modern developer experience
- ✅ Free tier (100 emails/day, 3k/month)
- ✅ Simple API (similar to SendGrid)
- ✅ React email template support
- ✅ Great documentation

### Cons

- ❌ Newer service (less track record)
- ❌ Smaller market share than SendGrid/AWS

### Setup

```bash
pnpm add resend
```

### Implementation

```typescript
import { Resend } from 'resend';

export class EmailNotifier implements INotifier {
  readonly type = 'email';
  private readonly config: EmailNotifierConfig;
  private readonly resend: Resend;

  constructor(config: EmailNotifierConfig) {
    this.config = config;
    if (!config.resend_api_key) {
      throw new Error('Resend API key not configured');
    }
    this.resend = new Resend(config.resend_api_key);
  }

  async send(
    recipient: string,
    context: NotificationContext,
    event: string
  ): Promise<NotificationResult> {
    const subject = this.getSubject(event, context);
    const htmlBody = await this.buildHtmlEmail(context, event);
    const textBody = this.buildTextEmail(context, event);

    try {
      await this.resend.emails.send({
        from: this.config.from,
        to: recipient,
        subject,
        html: htmlBody,
        text: textBody,
      });

      return { success: true, timestamp: new Date() };
    } catch (error) {
      logger.error('Resend delivery failed', { error, recipient, event });
      return {
        success: false,
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

### Environment Variables

```bash
EMAIL_NOTIFICATIONS_ENABLED=true
EMAIL_FROM_ADDRESS=notifications@yourdomain.com
EMAIL_PROVIDER=resend
EMAIL_API_KEY=re_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## Implementation Notes for Alternative Providers

If you want to switch from SMTP to one of the API-based providers above:

### Steps to Implement

1. Install the provider's SDK (e.g., `pnpm add @sendgrid/mail`)
2. Update `EmailNotifier` to detect `EMAIL_PROVIDER` environment variable
3. Add provider-specific sending logic in the `send()` method
4. Update config interface to include provider-specific fields
5. Test with provider's sandbox/test mode

### Benefits of API-based Providers

- ✅ Better deliverability (99%+ inbox rates)
- ✅ Built-in analytics and tracking
- ✅ Template management
- ✅ Bounce/complaint handling
- ✅ Higher sending limits

### When to Stick with SMTP

- ✅ Self-hosted deployments
- ✅ Existing SMTP infrastructure
- ✅ Low to medium email volume (<1000/day)
- ✅ No budget for third-party services
- ✅ Full control over email delivery

### Setup

```bash
pnpm add nodemailer
pnpm add -D @types/nodemailer
```

### Implementation

```typescript
import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';

export class EmailNotifier implements INotifier {
  readonly type = 'email';
  private readonly config: EmailNotifierConfig;
  private readonly transporter: Transporter;

  constructor(config: EmailNotifierConfig) {
    this.config = config;

    if (!config.smtp) {
      throw new Error('SMTP configuration required');
    }

    this.transporter = nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.secure ?? true, // true for 465, false for 587
      auth: {
        user: config.smtp.user,
        pass: config.smtp.password,
      },
    });
  }

  async send(
    recipient: string,
    context: NotificationContext,
    event: string
  ): Promise<NotificationResult> {
    const subject = this.getSubject(event, context);
    const htmlBody = await this.buildHtmlEmail(context, event);
    const textBody = this.buildTextEmail(context, event);

    try {
      await this.transporter.sendMail({
        from: this.config.from,
        to: recipient,
        subject,
        text: textBody,
        html: htmlBody,
      });

      return { success: true, timestamp: new Date() };
    } catch (error) {
      logger.error('SMTP delivery failed', { error, recipient, event });
      return {
        success: false,
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

---

## Recommendation Summary

### ✅ Default (Already Working): **SMTP with Nodemailer**

- Already implemented and functional
- Works with any SMTP server (Gmail, Outlook, custom)
- No additional setup required
- Sufficient for most self-hosted instances (<1000 emails/day)

### For Better Deliverability: **SendGrid** ⭐

- 99%+ inbox rates, reliable delivery
- Free tier: 100 emails/day
- Built-in analytics and bounce handling

### For High Volume: **AWS SES**

- Best cost at scale ($0.10 per 1,000 emails)
- Scales to millions of emails
- Integrates with AWS infrastructure

### For Transactional Focus: **Postmark**

- 99%+ delivery rates
- Focused on transactional emails (not marketing)
- Excellent developer experience

### For Modern DX: **Resend**

- Modern API, React email template support
- Free tier: 3,000 emails/month
- Great documentation

---

## Testing Email Delivery

After implementing, test with:

```typescript
// packages/backend/src/queue/workers/notifications/email-notifier.test.ts

import { describe, it, expect, beforeEach } from 'vitest';
import { EmailNotifier } from './email-notifier';

describe('EmailNotifier', () => {
  let notifier: EmailNotifier;

  beforeEach(() => {
    const config = {
      type: 'email' as const,
      enabled: true,
      from: 'test@example.com',
      sendgrid_api_key: process.env.SENDGRID_API_KEY || 'test-key',
    };
    notifier = new EmailNotifier(config);
  });

  it('should send bug report notification', async () => {
    const result = await notifier.send(
      'recipient@example.com',
      {
        bugId: 'bug-123',
        projectId: 'proj-456',
        severity: 'high',
        title: 'Test Bug',
        description: 'Test Description',
        timestamp: new Date(),
      },
      'bug.created'
    );

    expect(result.success).toBe(true);
    expect(result.timestamp).toBeDefined();
  });
});
```

---

## Next Steps

### Using Current SMTP Implementation (Recommended)

1. ✅ **Already done** - SMTP email delivery is implemented
2. Configure environment variables in `.env`:
   ```bash
   EMAIL_NOTIFICATIONS_ENABLED=true
   EMAIL_FROM_ADDRESS=notifications@yourdomain.com
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-app-password
   ```
3. Create email notification channel in admin panel
4. Test email delivery
5. Configure notification rules

### Upgrading to API-based Provider (Optional)

Only needed if you require:

- Higher deliverability rates (99%+)
- Built-in analytics and tracking
- Higher sending volumes (>1000/day)
- Advanced features (templates, A/B testing, etc.)

**Steps**:

1. Choose provider (SendGrid recommended for ease of setup)
2. Install SDK: `pnpm add @sendgrid/mail`
3. Update `EmailNotifier.send()` to check `EMAIL_PROVIDER` env var
4. Implement provider-specific delivery logic
5. Update environment variables
6. Test and migrate

---

**Current state**: Email notifications work out of the box with SMTP. Alternative providers are optional enhancements for specific use cases.
