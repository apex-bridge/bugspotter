# SMTP Configuration Guide

## Port Selection and Security Settings

SMTP uses different ports with different security mechanisms:

### Port 465 - Direct SSL/TLS (SMTPS)

- Uses **implicit SSL/TLS** from the start of the connection
- Requires `smtp_secure: true`
- Older standard, but still widely supported
- Example: `smtp.gmail.com:465`

### Port 587 - STARTTLS (Recommended)

- Starts as **plain text** connection, then upgrades to TLS using STARTTLS command
- Requires `smtp_secure: false` but connection is still encrypted after upgrade
- Modern standard, preferred by most email providers
- Example: `smtp.gmail.com:587`

### Port 25 - Plain SMTP

- **Unencrypted** connection (not recommended for authentication)
- Used primarily for server-to-server email relay
- Requires `smtp_secure: false`

## Configuration Examples

### Gmail (Port 587 - STARTTLS)

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false  # Uses STARTTLS, not direct SSL
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Gmail (Port 465 - SSL/TLS)

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true  # Direct SSL connection
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Outlook/Office 365 (Port 587)

```env
SMTP_HOST=smtp-mail.outlook.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@outlook.com
SMTP_PASS=your-password
```

### SendGrid (Port 587)

```env
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
```

## Implementation Details

The email handler automatically configures the correct security settings:

```typescript
// Port 465 uses direct SSL (secure: true)
// Port 587 uses STARTTLS (secure: false, but still encrypted)
const useSecure = config.smtp_secure && config.smtp_port === 465;
const requireTls = config.smtp_port === 587 || !useSecure;

nodemailer.createTransport({
  secure: useSecure, // true for 465, false for other ports
  requireTLS: requireTls, // true for 587 to force STARTTLS
  // ...
});
```

## Common Errors

### "SSL routines: wrong version number" (ESOCKET)

**Cause**: Using `smtp_secure: true` with port 587 (STARTTLS)

**Solution**: Set `smtp_secure: false` for port 587. The connection will still be encrypted using STARTTLS.

### "ECONNREFUSED" or "ETIMEDOUT"

**Cause**: Incorrect host or port, firewall blocking connection

**Solution**:

- Verify the SMTP host and port are correct
- Check if your network/firewall allows outbound connections to the SMTP port
- Some cloud providers block port 25 by default

### "Invalid login" or "Authentication failed"

**Cause**: Incorrect credentials or app-specific password required

**Solution**:

- For Gmail: Enable 2FA and create an [App Password](https://myaccount.google.com/apppasswords)
- For other providers: Check if they require app-specific passwords
- Verify the username (often the full email address)

## Testing SMTP Configuration

Use the test command to verify your SMTP settings:

```bash
# Run email integration tests
RUN_INTEGRATION_TESTS=true \
SMTP_HOST=smtp.gmail.com \
SMTP_PORT=587 \
SMTP_USER=your-email@gmail.com \
SMTP_PASS=your-app-password \
EMAIL_FROM_ADDRESS=your-email@gmail.com \
pnpm --filter @bugspotter/backend run test:notifications:email
```

Or test manually via API:

```bash
curl -X POST http://localhost:3000/api/notifications/test \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "channel": "email",
    "config": {
      "type": "email",
      "smtp_host": "smtp.gmail.com",
      "smtp_port": 587,
      "smtp_secure": false,
      "smtp_user": "your-email@gmail.com",
      "smtp_pass": "your-app-password",
      "from_address": "your-email@gmail.com",
      "from_name": "BugSpotter"
    }
  }'
```

## Security Best Practices

1. **Always use TLS/STARTTLS** - Never send credentials over unencrypted connections
2. **Use app-specific passwords** - Don't use your main account password
3. **Validate certificates** - Keep `tls_reject_unauthorized: true` in production
4. **Rotate credentials** - Periodically update SMTP passwords
5. **Monitor logs** - Watch for authentication failures that might indicate compromised credentials

## References

- [Nodemailer SMTP Transport](https://nodemailer.com/smtp/)
- [RFC 3207 - SMTP STARTTLS](https://tools.ietf.org/html/rfc3207)
- [Gmail SMTP Settings](https://support.google.com/mail/answer/7126229)
- [Microsoft 365 SMTP Settings](https://learn.microsoft.com/en-us/exchange/mail-flow-best-practices/how-to-set-up-a-multifunction-device-or-application-to-send-email-using-microsoft-365-or-office-365)
