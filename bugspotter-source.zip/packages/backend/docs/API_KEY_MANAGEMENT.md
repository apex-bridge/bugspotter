# API Key Management System

Enterprise-grade API key management with permissions, rate limiting, rotation, and comprehensive audit trails.

## Overview

BugSpotter's API key system provides:

- **Granular Permissions** - Scope keys to specific resources and actions
- **Rate Limiting** - Sliding window algorithm (minute/hour/day/burst)
- **Key Rotation** - Automatic rotation with configurable grace periods
- **Usage Tracking** - Partitioned tables for scalability (per-month partitions)
- **Audit Logging** - Complete trail of all key management actions
- **Security Features** - IP whitelisting, CORS, user agent restrictions

## Database Schema

### Tables

**`api_keys`** - Main API key table

- Stores SHA-256 hash (never plaintext)
- Key metadata: name, description, type, status
- Permissions: scope, custom permissions, project/environment restrictions
- Rate limits: per-minute, per-hour, per-day, burst, per-endpoint
- Security: IP whitelist, allowed origins, user agent patterns
- Lifecycle: expiration, rotation schedule, grace periods

**`api_key_usage`** - Usage tracking

- Request details: endpoint, method, status code, response time
- Client info: IP address, user agent
- Error tracking: error message, error type
- Retention policy: 90-day cleanup via scheduled function

**`api_key_rate_limits`** - Rate limit tracking (sliding window)

- Window types: minute, hour, day, burst (10 seconds)
- Request counters per window
- Automatic cleanup of expired windows

**`api_key_audit_log`** - Audit trail

- Actions: created, updated, rotated, revoked, permissions_changed
- Tracks who performed action, when, from what IP
- Stores change diffs for updates

### Key Prefixes

- `bs_prod_*` - Production keys
- `bs_dev_*` - Development keys
- `bs_test_*` - Test keys

## Repository Layer

**`ApiKeyRepository`** - 28 methods covering:

### CRUD Operations

- `create()` - Create new API key
- `findById()` - Find by UUID
- `findByHash()` - Find by SHA-256 hash (for authentication)
- `update()` - Update key metadata
- `delete()` - Hard delete key

### Listing & Filtering

- `list()` - Paginated list with filters
  - Filter by: status, type, team_id, created_by, tag, expiration
  - Search: name, description
  - Sort by: created_at, updated_at, last_used_at, name, expires_at
  - Pagination: page, limit

### Lifecycle Management

- `revoke()` - Revoke key (sets status to 'revoked')
- `updateLastUsed()` - Update last_used_at timestamp
- `checkAndUpdateExpired()` - Mark expired keys (batch operation)
- `markExpiring()` - Mark keys approaching expiration

### Usage Tracking

- `trackUsage()` - Log API request
- `getUsageLogs()` - Retrieve usage history (paginated)
- `getTopEndpoints()` - Analytics: most-hit endpoints
- `findByIdWithStats()` - Get key with aggregated usage stats

### Rate Limiting

- `getRateLimitCount()` - Get current count for window
- `incrementRateLimit()` - Increment counter (upsert)
- `cleanupOldRateLimits()` - Remove expired tracking data

### Audit Logging

- `logAudit()` - Create audit entry
- `getAuditLogs()` - Retrieve audit history (paginated)

## Usage Examples

### Creating an API Key

```typescript
import { createHash, randomBytes } from 'crypto';

const rawKey = `bs_prod_${Date.now()}_${randomBytes(16).toString('hex')}`;
const keyHash = createHash('sha256').update(rawKey).digest('hex');

const apiKey = await db.apiKeys.create({
  key_hash: keyHash,
  key_prefix: rawKey.substring(0, 10),
  key_suffix: rawKey.substring(rawKey.length - 4),
  name: 'Production API Key',
  description: 'Main SDK key for production',
  type: 'production',
  permission_scope: 'custom',
  permissions: ['bugs:read', 'bugs:write', 'replays:read'],
  allowed_projects: [projectId],
  rate_limit_per_minute: 500,
  rate_limit_per_hour: 10000,
  rate_limit_per_day: 100000,
  burst_limit: 1000,
  created_by: userId,
});

// Return full key to user (ONLY TIME it's visible)
return { id: apiKey.id, key: rawKey };
```

### Authenticating with API Key

```typescript
const apiKey = req.headers['x-api-key'];
const keyHash = createHash('sha256').update(apiKey).digest('hex');

const key = await db.apiKeys.findByHash(keyHash);

if (!key || key.status !== 'active') {
  throw new UnauthorizedError('Invalid or inactive API key');
}

// Check expiration
if (key.expires_at && key.expires_at < new Date()) {
  throw new UnauthorizedError('API key expired');
}

// Update last used
await db.apiKeys.updateLastUsed(key.id);
```

### Rate Limiting

```typescript
const windowStart = new Date();
windowStart.setSeconds(0, 0); // Start of current minute

const count = await db.apiKeys.incrementRateLimit(keyId, 'minute', windowStart);

if (count > key.rate_limit_per_minute) {
  throw new RateLimitError('Rate limit exceeded');
}
```

### Tracking Usage

```typescript
const startTime = Date.now();

// Process request...

await db.apiKeys.trackUsage({
  api_key_id: key.id,
  endpoint: req.path,
  method: req.method,
  status_code: res.statusCode,
  response_time_ms: Date.now() - startTime,
  ip_address: req.ip,
  user_agent: req.headers['user-agent'],
});
```

### Key Rotation

```typescript
// Find keys due for rotation
const result = await db.apiKeys.list({
  status: 'active',
  // Custom query: rotate_at <= NOW()
});

for (const oldKey of result.data) {
  // Generate new key
  const newRawKey = generateApiKey('production');
  const newKeyHash = createHash('sha256').update(newRawKey).digest('hex');

  // Create new key with same permissions
  const newKey = await db.apiKeys.create({
    key_hash: newKeyHash,
    key_prefix: newRawKey.substring(0, 10),
    key_suffix: newRawKey.substring(newRawKey.length - 4),
    name: `${oldKey.name} (Rotated)`,
    permissions: oldKey.permissions,
    allowed_projects: oldKey.allowed_projects,
    rate_limit_per_minute: oldKey.rate_limit_per_minute,
    rotated_from: oldKey.id,
    created_by: oldKey.created_by,
  });

  // Mark old key as expiring (grace period)
  await db.apiKeys.update(oldKey.id, {
    status: 'expiring',
    expires_at: new Date(Date.now() + oldKey.grace_period_days * 86400000),
  });

  // Log rotation
  await db.apiKeys.logAudit({
    api_key_id: oldKey.id,
    action: 'rotated',
    changes: { new_key_id: newKey.id },
  });

  // Notify user with new key
  await notifyKeyRotation(oldKey, newRawKey, oldKey.grace_period_days);
}
```

## Permission Scopes

### Permission Scope Types

- **`full`** - All permissions on all resources
- **`read`** - Read-only access
- **`write`** - Write access (create, update, delete)
- **`custom`** - Specific permissions array

### Custom Permissions Format

Format: `resource:action`

**Resources:**

- `bugs` - Bug reports
- `replays` - Session replays
- `screenshots` - Screenshots
- `analytics` - Analytics data
- `admin` - Admin operations

**Actions:**

- `read` - View/list resources
- `write` - Create resources
- `update` - Modify resources
- `delete` - Remove resources

**Examples:**

- `bugs:read` - List and view bug reports
- `bugs:write` - Create new bug reports
- `replays:read` - View session replays
- `screenshots:write` - Upload screenshots
- `admin:users` - Manage users

## Rate Limiting

### Window Types

- **`minute`** - Requests per minute (default: 500)
- **`hour`** - Requests per hour (default: 10,000)
- **`day`** - Requests per day (default: 100,000)
- **`burst`** - Requests in 10 seconds (default: 1,000)

### Sliding Window Algorithm

Uses `api_key_rate_limits` table to track request counts per window. Windows are aligned to calendar boundaries (e.g., minute starts at :00 seconds).

### Per-Endpoint Limits

Store custom limits in `per_endpoint_limits` JSONB:

```typescript
{
  "/api/bugs": 100,       // 100 req/min for bug creation
  "/api/replays": 50,     // 50 req/min for replay uploads
  "/api/screenshots": 200 // 200 req/min for screenshots
}
```

## Data Retention

**Per-client databases** - Each client has their own dedicated database, significantly reducing data volume per instance.

**Usage data cleanup** - Automatic retention policy keeps table size manageable:

```sql
-- Run daily via cron
SELECT cleanup_old_api_key_usage(90); -- 90 days retention
```

**Typical scale per client:**

- Active client: 10K-50K requests/day
- 90-day retention: ~1M-5M rows
- Handled efficiently by single table with proper indexes

**Future partitioning** - Can be added later if monitoring shows performance degradation (unlikely with per-client DBs).

## Cleanup Functions

### Rate Limit Cleanup

```sql
SELECT cleanup_old_rate_limits();
```

Removes tracking data older than 2 days (run daily).

### Usage Data Cleanup

```sql
SELECT cleanup_old_api_key_usage(90); -- 90 days retention
```

Removes usage logs older than specified days.

## Test Coverage

**37 comprehensive unit tests** covering:

- CRUD operations (8 tests)
- List/filter/sort/pagination (9 tests)
- Lifecycle management (5 tests)
- Usage tracking (5 tests)
- Rate limiting (4 tests)
- Audit logging (3 tests)
- Edge cases & validation (3 tests)

See: `packages/backend/tests/db/api-key-repository.test.ts`

### Migration Notes

### Schema Design

API keys are managed in a dedicated `api_keys` table with:

- Admin-only creation (`isAdmin` check in POST /api/v1/api-keys)
- Per-key permissions and rate limits
- Usage tracking and audit logging
- No API keys stored in the `projects` table

### Migration Safety

- ✅ Deterministic schema (static partition dates)
- ✅ Idempotent migration (safe to re-run)
- ✅ Preserves existing project keys
- ✅ No data loss during transition

## Performance Considerations

### Indexes

All critical columns are indexed:

- `key_hash` - UNIQUE index for fast authentication
- `status` - Partial index for active/expiring keys only
- `expires_at` - Partial index for non-null values
- `created_by`, `team_id` - Foreign key indexes
- `last_used_at DESC` - For sorting recent activity

### Usage Table Efficiency

- Partial index on old records for cleanup operations
- Regular cleanup via `cleanup_old_api_key_usage()` keeps table under 5M rows
- Per-client database isolation limits dataset size naturally

### Rate Limit Table Efficiency

Automatic cleanup prevents unbounded growth. Composite primary key `(api_key_id, window_type, window_start)` ensures fast lookups.

## Security Best Practices

1. **Never log full API keys** - Only log prefix/suffix
2. **Hash before storage** - Store SHA-256 hash, never plaintext
3. **Return key only on creation** - Show warning it won't be shown again
4. **Enforce HTTPS** - Prevent key interception
5. **IP whitelisting** - Restrict keys to known IPs when possible
6. **Regular rotation** - Force rotation every 30-90 days
7. **Monitor suspicious activity** - Alert on rate limit hits, invalid auth attempts
8. **Audit everything** - Log all key management actions

## Future Enhancements

- [ ] Key scoping by user (not just project)
- [ ] OAuth 2.0 support for API keys
- [ ] Key usage quotas (total requests before renewal)
- [ ] Automatic key suspension on abuse detection
- [ ] Key hierarchy (master keys can create sub-keys)
- [ ] Webhook notifications for key events
- [ ] GraphQL API for key management
- [ ] Multi-region rate limiting (Redis-based)
