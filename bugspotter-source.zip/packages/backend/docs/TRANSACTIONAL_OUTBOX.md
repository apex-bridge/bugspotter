# Transactional Outbox Pattern for Automatic Ticket Creation

## Problem Statement

### Critical Bug: Orphaned Tickets

**Issue**: The original implementation created tickets on external platforms (Jira, GitHub) **BEFORE** recording them in BugSpotter's database, violating transaction atomicity.

**Flow (BROKEN)**:

```
1. Evaluate rules ✅
2. Check throttle ✅
3. Create ticket in Jira ✅ (external API call)
4. [FAILURE POINT] Database transaction fails ❌
5. Record ticket in DB ❌ Never happens
```

**Result**: Orphaned ticket exists in Jira with no corresponding record in BugSpotter database.

**Real-World Impact**:

- Ticket created in Jira project "BACK-123"
- Database insert fails (network error, constraint violation, etc.)
- BugSpotter has no record of the ticket
- User tries to create ticket again → duplicate ticket "BACK-124"
- Team has 2 tickets for same bug report, confusion ensues

### Why This Is Critical

1. **Data Integrity**: Database and external system become inconsistent
2. **User Experience**: Users see failures but tickets were actually created
3. **Billing Impact**: Duplicate tickets waste team time
4. **Cannot Be Fixed Retroactively**: Once ticket is created, can't roll it back

## Solution: Transactional Outbox Pattern

### Core Principle

**Never call external APIs before committing database transaction.**

Instead:

1. Store intent to create ticket in database (outbox table)
2. Commit transaction (atomic - either both succeed or both fail)
3. Background worker reads outbox and makes external API calls
4. Update outbox status after ticket creation

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│ Bug Report Creation                                             │
├─────────────────────────────────────────────────────────────────┤
│ 1. Create bug_report record                                     │
│ 2. Evaluate auto-ticket rules                                   │
│ 3. Check throttle limits                                        │
│ 4. Create ticket_creation_outbox entry ◄─── ATOMIC TRANSACTION │
│ 5. COMMIT                                                       │
│ 6. Return to user (fast!)                                       │
└─────────────────────────────────────────────────────────────────┘
                            │
                            │ Outbox entry written to DB
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Background Worker (Async)                                       │
├─────────────────────────────────────────────────────────────────┤
│ 1. Poll for pending outbox entries                              │
│ 2. Mark entry as 'processing' (prevents duplicate processing)   │
│ 3. Create ticket on external platform (Jira, GitHub)            │
│ 4. Record ticket in bug_reports table                           │
│ 5. Mark outbox entry as 'completed'                             │
│                                                                  │
│ On Failure:                                                      │
│ - Mark entry as 'failed'                                         │
│ - Schedule retry with exponential backoff (1m, 5m, 30m, 2h, 12h)│
│ - After max retries: Move to 'dead_letter' queue                │
└─────────────────────────────────────────────────────────────────┘
```

## Database Schema

### ticket_creation_outbox Table

```sql
CREATE TABLE ticket_creation_outbox (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Context
  bug_report_id UUID NOT NULL REFERENCES bug_reports(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  integration_id UUID NOT NULL REFERENCES project_integrations(id) ON DELETE CASCADE,
  platform VARCHAR(50) NOT NULL,
  rule_id UUID NOT NULL REFERENCES integration_rules(id) ON DELETE CASCADE,

  -- Payload for external API (JSONB for flexibility)
  payload JSONB NOT NULL,

  -- Processing state
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'dead_letter')),
  retry_count INT NOT NULL DEFAULT 0,
  max_retries INT NOT NULL DEFAULT 3,

  -- Scheduling
  scheduled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  next_retry_at TIMESTAMPTZ,

  -- Result tracking
  external_ticket_id VARCHAR(255),
  external_ticket_url TEXT,
  error_message TEXT,

  -- Audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,

  -- Idempotency (prevents duplicate processing)
  idempotency_key VARCHAR(255) UNIQUE NOT NULL
);

-- Index for worker polling
CREATE INDEX idx_outbox_pending ON ticket_creation_outbox(status, scheduled_at)
  WHERE status IN ('pending', 'failed');
```

## Implementation Details

### AutoTicketService Changes

**Before (BROKEN)**:

```typescript
async tryCreateTicket(bugReport, projectId, integrationId, platform) {
  // 1. Evaluate rules
  const rule = await findMatchingRule();

  // 2. Create ticket on Jira ❌ BEFORE db transaction
  const ticketResult = await jiraService.createTicket(bugReport);

  // 3. Record in database ❌ Can fail, leaving orphaned ticket
  await db.tickets.create({ external_id: ticketResult.id });

  return { success: true, externalId: ticketResult.id };
}
```

**After (FIXED with Outbox)**:

```typescript
async tryCreateTicket(bugReport, projectId, integrationId, platform) {
  // 1. Evaluate rules
  const rule = await findMatchingRule();

  // 2. Create outbox entry in TRANSACTION ✅
  const outboxEntry = await db.ticketOutbox.create({
    bug_report_id: bugReport.id,
    project_id: projectId,
    integration_id: integrationId,
    platform,
    rule_id: rule.id,
    payload: { title, description, severity, ... },
  });

  // 3. Return immediately (fast response to user)
  return {
    success: true,
    // Note: externalId not yet available (async processing)
  };
}
```

### Background Worker

```typescript
class TicketCreationOutboxProcessor {
  async process(job: Job<{ outboxEntryId: string }>) {
    const { outboxEntryId } = job.data;

    try {
      // 1. Mark as processing (atomic, prevents duplicate processing)
      await db.ticketOutbox.markProcessing(outboxEntryId);

      // 2. Fetch entry
      const entry = await db.ticketOutbox.findById(outboxEntryId);

      // 3. Create ticket on external platform
      const ticketResult = await jiraService.createTicket(entry.payload);

      // 4. Record ticket in database (in transaction)
      await db.transaction(async (tx) => {
        await tx.tickets.create({
          bug_report_id: entry.bug_report_id,
          external_id: ticketResult.id,
          external_url: ticketResult.url,
        });
      });

      // 5. Mark outbox as completed
      await db.ticketOutbox.markCompleted(outboxEntryId, {
        external_ticket_id: ticketResult.id,
        external_ticket_url: ticketResult.url,
      });
    } catch (error) {
      // Mark as failed, schedule retry with exponential backoff
      await db.ticketOutbox.markFailed(outboxEntryId, error.message);
      throw error; // Let Bull queue know job failed
    }
  }

  // Cron job calls this every 30 seconds
  async pollAndScheduleJobs(batchSize = 10) {
    const pendingEntries = await db.ticketOutbox.findPending(batchSize);

    for (const entry of pendingEntries) {
      await queue.add('process-outbox', { outboxEntryId: entry.id });
    }
  }
}
```

## Benefits

### 1. **Atomicity**

- Bug report creation and outbox entry creation are in same transaction
- Both succeed or both fail - no inconsistent state

### 2. **Fast User Response**

- Bug report creation returns immediately (doesn't wait for Jira API)
- User sees success even if Jira is slow/down
- Ticket creation happens asynchronously

### 3. **Automatic Retries**

- Exponential backoff: 1min, 5min, 30min, 2h, 12h
- Transient failures (network issues, Jira downtime) automatically retried
- No manual intervention needed for temporary issues

### 4. **Dead Letter Queue**

- After max retries, entry moves to 'dead_letter' status
- Admin can review failed tickets and manually retry
- Prevents infinite retry loops

### 5. **Idempotency**

- Each outbox entry has unique idempotency key
- If worker processes entry twice (crash/restart), no duplicate tickets
- Format: `{bug_report_id}:{rule_id}:{timestamp}`

### 6. **Observability**

- Clear audit trail of ticket creation attempts
- Easy to monitor queue depth, failure rate, retry counts
- Can track "time to ticket creation" metric

## Deployment Strategy

### Phase 1: Deploy Outbox Infrastructure ✅

- [x] Create `ticket_creation_outbox` table migration
- [x] Implement `TicketCreationOutboxRepository`
- [x] Add to `DatabaseClient`

### Phase 2: Update AutoTicketService ✅

- [x] Replace direct ticket creation with outbox entry creation
- [x] Update documentation to reflect new behavior
- [x] Mark old methods as deprecated

### Phase 3: Implement Background Worker (IN PROGRESS)

- [x] Create `TicketCreationOutboxProcessor` worker
- [ ] Register worker with Bull queue
- [ ] Add cron job to poll outbox every 30 seconds
- [ ] Deploy worker alongside API server

### Phase 4: Testing & Monitoring

- [ ] Test happy path (entry → processing → completed)
- [ ] Test failure + retry (external API error)
- [ ] Test dead letter queue (max retries exhausted)
- [ ] Test idempotency (duplicate processing)
- [ ] Add Grafana dashboard for outbox metrics

### Phase 5: Cleanup

- [ ] Remove deprecated methods from AutoTicketService
- [ ] Archive old test cases that relied on synchronous behavior
- [ ] Update API documentation with async semantics

## Monitoring & Alerts

### Key Metrics

1. **Outbox Queue Depth**
   - Pending + Failed entries
   - Alert if > 100 (backlog building up)

2. **Processing Time**
   - P50, P95, P99 latency for outbox processing
   - Alert if P95 > 30 seconds

3. **Failure Rate**
   - % of entries moving to 'failed' status
   - Alert if > 10% in last hour

4. **Dead Letter Count**
   - Entries in 'dead_letter' status
   - Alert if > 10 (persistent failures)

5. **Retry Distribution**
   - Histogram of retry_count (0, 1, 2, 3+)
   - Helps identify chronic issues

### Admin API Endpoints

```typescript
// Get outbox statistics
GET /api/v1/admin/outbox/stats
Response: {
  pending: 5,
  processing: 2,
  completed: 1234,
  failed: 3,
  dead_letter: 1,
  avg_retry_count: 0.8
}

// Get dead letter queue
GET /api/v1/admin/outbox/dead-letter
Response: [{
  id: "uuid",
  bug_report_id: "uuid",
  platform: "jira",
  error_message: "Jira API returned 401 Unauthorized",
  retry_count: 3,
  updated_at: "2025-12-09T10:00:00Z"
}]

// Manually retry dead letter entry
POST /api/v1/admin/outbox/{id}/retry
Response: { success: true, message: "Entry moved back to pending" }
```

## Trade-offs

### Eventual Consistency

**Before**: Ticket created synchronously (immediate consistency)
**After**: Ticket created asynchronously (eventual consistency, ~30s delay)

**Mitigation**:

- Most users don't refresh page immediately
- Can show "Ticket creation in progress" status in UI
- Background worker processes entries within 30 seconds (fast enough for UX)

### Complexity

**Before**: Simple synchronous flow (easier to understand)
**After**: Asynchronous flow with outbox + background worker (more moving parts)

**Mitigation**:

- Comprehensive documentation (this file!)
- Clear monitoring and alerting
- Dead letter queue for manual intervention
- Benefits outweigh complexity (data integrity is critical)

## Testing Strategy

### Unit Tests

```typescript
describe('AutoTicketService with Outbox', () => {
  it('should create outbox entry instead of calling external API', async () => {
    const result = await autoTicketService.tryCreateTicket(bugReport, projectId, integrationId, 'jira');

    expect(result.success).toBe(true);
    expect(jiraService.createTicket).not.toHaveBeenCalled(); // Not called!

    const outboxEntry = await db.ticketOutbox.findByBugReport(bugReport.id);
    expect(outboxEntry).toBeDefined();
    expect(outboxEntry.status).toBe('pending');
  });
});

describe('TicketCreationOutboxProcessor', () => {
  it('should process outbox entry and create ticket', async () => {
    const entry = await db.ticketOutbox.create({ ... });

    await processor.process({ id: entry.id, data: { outboxEntryId: entry.id } });

    const updatedEntry = await db.ticketOutbox.findById(entry.id);
    expect(updatedEntry.status).toBe('completed');
    expect(updatedEntry.external_ticket_id).toBeDefined();
  });

  it('should retry on failure with exponential backoff', async () => {
    jiraService.createTicket.mockRejectedValue(new Error('Jira API error'));
    const entry = await db.ticketOutbox.create({ ... });

    await expect(processor.process({ id: entry.id, data: { outboxEntryId: entry.id } })).rejects.toThrow();

    const updatedEntry = await db.ticketOutbox.findById(entry.id);
    expect(updatedEntry.status).toBe('failed');
    expect(updatedEntry.retry_count).toBe(1);
    expect(updatedEntry.next_retry_at).toBeAfter(new Date());
  });

  it('should move to dead letter queue after max retries', async () => {
    jiraService.createTicket.mockRejectedValue(new Error('Persistent error'));
    const entry = await db.ticketOutbox.create({ ..., retry_count: 2, max_retries: 3 });

    await expect(processor.process({ id: entry.id, data: { outboxEntryId: entry.id } })).rejects.toThrow();

    const updatedEntry = await db.ticketOutbox.findById(entry.id);
    expect(updatedEntry.status).toBe('dead_letter');
    expect(updatedEntry.retry_count).toBe(3);
  });
});
```

### Integration Tests

```typescript
describe('E2E: Automatic Ticket Creation with Outbox', () => {
  it('should create bug report, queue ticket creation, and process outbox', async () => {
    // Create bug report (triggers auto-ticket rule)
    const bugReport = await createBugReport({ title: 'Critical bug' });

    // Verify outbox entry created
    const outboxEntry = await db.ticketOutbox.findByBugReport(bugReport.id);
    expect(outboxEntry.status).toBe('pending');

    // Simulate background worker processing
    await processor.process({ id: outboxEntry.id, data: { outboxEntryId: outboxEntry.id } });

    // Verify ticket created in external system
    expect(jiraService.createTicket).toHaveBeenCalledWith(
      expect.objectContaining({
        title: 'Critical bug',
      })
    );

    // Verify outbox entry marked as completed
    const completedEntry = await db.ticketOutbox.findById(outboxEntry.id);
    expect(completedEntry.status).toBe('completed');
    expect(completedEntry.external_ticket_id).toBe('PROJ-123');
  });
});
```

## FAQ

### Q: What if background worker crashes while processing?

**A**: Entry remains in 'processing' status. Next polling cycle will skip it (status check). Add cleanup job to reset stale 'processing' entries (older than 10 minutes) back to 'failed'.

### Q: What if same entry is processed twice?

**A**: Idempotency key prevents duplicate tickets. Jira API returns existing ticket if called with same idempotency key.

### Q: What if database transaction fails AFTER creating outbox entry?

**A**: Transaction rollback removes outbox entry - no ticket creation happens. This is the whole point of the pattern!

### Q: How do users know ticket was created?

**A**: Three options:

1. Poll outbox status API: `GET /api/v1/outbox/{bug_report_id}/status`
2. WebSocket notification when status changes to 'completed'
3. Email notification with ticket link (existing notification system)

### Q: Can we still create tickets synchronously?

**A**: Yes, deprecated methods remain for manual ticket creation (admin panel). But automatic ticket creation should use outbox for reliability.

## Conclusion

The Transactional Outbox Pattern is the **correct solution** for automatic ticket creation because it:

1. ✅ Prevents orphaned tickets (data integrity)
2. ✅ Provides automatic retries (reliability)
3. ✅ Enables fast user response (performance)
4. ✅ Gives clear audit trail (observability)
5. ✅ Handles failures gracefully (resilience)

The complexity trade-off is worth it because **data integrity cannot be compromised** in a production system.

---

**Last Updated**: December 9, 2025
**Status**: Implementation in progress (Phase 3)
**Next Steps**: Register worker with Bull queue, add cron polling
