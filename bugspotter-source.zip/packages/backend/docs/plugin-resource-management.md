# Plugin Resource Management

## Resource Leak Discovery (2025-11-30)

### The Problem

The `executeFactory()` method in `SecurePluginExecutor` had a **critical memory leak**:

- Each call to `executeFactory()` created a new isolated-vm isolate (128MB memory allocation)
- The isolate remained alive for the lifetime of the returned service instance
- Services are cached in `PluginRegistry` indefinitely
- **The isolate was never disposed**, causing unbounded memory growth

**Impact:**

- Memory leak: 128MB per project using the plugin (not per plugin registration)
- If 10 projects use same plugin, 9 isolates leaked = 1.15GB
- Resource exhaustion with multiple plugins across projects
- Performance degradation over time
- Potential OOM crashes in production

### Root Cause

Custom plugins create per-project service instances (one isolate per project). The `execute()` method had proper cleanup in a `finally` block:

```typescript
async execute(...) {
  const isolate = new ivmModule.Isolate({ memoryLimit: 128 });
  try {
    // ... execution logic
  } finally {
    isolate.dispose();  // ✅ Proper cleanup
  }
}
```

But `executeFactory()` only disposed on error, **not on success**:

```typescript
async executeFactory(...) {
  const isolate = new ivmModule.Isolate({ memoryLimit: 128 });
  try {
    // ... return service that references isolate context
    return { createFromBugReport: async (...) => { /* uses isolate */ } };
  } catch (error) {
    isolate.dispose();  // ✅ Cleanup on error
    throw error;
  }
  // ❌ No cleanup on success - isolate leaks!
}
```

### Why Immediate Disposal Wasn't Possible

Unlike `execute()` which is a one-time validation, `executeFactory()` returns a service object that needs ongoing access to the isolate context for RPC calls. The isolate **must** remain alive as long as the service is in use.

**Additionally**, each project that uses a custom plugin gets its own isolate (for security isolation). The original implementation only stored one disposer per platform, causing all but the last project's isolate to leak.

## The Solution

### 1. Add Dispose Method to Service

Modified `executeFactory()` to return a `dispose()` method alongside `createFromBugReport()`:

```typescript
async executeFactory(...): Promise<{
  createFromBugReport: (...) => Promise<...>;
  dispose: () => void;  // NEW: Cleanup method
}> {
  const isolate = new ivmModule.Isolate({ memoryLimit: 128 });
  let isDisposed = false;  // Track disposal state

  return {
    createFromBugReport: async (...) => {
      if (isDisposed) {
        return { success: false, error: 'Service has been disposed' };
      }
      // ... normal execution
    },
    dispose: () => {
      if (isDisposed) {
        logger.warn('Plugin dispose called multiple times', { platform });
        return;  // Idempotent - safe to call multiple times
      }
      isolate.dispose();
      isDisposed = true;
      logger.info('Plugin isolate disposed', { platform });
    },
  };
}
```

**Key features:**

- **Idempotent**: Safe to call `dispose()` multiple times
- **Fail-safe**: Service methods return error after disposal
- **Logging**: Clear audit trail of resource cleanup

### 2. Store Dispose Functions in Registry

Modified `PluginRegistry` to track disposal functions:

```typescript
export class PluginRegistry {
  private services: Map<string, IntegrationService> = new Map();
  private serviceDisposers: Map<string, Array<() => void>> = new Map();  // NEW: Array to track per-project disposers

  private async createSecureService(...): Promise<IntegrationService> {
    const serviceWithDisposer = await this.executor.executeFactory(...);

    // Store dispose method for cleanup (per-project isolates)
    // Note: Actual storage happens in factory function after per-project service creation
    // This ensures each project's isolate gets its own disposer tracked

    return { /* wrapped service */ };
  }
}
```

### 3. Call Dispose on Unregister

Modified `unregister()` to cleanup isolates:

```typescript
async unregister(platform: string): Promise<void> {
  // ... existing lifecycle hooks

  // Dispose all isolates for this plugin (one per project)
  const disposers = this.serviceDisposers.get(normalizedPlatform);
  if (disposers) {
    for (const disposer of disposers) {
      try {
        disposer();
      } catch (error) {
        logger.error('Service disposer failed', {
          platform,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }

  // Remove from registry
  this.plugins.delete(normalizedPlatform);
  this.services.delete(normalizedPlatform);
  this.serviceDisposers.delete(normalizedPlatform);  // NEW
}
```

## Test Coverage

Created comprehensive test suite in `tests/integrations/plugin-resource-cleanup.test.ts`:

### Test 1: Dispose Method Exists

✅ Verifies `executeFactory()` returns both `createFromBugReport` and `dispose` methods

### Test 2: Idempotent Disposal

✅ Confirms `dispose()` can be called multiple times safely without throwing

### Test 3: Post-Disposal Failure

✅ Validates that calling `createFromBugReport()` after disposal returns error

### Test 4: Lifecycle Verification

✅ Tests complete workflow:

1. Create service
2. Successfully execute method
3. Dispose service
4. Verify method calls fail with "Service has been disposed"

## Verification

All tests pass:

- ✅ 4 new resource cleanup tests
- ✅ 23 existing plugin registry tests (no regressions)
- ✅ Build successful with no TypeScript errors

## Best Practices

### For Plugin Developers

Custom plugins don't need to worry about resource management - the platform handles it automatically:

```javascript
// Plugin code - no cleanup needed
module.exports.factory = function ({ rpcBridge, config }) {
  return {
    async createFromBugReport(bugReport, projectId) {
      // Use RPC methods freely
      // Platform will dispose isolate when plugin is unregistered
      return { success: true, external_id: 'ISSUE-123' };
    },
  };
};
```

### For Platform Operators

When managing plugins:

1. **Unregister unused plugins** to free resources:

   ```typescript
   await pluginRegistry.unregister('unused-platform');
   ```

2. **Monitor memory usage** for each plugin (128MB isolate + overhead)

3. **Consider plugin lifecycle** when scaling:
   - Each plugin registration = 128MB base memory
   - 10 plugins = 1.28GB minimum memory requirement

## Related Files

- `packages/backend/src/integrations/security/plugin-executor.ts` - Executor with dispose logic
- `packages/backend/src/integrations/plugin-registry.ts` - Registry with disposal tracking
- `packages/backend/tests/integrations/plugin-resource-cleanup.test.ts` - Test suite
- `INTEGRATION_MANAGEMENT.md` - Plugin architecture documentation

## Future Improvements

Potential enhancements for consideration:

1. **Isolate pooling** - Reuse isolates across plugin executions
2. **Memory limits per project** - Prevent runaway plugin registrations
3. **Auto-disposal on inactivity** - Dispose plugins after N minutes of no use
4. **Health monitoring** - Track isolate memory usage and alert on leaks
