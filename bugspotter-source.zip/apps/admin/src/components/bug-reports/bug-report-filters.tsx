import { useCallback } from 'react';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Select } from '../ui/select';
import { Button } from '../ui/button';
import { Filter, X } from 'lucide-react';
import type { BugReportFilters, BugStatus, BugPriority, Project } from '../../types';

interface BugReportFiltersProps {
  filters: BugReportFilters;
  onFiltersChange: (filters: BugReportFilters) => void;
  projects: Project[];
}

const statusOptions: { value: BugStatus; label: string }[] = [
  { value: 'open', label: 'Open' },
  { value: 'in-progress', label: 'In Progress' },
  { value: 'resolved', label: 'Resolved' },
  { value: 'closed', label: 'Closed' },
];

const priorityOptions: { value: BugPriority; label: string; color: string }[] = [
  { value: 'low', label: 'Low', color: 'text-gray-600' },
  { value: 'medium', label: 'Medium', color: 'text-blue-600' },
  { value: 'high', label: 'High', color: 'text-orange-600' },
  { value: 'critical', label: 'Critical', color: 'text-red-600' },
];

export function BugReportFilters({ filters, onFiltersChange, projects }: BugReportFiltersProps) {
  const updateFilter = useCallback(
    <K extends keyof BugReportFilters>(key: K, value: BugReportFilters[K]) => {
      onFiltersChange({ ...filters, [key]: value });
    },
    [filters, onFiltersChange]
  );

  const clearFilters = useCallback(() => {
    onFiltersChange({});
  }, [onFiltersChange]);

  const hasActiveFilters = Object.keys(filters).length > 0;

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-gray-500" />
          <h3 className="font-semibold">Filters</h3>
          {hasActiveFilters && (
            <Button size="sm" variant="ghost" onClick={clearFilters} className="ml-auto">
              <X className="w-3 h-3 mr-1" />
              Clear All
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Project Filter */}
          <Select
            label="Project"
            id="filter-project"
            value={filters.project_id || ''}
            onChange={(e) => updateFilter('project_id', e.target.value || undefined)}
          >
            <option value="">All Projects</option>
            {projects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.name}
              </option>
            ))}
          </Select>

          {/* Status Filter */}
          <Select
            label="Status"
            id="filter-status"
            value={filters.status || ''}
            onChange={(e) => updateFilter('status', (e.target.value as BugStatus) || undefined)}
          >
            <option value="">All Statuses</option>
            {statusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>

          {/* Priority Filter */}
          <Select
            label="Priority"
            id="filter-priority"
            value={filters.priority || ''}
            onChange={(e) => updateFilter('priority', (e.target.value as BugPriority) || undefined)}
          >
            <option value="">All Priorities</option>
            {priorityOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>

          {/* Date From Filter */}
          <Input
            label="From Date"
            id="filter-from-date"
            type="date"
            value={filters.created_after || ''}
            onChange={(e) => updateFilter('created_after', e.target.value || undefined)}
          />

          {/* Date To Filter */}
          <Input
            label="To Date"
            id="filter-to-date"
            type="date"
            value={filters.created_before || ''}
            onChange={(e) => updateFilter('created_before', e.target.value || undefined)}
          />
        </div>
      </CardContent>
    </Card>
  );
}
