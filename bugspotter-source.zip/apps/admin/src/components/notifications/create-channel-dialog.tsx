/**
 * Create Channel Dialog
 * Form for creating new notification channels
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { notificationService, projectService } from '../../services/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select-radix';
import { Textarea } from '../ui/textarea';
import type { ChannelType } from '../../types';

interface CreateChannelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function CreateChannelDialog({ open, onOpenChange, onSuccess }: CreateChannelDialogProps) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: '',
    type: 'email' as ChannelType,
    project_id: '',
    config: {} as Record<string, string>,
  });

  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: projectService.getAll,
  });

  const createMutation = useMutation({
    mutationFn: notificationService.createChannel,
    onSuccess: () => {
      toast.success('Notification channel created successfully');
      queryClient.invalidateQueries({ queryKey: ['notification-channels'] });
      onSuccess();
      // Reset form
      setFormData({
        name: '',
        type: 'email',
        project_id: '',
        config: {},
      });
    },
    onError: (error: Error) => {
      toast.error(`Failed to create channel: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.type || !formData.project_id) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Build config based on channel type
    const config: Record<string, unknown> = {};

    switch (formData.type) {
      case 'email':
        if (!formData.config.smtp_host || !formData.config.from_address) {
          toast.error('Please provide SMTP host and from address');
          return;
        }
        config.type = 'email';
        config.smtp_host = formData.config.smtp_host;
        config.smtp_port = parseInt(formData.config.smtp_port || '587');
        config.smtp_secure = formData.config.smtp_secure === 'true';
        config.smtp_user = formData.config.smtp_user || '';
        config.smtp_pass = formData.config.smtp_pass || '';
        config.from_address = formData.config.from_address;
        config.from_name = formData.config.from_name || 'BugSpotter';
        break;

      case 'slack':
        if (!formData.config.webhook_url) {
          toast.error('Please provide Slack webhook URL');
          return;
        }
        config.type = 'slack';
        config.webhook_url = formData.config.webhook_url;
        config.username = formData.config.username || 'BugSpotter';
        config.icon_emoji = formData.config.icon_emoji || ':bug:';
        break;

      case 'webhook':
        if (!formData.config.url) {
          toast.error('Please provide webhook URL');
          return;
        }
        config.type = 'webhook';
        config.url = formData.config.url;
        config.method = formData.config.method || 'POST';
        if (formData.config.headers) {
          try {
            config.headers = JSON.parse(formData.config.headers);
          } catch {
            toast.error('Invalid JSON in headers field');
            return;
          }
        }
        break;

      case 'discord':
        if (!formData.config.webhook_url) {
          toast.error('Please provide Discord webhook URL');
          return;
        }
        config.type = 'discord';
        config.webhook_url = formData.config.webhook_url;
        config.username = formData.config.username || 'BugSpotter';
        break;

      case 'teams':
        if (!formData.config.webhook_url) {
          toast.error('Please provide Teams webhook URL');
          return;
        }
        config.type = 'teams';
        config.webhook_url = formData.config.webhook_url;
        break;
    }

    createMutation.mutate({
      ...formData,
      config,
      active: true,
    });
  };

  const updateConfig = (key: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      config: { ...prev.config, [key]: value },
    }));
  };

  const renderConfigFields = () => {
    switch (formData.type) {
      case 'email':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="smtp_host">SMTP Host *</Label>
              <Input
                id="smtp_host"
                value={formData.config.smtp_host || ''}
                onChange={(e) => updateConfig('smtp_host', e.target.value)}
                placeholder="smtp.example.com"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="smtp_port">SMTP Port</Label>
                <Input
                  id="smtp_port"
                  type="number"
                  value={formData.config.smtp_port || '587'}
                  onChange={(e) => updateConfig('smtp_port', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp_secure">Secure (TLS)</Label>
                <Select
                  value={formData.config.smtp_secure || 'false'}
                  onValueChange={(value) => updateConfig('smtp_secure', value)}
                >
                  <SelectTrigger id="smtp_secure">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="true">Yes</SelectItem>
                    <SelectItem value="false">No</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp_user">SMTP Username</Label>
              <Input
                id="smtp_user"
                value={formData.config.smtp_user || ''}
                onChange={(e) => updateConfig('smtp_user', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp_pass">SMTP Password</Label>
              <Input
                id="smtp_pass"
                type="password"
                value={formData.config.smtp_pass || ''}
                onChange={(e) => updateConfig('smtp_pass', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="from_address">From Address *</Label>
              <Input
                id="from_address"
                type="email"
                value={formData.config.from_address || ''}
                onChange={(e) => updateConfig('from_address', e.target.value)}
                placeholder="noreply@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="from_name">From Name</Label>
              <Input
                id="from_name"
                value={formData.config.from_name || 'BugSpotter'}
                onChange={(e) => updateConfig('from_name', e.target.value)}
                placeholder="BugSpotter Notifications"
              />
            </div>
          </>
        );

      case 'slack':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="webhook_url">Webhook URL *</Label>
              <Input
                id="webhook_url"
                value={formData.config.webhook_url || ''}
                onChange={(e) => updateConfig('webhook_url', e.target.value)}
                placeholder="https://hooks.slack.com/services/..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Bot Username</Label>
              <Input
                id="username"
                value={formData.config.username || 'BugSpotter'}
                onChange={(e) => updateConfig('username', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="icon_emoji">Icon Emoji</Label>
              <Input
                id="icon_emoji"
                value={formData.config.icon_emoji || ':bug:'}
                onChange={(e) => updateConfig('icon_emoji', e.target.value)}
                placeholder=":bug:"
              />
            </div>
          </>
        );

      case 'webhook':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="url">Webhook URL *</Label>
              <Input
                id="url"
                value={formData.config.url || ''}
                onChange={(e) => updateConfig('url', e.target.value)}
                placeholder="https://api.example.com/webhook"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="method">HTTP Method</Label>
              <Select
                value={formData.config.method || 'POST'}
                onValueChange={(value) => updateConfig('method', value)}
              >
                <SelectTrigger id="method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="POST">POST</SelectItem>
                  <SelectItem value="PUT">PUT</SelectItem>
                  <SelectItem value="PATCH">PATCH</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="headers">Headers (JSON)</Label>
              <Textarea
                id="headers"
                value={formData.config.headers || ''}
                onChange={(e) => updateConfig('headers', e.target.value)}
                placeholder='{"Authorization": "Bearer token"}'
                rows={3}
              />
            </div>
          </>
        );

      case 'discord':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="webhook_url">Webhook URL *</Label>
              <Input
                id="webhook_url"
                value={formData.config.webhook_url || ''}
                onChange={(e) => updateConfig('webhook_url', e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Bot Username</Label>
              <Input
                id="username"
                value={formData.config.username || 'BugSpotter'}
                onChange={(e) => updateConfig('username', e.target.value)}
              />
            </div>
          </>
        );

      case 'teams':
        return (
          <div className="space-y-2">
            <Label htmlFor="webhook_url">Webhook URL *</Label>
            <Input
              id="webhook_url"
              value={formData.config.webhook_url || ''}
              onChange={(e) => updateConfig('webhook_url', e.target.value)}
              placeholder="https://outlook.office.com/webhook/..."
            />
          </div>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Notification Channel</DialogTitle>
          <DialogDescription>Configure a new channel for sending notifications</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Channel Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Production Alerts"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Channel Type *</Label>
            <Select
              value={formData.type}
              onValueChange={(value) =>
                setFormData({ ...formData, type: value as ChannelType, config: {} })
              }
            >
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="email">Email (SMTP)</SelectItem>
                <SelectItem value="slack">Slack</SelectItem>
                <SelectItem value="webhook">Generic Webhook</SelectItem>
                <SelectItem value="discord">Discord</SelectItem>
                <SelectItem value="teams">Microsoft Teams</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="project">Project *</Label>
            <Select
              value={formData.project_id}
              onValueChange={(value) => setFormData({ ...formData, project_id: value })}
            >
              <SelectTrigger id="project">
                <SelectValue placeholder="Select a project" />
              </SelectTrigger>
              <SelectContent>
                {projects?.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {renderConfigFields()}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={createMutation.isPending}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Channel'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
