import { useState, useCallback, useEffect } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Copy, AlertTriangle, Check } from 'lucide-react';
import { toast } from 'sonner';
import type { ApiKeyResponse } from '../../types';

const AUTO_CLEAR_TIMEOUT = 30000; // 30 seconds
const COPY_FEEDBACK_TIMEOUT = 2000; // 2 seconds

interface ShowApiKeyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  apiKey: ApiKeyResponse | null;
  title?: string;
  description?: string;
}

export function ShowApiKeyDialog({
  open,
  onOpenChange,
  apiKey,
  title = 'API Key',
  description = "Copy your API key now. You won't be able to see it again!",
}: ShowApiKeyDialogProps) {
  const [copied, setCopied] = useState(false);

  // Clear copied state when dialog closes
  useEffect(() => {
    if (!open) {
      setCopied(false);
    }
  }, [open]);

  // Auto-clear after 30 seconds for security
  useEffect(() => {
    if (open && apiKey) {
      const timer = setTimeout(() => {
        onOpenChange(false);
        toast.info('API key has been cleared from memory for security');
      }, AUTO_CLEAR_TIMEOUT);
      return () => clearTimeout(timer);
    }
  }, [open, apiKey, onOpenChange]);

  const handleCopy = useCallback(async (): Promise<void> => {
    if (!apiKey) {
      return;
    }

    try {
      await navigator.clipboard.writeText(apiKey.api_key);
      setCopied(true);
      toast.success('API key copied to clipboard');
      setTimeout(() => setCopied(false), COPY_FEEDBACK_TIMEOUT);
    } catch {
      toast.error('Failed to copy to clipboard');
    }
  }, [apiKey]);

  if (!apiKey) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent role="dialog" aria-modal="true" aria-labelledby="show-api-key-dialog-title">
        <DialogHeader>
          <DialogTitle id="show-api-key-dialog-title">{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Security Warning */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex gap-3">
            <AlertTriangle
              className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5"
              aria-hidden="true"
            />
            <div className="text-sm text-yellow-800">
              <p className="font-semibold">This is the only time you'll see the full API key.</p>
              <p className="mt-1">
                Copy it now and store it securely. This key will be cleared from memory in 30
                seconds.
              </p>
            </div>
          </div>

          {/* API Key Display */}
          <div className="space-y-2">
            <Label htmlFor="api-key-display">API Key</Label>
            <div className="flex gap-2">
              <Input
                id="api-key-display"
                value={apiKey.api_key}
                readOnly
                className="font-mono text-sm"
                onClick={(e) => {
                  if (e.target instanceof HTMLInputElement) {
                    e.target.select();
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleCopy}
                aria-label="Copy API key to clipboard"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-green-600" aria-hidden="true" />
                    <span className="sr-only">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" aria-hidden="true" />
                    <span className="sr-only">Copy</span>
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Key Details */}
          <div className="space-y-2 text-sm">
            <div>
              <span className="font-medium">Name:</span> {apiKey.name}
            </div>
            <div>
              <span className="font-medium">Key Prefix:</span>{' '}
              <code className="font-mono">{apiKey.key_prefix}...</code>
            </div>
            <div>
              <span className="font-medium">Permissions:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {apiKey.permissions.map((permission) => (
                  <span
                    key={permission}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {permission}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
