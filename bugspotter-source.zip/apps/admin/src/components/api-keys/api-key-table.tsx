import { useState, useCallback, useMemo } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Copy, Eye, RotateCw, Trash2, Check, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate } from '../../utils/format';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';
import type { ApiKey, Project } from '../../types';
import type { ApiKeyStatus } from '@bugspotter/types';

// ============================================================================
// CONSTANTS
// ============================================================================

const TABLE_CELL_CLASS = 'px-6 py-4 whitespace-nowrap';
const TABLE_HEADER_CLASS =
  'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider';

const STATUS_BADGE_CONFIG: Record<
  ApiKeyStatus,
  { label: string; className: string; icon?: React.ReactNode }
> = {
  active: {
    label: 'Active',
    className: 'bg-green-100 text-green-800',
  },
  expiring: {
    label: 'Expiring Soon',
    className: 'bg-yellow-100 text-yellow-800',
    icon: <AlertCircle className="w-3 h-3 mr-1" aria-hidden="true" />,
  },
  expired: {
    label: 'Expired',
    className: 'bg-red-100 text-red-800',
  },
  revoked: {
    label: 'Revoked',
    className: 'bg-gray-100 text-gray-800',
  },
};

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

/**
 * Status badge component
 */
function StatusBadge({ status }: { status: ApiKeyStatus }) {
  const config = STATUS_BADGE_CONFIG[status] || {
    label: status,
    className: 'bg-gray-100 text-gray-800',
  };

  return (
    <span
      role="status"
      aria-label={`API key status: ${config.label}`}
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${config.className}`}
    >
      {config.icon}
      {config.label}
    </span>
  );
}

/**
 * Empty state component
 */
function EmptyState() {
  return (
    <Card>
      <CardContent className="p-12 text-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
            <Copy className="w-8 h-8 text-gray-400" aria-hidden="true" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No API Keys</h3>
            <p className="text-gray-500 mt-1">Create your first API key to get started</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Table header component
 */
function TableHeader() {
  const headers = [
    'Name',
    'Key Prefix',
    'Status',
    'Project',
    'Permissions',
    'Expires',
    'Last Used',
    'Actions',
  ];

  return (
    <thead className="bg-gray-50 border-b border-gray-200">
      <tr>
        {headers.map((header, index) => (
          <th
            key={header}
            scope="col"
            className={`${TABLE_HEADER_CLASS} ${index === headers.length - 1 ? 'text-right' : ''}`}
          >
            {header}
          </th>
        ))}
      </tr>
    </thead>
  );
}

interface CopyButtonProps {
  keyPrefix: string;
  apiKeyId: string;
  isCopied: boolean;
  onCopy: (keyPrefix: string, id: string) => void;
}

/**
 * Copy button with visual feedback
 */
function CopyButton({ keyPrefix, apiKeyId, isCopied, onCopy }: CopyButtonProps) {
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => onCopy(keyPrefix, apiKeyId)}
      aria-label={`Copy key prefix ${keyPrefix}`}
    >
      {isCopied ? (
        <>
          <Check className="w-4 h-4 text-green-600" aria-hidden="true" />
          <span className="sr-only">Copied</span>
        </>
      ) : (
        <>
          <Copy className="w-4 h-4" aria-hidden="true" />
          <span className="sr-only">Copy</span>
        </>
      )}
    </Button>
  );
}

interface TableRowProps {
  apiKey: ApiKey;
  projectName: string;
  isCopied: boolean;
  isLoading: boolean;
  onCopy: (keyPrefix: string, id: string) => void;
  onViewUsage: (id: string) => void;
  onRotate: (id: string) => void;
  onRevoke: (id: string) => void;
}

/**
 * Table row component for a single API key
 */
function TableRow({
  apiKey,
  projectName,
  isCopied,
  isLoading,
  onCopy,
  onViewUsage,
  onRotate,
  onRevoke,
}: TableRowProps) {
  return (
    <tr className="hover:bg-gray-50">
      {/* Name */}
      <td className={TABLE_CELL_CLASS}>
        <div className="text-sm font-medium text-gray-900">{apiKey.name}</div>
      </td>

      {/* Key Prefix */}
      <td className={TABLE_CELL_CLASS}>
        <div className="flex items-center gap-2">
          <code className="text-sm text-gray-600 font-mono">{apiKey.key_prefix}...</code>
          <CopyButton
            keyPrefix={apiKey.key_prefix}
            apiKeyId={apiKey.id}
            isCopied={isCopied}
            onCopy={onCopy}
          />
        </div>
      </td>

      {/* Status */}
      <td className={TABLE_CELL_CLASS}>
        <StatusBadge status={apiKey.status} />
      </td>

      {/* Project */}
      <td className={TABLE_CELL_CLASS}>
        <div className="text-sm text-gray-900">{projectName}</div>
      </td>

      {/* Permissions */}
      <td className="px-6 py-4">
        <div className="flex flex-wrap gap-1">
          {apiKey.permissions.map((permission) => (
            <span
              key={permission}
              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
            >
              {permission}
            </span>
          ))}
        </div>
      </td>

      {/* Expires */}
      <td className={TABLE_CELL_CLASS}>
        <div className="text-sm text-gray-500">
          {apiKey.expires_at ? formatDate(apiKey.expires_at) : 'Never'}
        </div>
      </td>

      {/* Last Used */}
      <td className={TABLE_CELL_CLASS}>
        <div className="text-sm text-gray-500">
          {apiKey.last_used_at ? formatDate(apiKey.last_used_at) : 'Never'}
        </div>
      </td>

      {/* Actions */}
      <td className={`${TABLE_CELL_CLASS} text-right`}>
        <div className="flex items-center justify-end gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewUsage(apiKey.id)}
            aria-label={`View usage statistics for ${apiKey.name}`}
          >
            <Eye className="w-4 h-4" aria-hidden="true" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRotate(apiKey.id)}
            disabled={isLoading}
            aria-label={`Rotate API key ${apiKey.name}`}
          >
            <RotateCw className="w-4 h-4" aria-hidden="true" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRevoke(apiKey.id)}
            disabled={isLoading}
            aria-label={`Revoke API key ${apiKey.name}`}
          >
            <Trash2 className="w-4 h-4 text-red-600" aria-hidden="true" />
          </Button>
        </div>
      </td>
    </tr>
  );
}

interface ConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel: string;
  confirmClassName?: string;
}

/**
 * Reusable confirmation dialog
 */
function ConfirmDialog({
  isOpen,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel,
  confirmClassName,
}: ConfirmDialogProps) {
  return (
    <AlertDialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className={confirmClassName}>
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

interface ApiKeyTableProps {
  apiKeys: ApiKey[];
  projects: Project[];
  onRevoke: (id: string) => void;
  onRotate: (id: string) => void;
  onViewUsage: (id: string) => void;
  isLoading: boolean;
}

export function ApiKeyTable({
  apiKeys,
  projects,
  onRevoke,
  onRotate,
  onViewUsage,
  isLoading,
}: ApiKeyTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revokeDialogId, setRevokeDialogId] = useState<string | null>(null);
  const [rotateDialogId, setRotateDialogId] = useState<string | null>(null);

  // Use Map for O(1) project name lookups instead of O(n) array.find()
  const projectMap = useMemo(() => new Map(projects.map((p) => [p.id, p.name])), [projects]);

  // Helper to get project names from allowed_projects array
  const getProjectNames = useCallback(
    (allowedProjects: string[] | null): string => {
      if (!allowedProjects || allowedProjects.length === 0) {
        return 'All Projects';
      }

      const projectNames = allowedProjects
        .map((id) => projectMap.get(id))
        .filter((name): name is string => name !== undefined);

      if (projectNames.length === 0) {
        return 'Unknown';
      }

      if (projectNames.length === 1) {
        return projectNames[0];
      }

      // Multiple projects: show first + count
      return `${projectNames[0]} +${projectNames.length - 1}`;
    },
    [projectMap]
  );

  const handleCopy = useCallback(async (keyPrefix: string, id: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(keyPrefix);
      setCopiedId(id);
      toast.success('Key prefix copied to clipboard');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      toast.error('Failed to copy to clipboard');
    }
  }, []);

  const handleRevokeConfirm = useCallback((): void => {
    if (revokeDialogId) {
      onRevoke(revokeDialogId);
      setRevokeDialogId(null);
    }
  }, [revokeDialogId, onRevoke]);

  const handleRotateConfirm = useCallback((): void => {
    if (rotateDialogId) {
      onRotate(rotateDialogId);
      setRotateDialogId(null);
    }
  }, [rotateDialogId, onRotate]);

  if (apiKeys.length === 0) {
    return <EmptyState />;
  }

  return (
    <>
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <caption className="sr-only">
                API keys with name, status, project, permissions, expiry, and actions
              </caption>
              <TableHeader />
              <tbody className="bg-white divide-y divide-gray-200">
                {apiKeys.map((apiKey) => (
                  <TableRow
                    key={apiKey.id}
                    apiKey={apiKey}
                    projectName={getProjectNames(apiKey.allowed_projects)}
                    isCopied={copiedId === apiKey.id}
                    isLoading={isLoading}
                    onCopy={handleCopy}
                    onViewUsage={onViewUsage}
                    onRotate={setRotateDialogId}
                    onRevoke={setRevokeDialogId}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Revoke Confirmation */}
      <ConfirmDialog
        isOpen={revokeDialogId !== null}
        onClose={() => setRevokeDialogId(null)}
        onConfirm={handleRevokeConfirm}
        title="Revoke API Key"
        description="Are you sure you want to revoke this API key? This action cannot be undone and any applications using this key will lose access immediately."
        confirmLabel="Revoke"
        confirmClassName="bg-red-600 hover:bg-red-700"
      />

      {/* Rotate Confirmation */}
      <ConfirmDialog
        isOpen={rotateDialogId !== null}
        onClose={() => setRotateDialogId(null)}
        onConfirm={handleRotateConfirm}
        title="Rotate API Key"
        description="Are you sure you want to rotate this API key? The old key will be immediately revoked and a new key will be generated. You'll need to update any applications using the old key."
        confirmLabel="Rotate"
      />
    </>
  );
}
