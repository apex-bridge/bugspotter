import { useState, useCallback, useEffect } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select-radix';
import { Checkbox } from '../ui/checkbox';
import { toast } from 'sonner';
import type { PermissionScope, ApiKeyType } from '@bugspotter/types';
import type { Project, ApiKeyResponse, CreateApiKeyData } from '../../types';

interface CreateApiKeyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: CreateApiKeyData) => Promise<ApiKeyResponse>;
  projects: Project[];
  isLoading: boolean;
}

const AVAILABLE_PERMISSIONS = [
  { id: 'reports:read', label: 'Read Bug Reports' },
  { id: 'reports:write', label: 'Create Bug Reports' },
  { id: 'reports:update', label: 'Update Bug Reports' },
  { id: 'reports:delete', label: 'Delete Bug Reports' },
  { id: 'sessions:read', label: 'Read Sessions' },
  { id: 'sessions:write', label: 'Upload Sessions' },
] as const;

const DEFAULT_PERMISSIONS = ['reports:write', 'sessions:write'] as const;

export function CreateApiKeyDialog({
  open,
  onOpenChange,
  onSubmit,
  projects,
  isLoading,
}: CreateApiKeyDialogProps) {
  const [name, setName] = useState('');
  const [type, setType] = useState<ApiKeyType>('development');
  const [permissionScope, setPermissionScope] = useState<PermissionScope>('write');
  const [selectedProjects, setSelectedProjects] = useState<string[]>([]);
  const [permissions, setPermissions] = useState<string[]>(Array.from(DEFAULT_PERMISSIONS));
  const [allowedOrigins, setAllowedOrigins] = useState<string[]>([]);
  const [rateLimitPerMinute, setRateLimitPerMinute] = useState<number | undefined>(undefined);
  const [rateLimitPerHour, setRateLimitPerHour] = useState<number | undefined>(undefined);
  const [rateLimitPerDay, setRateLimitPerDay] = useState<number | undefined>(undefined);
  const [expiresAt, setExpiresAt] = useState<Date | undefined>(undefined);

  // Reset form when dialog closes
  useEffect(() => {
    if (!open) {
      setName('');
      setType('development');
      setPermissionScope('write');
      setSelectedProjects([]);
      setPermissions(Array.from(DEFAULT_PERMISSIONS));
      setAllowedOrigins([]);
      setRateLimitPerMinute(undefined);
      setRateLimitPerHour(undefined);
      setRateLimitPerDay(undefined);
      setExpiresAt(undefined);
    }
  }, [open]);

  const handlePermissionToggle = useCallback((permissionId: string): void => {
    setPermissions((prev) =>
      prev.includes(permissionId) ? prev.filter((p) => p !== permissionId) : [...prev, permissionId]
    );
  }, []);

  const handleProjectToggle = useCallback((projectId: string): void => {
    setSelectedProjects((prev) =>
      prev.includes(projectId) ? prev.filter((p) => p !== projectId) : [...prev, projectId]
    );
  }, []);

  const handleSubmit = useCallback(
    async (e: React.FormEvent): Promise<void> => {
      e.preventDefault();

      if (!name.trim()) {
        toast.error('Please enter a name for the API key');
        return;
      }

      if (selectedProjects.length === 0) {
        toast.error('Please select at least one project');
        return;
      }

      if (permissionScope === 'custom' && permissions.length === 0) {
        toast.error('Please select at least one permission for custom scope');
        return;
      }

      const data: CreateApiKeyData = {
        name: name.trim(),
        type,
        permission_scope: permissionScope,
        allowed_projects: selectedProjects,
      };

      // Add optional fields only if they have values
      if (permissionScope === 'custom') {
        data.permissions = permissions;
      }
      if (allowedOrigins.length > 0) {
        data.allowed_origins = allowedOrigins;
      }
      if (rateLimitPerMinute !== undefined && rateLimitPerMinute >= 0) {
        data.rate_limit_per_minute = rateLimitPerMinute;
      }
      if (rateLimitPerHour !== undefined && rateLimitPerHour >= 0) {
        data.rate_limit_per_hour = rateLimitPerHour;
      }
      if (rateLimitPerDay !== undefined && rateLimitPerDay >= 0) {
        data.rate_limit_per_day = rateLimitPerDay;
      }
      if (expiresAt) {
        data.expires_at = expiresAt.toISOString();
      }

      await onSubmit(data);
      onOpenChange(false);
    },
    [
      name,
      type,
      permissionScope,
      selectedProjects,
      permissions,
      allowedOrigins,
      rateLimitPerMinute,
      rateLimitPerHour,
      rateLimitPerDay,
      expiresAt,
      onSubmit,
      onOpenChange,
    ]
  );

  // Show the creation form
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent role="dialog" aria-modal="true" aria-labelledby="create-api-key-dialog-title">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle id="create-api-key-dialog-title">Create API Key</DialogTitle>
            <DialogDescription>
              Generate a new API key for authenticating SDK requests.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Name Input */}
            <div className="space-y-2">
              <Label htmlFor="api-key-name">Name</Label>
              <Input
                id="api-key-name"
                placeholder="e.g., Production Frontend App"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={isLoading}
              />
            </div>

            {/* Type Selection */}
            <div className="space-y-2">
              <Label htmlFor="api-key-type">Type</Label>
              <Select
                value={type}
                onValueChange={(value) => setType(value as ApiKeyType)}
                disabled={isLoading}
              >
                <SelectTrigger id="api-key-type">
                  <SelectValue placeholder="Select key type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="development">Development</SelectItem>
                  <SelectItem value="test">Test</SelectItem>
                  <SelectItem value="production">Production</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Permission Scope */}
            <div className="space-y-2">
              <Label htmlFor="permission-scope">Permission Scope</Label>
              <Select
                value={permissionScope}
                onValueChange={(value) => setPermissionScope(value as PermissionScope)}
                disabled={isLoading}
              >
                <SelectTrigger id="permission-scope">
                  <SelectValue placeholder="Select permission scope" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full">Full Access</SelectItem>
                  <SelectItem value="read">Read Only</SelectItem>
                  <SelectItem value="write">Write Only</SelectItem>
                  <SelectItem value="custom">Custom Permissions</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Project Selection (Multi-select) */}
            <div className="space-y-2">
              <Label>Allowed Projects</Label>
              <div className="space-y-2 border rounded-lg p-4 max-h-48 overflow-y-auto">
                {projects.map((project) => (
                  <div key={project.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`project-${project.id}`}
                      checked={selectedProjects.includes(project.id)}
                      onCheckedChange={() => handleProjectToggle(project.id)}
                      disabled={isLoading}
                    />
                    <label
                      htmlFor={`project-${project.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      {project.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Permissions (only show when permission_scope is 'custom') */}
            {permissionScope === 'custom' && (
              <div className="space-y-2">
                <Label>Custom Permissions</Label>
                <div className="space-y-2 border rounded-lg p-4">
                  {AVAILABLE_PERMISSIONS.map((permission) => (
                    <div key={permission.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`permission-${permission.id}`}
                        checked={permissions.includes(permission.id)}
                        onCheckedChange={() => handlePermissionToggle(permission.id)}
                        disabled={isLoading}
                      />
                      <label
                        htmlFor={`permission-${permission.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {permission.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Creating...' : 'Create API Key'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
