import { useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../ui/dialog';
import { Card, CardContent } from '../ui/card';
import { Activity, TrendingUp, Calendar, CalendarDays } from 'lucide-react';
import { formatNumber, formatDate } from '../../utils/format';
import type { ApiKeyUsage } from '../../types/api-keys';

const DAYS_IN_WEEK = 7;
const DAYS_IN_MONTH = 30;
const MS_PER_DAY = 1000 * 60 * 60 * 24;

interface ApiKeyUsageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  usage: ApiKeyUsage | null;
  isLoading: boolean;
}

export function ApiKeyUsageDialog({
  open,
  onOpenChange,
  usage,
  isLoading,
}: ApiKeyUsageDialogProps) {
  const previousFocusRef = useRef<HTMLElement | null>(null);

  // Focus management
  useEffect(() => {
    if (open) {
      previousFocusRef.current = document.activeElement as HTMLElement;
    } else {
      previousFocusRef.current?.focus();
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-labelledby="usage-dialog-title" className="max-w-2xl">
        <DialogHeader>
          <DialogTitle id="usage-dialog-title">API Key Usage Statistics</DialogTitle>
          <DialogDescription>
            View request statistics and usage patterns for this API key.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="py-8" role="status" aria-live="polite">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
            <span className="sr-only">Loading usage statistics...</span>
          </div>
        ) : usage ? (
          <div className="space-y-4">
            {/* Key Info */}
            <div className="space-y-2">
              <div className="text-sm">
                <span className="font-medium">Name:</span> {usage.name}
              </div>
              <div className="text-sm">
                <span className="font-medium">Created:</span> {formatDate(usage.created_at)}
              </div>
              <div className="text-sm">
                <span className="font-medium">Last Used:</span>{' '}
                {usage.last_used_at ? formatDate(usage.last_used_at) : 'Never'}
              </div>
            </div>

            {/* Usage Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                      <Activity className="w-5 h-5 text-blue-600" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Total Requests</p>
                      <p className="text-2xl font-bold">{formatNumber(usage.total_requests)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-green-600" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Last 24 Hours</p>
                      <p className="text-2xl font-bold">{formatNumber(usage.requests_last_24h)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-purple-600" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Last 7 Days</p>
                      <p className="text-2xl font-bold">{formatNumber(usage.requests_last_7d)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                      <CalendarDays className="w-5 h-5 text-orange-600" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Last 30 Days</p>
                      <p className="text-2xl font-bold">{formatNumber(usage.requests_last_30d)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Usage Summary */}
            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <h3 className="font-semibold text-sm mb-2">Usage Summary</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Average requests per day (30d):</span>
                    <span className="font-medium">
                      {formatNumber(Math.round(usage.requests_last_30d / DAYS_IN_MONTH))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average requests per day (7d):</span>
                    <span className="font-medium">
                      {formatNumber(Math.round(usage.requests_last_7d / DAYS_IN_WEEK))}
                    </span>
                  </div>
                  {usage.last_used_at && (
                    <div className="flex justify-between">
                      <span>Days since last use:</span>
                      <span className="font-medium">
                        {Math.floor(
                          (Date.now() - new Date(usage.last_used_at).getTime()) / MS_PER_DAY
                        )}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="py-8 text-center text-gray-500">
            <p>No usage data available</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
