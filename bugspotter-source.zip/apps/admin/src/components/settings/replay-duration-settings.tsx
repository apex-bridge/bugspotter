/**
 * Session Replay Duration Settings Section
 * Controls buffer duration for replay capture
 */

import { SettingsSection } from './settings-section';
import { Clock, AlertCircle } from 'lucide-react';
import { Input } from '../ui/input';
import type { InstanceSettings } from '../../types';

// Replay duration constraints (in seconds)
const MIN_REPLAY_DURATION = 5;
const MAX_REPLAY_DURATION = 60;
const DEFAULT_REPLAY_DURATION = 15;
const RECOMMENDED_MAX_DURATION = 30;
const DURATION_STEP = 5;

interface ReplayDurationSettingsProps {
  formData: Partial<InstanceSettings>;
  updateField: <K extends keyof InstanceSettings>(field: K, value: InstanceSettings[K]) => void;
}

export function ReplayDurationSettings({ formData, updateField }: ReplayDurationSettingsProps) {
  const duration = formData.replay_duration ?? DEFAULT_REPLAY_DURATION;

  const handleDurationChange = (value: string) => {
    const parsed = parseInt(value, 10);
    if (!isNaN(parsed) && parsed >= MIN_REPLAY_DURATION && parsed <= MAX_REPLAY_DURATION) {
      updateField('replay_duration', parsed);
    }
  };

  return (
    <SettingsSection
      title="Session Replay Duration"
      description="Control how many seconds of user activity are captured before a bug report"
    >
      <div className="space-y-6">
        {/* Duration Input */}
        <div className="space-y-2">
          <label htmlFor="replay-duration" className="block text-sm font-medium text-gray-700">
            Buffer Duration (seconds)
          </label>
          <Input
            id="replay-duration"
            type="number"
            min={MIN_REPLAY_DURATION}
            max={MAX_REPLAY_DURATION}
            step={DURATION_STEP}
            value={duration}
            onChange={(e) => handleDurationChange(e.target.value)}
            className="max-w-xs"
          />
          <p className="text-sm text-gray-500">
            Recommended: {DEFAULT_REPLAY_DURATION}-{RECOMMENDED_MAX_DURATION} seconds. Range:{' '}
            {MIN_REPLAY_DURATION}-{MAX_REPLAY_DURATION} seconds.
          </p>
        </div>

        {/* Warning for High Values */}
        {duration > RECOMMENDED_MAX_DURATION && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h4 className="text-sm font-semibold text-amber-900 mb-1">
                  High Memory Usage Warning
                </h4>
                <p className="text-sm text-amber-800">
                  Durations above {RECOMMENDED_MAX_DURATION} seconds increase client-side memory
                  usage and may impact browser performance on low-end devices.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-blue-900 mb-1">
                Duration vs. Storage Tradeoff
              </h4>
              <p className="text-sm text-blue-800 mb-3">
                Longer durations capture more context but increase storage costs and client memory
                usage. Consider your use case:
              </p>
              <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                <li>
                  <strong>{MIN_REPLAY_DURATION}-10 seconds:</strong> Minimal context, low
                  memory/storage
                </li>
                <li>
                  <strong>{DEFAULT_REPLAY_DURATION} seconds (default):</strong> Balanced context and
                  performance
                </li>
                <li>
                  <strong>{RECOMMENDED_MAX_DURATION} seconds:</strong> Extended context, moderate
                  memory/storage
                </li>
                <li>
                  <strong>{MAX_REPLAY_DURATION} seconds:</strong> Maximum context, high
                  memory/storage impact
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </SettingsSection>
  );
}
