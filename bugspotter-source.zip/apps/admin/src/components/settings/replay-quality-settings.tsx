/**
 * Session Replay Quality Settings Section
 * Controls visual fidelity vs storage cost tradeoffs
 */

import { SettingsSection } from './settings-section';
import { AlertCircle, HardDrive } from 'lucide-react';
import type { InstanceSettings } from '../../types';

interface ReplayQualitySettingsProps {
  formData: Partial<InstanceSettings>;
  updateField: <K extends keyof InstanceSettings>(field: K, value: InstanceSettings[K]) => void;
}

// Replay size impact constants (multipliers applied to base size)
const BASE_REPLAY_SIZE_KB = 100; // Baseline replay size without any quality options
const STYLESHEETS_MULTIPLIER = 0.3; // +30% size impact for inline stylesheets
const IMAGES_MULTIPLIER = 3.0; // +300% size impact for inline images
const FONTS_MULTIPLIER = 0.15; // +15% size impact for font collection
const CANVAS_MULTIPLIER = 1.0; // +100% size impact for canvas recording

export function ReplayQualitySettings({ formData, updateField }: ReplayQualitySettingsProps) {
  // Calculate estimated size impact based on enabled quality options
  const estimateSizeImpact = () => {
    let multiplier = 1;

    if (formData.replay_inline_stylesheets) {
      multiplier += STYLESHEETS_MULTIPLIER;
    }
    if (formData.replay_inline_images) {
      multiplier += IMAGES_MULTIPLIER;
    }
    if (formData.replay_collect_fonts) {
      multiplier += FONTS_MULTIPLIER;
    }
    if (formData.replay_record_canvas) {
      multiplier += CANVAS_MULTIPLIER;
    }

    const estimatedSize = Math.round(BASE_REPLAY_SIZE_KB * multiplier);
    return estimatedSize;
  };

  const sizeImpact = estimateSizeImpact();

  return (
    <SettingsSection
      title="Session Replay Quality"
      description="Control replay visual fidelity and storage costs. Higher fidelity options increase payload size and storage requirements."
    >
      <div className="space-y-6">
        {/* Visual Fidelity Options */}
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-gray-700">Visual Fidelity</h4>

          <label className="flex items-start space-x-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={formData.replay_inline_stylesheets ?? true}
              onChange={(e) => updateField('replay_inline_stylesheets', e.target.checked)}
              className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900">Inline Stylesheets</p>
                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded">
                  Recommended
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Captures external CSS for accurate styling. Essential for proper replay appearance.
              </p>
              <p className="text-xs text-gray-500 mt-1">Impact: +20-50% size (~30KB typical)</p>
            </div>
          </label>

          <label className="flex items-start space-x-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={formData.replay_inline_images ?? false}
              onChange={(e) => updateField('replay_inline_images', e.target.checked)}
              className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900">Inline Images</p>
                <span className="text-xs px-2 py-0.5 bg-orange-100 text-orange-800 rounded">
                  High Cost
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Embeds images directly in replay data. Ensures images are visible but significantly
                increases size.
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Impact: +200-500% size (~300KB typical) - expensive storage cost
              </p>
            </div>
          </label>

          <label className="flex items-start space-x-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={formData.replay_collect_fonts ?? true}
              onChange={(e) => updateField('replay_collect_fonts', e.target.checked)}
              className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900">Collect Fonts</p>
                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded">
                  Recommended
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Includes custom fonts for proper text rendering. Important for brand consistency.
              </p>
              <p className="text-xs text-gray-500 mt-1">Impact: +5-15% size (~10KB typical)</p>
            </div>
          </label>
        </div>

        {/* Advanced Recording Options */}
        <div className="space-y-4 pt-4 border-t">
          <h4 className="text-sm font-semibold text-gray-700">Advanced Recording</h4>

          <label className="flex items-start space-x-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={formData.replay_record_canvas ?? false}
              onChange={(e) => updateField('replay_record_canvas', e.target.checked)}
              className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900">Record Canvas Elements</p>
                <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 rounded">
                  Specialized
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Captures HTML5 canvas content (charts, games, graphics). Only needed for
                canvas-heavy applications.
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Impact: +50-150% size, may affect performance
              </p>
            </div>
          </label>

          <label className="flex items-start space-x-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={formData.replay_record_cross_origin_iframes ?? false}
              onChange={(e) => updateField('replay_record_cross_origin_iframes', e.target.checked)}
              className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900">Record Cross-Origin Iframes</p>
                <span className="text-xs px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded">
                  Privacy Risk
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Attempts to record content from embedded iframes. May have privacy and security
                implications.
              </p>
              <p className="text-xs text-gray-500 mt-1">Impact: Varies, potential CORS issues</p>
            </div>
          </label>
        </div>

        {/* Performance Tuning */}
        <div className="space-y-4 pt-4 border-t">
          <h4 className="text-sm font-semibold text-gray-700">Performance Tuning</h4>
          <p className="text-xs text-gray-500 mb-4">
            Control event sampling rates to balance replay smoothness with data size. Lower values =
            more events = larger files.
          </p>

          <div className="space-y-3">
            <div>
              <label htmlFor="mousemove-sampling" className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">Mouse Movement Throttle</span>
                <span className="text-xs text-gray-500">
                  {formData.replay_sampling_mousemove ?? 50}ms (
                  {Math.round(1000 / (formData.replay_sampling_mousemove ?? 50))} FPS)
                </span>
              </label>
              <input
                id="mousemove-sampling"
                type="range"
                min="25"
                max="200"
                step="25"
                value={formData.replay_sampling_mousemove ?? 50}
                onChange={(e) =>
                  updateField('replay_sampling_mousemove', parseInt(e.target.value, 10))
                }
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>25ms (40 FPS)</span>
                <span className="text-green-600 font-medium">50ms (20 FPS) - Recommended</span>
                <span>200ms (5 FPS)</span>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Controls how often mouse movements are recorded. Lower values = smoother replay but
                larger files.
              </p>
            </div>

            <div>
              <label htmlFor="scroll-sampling" className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">Scroll Event Throttle</span>
                <span className="text-xs text-gray-500">
                  {formData.replay_sampling_scroll ?? 100}ms (
                  {Math.round(1000 / (formData.replay_sampling_scroll ?? 100))} FPS)
                </span>
              </label>
              <input
                id="scroll-sampling"
                type="range"
                min="50"
                max="500"
                step="50"
                value={formData.replay_sampling_scroll ?? 100}
                onChange={(e) =>
                  updateField('replay_sampling_scroll', parseInt(e.target.value, 10))
                }
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>50ms (20 FPS)</span>
                <span className="text-green-600 font-medium">100ms (10 FPS) - Recommended</span>
                <span>500ms (2 FPS)</span>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Controls how often scroll events are recorded. Scrolling is less critical than mouse
                movements.
              </p>
            </div>
          </div>
        </div>

        {/* Size Impact Summary */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <HardDrive className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-blue-900 mb-1">Estimated Storage Impact</h4>
              <p className="text-sm text-blue-800">
                Average replay size with current settings: <strong>~{sizeImpact}KB</strong>
              </p>
              <p className="text-xs text-blue-700 mt-2">
                Baseline (no options): ~{BASE_REPLAY_SIZE_KB}KB | All options enabled: ~500KB+
              </p>
            </div>
          </div>
        </div>

        {/* Warning for Image Inlining */}
        {formData.replay_inline_images && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h4 className="text-sm font-semibold text-orange-900 mb-1">
                  High Storage Cost Warning
                </h4>
                <p className="text-sm text-orange-800">
                  Image inlining can increase replay sizes by 3-5x. Monitor your storage costs
                  carefully.
                </p>
                <p className="text-xs text-orange-700 mt-2">
                  Consider disabling this for production unless visual accuracy is critical for your
                  use case.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Recommendations */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-2">💡 Recommendations</h4>
          <ul className="text-sm text-gray-700 space-y-1.5">
            <li className="flex items-start gap-2">
              <span className="text-green-600 mt-0.5">✓</span>
              <span>
                <strong>Standard setup:</strong> Enable stylesheets and fonts, disable images
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 mt-0.5">✓</span>
              <span>
                <strong>High fidelity:</strong> Add images only if visual accuracy is critical
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-orange-600 mt-0.5">!</span>
              <span>
                <strong>Canvas recording:</strong> Only for apps with charts, games, or graphics
              </span>
            </li>
          </ul>
        </div>
      </div>
    </SettingsSection>
  );
}
