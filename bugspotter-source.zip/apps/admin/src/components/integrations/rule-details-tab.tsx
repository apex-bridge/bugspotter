import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';

interface RuleDetailsTabProps {
  name: string;
  onNameChange: (name: string) => void;
  enabled: boolean;
  onEnabledChange: (enabled: boolean) => void;
  priority: number;
  onPriorityChange: (priority: number) => void;
  autoCreate: boolean;
  onAutoCreateChange: (autoCreate: boolean) => void;
  platform: string;
}

export function RuleDetailsTab({
  name,
  onNameChange,
  enabled,
  onEnabledChange,
  priority,
  onPriorityChange,
  autoCreate,
  onAutoCreateChange,
  platform,
}: RuleDetailsTabProps) {
  return (
    <div className="space-y-4 py-4">
      <div className="space-y-2">
        <Label htmlFor="rule-name">Rule Name *</Label>
        <Input
          id="rule-name"
          value={name}
          onChange={(e) => onNameChange(e.target.value)}
          placeholder="e.g., High Priority Chrome Bugs"
          autoFocus
        />
        <p className="text-xs text-gray-500">
          A descriptive name to identify this rule in the admin panel
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="priority">Execution Order</Label>
        <Input
          id="priority"
          type="number"
          min="0"
          value={priority}
          onChange={(e) => {
            const value = parseInt(e.target.value, 10) || 0;
            onPriorityChange(Math.max(0, value));
          }}
        />
        <p className="text-xs text-gray-500">
          Higher numbers are evaluated first (e.g., 1000, 800, 600). This determines when the rule
          runs, not bug priority.
        </p>
      </div>

      <div className="space-y-3 pt-2">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="enabled"
            checked={enabled}
            onCheckedChange={(checked) => onEnabledChange(checked === true)}
          />
          <Label htmlFor="enabled" className="text-sm font-medium cursor-pointer">
            Enabled
          </Label>
        </div>
        <p className="text-xs text-gray-500 pl-6">
          Disabled rules will not process any bug reports
        </p>

        <div className="flex items-start space-x-2 pt-2">
          <Checkbox
            id="auto-create"
            checked={autoCreate}
            onCheckedChange={(checked) => onAutoCreateChange(checked === true)}
            className="mt-0.5"
          />
          <div className="flex-1">
            <Label htmlFor="auto-create" className="text-sm font-medium cursor-pointer">
              Automatically create tickets
            </Label>
            <p className="text-xs text-gray-500 mt-1">
              When enabled, matching bug reports will automatically create tickets in {platform}. If
              disabled, tickets must be created manually from the admin panel.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
