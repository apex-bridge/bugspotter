import { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select-radix';
import { Alert, AlertDescription } from '../ui/alert';
import { integrationService } from '../../services/integration-service';
import { handleApiError } from '../../lib/api-client';
import { toast } from 'sonner';
import { Shield, AlertTriangle, AlertCircle } from 'lucide-react';
import type { SecurityAnalysisResult } from '../../types';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';

// Comprehensive CodeMirror editor configuration for consistency across all editors
const CODE_MIRROR_BASIC_SETUP = {
  lineNumbers: true,
  highlightActiveLineGutter: true,
  foldGutter: true,
  dropCursor: true,
  indentOnInput: true,
  syntaxHighlighting: true,
  bracketMatching: true,
  closeBrackets: true,
  rectangularSelection: true,
  highlightActiveLine: true,
  highlightSelectionMatches: true,
};

export interface PluginFormData {
  plugin_code: string;
  // Guided mode fields
  pluginName: string;
  pluginPlatform: string;
  pluginVersion: string;
  pluginDescription: string;
  pluginAuthType: 'basic' | 'bearer' | 'api_key' | 'custom';
  createTicketCode: string;
  testConnectionCode: string;
  validateConfigCode: string;
  includeTestConnection: boolean;
  includeValidateConfig: boolean;
  // Security consent
  allowCodeExecution: boolean;
}

interface IntegrationPluginFormProps {
  initialData?: Partial<PluginFormData>;
  onSubmit: (formData: PluginFormData, useGuidedMode: boolean) => Promise<void>;
  loading?: boolean;
  onCancel?: () => void;
  // If true, guided mode is forced off (code cannot be parsed)
  guidedModeDisabled?: boolean;
  // Default mode (can be overridden by user)
  defaultMode?: 'guided' | 'advanced';
  // Submit button text (defaults to 'Save Changes')
  submitButtonText?: string;
}

const DEFAULT_FORM_DATA: PluginFormData = {
  plugin_code: '',
  pluginName: '',
  pluginPlatform: '',
  pluginVersion: '1.0.0',
  pluginDescription: '',
  pluginAuthType: 'basic',
  createTicketCode: '',
  testConnectionCode: '',
  validateConfigCode: '',
  includeTestConnection: false,
  includeValidateConfig: false,
  allowCodeExecution: false,
};

export default function IntegrationPluginForm({
  initialData = {},
  onSubmit,
  loading = false,
  onCancel,
  guidedModeDisabled = false,
  defaultMode = 'guided',
  submitButtonText = 'Save Changes',
}: IntegrationPluginFormProps) {
  const [analyzing, setAnalyzing] = useState(false);
  const [securityAnalysis, setSecurityAnalysis] = useState<SecurityAnalysisResult | null>(null);
  const [isFormDirty, setIsFormDirty] = useState(false);

  // Mode toggle: guided (simpler) vs advanced (full code)
  const [useGuidedMode, setUseGuidedMode] = useState(
    guidedModeDisabled ? false : defaultMode === 'guided'
  );

  const [formData, setFormData] = useState<PluginFormData>({
    ...DEFAULT_FORM_DATA,
    ...initialData,
  });

  // Sync form data when initialData prop changes, but only if user hasn't made edits yet
  useEffect(() => {
    if (!isFormDirty) {
      setFormData({
        ...DEFAULT_FORM_DATA,
        ...initialData,
      });
    }
  }, [initialData, isFormDirty]);

  // Clear security analysis when code changes (prevent stale analysis on modified code)
  // Always clear unconditionally - no need to check current value
  useEffect(() => {
    setSecurityAnalysis(null);
  }, [formData.plugin_code]);

  const updateField = useCallback(
    <K extends keyof PluginFormData>(field: K, value: PluginFormData[K]) => {
      setIsFormDirty(true);
      setFormData((prev) => ({ ...prev, [field]: value }));
    },
    []
  );

  const handleAnalyzeCode = async () => {
    if (!formData.plugin_code) {
      toast.error('No code to analyze');
      return;
    }

    setAnalyzing(true);
    try {
      const result = await integrationService.analyzeCode(formData.plugin_code);
      setSecurityAnalysis(result);

      if (!result.safe) {
        toast.error('Code failed security validation');
      } else if (result.warnings.length > 0) {
        toast.warning(`Code has ${result.warnings.length} warning(s)`);
      } else {
        toast.success('Code passed security validation');
      }
    } catch (error) {
      const message = handleApiError(error);
      toast.error(`Analysis failed: ${message}`);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Security consent validation
    if (!formData.allowCodeExecution) {
      toast.error('You must enable code execution to create/update a custom integration');
      return;
    }

    // Validate guided mode fields
    if (useGuidedMode) {
      if (!formData.pluginName || !formData.pluginPlatform || !formData.createTicketCode) {
        toast.error('Plugin name, platform, and createTicket code are required in guided mode');
        return;
      }
      // Backend will generate and analyze code from parts
    } else {
      // Advanced mode validation
      if (formData.plugin_code && !securityAnalysis) {
        toast.error('Please analyze the code before submitting');
        return;
      }

      if (securityAnalysis && !securityAnalysis.safe) {
        toast.error('Code failed security validation. Fix violations before submitting.');
        return;
      }
    }

    await onSubmit(formData, useGuidedMode);
    setIsFormDirty(false); // Reset after successful submit
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Plugin Code</CardTitle>
          <CardDescription>
            {useGuidedMode
              ? 'Use structured fields to build your integration plugin.'
              : 'Write your integration plugin code with full control.'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Mode Toggle */}
          <div
            className="inline-flex gap-2"
            role="group"
            aria-label="Plugin development mode selection"
          >
            <Button
              type="button"
              variant={useGuidedMode ? 'primary' : 'outline'}
              onClick={() => setUseGuidedMode(true)}
              aria-pressed={useGuidedMode}
              disabled={guidedModeDisabled}
              data-testid="guided-mode-button"
            >
              Guided Mode {guidedModeDisabled && '(Unavailable)'}
            </Button>
            <Button
              type="button"
              variant={!useGuidedMode ? 'primary' : 'outline'}
              onClick={() => setUseGuidedMode(false)}
              aria-pressed={!useGuidedMode}
              data-testid="advanced-mode-button"
            >
              Advanced Mode
            </Button>
          </div>

          {guidedModeDisabled && useGuidedMode && (
            <Alert>
              <AlertCircle className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>
                Guided mode is not available for this integration. Please use Advanced Mode to edit
                the code directly.
              </AlertDescription>
            </Alert>
          )}

          {useGuidedMode && !guidedModeDisabled ? (
            /* Guided Mode - Separate Fields */
            <div className="space-y-6">
              {/* Plugin Metadata */}
              <div className="border-l-4 border-blue-500 pl-4 space-y-4">
                <h3 className="font-semibold text-lg">Plugin Metadata</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pluginName">Plugin Name*</Label>
                    <Input
                      id="pluginName"
                      data-testid="plugin-name-input"
                      value={formData.pluginName}
                      onChange={(e) => updateField('pluginName', e.target.value)}
                      placeholder="jira-integration"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="pluginPlatform">Platform*</Label>
                    <Input
                      id="pluginPlatform"
                      data-testid="plugin-platform-input"
                      value={formData.pluginPlatform}
                      onChange={(e) => updateField('pluginPlatform', e.target.value)}
                      placeholder="jira"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pluginVersion">Version</Label>
                    <Input
                      id="pluginVersion"
                      value={formData.pluginVersion}
                      onChange={(e) => updateField('pluginVersion', e.target.value)}
                      placeholder="1.0.0"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="pluginDescription">Description</Label>
                  <Textarea
                    id="pluginDescription"
                    data-testid="plugin-description"
                    value={formData.pluginDescription}
                    onChange={(e) => updateField('pluginDescription', e.target.value)}
                    placeholder="Integration with Jira Cloud for creating bug tickets"
                    rows={2}
                  />
                </div>
              </div>

              {/* Authentication Helper */}
              <div className="border-l-4 border-green-500 pl-4 space-y-4">
                <h3 className="font-semibold text-lg">Authentication Helper</h3>

                <div>
                  <Label htmlFor="pluginAuthType">Authentication Type</Label>
                  <Select
                    value={formData.pluginAuthType}
                    onValueChange={(value) =>
                      updateField(
                        'pluginAuthType',
                        value as 'custom' | 'basic' | 'bearer' | 'api_key'
                      )
                    }
                  >
                    <SelectTrigger id="pluginAuthType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic Auth (email + API token)</SelectItem>
                      <SelectItem value="bearer">Bearer Token</SelectItem>
                      <SelectItem value="api_key">API Key</SelectItem>
                      <SelectItem value="custom">Custom (I'll handle it myself)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Auth Helper Preview */}
                <Alert>
                  <AlertCircle className="h-4 w-4" aria-hidden="true" />
                  <AlertDescription>
                    <strong>Auto-generated code snippet:</strong>
                    <pre className="mt-2 p-2 bg-gray-800 text-green-400 rounded text-xs overflow-x-auto">
                      {formData.pluginAuthType === 'basic' &&
                        `const auth = Buffer.from(context.config.email + ':' + context.config.apiToken).toString('base64');`}
                      {formData.pluginAuthType === 'bearer' &&
                        `const auth = context.config.apiToken;`}
                      {formData.pluginAuthType === 'api_key' &&
                        `const apiKey = context.config.apiKey;`}
                      {formData.pluginAuthType === 'custom' &&
                        `// No helper - you'll handle authentication in your code`}
                    </pre>
                    {formData.pluginAuthType !== 'custom' && (
                      <p className="mt-2 text-sm">
                        This variable will be available in your createTicket function.
                      </p>
                    )}
                  </AlertDescription>
                </Alert>
              </div>

              {/* Create Ticket Code */}
              <div className="border-l-4 border-purple-500 pl-4 space-y-4">
                <h3 className="font-semibold text-lg">Ticket Creation Logic*</h3>
                <p className="text-sm text-gray-600">
                  Write the function body for creating a ticket. No need for module.exports or
                  factory pattern.
                </p>

                <div data-testid="create-ticket-code-editor">
                  <Label htmlFor="create-ticket-code" className="sr-only">
                    Create Ticket Code Editor
                  </Label>
                  <CodeMirror
                    id="create-ticket-code"
                    value={formData.createTicketCode}
                    height="400px"
                    extensions={[javascript({ jsx: false })]}
                    onChange={(value) => updateField('createTicketCode', value)}
                    theme={vscodeDark}
                    basicSetup={CODE_MIRROR_BASIC_SETUP}
                  />
                </div>
              </div>

              {/* Optional: Test Connection */}
              <div className="border-l-4 border-orange-500 pl-4 space-y-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="include-test-connection"
                    checked={formData.includeTestConnection}
                    onChange={(e) => updateField('includeTestConnection', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="include-test-connection" className="cursor-pointer">
                    Include testConnection method (optional)
                  </Label>
                </div>

                {formData.includeTestConnection && (
                  <div>
                    <Label htmlFor="test-connection-code" className="sr-only">
                      Test Connection Code Editor
                    </Label>
                    <CodeMirror
                      id="test-connection-code"
                      value={formData.testConnectionCode}
                      height="200px"
                      extensions={[javascript({ jsx: false })]}
                      onChange={(value) => updateField('testConnectionCode', value)}
                      theme={vscodeDark}
                      basicSetup={CODE_MIRROR_BASIC_SETUP}
                    />
                  </div>
                )}
              </div>

              {/* Optional: Validate Config */}
              <div className="border-l-4 border-pink-500 pl-4 space-y-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="include-validate-config"
                    checked={formData.includeValidateConfig}
                    onChange={(e) => updateField('includeValidateConfig', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="include-validate-config" className="cursor-pointer">
                    Include validateConfig method (optional)
                  </Label>
                </div>

                {formData.includeValidateConfig && (
                  <div>
                    <Label htmlFor="validate-config-code" className="sr-only">
                      Validate Config Code Editor
                    </Label>
                    <CodeMirror
                      id="validate-config-code"
                      value={formData.validateConfigCode}
                      height="200px"
                      extensions={[javascript({ jsx: false })]}
                      onChange={(value) => updateField('validateConfigCode', value)}
                      theme={vscodeDark}
                      basicSetup={CODE_MIRROR_BASIC_SETUP}
                    />
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Advanced Mode - Full Code Editor */
            <div className="space-y-4">
              <div data-testid="advanced-code-editor">
                <Label htmlFor="plugin-code" className="sr-only">
                  Plugin Code Editor
                </Label>
                <CodeMirror
                  id="plugin-code"
                  value={formData.plugin_code}
                  height="500px"
                  extensions={[javascript({ jsx: false })]}
                  onChange={(value) => updateField('plugin_code', value)}
                  theme={vscodeDark}
                  basicSetup={CODE_MIRROR_BASIC_SETUP}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleAnalyzeCode}
                  disabled={!formData.plugin_code || analyzing}
                  data-testid="analyze-security-button"
                >
                  <Shield className="w-4 h-4 mr-2" aria-hidden="true" />
                  {analyzing ? 'Analyzing...' : 'Analyze Security'}
                </Button>
              </div>

              {securityAnalysis && (
                <Alert variant={securityAnalysis.safe ? 'default' : 'destructive'}>
                  {securityAnalysis.safe ? (
                    <Shield className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <AlertTriangle className="w-4 h-4" aria-hidden="true" />
                  )}
                  <AlertDescription>
                    <div className="space-y-2">
                      <div className="font-semibold">
                        {securityAnalysis.safe
                          ? 'Security Validation Passed'
                          : 'Security Violations Detected'}
                      </div>
                      <div>Risk Level: {securityAnalysis.risk_level}</div>

                      {securityAnalysis.violations.length > 0 && (
                        <div>
                          <div className="font-medium mt-2">Violations:</div>
                          <ul className="list-disc list-inside">
                            {securityAnalysis.violations.map((v: string, i: number) => (
                              <li key={i}>{v}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {securityAnalysis.warnings.length > 0 && (
                        <div>
                          <div className="font-medium mt-2">Warnings:</div>
                          <ul className="list-disc list-inside">
                            {securityAnalysis.warnings.map((w: string, i: number) => (
                              <li key={i}>{w}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Consent */}
      <Card className="border-orange-500">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <input
              type="checkbox"
              id="allow-code-execution"
              checked={formData.allowCodeExecution}
              onChange={(e) => updateField('allowCodeExecution', e.target.checked)}
              className="w-5 h-5 mt-0.5"
              data-testid="allow-code-execution-checkbox"
            />
            <div className="flex-1">
              <Label htmlFor="allow-code-execution" className="cursor-pointer font-semibold">
                Allow Code Execution *
              </Label>
              <p className="text-sm text-muted-foreground mt-1">
                I understand that this custom integration will execute code in a sandboxed
                environment (isolated-vm). While sandboxed, custom code should be reviewed for
                security before enabling.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Button type="submit" disabled={loading} data-testid="save-plugin-button">
          {loading ? 'Saving...' : submitButtonText}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}
