import type { ThrottleConfig } from '../../types';
import { ThrottleConfigForm } from './throttle-config-form';

interface AdvancedTabProps {
  throttleConfig: ThrottleConfig | null;
  onThrottleConfigChange: (config: ThrottleConfig | null) => void;
}

export function AdvancedTab({ throttleConfig, onThrottleConfigChange }: AdvancedTabProps) {
  return (
    <div className="py-4">
      <div className="mb-4">
        <h3 className="text-sm font-medium mb-1">Throttling Settings</h3>
        <p className="text-xs text-gray-500">
          Prevent duplicate tickets by limiting how often this rule creates tickets for similar bug
          reports
        </p>
      </div>
      <ThrottleConfigForm config={throttleConfig} onChange={onThrottleConfigChange} />
    </div>
  );
}
