import type { FieldMappings } from '@bugspotter/types';
import { FieldMappingsForm } from './field-mappings-form';
import { MarkdownEditor } from './markdown-editor';

interface FieldMappingsTabProps {
  autoCreate: boolean;
  platform: string;
  fieldMappings: FieldMappings | null;
  onFieldMappingsChange: (mappings: FieldMappings | null) => void;
  descriptionTemplate: string | null;
  onDescriptionTemplateChange: (template: string | null) => void;
  renderFieldMappings?: (props: {
    mappings: FieldMappings | null;
    onChange: (mappings: FieldMappings | null) => void;
  }) => React.ReactNode;
}

export function FieldMappingsTab({
  autoCreate,
  platform,
  fieldMappings,
  onFieldMappingsChange,
  descriptionTemplate,
  onDescriptionTemplateChange,
  renderFieldMappings,
}: FieldMappingsTabProps) {
  if (!autoCreate) {
    return (
      <div className="py-8 text-center text-gray-500">
        <p className="text-sm">
          Field mappings are only available when automatic ticket creation is enabled.
        </p>
        <p className="text-xs mt-2">
          Enable &quot;Automatically create tickets&quot; in the Rule Details tab to configure field
          mappings.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 py-4">
      {/* Field Mappings Section */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-medium mb-1">Platform Field Mappings</h3>
          <p className="text-xs text-gray-500">
            Map bug report data to {platform} ticket fields using template variables
          </p>
        </div>
        {renderFieldMappings ? (
          renderFieldMappings({
            mappings: fieldMappings,
            onChange: onFieldMappingsChange,
          })
        ) : (
          <FieldMappingsForm
            platform={platform}
            mappings={fieldMappings}
            onChange={onFieldMappingsChange}
          />
        )}
      </div>

      {/* Description Template Section */}
      <div className="space-y-3 pt-4 border-t">
        <div>
          <h3 className="text-sm font-medium mb-1">Custom Ticket Description Template</h3>
          <p className="text-xs text-gray-500">
            Customize the ticket description using Markdown. Preview shows how it will appear in{' '}
            {platform}.
          </p>
        </div>
        <MarkdownEditor
          value={descriptionTemplate || ''}
          onChange={(value: string) => {
            onDescriptionTemplateChange(value.trim().length === 0 ? null : value);
          }}
        />
      </div>
    </div>
  );
}
