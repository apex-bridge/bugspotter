import type { FilterCondition } from '../../types';
import { RuleBuilder } from './rule-builder';

interface ConditionsTabProps {
  filters: FilterCondition[];
  onFiltersChange: (filters: FilterCondition[]) => void;
}

export function ConditionsTab({ filters, onFiltersChange }: ConditionsTabProps) {
  return (
    <div className="py-4">
      <div className="mb-4">
        <h3 className="text-sm font-medium mb-1">Filter Conditions</h3>
        <p className="text-xs text-gray-500">
          Define conditions to match bug reports. All conditions must be met (AND logic). Leave
          empty to match all reports.
        </p>
      </div>
      <RuleBuilder filters={filters} onChange={onFiltersChange} />
    </div>
  );
}
