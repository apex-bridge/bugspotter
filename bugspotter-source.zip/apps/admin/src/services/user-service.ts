/**
 * User Service
 * Handles user management operations
 */

import { api, API_ENDPOINTS } from '../lib/api-client';
import type {
  User,
  UserRole,
  CreateUserRequest,
  UpdateUserRequest,
  UserManagementResponse,
} from '../types';

export const userService = {
  getAll: async (
    params: {
      page?: number;
      limit?: number;
      role?: UserRole;
      email?: string;
    } = {}
  ): Promise<UserManagementResponse> => {
    const response = await api.get<{ success: boolean; data: UserManagementResponse }>(
      API_ENDPOINTS.adminUsers.list(),
      { params }
    );
    return response.data.data;
  },

  create: async (data: CreateUserRequest): Promise<User> => {
    const response = await api.post<{ success: boolean; data: User }>(
      API_ENDPOINTS.adminUsers.create(),
      data
    );
    return response.data.data;
  },

  update: async (id: string, data: UpdateUserRequest): Promise<User> => {
    const response = await api.patch<{ success: boolean; data: User }>(
      API_ENDPOINTS.adminUsers.update(id),
      data
    );
    return response.data.data;
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(API_ENDPOINTS.adminUsers.delete(id));
  },
};
