/**
 * Notifications Page
 * Manages notification channels, rules, and history
 */

import { useState } from 'react';
import { Bell, Plus } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { ChannelsList } from '../components/notifications/channels-list';
import { RulesList } from '../components/notifications/rules-list';
import { HistoryList } from '../components/notifications/history-list';
import { CreateChannelDialog } from '../components/notifications/create-channel-dialog';
import { CreateRuleDialog } from '../components/notifications/create-rule-dialog';

export default function NotificationsPage() {
  const [activeTab, setActiveTab] = useState('channels');
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showCreateRule, setShowCreateRule] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Bell className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
            <p className="text-sm text-gray-600">
              Manage notification channels, rules, and delivery history
            </p>
          </div>
        </div>
        {activeTab === 'channels' && (
          <Button onClick={() => setShowCreateChannel(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Channel
          </Button>
        )}
        {activeTab === 'rules' && (
          <Button onClick={() => setShowCreateRule(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Rule
          </Button>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="channels">Channels</TabsTrigger>
          <TabsTrigger value="rules">Rules</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="channels" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Channels</CardTitle>
              <CardDescription>
                Configure where notifications are delivered (Email, Slack, Webhooks, etc.)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChannelsList onRefresh={() => setShowCreateChannel(false)} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Rules</CardTitle>
              <CardDescription>
                Define when and how notifications are triggered based on bug report events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RulesList onRefresh={() => setShowCreateRule(false)} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification History</CardTitle>
              <CardDescription>View past notification deliveries and their status</CardDescription>
            </CardHeader>
            <CardContent>
              <HistoryList />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <CreateChannelDialog
        open={showCreateChannel}
        onOpenChange={setShowCreateChannel}
        onSuccess={() => setShowCreateChannel(false)}
      />
      <CreateRuleDialog
        open={showCreateRule}
        onOpenChange={setShowCreateRule}
        onSuccess={() => setShowCreateRule(false)}
      />
    </div>
  );
}
