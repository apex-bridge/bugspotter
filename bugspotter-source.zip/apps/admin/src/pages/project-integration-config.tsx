/**
 * Project Integration Configuration Page
 * Configure credentials and settings for a specific integration on a specific project
 */

import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Save, TestTube, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import projectIntegrationService from '../services/project-integration-service';
import { handleApiError } from '../lib/api-client';

export default function ProjectIntegrationConfigPage() {
  const { projectId, platform } = useParams<{ projectId: string; platform: string }>();

  // Validate params early - must be before any conditional hooks
  const isInvalidParam = (param: string | undefined): boolean => {
    if (!param) {
      return true;
    }
    if (param.trim() === '') {
      return true;
    }
    return false;
  };

  if (isInvalidParam(platform) || isInvalidParam(projectId)) {
    return (
      <div className="container mx-auto py-8">
        <p className="text-red-600" data-testid="error-message">
          Missing platform or project ID
        </p>
      </div>
    );
  }

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [config, setConfig] = useState<Record<string, string>>({});
  const [credentials, setCredentials] = useState<Record<string, string>>({});

  // Load existing configuration
  const { isLoading } = useQuery({
    queryKey: ['project-integration', platform, projectId],
    queryFn: async () => {
      if (!platform || !projectId) {
        return null;
      }
      const data = await projectIntegrationService.get(platform, projectId);
      if (data?.config) {
        setConfig(data.config as Record<string, string>);
      }
      return data;
    },
    enabled: !!platform && !!projectId,
  });

  // Test connection mutation
  const testMutation = useMutation({
    mutationFn: async () => {
      if (!platform) {
        throw new Error('Platform not specified');
      }
      return await projectIntegrationService.testConnection(platform, {
        ...config,
        ...credentials,
      });
    },
    onSuccess: () => {
      toast.success('Connection test successful!');
    },
    onError: (error) => {
      toast.error(`Connection test failed: ${handleApiError(error)}`);
    },
  });

  // Save configuration mutation
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!platform || !projectId) {
        throw new Error('Missing platform or project ID');
      }
      return await projectIntegrationService.configure(platform, projectId, {
        config,
        credentials,
        enabled: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project-integration', platform, projectId] });
      queryClient.invalidateQueries({ queryKey: ['project-integrations', projectId] });
      toast.success('Configuration saved successfully!');
      navigate(`/projects/${projectId}/integrations`);
    },
    onError: (error) => {
      toast.error(`Failed to save configuration: ${handleApiError(error)}`);
    },
  });

  // Delete configuration mutation
  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (!platform || !projectId) {
        throw new Error('Missing platform or project ID');
      }
      return await projectIntegrationService.delete(platform, projectId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project-integrations', projectId] });
      toast.success('Configuration deleted successfully!');
      navigate(`/projects/${projectId}/integrations`);
    },
    onError: (error) => {
      toast.error(`Failed to delete configuration: ${handleApiError(error)}`);
    },
  });

  const updateConfig = (key: string, value: string) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
  };

  const updateCredentials = (key: string, value: string) => {
    setCredentials((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(`/projects/${projectId}/integrations`)}
              aria-label="Back to integrations"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            </Button>
            <h1 className="text-3xl font-bold">
              Configure {platform?.replace('_', ' ').toUpperCase()}
            </h1>
          </div>
          <p className="text-gray-600">Set up credentials and settings for this integration</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <div
            className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"
            role="status"
            aria-live="polite"
          ></div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {/* Configuration Section */}
          <Card>
            <CardHeader>
              <CardTitle>Configuration</CardTitle>
              <CardDescription>Non-sensitive settings for this integration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="instance-url">Instance URL</Label>
                <Input
                  id="instance-url"
                  type="url"
                  placeholder="https://your-instance.atlassian.net"
                  value={config.instanceUrl || ''}
                  onChange={(e) => updateConfig('instanceUrl', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="project-key">Project Key</Label>
                <Input
                  id="project-key"
                  placeholder="PROJ"
                  value={config.projectKey || ''}
                  onChange={(e) => updateConfig('projectKey', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="config-json">Additional Config (JSON)</Label>
                <Textarea
                  id="config-json"
                  placeholder='{"issueType": "Bug", "priority": "High"}'
                  value={config.additionalConfig || ''}
                  onChange={(e) => updateConfig('additionalConfig', e.target.value)}
                  rows={4}
                />
                <p className="text-xs text-gray-500">
                  Optional: Add any extra configuration as JSON
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Credentials Section */}
          <Card>
            <CardHeader>
              <CardTitle>Credentials</CardTitle>
              <CardDescription>Sensitive credentials (encrypted before storage)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your-email@example.com"
                  value={credentials.email || ''}
                  onChange={(e) => updateCredentials('email', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="api-token">API Token</Label>
                <Input
                  id="api-token"
                  type="password"
                  placeholder="Enter your API token"
                  value={credentials.apiToken || ''}
                  onChange={(e) => updateCredentials('apiToken', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password (if using basic auth)</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter password"
                  value={credentials.password || ''}
                  onChange={(e) => updateCredentials('password', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Actions */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between gap-4">
            <Button
              variant="destructive"
              onClick={() => deleteMutation.mutate()}
              disabled={deleteMutation.isPending}
            >
              <Trash2 className="w-4 h-4 mr-2" aria-hidden="true" />
              Delete Configuration
            </Button>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => testMutation.mutate()}
                disabled={testMutation.isPending}
              >
                <TestTube className="w-4 h-4 mr-2" aria-hidden="true" />
                Test Connection
              </Button>

              <Button
                onClick={() => saveMutation.mutate()}
                disabled={saveMutation.isPending}
                data-testid="save-config-button"
              >
                <Save className="w-4 h-4 mr-2" aria-hidden="true" />
                Save Configuration
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-2 text-sm text-gray-600">
            <p>
              <strong>Configuration</strong> contains non-sensitive settings like URLs and project
              keys.
            </p>
            <p>
              <strong>Credentials</strong> are encrypted before being stored in the database and
              never exposed in API responses.
            </p>
            <p>
              Click <strong>Test Connection</strong> to verify your settings before saving.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
