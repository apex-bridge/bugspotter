import { useQuery } from '@tanstack/react-query';
import { adminService } from '../services/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import {
  Database,
  HardDrive,
  Server,
  CheckCircle,
  XCircle,
  Clock,
  Activity,
  Cpu,
  Layers,
  Zap,
  AlertTriangle,
  Pause,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Download,
} from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { ServiceStatusCard } from '../components/health/service-status-card';
import { useState, useEffect, useRef, useCallback } from 'react';

// Memory usage thresholds (percentage)
const MEMORY_WARNING_THRESHOLD = 70;
const MEMORY_CRITICAL_THRESHOLD = 85;

// Processing time thresholds (milliseconds)
const SLOW_PROCESSING_THRESHOLD_MS = 1000;
const FAST_PROCESSING_THRESHOLD_MS = 500;

// Queue depth thresholds
const HIGH_QUEUE_WAITING_THRESHOLD = 100;
const HIGH_QUEUE_FAILED_THRESHOLD = 10;

// Pure helper functions (defined outside component to avoid recreation on every render)
const getStatusColor = (status: string) => {
  switch (status) {
    case 'up':
    case 'healthy':
      return 'text-green-600';
    case 'degraded':
      return 'text-yellow-600';
    default:
      return 'text-red-600';
  }
};

const getStatusIcon = (status: string) => {
  if (status === 'up' || status === 'healthy') {
    return <CheckCircle className="w-6 h-6" aria-hidden="true" />;
  }
  return <XCircle className="w-6 h-6" aria-hidden="true" />;
};

const formatBytes = (bytes: number) => {
  if (bytes === 0) {
    return '0 B';
  }
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`;
};

const formatUptime = (seconds: number) => {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${days}d ${hours}h ${minutes}m`;
};

const getTimeAgo = (date: Date) => {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 5) {
    return 'just now';
  }
  if (seconds < 60) {
    return `${seconds}s ago`;
  }
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes}m ago`;
  }
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
};

const getMemoryColor = (percentage: number) => {
  if (percentage < MEMORY_WARNING_THRESHOLD) {
    return 'bg-green-600';
  }
  if (percentage < MEMORY_CRITICAL_THRESHOLD) {
    return 'bg-yellow-500';
  }
  return 'bg-red-600';
};

const getMemoryStatus = (percentage: number) => {
  if (percentage < MEMORY_WARNING_THRESHOLD) {
    return 'healthy';
  }
  if (percentage < MEMORY_CRITICAL_THRESHOLD) {
    return 'warning';
  }
  return 'critical';
};

const getMemoryTextColor = (percentage: number) => {
  if (percentage < MEMORY_WARNING_THRESHOLD) {
    return 'text-green-600';
  }
  if (percentage < MEMORY_CRITICAL_THRESHOLD) {
    return 'text-yellow-600';
  }
  return 'text-red-600';
};

export default function HealthPage() {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const downloadLinkRef = useRef<HTMLAnchorElement>(null);

  const {
    data: health,
    isLoading,
    refetch,
    dataUpdatedAt,
  } = useQuery({
    queryKey: ['health'],
    queryFn: adminService.getHealth,
    refetchInterval: 10000, // Refresh every 10 seconds for near real-time monitoring
  });

  useEffect(() => {
    if (dataUpdatedAt) {
      setLastUpdated(new Date(dataUpdatedAt));
    }
  }, [dataUpdatedAt]);

  const exportHealthSnapshot = useCallback(() => {
    const snapshot = {
      timestamp: new Date().toISOString(),
      status: health?.status,
      services: health?.services,
      workers: health?.workers,
      queues: health?.queues,
      system: health?.system,
      plugins: health?.plugins,
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    if (downloadLinkRef.current) {
      downloadLinkRef.current.href = url;
      downloadLinkRef.current.download = `health-snapshot-${Date.now()}.json`;
      downloadLinkRef.current.click();

      // Clean up the object URL after a short delay
      setTimeout(() => URL.revokeObjectURL(url), 100);
    }
  }, [health]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await Promise.all([refetch(), new Promise((resolve) => setTimeout(resolve, 500))]);
    setIsRefreshing(false);
  }, [refetch]);

  // Calculate memory usage percentage for progress bar
  const memoryUsagePercentage = Math.min(
    ((health?.system?.process_memory_mb || 0) / (health?.system?.system_memory_mb || 1)) * 100,
    100
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div
          className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"
          role="status"
          aria-live="polite"
        >
          <span className="sr-only">Loading system health data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">System Health</h1>
          <div className="flex items-center gap-3 mt-1">
            <p className="text-gray-500">Real-time monitoring of your BugSpotter instance</p>
            <span className="text-xs text-gray-400 flex items-center gap-1">
              <Clock className="w-3 h-3" aria-hidden="true" />
              Updated {getTimeAgo(lastUpdated)}
            </span>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportHealthSnapshot}
            className="px-4 py-2 bg-white border rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
            aria-label="Export health snapshot as JSON"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            Export
          </button>
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className={`px-4 py-2 bg-white border rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2 ${isRefreshing ? 'opacity-50' : ''}`}
            aria-label="Manually refresh system health data"
          >
            <RefreshCw
              className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            Refresh
          </button>
        </div>
      </div>

      {/* Overall Status */}
      <Card
        className={`border-l-4 ${health?.status === 'healthy' ? 'border-l-green-500' : health?.status === 'degraded' ? 'border-l-yellow-500' : 'border-l-red-500'}`}
      >
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Overall Status</CardTitle>
              <CardDescription>System is {health?.status}</CardDescription>
            </div>
            <div className={getStatusColor(health?.status || '')} role="status" aria-live="polite">
              <div className="relative">
                {getStatusIcon(health?.status || '')}
                {health?.status === 'healthy' && (
                  <span className="absolute inset-0 animate-ping opacity-75">
                    <CheckCircle className="w-6 h-6" aria-hidden="true" />
                  </span>
                )}
              </div>
              <span className="sr-only">
                System status: {health?.status || 'unknown'}
                {health?.status === 'healthy' && ' - All systems operational'}
              </span>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Core Services */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Core Services</h2>
        <div className="grid gap-6 md:grid-cols-3">
          <ServiceStatusCard
            title="Database"
            icon={Database}
            service={health?.services?.database}
            getStatusColor={getStatusColor}
          />
          <ServiceStatusCard
            title="Redis"
            icon={Server}
            service={health?.services?.redis}
            getStatusColor={getStatusColor}
          />
          <ServiceStatusCard
            title="Storage"
            icon={HardDrive}
            service={health?.services?.storage}
            getStatusColor={getStatusColor}
          />
        </div>
      </div>

      {/* Background Workers */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Background Workers</h2>
        {health?.workers && health.workers.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {health.workers.map((worker) => (
              <Card key={worker.name}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium capitalize">
                      {worker.name.replace(/_/g, ' ')}
                    </CardTitle>
                    {worker.running ? (
                      <>
                        <Activity className="h-4 w-4 text-green-600" aria-hidden="true" />
                        <span className="sr-only">Worker running</span>
                      </>
                    ) : worker.enabled ? (
                      <>
                        <AlertTriangle className="h-4 w-4 text-red-600" aria-hidden="true" />
                        <span className="sr-only">Worker stopped (error)</span>
                      </>
                    ) : (
                      <>
                        <Pause className="h-4 w-4 text-gray-400" aria-hidden="true" />
                        <span className="sr-only">Worker disabled</span>
                      </>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">Status</span>
                    <Badge variant={worker.running ? 'default' : 'destructive'} className="text-xs">
                      {worker.running ? 'Running' : 'Stopped'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">Processed</span>
                    <span className="font-mono font-medium">{worker.jobs_processed}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">Failed</span>
                    <span
                      className={`font-mono font-medium ${worker.jobs_failed > 0 ? 'text-red-600' : ''}`}
                    >
                      {worker.jobs_failed}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">Avg Time</span>
                    <span className="font-mono font-medium flex items-center gap-1">
                      {(worker.avg_processing_time_ms || 0).toFixed(0)}ms
                      {(() => {
                        const processingTime = worker.avg_processing_time_ms;
                        if (!processingTime) {
                          return null;
                        }

                        if (processingTime > SLOW_PROCESSING_THRESHOLD_MS) {
                          return (
                            <>
                              <TrendingUp className="w-3 h-3 text-orange-500" aria-hidden="true" />
                              <span className="sr-only">Processing time is slow</span>
                            </>
                          );
                        }

                        if (processingTime < FAST_PROCESSING_THRESHOLD_MS) {
                          return (
                            <>
                              <TrendingDown className="w-3 h-3 text-green-500" aria-hidden="true" />
                              <span className="sr-only">Processing time is fast</span>
                            </>
                          );
                        }

                        return null;
                      })()}
                    </span>
                  </div>
                  {worker.last_error && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-red-600 line-clamp-2" title={worker.last_error}>
                        {worker.last_error}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center text-gray-500">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-yellow-500" aria-hidden="true" />
              <p>No background workers detected</p>
              <p className="text-xs mt-1">Workers may not be enabled or deployed</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Queue Health */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Job Queues</h2>
        {health?.queues && health.queues.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2">
            {health.queues.map((queue) => (
              <Card key={queue.name}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium capitalize">
                      {queue.name} Queue
                    </CardTitle>
                    <Layers className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-xs text-gray-500">Waiting</p>
                      <p className="text-lg font-semibold flex items-center gap-1">
                        {queue.waiting}
                        {queue.waiting > HIGH_QUEUE_WAITING_THRESHOLD && (
                          <>
                            <AlertTriangle className="w-4 h-4 text-yellow-500" aria-hidden="true" />
                            <span className="sr-only">High queue depth warning</span>
                          </>
                        )}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Active</p>
                      <p
                        className="text-lg font-semibold text-blue-600 flex items-center gap-1"
                        role="status"
                        aria-live="polite"
                      >
                        {queue.active}
                        {queue.active > 0 && (
                          <>
                            <Activity className="w-4 h-4 animate-pulse" aria-hidden="true" />
                            <span className="sr-only">Processing jobs</span>
                          </>
                        )}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Failed</p>
                      <p
                        className={`text-lg font-semibold flex items-center gap-1 ${queue.failed > 0 ? 'text-red-600' : ''}`}
                      >
                        {queue.failed}
                        {queue.failed > HIGH_QUEUE_FAILED_THRESHOLD && (
                          <>
                            <AlertTriangle className="w-4 h-4" aria-hidden="true" />
                            <span className="sr-only">Many failed jobs detected</span>
                          </>
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t">
                    <div>
                      <p className="text-xs text-gray-500">Completed</p>
                      <p className="text-sm font-mono">{queue.completed.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Delayed</p>
                      <p className="text-sm font-mono">{queue.delayed}</p>
                    </div>
                  </div>
                  {queue.paused && (
                    <div className="mt-3 pt-3 border-t">
                      <Badge variant="secondary" className="text-xs">
                        <Pause className="w-3 h-3 mr-1" aria-hidden="true" />
                        Paused
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center text-gray-500">
              <Layers className="h-8 w-8 mx-auto mb-2 text-gray-400" aria-hidden="true" />
              <p>No job queues detected</p>
              <p className="text-xs mt-1">Queue system may not be initialized</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Plugin Registry */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Integration Plugins</h2>
        {health?.plugins && health.plugins.length > 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {health.plugins.map((plugin) => (
                  <div
                    key={plugin.platform}
                    className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg"
                  >
                    <Zap
                      className={`h-4 w-4 ${plugin.enabled ? 'text-green-600' : 'text-gray-400'}`}
                      aria-hidden="true"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium capitalize truncate">{plugin.platform}</p>
                      <p className="text-xs text-gray-500">{plugin.type}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-8 text-center text-gray-500">
              <Zap className="h-8 w-8 mx-auto mb-2 text-gray-400" aria-hidden="true" />
              <p>No integration plugins registered</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* System Metrics */}
      <div>
        <h2 className="text-xl font-semibold mb-4">System Metrics</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Process Memory</CardTitle>
              <Cpu className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{health?.system?.process_memory_mb || 0} MB</div>
              <p className="text-xs text-muted-foreground">
                of {health?.system?.system_memory_mb || 0} MB system total (
                {Math.round(memoryUsagePercentage)}%)
              </p>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-2 rounded-full transition-all duration-500 ${getMemoryColor(memoryUsagePercentage)}`}
                  style={{ width: `${memoryUsagePercentage}%` }}
                  role="progressbar"
                  aria-valuenow={health?.system?.process_memory_mb || 0}
                  aria-valuemin={0}
                  aria-valuemax={health?.system?.system_memory_mb || 0}
                  aria-label={`Process memory usage: ${health?.system?.process_memory_mb || 0} MB of ${health?.system?.system_memory_mb || 0} MB system memory (${Math.round(memoryUsagePercentage)}%)`}
                />
              </div>
              <div className="mt-1 flex items-center justify-between">
                <span
                  className={`text-xs font-medium ${getMemoryTextColor(memoryUsagePercentage)}`}
                >
                  {getMemoryStatus(memoryUsagePercentage).toUpperCase()}
                </span>
                {memoryUsagePercentage >= MEMORY_WARNING_THRESHOLD && (
                  <>
                    <TrendingUp className="w-4 h-4 text-orange-500" aria-hidden="true" />
                    <span className="sr-only">
                      Memory usage is{' '}
                      {memoryUsagePercentage >= MEMORY_CRITICAL_THRESHOLD
                        ? 'critically high'
                        : 'elevated'}
                    </span>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Disk Space</CardTitle>
              <HardDrive className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatBytes(health?.system?.disk_space_available || 0)}
              </div>
              <p className="text-xs text-muted-foreground">
                of {formatBytes(health?.system?.disk_space_total || 0)} available
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Queue Depth</CardTitle>
              <Layers className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{health?.system?.worker_queue_depth || 0}</div>
              <p className="text-xs text-muted-foreground">pending jobs across all queues</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Uptime</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatUptime(health?.system?.uptime || 0)}</div>
              <p className="text-xs text-muted-foreground">
                Node.js {health?.system?.node_version}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Hidden anchor for accessible file downloads */}
      <a ref={downloadLinkRef} className="sr-only" aria-hidden="true" tabIndex={-1} />
    </div>
  );
}
