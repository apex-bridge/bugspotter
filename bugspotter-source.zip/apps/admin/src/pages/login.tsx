import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '../contexts/auth-context';
import { authService, setupService } from '../services/api';
import { handleApiError } from '../lib/api-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { LogIn } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingSetup, setIsCheckingSetup] = useState(true);
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const handleMagicLogin = useCallback(
    async (token: string) => {
      setIsLoading(true);
      try {
        const response = await authService.magicLogin(token);
        login(response.access_token, '', response.user);
        toast.success('Successfully logged in with magic link!');
        navigate('/', { replace: true });
      } catch (error) {
        toast.error(handleApiError(error));
        // Remove token from URL on error
        navigate('/login', { replace: true });
      } finally {
        setIsLoading(false);
      }
    },
    [login, navigate]
  );

  const checkSetupStatusAndMagicToken = useCallback(async () => {
    try {
      const status = await setupService.getStatus();
      if (!status.initialized) {
        // System not initialized, redirect to setup
        navigate('/setup');
        return;
      }

      // Check for magic token in URL query parameter
      const magicToken = searchParams.get('token');
      if (magicToken) {
        await handleMagicLogin(magicToken);
      }
    } catch (error) {
      // If setup status endpoint doesn't exist or returns error,
      // assume setup is needed
      const errorMessage = handleApiError(error);
      if (!errorMessage.includes('not found') && !errorMessage.includes('404')) {
        // Real error (not just "not found"), but continue to login
        // User can try to login and see what happens
      }
    } finally {
      setIsCheckingSetup(false);
    }
  }, [navigate, searchParams, handleMagicLogin]);

  useEffect(() => {
    checkSetupStatusAndMagicToken();
  }, [checkSetupStatusAndMagicToken]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await authService.login(email, password);
      // Refresh token is now in httpOnly cookie, pass empty string for backward compat
      login(response.access_token, '', response.user);
      toast.success('Login successful');
      navigate('/');
    } catch (error) {
      toast.error(handleApiError(error));
    } finally {
      setIsLoading(false);
    }
  };

  if (isCheckingSetup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Checking system status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-3xl font-bold">BugSpotter Admin</CardTitle>
          <CardDescription>Sign in to your admin account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="admin@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Button type="submit" className="w-full" isLoading={isLoading}>
              <LogIn className="w-4 h-4 mr-2" />
              Sign In
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
