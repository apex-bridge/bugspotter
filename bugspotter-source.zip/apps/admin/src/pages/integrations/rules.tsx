import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Edit, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';
import { integrationRulesService } from '../../services/integration-rules-service';
import { handleApiError } from '../../lib/api-client';
import {
  transformFieldMappingsForApi,
  transformFieldMappingsForUI,
} from '../../utils/field-mappings';
import { Button } from '../../components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../../components/ui/dialog';
import { GenericRuleForm } from '../../components/integrations/generic-rule-form';
import {
  JiraFieldMappingsForm,
  type JiraFieldMappings,
} from '../../integrations/jira/components/jira-field-mappings';
import type {
  IntegrationRule,
  FilterCondition,
  ThrottleConfig,
  CreateIntegrationRuleRequest,
  UpdateIntegrationRuleRequest,
} from '../../types';
import type { FieldMappings } from '@bugspotter/types';

const RULES_QUERY_KEY = 'integrationRules';

export default function IntegrationRulesPage() {
  const { platform, projectId } = useParams<{ platform: string; projectId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingRule, setEditingRule] = useState<IntegrationRule | null>(null);
  const [deletingRuleId, setDeletingRuleId] = useState<string | null>(null);

  // Fetch rules
  const {
    data: rules = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: [RULES_QUERY_KEY, platform, projectId],
    queryFn: () => integrationRulesService.list(platform!, projectId!),
    enabled: !!platform && !!projectId,
  });

  // Mutations
  const createMutation = useMutation({
    mutationFn: (payload: CreateIntegrationRuleRequest) =>
      integrationRulesService.create(platform!, projectId!, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [RULES_QUERY_KEY, platform, projectId] });
      toast.success('Rule created successfully');
      handleCloseDialog();
    },
    onError: (error) => {
      // Don't close dialog on error - preserve form data for corrections
      toast.error(handleApiError(error));
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ ruleId, payload }: { ruleId: string; payload: UpdateIntegrationRuleRequest }) =>
      integrationRulesService.update(platform!, projectId!, ruleId, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [RULES_QUERY_KEY, platform, projectId] });
      toast.success('Rule updated successfully');
      handleCloseDialog();
    },
    onError: (error) => {
      // Don't close dialog on error - preserve form data for corrections
      toast.error(handleApiError(error));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (ruleId: string) => integrationRulesService.delete(platform!, projectId!, ruleId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [RULES_QUERY_KEY, platform, projectId] });
      toast.success('Rule deleted successfully');
      setDeletingRuleId(null);
    },
    onError: (error) => toast.error(handleApiError(error)),
  });

  const toggleEnabledMutation = useMutation({
    mutationFn: ({ ruleId, enabled }: { ruleId: string; enabled: boolean }) =>
      integrationRulesService.toggleEnabled(platform!, projectId!, ruleId, enabled),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [RULES_QUERY_KEY, platform, projectId] });
      toast.success('Rule status updated');
    },
    onError: (error) => toast.error(handleApiError(error)),
  });

  const handleOpenCreateDialog = useCallback(() => {
    setEditingRule(null);
    setShowCreateDialog(true);
  }, []);

  const handleOpenEditDialog = useCallback((rule: IntegrationRule) => {
    setEditingRule(rule);
    setShowCreateDialog(true);
  }, []);

  const handleCloseDialog = useCallback(() => {
    setShowCreateDialog(false);
    setEditingRule(null);
  }, []);

  const handleFormSubmit = useCallback(
    (values: {
      name: string;
      enabled: boolean;
      priority: number;
      filters: FilterCondition[];
      throttle?: ThrottleConfig | null;
      autoCreate: boolean;
      fieldMappings: FieldMappings | null;
      descriptionTemplate: string | null;
    }) => {
      const trimmedName = values.name.trim();

      if (!trimmedName) {
        toast.error('Rule name is required');
        return;
      }

      if (trimmedName.length > 255) {
        toast.error('Rule name must be 255 characters or less');
        return;
      }

      // Validate priority is non-negative
      if (values.priority < 0) {
        toast.error('Priority must be 0 or greater');
        return;
      }

      // Validate filter values are not empty
      const emptyFilters = values.filters.filter((f) => {
        if (Array.isArray(f.value)) {
          return f.value.length === 0 || f.value.every((v: string) => !v.trim());
        }
        return !f.value || f.value.trim() === '';
      });

      if (emptyFilters.length > 0) {
        toast.error('All filter values must be filled in');
        return;
      }

      // Validate throttle configuration if present
      if (values.throttle) {
        // Require at least one rate limit when throttling is enabled
        if (
          values.throttle.max_per_hour === undefined &&
          values.throttle.max_per_day === undefined
        ) {
          toast.error(
            'At least one rate limit (per hour or per day) is required when throttling is enabled'
          );
          return;
        }

        if (values.throttle.max_per_hour !== undefined && values.throttle.max_per_hour <= 0) {
          toast.error('Max tickets per hour must be greater than 0');
          return;
        }
        if (values.throttle.max_per_day !== undefined && values.throttle.max_per_day <= 0) {
          toast.error('Max tickets per day must be greater than 0');
          return;
        }
        if (
          values.throttle.digest_interval_minutes !== undefined &&
          values.throttle.digest_interval_minutes <= 0
        ) {
          toast.error('Digest interval must be greater than 0 minutes');
          return;
        }
      }

      // Convert JiraFieldMappings string values to objects for JSONB storage
      // JiraFieldMappings has string values (JSON strings for UI), but backend expects objects
      const fieldMappingsForApi = transformFieldMappingsForApi(values.fieldMappings);

      const payload: CreateIntegrationRuleRequest = {
        name: trimmedName,
        enabled: values.enabled,
        priority: values.priority,
        filters: values.filters,
        throttle: values.throttle,
        auto_create: values.autoCreate,
        field_mappings: fieldMappingsForApi,
        description_template: values.descriptionTemplate?.trim() || null,
      };

      if (editingRule) {
        updateMutation.mutate({ ruleId: editingRule.id, payload });
      } else {
        createMutation.mutate(payload);
      }
    },
    [editingRule, createMutation, updateMutation]
  );

  const handleToggleEnabled = useCallback(
    (ruleId: string, currentEnabled: boolean) => {
      toggleEnabledMutation.mutate({ ruleId, enabled: !currentEnabled });
    },
    [toggleEnabledMutation]
  );

  const handleDelete = useCallback(
    (ruleId: string) => {
      deleteMutation.mutate(ruleId);
    },
    [deleteMutation]
  );

  if (!platform || !projectId) {
    return (
      <div className="container mx-auto py-8">
        <p className="text-red-600">Missing platform or project ID</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8">
        <p className="text-red-600">Error loading rules: {handleApiError(error)}</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(-1)}
              aria-label="Back to integration"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-3xl font-bold">Integration Rules</h1>
          </div>
          <p className="text-gray-600">
            Configure filtering and throttling rules for {platform} integration
          </p>
        </div>
        <Button onClick={handleOpenCreateDialog}>
          <Plus className="h-4 w-4 mr-2" />
          Create Rule
        </Button>
      </div>

      {/* Rules list */}
      {isLoading ? (
        <Card>
          <CardContent className="py-8">
            <p className="text-center text-gray-500">Loading rules...</p>
          </CardContent>
        </Card>
      ) : rules.length === 0 ? (
        <Card>
          <CardContent className="py-8">
            <p className="text-center text-gray-500">
              No rules configured yet. Create your first rule to start filtering bug reports.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {rules.map((rule) => (
            <Card key={rule.id} role="article" aria-label={`Rule: ${rule.name}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      {rule.name}
                      <Badge variant={rule.enabled ? 'default' : 'secondary'}>
                        {rule.enabled ? 'Enabled' : 'Disabled'}
                      </Badge>
                      {rule.auto_create && (
                        <Badge variant="success" role="status" aria-label="Auto-create enabled">
                          Auto-create
                        </Badge>
                      )}
                      {rule.priority > 0 && <Badge variant="outline">Order: {rule.priority}</Badge>}
                    </CardTitle>
                    <CardDescription>
                      {rule.filters.length} filter{rule.filters.length !== 1 ? 's' : ''}
                      {rule.throttle && ' • Throttling enabled'}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleToggleEnabled(rule.id, rule.enabled)}
                      aria-label={rule.enabled ? 'Disable rule' : 'Enable rule'}
                    >
                      {rule.enabled ? (
                        <ToggleRight className="h-4 w-4" />
                      ) : (
                        <ToggleLeft className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleOpenEditDialog(rule)}
                      aria-label="Edit rule"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeletingRuleId(rule.id)}
                      aria-label="Delete rule"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filter summary */}
                {rule.filters.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Filters:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      {rule.filters.map((filter, idx) => (
                        <li key={idx}>
                          • <strong>{filter.field}</strong> {filter.operator}{' '}
                          <code className="px-1 py-0.5 bg-gray-100 rounded text-xs">
                            {Array.isArray(filter.value) ? filter.value.join(', ') : filter.value}
                          </code>
                          {filter.case_sensitive && ' (case sensitive)'}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Throttle summary */}
                {rule.throttle && (
                  <div className="mt-4 space-y-2">
                    <h4 className="text-sm font-medium">Throttling:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      {rule.throttle.max_per_hour && (
                        <li>• Max {rule.throttle.max_per_hour} tickets per hour</li>
                      )}
                      {rule.throttle.max_per_day && (
                        <li>• Max {rule.throttle.max_per_day} tickets per day</li>
                      )}
                      {rule.throttle.group_by && <li>• Grouped by {rule.throttle.group_by}</li>}
                      {rule.throttle.digest_mode && (
                        <li>
                          • Digest mode enabled (every {rule.throttle.digest_interval_minutes}{' '}
                          minutes)
                        </li>
                      )}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingRule ? 'Edit Rule' : 'Create Rule'}</DialogTitle>
            <DialogDescription>
              Configure filtering conditions and throttling for this integration
            </DialogDescription>
          </DialogHeader>

          {/* Platform-specific forms */}
          <GenericRuleForm
            key={editingRule?.id || 'new'}
            platform={platform}
            initialValues={
              editingRule
                ? {
                    name: editingRule.name,
                    enabled: editingRule.enabled,
                    priority: editingRule.priority,
                    filters: editingRule.filters,
                    autoCreate: editingRule.auto_create || false,
                    fieldMappings: transformFieldMappingsForUI(editingRule.field_mappings),
                    throttle: editingRule.throttle,
                    descriptionTemplate: editingRule.description_template || null,
                  }
                : undefined
            }
            onSubmit={(values) => {
              handleFormSubmit({
                ...values,
                fieldMappings: values.fieldMappings as FieldMappings | null,
              });
            }}
            onCancel={handleCloseDialog}
            isSubmitting={createMutation.isPending || updateMutation.isPending}
            renderFieldMappings={
              platform === 'jira'
                ? ({ mappings, onChange }) => (
                    <JiraFieldMappingsForm
                      projectId={projectId!}
                      mappings={mappings as JiraFieldMappings | null}
                      onChange={onChange as (mappings: JiraFieldMappings | null) => void}
                    />
                  )
                : undefined
            }
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deletingRuleId} onOpenChange={() => setDeletingRuleId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Rule</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this rule? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingRuleId(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deletingRuleId && handleDelete(deletingRuleId)}
              disabled={deleteMutation.isPending}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
