import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { projectService } from '../services/api';
import { handleApiError } from '../lib/api-client';
import { formatDateShort } from '../utils/format';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { FolderPlus, Trash2, Users, Settings } from 'lucide-react';

export default function ProjectsPage() {
  const navigate = useNavigate();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: projectService.getAll,
  });

  const createMutation = useMutation({
    mutationFn: projectService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Project created successfully');
      setProjectName('');
      setShowCreateForm(false);
    },
    onError: (error) => {
      toast.error(handleApiError(error));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: projectService.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Project deleted successfully');
      setDeleteConfirm(null);
    },
    onError: (error) => {
      toast.error(handleApiError(error));
    },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectName.trim()) {
      return;
    }
    createMutation.mutate(projectName);
  };

  const handleDelete = (id: string) => {
    if (deleteConfirm === id) {
      deleteMutation.mutate(id);
    } else {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Projects</h1>
          <p className="text-gray-500 mt-1">Manage your BugSpotter projects</p>
        </div>
        <Button onClick={() => setShowCreateForm(!showCreateForm)} data-testid="new-project-button">
          <FolderPlus className="w-4 h-4 mr-2" aria-hidden="true" />
          New Project
        </Button>
      </div>

      {showCreateForm && (
        <Card data-testid="create-project-form">
          <CardHeader>
            <CardTitle>Create New Project</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="flex gap-2">
              <Input
                placeholder="Project name"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="flex-1"
                data-testid="project-name-input"
              />
              <Button
                type="submit"
                isLoading={createMutation.isPending}
                data-testid="create-project-submit"
              >
                Create
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setShowCreateForm(false)}
                data-testid="cancel-create-project"
              >
                Cancel
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div
          className="flex items-center justify-center min-h-[400px]"
          data-testid="projects-loading"
        >
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="grid gap-4">
          {projects?.map((project) => (
            <Card key={project.id} data-testid={`project-card-${project.id}`}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3
                      className="text-xl font-semibold mb-2"
                      data-testid={`project-name-${project.id}`}
                    >
                      {project.name}
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="text-gray-600">
                        Created: {formatDateShort(project.created_at)}
                      </div>
                      <div className="text-gray-600">Reports: {project.report_count}</div>
                      <div className="text-gray-500 text-xs mt-2">
                        Manage API keys in the API Keys section
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => navigate(`/projects/${project.id}/integrations`)}
                      aria-label={`Manage integrations for ${project.name}`}
                    >
                      <Settings className="w-4 h-4 mr-1" aria-hidden="true" />
                      Integrations
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => navigate(`/projects/${project.id}/members`)}
                      aria-label={`Manage members for ${project.name}`}
                    >
                      <Users className="w-4 h-4 mr-1" aria-hidden="true" />
                      Members
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(project.id)}
                      isLoading={deleteMutation.isPending && deleteConfirm === project.id}
                      data-testid={`delete-project-${project.id}`}
                    >
                      <Trash2 className="w-4 h-4 mr-1" aria-hidden="true" />
                      {deleteConfirm === project.id ? 'Confirm Delete?' : 'Delete'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {projects?.length === 0 && (
            <Card data-testid="projects-empty">
              <CardContent className="pt-6 text-center text-gray-500">
                No projects yet. Create your first project to get started.
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
