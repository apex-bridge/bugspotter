import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Settings2, Wrench, Plus } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { AddIntegrationDropdown } from '../components/integrations/add-integration-dropdown';
import { projectService } from '../services/api';
import { handleApiError } from '../lib/api-client';

export default function ProjectIntegrationsPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  const {
    data: integrations,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ['project-integrations', projectId],
    queryFn: () => projectService.listIntegrations(projectId!),
    enabled: !!projectId,
    staleTime: 30000, // 30 seconds
    retry: false, // Don't retry on error (e.g., invalid project ID)
  });

  // Filter to show only configured integrations
  const configuredIntegrations = integrations?.filter((int) => int.enabled && int.config) || [];

  // Available integrations that are not yet configured
  const availableIntegrations = integrations?.filter((int) => !int.enabled || !int.config) || [];

  // Show error state but still allow navigation
  if (isError && !isLoading) {
    return (
      <div className="container mx-auto py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/projects')}
                aria-label="Back to projects"
                data-testid="back-to-projects"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </Button>
              <h1 className="text-3xl font-bold">Project Integrations</h1>
            </div>
            <p className="text-gray-600">
              Manage integrations and automation rules for this project
            </p>
          </div>

          {/* Add Integration Dropdown - disabled in error state */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button disabled aria-label="Add integration - unavailable due to loading error">
                <Plus className="w-4 h-4 mr-2" aria-hidden="true" />
                Add Integration
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem disabled>
                <div className="flex flex-col">
                  <span className="font-medium text-gray-500">No integrations available</span>
                  <span className="text-xs text-gray-400">Unable to load integrations</span>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Error Message */}
        <Card className="border-red-200 bg-red-50">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <h3 className="text-lg font-semibold mb-2 text-red-800">Unable to Load Integrations</h3>
            <p className="text-red-700 mb-4 max-w-md">{handleApiError(error)}</p>
            <Button variant="outline" onClick={() => navigate('/projects')}>
              <ArrowLeft className="w-4 h-4 mr-2" aria-hidden="true" />
              Back to Projects
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!projectId) {
    return (
      <div className="container mx-auto py-8">
        <p className="text-red-600" data-testid="error-message">
          Missing project ID
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/projects')}
              aria-label="Back to projects"
              data-testid="back-to-projects"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            </Button>
            <h1 className="text-3xl font-bold">Project Integrations</h1>
          </div>
          <p className="text-gray-600">Manage integrations and automation rules for this project</p>
        </div>

        {/* Add Integration Dropdown */}
        <AddIntegrationDropdown
          projectId={projectId}
          availableIntegrations={availableIntegrations}
        />
      </div>

      {/* Integration Cards */}
      {isLoading ? (
        <div
          className="flex items-center justify-center min-h-[400px]"
          role="status"
          aria-live="polite"
        >
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <span className="sr-only">Loading integrations...</span>
        </div>
      ) : configuredIntegrations.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Wrench className="w-12 h-12 text-gray-400 mb-4" aria-hidden="true" />
            <h3 className="text-lg font-semibold mb-2">No Integrations Configured</h3>
            <p className="text-gray-600 mb-4 max-w-md">
              Connect external platforms to automatically create tickets and sync data when bug
              reports are created.
            </p>
            <AddIntegrationDropdown
              projectId={projectId}
              availableIntegrations={availableIntegrations}
              buttonText="Configure Your First Integration"
              align="center"
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {configuredIntegrations.map((integration) => (
            <Card
              key={integration.platform}
              data-testid={`integration-card-${integration.platform}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{integration.name}</CardTitle>
                    <CardDescription className="mt-2">{integration.description}</CardDescription>
                  </div>
                  {integration.hasRules && (
                    <Badge variant="outline" className="ml-2">
                      Rules
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() =>
                      navigate(
                        `/projects/${projectId}/integrations/${integration.platform}/configure`
                      )
                    }
                    data-testid={`configure-${integration.platform}`}
                    aria-label={`Configure ${integration.name} for this project`}
                  >
                    <Wrench className="w-4 h-4 mr-2" aria-hidden="true" />
                    Configure
                  </Button>
                  {integration.hasRules && (
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() =>
                        navigate(`/integrations/${integration.platform}/${projectId}/rules`)
                      }
                      data-testid={`manage-rules-${integration.platform}`}
                      aria-label={`Manage ${integration.name} rules for this project`}
                    >
                      <Settings2 className="w-4 h-4 mr-2" aria-hidden="true" />
                      Manage Rules
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Info */}
      <Card data-testid="integration-info-card">
        <CardContent className="pt-6">
          <div className="space-y-2 text-sm text-gray-600">
            <p>
              <strong>Integration Rules</strong> allow you to automatically create tickets in
              external platforms when bug reports match certain conditions.
            </p>
            <p>
              Click "Manage Rules" on any integration to configure filtering, field mappings,
              throttling, and auto-create settings.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
