/**
 * API Constants
 * Centralized API base paths and endpoints
 */

/**
 * API version prefix
 * Used to construct all API endpoint paths
 */
export const API_VERSION = '/api/v1';

/**
 * API endpoint builders
 * Helper functions to construct consistent API paths
 */
export const API_ENDPOINTS = {
  // Auth endpoints
  auth: {
    login: () => `${API_VERSION}/auth/login`,
    logout: () => `${API_VERSION}/auth/logout`,
    refresh: () => `${API_VERSION}/auth/refresh`,
    magicLogin: () => `${API_VERSION}/auth/magic-login`,
    me: () => `${API_VERSION}/auth/me`,
  },

  // Setup endpoints
  setup: {
    status: () => `${API_VERSION}/setup/status`,
    initialize: () => `${API_VERSION}/setup/initialize`,
    testStorage: () => `${API_VERSION}/setup/test-storage`,
  },

  // Project endpoints
  projects: {
    list: () => `${API_VERSION}/projects`,
    create: () => `${API_VERSION}/projects`,
    get: (id: string) => `${API_VERSION}/projects/${id}`,
    update: (id: string) => `${API_VERSION}/projects/${id}`,
    delete: (id: string) => `${API_VERSION}/projects/${id}`,
    stats: (id: string) => `${API_VERSION}/projects/${id}/stats`,
    members: (id: string) => `${API_VERSION}/projects/${id}/members`,
    apiKeys: (id: string) => `${API_VERSION}/projects/${id}/api-keys`,
    integrations: (id: string) => `${API_VERSION}/projects/${id}/integrations`,
  },

  // Bug report endpoints
  bugReports: {
    list: () => `${API_VERSION}/reports`,
    get: (id: string) => `${API_VERSION}/reports/${id}`,
    update: (id: string) => `${API_VERSION}/reports/${id}`,
    delete: (id: string) => `${API_VERSION}/reports/${id}`,
    bulkDelete: () => `${API_VERSION}/reports/bulk-delete`,
  },

  // User endpoints
  users: {
    list: () => `${API_VERSION}/users`,
    create: () => `${API_VERSION}/users`,
    get: (id: string) => `${API_VERSION}/users/${id}`,
    update: (id: string) => `${API_VERSION}/users/${id}`,
    delete: (id: string) => `${API_VERSION}/users/${id}`,
  },

  // Admin user endpoints
  adminUsers: {
    list: () => `${API_VERSION}/admin/users`,
    create: () => `${API_VERSION}/admin/users`,
    get: (id: string) => `${API_VERSION}/admin/users/${id}`,
    update: (id: string) => `${API_VERSION}/admin/users/${id}`,
    delete: (id: string) => `${API_VERSION}/admin/users/${id}`,
    projects: (id: string) => `${API_VERSION}/admin/users/${id}/projects`,
  },

  // Project member endpoints
  projectMembers: {
    list: (projectId: string) => `${API_VERSION}/projects/${projectId}/members`,
    add: (projectId: string) => `${API_VERSION}/projects/${projectId}/members`,
    update: (projectId: string, userId: string) =>
      `${API_VERSION}/projects/${projectId}/members/${userId}`,
    remove: (projectId: string, userId: string) =>
      `${API_VERSION}/projects/${projectId}/members/${userId}`,
  },

  // Integration endpoints (admin)
  integrations: {
    list: () => `${API_VERSION}/admin/integrations`,
    create: () => `${API_VERSION}/admin/integrations`,
    analyzeCode: () => `${API_VERSION}/admin/integrations/analyze-code`,
    getDetails: (type: string) => `${API_VERSION}/admin/integrations/${type}`,
    update: (type: string) => `${API_VERSION}/admin/integrations/${type}`,
    getStatus: (type: string) => `${API_VERSION}/admin/integrations/${type}/status`,
    getConfig: (type: string) => `${API_VERSION}/admin/integrations/${type}/config`,
    updateConfig: (type: string) => `${API_VERSION}/admin/integrations/${type}/config`,
    deleteConfig: (type: string) => `${API_VERSION}/admin/integrations/${type}/config`,
    delete: (type: string) => `${API_VERSION}/admin/integrations/${type}`,
    testConnection: (type: string) => `${API_VERSION}/admin/integrations/${type}/test`,
    oauthAuthorize: (type: string) => `${API_VERSION}/admin/integrations/${type}/oauth/authorize`,
    rules: {
      list: (platform: string, projectId: string) =>
        `${API_VERSION}/integrations/${platform}/${projectId}/rules`,
      create: (platform: string, projectId: string) =>
        `${API_VERSION}/integrations/${platform}/${projectId}/rules`,
      update: (platform: string, projectId: string, ruleId: string) =>
        `${API_VERSION}/integrations/${platform}/${projectId}/rules/${ruleId}`,
      delete: (platform: string, projectId: string, ruleId: string) =>
        `${API_VERSION}/integrations/${platform}/${projectId}/rules/${ruleId}`,
    },
  },

  // Project-specific integration configuration
  projectIntegrations: {
    configure: (platform: string, projectId: string) =>
      `${API_VERSION}/integrations/${platform}/${projectId}`,
    get: (platform: string, projectId: string) =>
      `${API_VERSION}/integrations/${platform}/${projectId}`,
    update: (platform: string, projectId: string) =>
      `${API_VERSION}/integrations/${platform}/${projectId}`,
    delete: (platform: string, projectId: string) =>
      `${API_VERSION}/integrations/${platform}/${projectId}`,
    testConnection: (platform: string) => `${API_VERSION}/integrations/${platform}/test`,
  },

  // Notification endpoints
  notifications: {
    channels: {
      list: () => `${API_VERSION}/notifications/channels`,
      create: () => `${API_VERSION}/notifications/channels`,
      get: (id: string) => `${API_VERSION}/notifications/channels/${id}`,
      update: (id: string) => `${API_VERSION}/notifications/channels/${id}`,
      delete: (id: string) => `${API_VERSION}/notifications/channels/${id}`,
      test: (id: string) => `${API_VERSION}/notifications/channels/${id}/test`,
    },
    rules: {
      list: () => `${API_VERSION}/notifications/rules`,
      create: () => `${API_VERSION}/notifications/rules`,
      get: (id: string) => `${API_VERSION}/notifications/rules/${id}`,
      update: (id: string) => `${API_VERSION}/notifications/rules/${id}`,
      delete: (id: string) => `${API_VERSION}/notifications/rules/${id}`,
    },
    history: {
      list: () => `${API_VERSION}/notifications/history`,
      get: (id: string) => `${API_VERSION}/notifications/history/${id}`,
      retry: (id: string) => `${API_VERSION}/notifications/history/${id}/retry`,
    },
  },

  // Analytics endpoints
  analytics: {
    overview: () => `${API_VERSION}/analytics/overview`,
    trends: () => `${API_VERSION}/analytics/trends`,
    dashboard: () => `${API_VERSION}/analytics/dashboard`,
    reportsTrend: () => `${API_VERSION}/analytics/reports/trend`,
    projectsStats: () => `${API_VERSION}/analytics/projects/stats`,
  },

  // Audit log endpoints
  auditLogs: {
    list: () => `${API_VERSION}/audit-logs`,
    get: (id: string) => `${API_VERSION}/audit-logs/${id}`,
    statistics: () => `${API_VERSION}/audit-logs/statistics`,
    recent: () => `${API_VERSION}/audit-logs/recent`,
    byUser: (userId: string) => `${API_VERSION}/audit-logs/user/${userId}`,
  },

  // API key endpoints
  apiKeys: {
    list: () => `${API_VERSION}/api-keys`,
    create: () => `${API_VERSION}/api-keys`,
    get: (id: string) => `${API_VERSION}/api-keys/${id}`,
    update: (id: string) => `${API_VERSION}/api-keys/${id}`,
    delete: (id: string) => `${API_VERSION}/api-keys/${id}`,
    rotate: (id: string) => `${API_VERSION}/api-keys/${id}/rotate`,
    usage: (id: string) => `${API_VERSION}/api-keys/${id}/usage`,
  },

  // Admin endpoints
  admin: {
    health: () => `${API_VERSION}/admin/health`,
    settings: () => `${API_VERSION}/admin/settings`,
  },

  // Health check
  health: () => `${API_VERSION}/health`,
};
