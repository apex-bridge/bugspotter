import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AuthProvider } from './contexts/auth-context';
import { ProtectedRoute } from './components/protected-route';
import { AdminRoute } from './components/admin-route';
import { DefaultRedirect } from './components/default-redirect';
import LoginPage from './pages/login';
import SetupWizard from './pages/setup';
import DashboardLayout from './components/dashboard-layout';
import DashboardPage from './pages/dashboard';
import UsersPage from './pages/users';
import SettingsPage from './pages/settings';
import ProjectsPage from './pages/projects';
import ProjectIntegrationsPage from './pages/project-integrations';
import ProjectIntegrationConfigPage from './pages/project-integration-config';
import ProjectMembersPage from './pages/project-members';
import HealthPage from './pages/health';
import BugReportsPage from './pages/bug-reports';
import AuditLogsPage from './pages/audit-logs';
import NotificationsPage from './pages/notifications';
import IntegrationsOverview from './pages/integrations/overview';
import CreateIntegration from './pages/integrations/create';
import IntegrationConfigPage from './pages/integrations/integration-config';
import IntegrationEditPage from './pages/integrations/edit';
import IntegrationRulesPage from './pages/integrations/rules';
import ApiKeysPage from './pages/api-keys';
import SharedReplayViewer from './pages/shared-replay-viewer';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          {/* Public routes - no authentication required */}
          <Route path="/shared/:token" element={<SharedReplayViewer />} />

          <Route path="/login" element={<LoginPage />} />
          <Route path="/setup" element={<SetupWizard />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            {/* Default route: admin -> dashboard, user -> projects */}
            <Route index element={<DefaultRedirect />} />

            {/* Admin-only routes */}
            <Route
              path="dashboard"
              element={
                <AdminRoute>
                  <DashboardPage />
                </AdminRoute>
              }
            />
            <Route
              path="users"
              element={
                <AdminRoute>
                  <UsersPage />
                </AdminRoute>
              }
            />
            <Route
              path="system-health"
              element={
                <AdminRoute>
                  <HealthPage />
                </AdminRoute>
              }
            />
            <Route
              path="settings"
              element={
                <AdminRoute>
                  <SettingsPage />
                </AdminRoute>
              }
            />
            <Route
              path="audit-logs"
              element={
                <AdminRoute>
                  <AuditLogsPage />
                </AdminRoute>
              }
            />

            <Route
              path="integrations"
              element={
                <AdminRoute>
                  <IntegrationsOverview />
                </AdminRoute>
              }
            />

            <Route
              path="integrations/create"
              element={
                <AdminRoute>
                  <CreateIntegration />
                </AdminRoute>
              }
            />

            <Route
              path="integrations/:type"
              element={
                <AdminRoute>
                  <IntegrationConfigPage />
                </AdminRoute>
              }
            />

            <Route
              path="integrations/:type/edit"
              element={
                <AdminRoute>
                  <IntegrationEditPage />
                </AdminRoute>
              }
            />

            <Route
              path="integrations/:platform/:projectId/rules"
              element={
                <AdminRoute>
                  <IntegrationRulesPage />
                </AdminRoute>
              }
            />

            <Route
              path="api-keys"
              element={
                <AdminRoute>
                  <ApiKeysPage />
                </AdminRoute>
              }
            />

            {/* All users */}
            <Route path="projects" element={<ProjectsPage />} />
            <Route path="projects/:projectId/integrations" element={<ProjectIntegrationsPage />} />
            <Route
              path="projects/:projectId/integrations/:platform/configure"
              element={<ProjectIntegrationConfigPage />}
            />
            <Route path="projects/:projectId/members" element={<ProjectMembersPage />} />
            <Route path="bug-reports" element={<BugReportsPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
          </Route>
        </Routes>
        <Toaster position="top-right" richColors />
      </AuthProvider>
    </Router>
  );
}

export default App;
