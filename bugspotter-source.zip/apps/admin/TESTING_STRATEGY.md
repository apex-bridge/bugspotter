# Testing Strategy for Setup and Authentication

## Overview

BugSpotter admin panel uses two testing approaches:

1. **Unit Tests (Vitest + React Testing Library)** - Component and utility function tests
2. **E2E Tests (Playwright + Testcontainers)** - Full integration tests with real database

## Unit Testing Strategy

### Philosophy

**"The more your tests resemble the way your software is used, the more confidence they can give you."**

We follow React Testing Library's guiding principles:

- ✅ Test **user interactions**, not implementation details
- ✅ Use **semantic queries** (roles, labels) over text content
- ✅ Query by **accessibility attributes** (what screen readers see)
- ❌ Avoid **fragile selectors** (class names, test IDs, exact text)

### Query Priority

**1. Accessible Queries** (Preferred):

```typescript
// ✅ BEST: Query by semantic role
const button = screen.getByRole('button', { name: /submit/i });
const status = screen.getByRole('status', { name: /api key status: active/i });

// ✅ GOOD: Query by label (for form inputs)
const emailInput = screen.getByLabelText('Email Address');

// ✅ OK: Query by text (use sparingly, only for unique content)
const heading = screen.getByRole('heading', { name: /dashboard/i });
```

**2. Anti-Patterns** (Avoid):

```typescript
// ❌ BAD: Fragile text queries
expect(screen.getByText('Active')).toBeInTheDocument();

// ❌ BAD: Exact text matching (breaks on format changes)
expect(screen.getByText('12/31/2025')).toBeInTheDocument();

// ❌ WORSE: Test IDs or class names (use only as last resort)
screen.getByTestId('submit-button');
screen.getByClassName('btn-primary');
```

### Table Data Testing

When testing tables, use **table structure queries**:

```typescript
// ✅ GOOD: Query by table semantics
const row = screen.getByRole('row', { name: /api-key-name/i });
const cells = within(row).getAllByRole('cell');
const expiryCell = cells[5]; // 6th column (0-indexed)
expect(expiryCell).toHaveTextContent(/\d{1,2}\/\d{1,2}\/\d{4}/);

// ✅ ALSO GOOD: Use within() to scope queries
const row = screen.getByRole('row', { name: /api-key-name/i });
expect(within(row).getByText('Project Name')).toBeInTheDocument();

// ❌ BAD: Global text search (ambiguous, breaks on duplicates)
expect(screen.getByText('Project Name')).toBeInTheDocument();
```

### Status Indicators and Badges

Status badges should use **ARIA roles**:

```typescript
// Component implementation
<span
  role="status"
  aria-label={`API key status: ${status}`}
  className="badge"
>
  {statusText}
</span>

// Test query
const badge = screen.getByRole('status', { name: /api key status: active/i });
expect(badge).toHaveTextContent('Active');
expect(badge).toHaveClass('bg-green-100'); // Optional: verify styling
```

### Pattern Matching

Use **regex patterns** for flexible matching:

```typescript
// ✅ GOOD: Flexible pattern matching
expect(expiryCell).toHaveTextContent(/\d{1,2}\/\d{1,2}\/\d{4}/); // Any date format
expect(statusCell).toHaveTextContent(/active|expired|revoked/i); // Multiple values

// ✅ GOOD: Case-insensitive partial matching
screen.getByRole('row', { name: /user-name/i });

// ❌ BAD: Exact text (fragile)
expect(screen.getByText('12/31/2025, 11:59:59 PM')).toBeInTheDocument();
```

### Disambiguating Multiple Elements

When multiple elements have the same label, use **data-testid** attributes:

```typescript
// ❌ BAD: Ambiguous selector (strict mode violation)
const description = page.getByLabel('Description');
// Error: resolved to 2 elements (integration + plugin descriptions)

// ✅ GOOD: Use data-testid for disambiguation
<Textarea id="description" data-testid="integration-description" {...field} />
<Textarea id="pluginDescription" data-testid="plugin-description" {...field} />

// In tests:
await page.getByTestId('integration-description').fill('Integration desc');
await page.getByTestId('plugin-description').fill('Plugin desc');
```

### Handling Multiple Toast Notifications

When using **Sonner** toasts, handle duplicate messages with `.first()`:

```typescript
// ❌ BAD: Fails with strict mode violation on duplicate toasts
await expect(page.locator('text="Success"')).toBeVisible();

// ✅ GOOD: Use .first() to select first matching toast
await expect(page.locator('text="Share link created successfully"').first()).toBeVisible({
  timeout: 5000,
});

// ✅ ALSO GOOD: Use Sonner's data attribute
await expect(page.locator('[data-sonner-toast]').first()).toBeVisible();
```

### Unit Test Examples

See comprehensive examples:

- `src/tests/components/api-key-table.test.tsx` - 16 tests with accessible queries
- `src/tests/components/bug-report-card.test.tsx` - Component testing
- `src/tests/utils/format.test.ts` - Utility function testing

### Running Unit Tests

```bash
# Run all unit tests
pnpm test

# Run specific test file
pnpm test api-key-table

# Watch mode
pnpm test --watch

# Coverage report
pnpm test --coverage
```

---

## E2E Testing Strategy

E2E tests use **Testcontainers** for complete database isolation. Each test run gets a fresh PostgreSQL 16 container with migrations applied.

The setup and authentication flow has two distinct states that need testing:

1. **Uninitialized State** - No admin user exists, system needs setup
2. **Initialized State** - Admin exists, system is ready for login

**Key Benefits:**

- ✅ Complete test isolation - no shared state between runs
- ✅ No conditional skips - tests reliably set up their prerequisites
- ✅ No manual database setup - testcontainers handles everything
- ✅ Ready for parallel execution - each worker can have its own database

## Test Structure

### Test Fixtures (`tests/fixtures/setup-fixture.ts`)

Provides utilities to control system state:

```typescript
import { test, expect } from '../fixtures/setup-fixture';

test('my test', async ({ setupState }) => {
  // Ensure uninitialized
  await setupState.ensureUninitialized();

  // Or ensure initialized
  await setupState.ensureInitialized({
    email: 'admin@test.com',
    password: 'password123',
  });

  // Check current status
  const isInitialized = await setupState.checkStatus();
});
```

### Test Files

1. **`auth-setup.spec.ts`** - Authentication and setup flow tests
   - Tests redirect to setup when uninitialized
   - Tests login flow when initialized
   - Uses `test.skip()` to handle state mismatches

2. **`setup-comprehensive.spec.ts`** - Complete coverage of both states
   - Uses fixtures to control state
   - Tests both uninitialized and initialized scenarios
   - Uses database reset utility for state management

## Testcontainers Setup

**Global Setup**: `src/tests/e2e/global-setup.ts`

1. Starts PostgreSQL 16 container
2. Starts Redis 7 container
3. Runs database migrations
4. Starts backend server on port 4000
5. Saves connection details for tests

**Database Reset**: `src/tests/utils/db-reset.ts`

Utility functions for resetting database state between tests:

```typescript
import { resetDatabase } from '../utils/db-reset';

// Truncate all tables and reset sequences
await resetDatabase();
```

**Benefits:**

- No test endpoints needed in API
- Complete isolation from production code
- Direct database access for reliable resets

## Running Tests

### Prerequisites

- **Docker** must be running (for Testcontainers)
- **pnpm dependencies** installed

**Note**: The backend API is automatically started by global-setup.ts on port 4000. You don't need to start it manually.

### Run All Tests

```bash
# From admin directory
cd apps/admin
pnpm test:e2e
```

### Run Specific Test Files

```bash
# Setup flow tests
pnpm test:e2e setup-comprehensive.spec.ts

# Auth flow tests
pnpm test:e2e auth-setup.spec.ts

# Bug report tests
pnpm test:e2e bug-reports.spec.ts
```

### Debug Tests

```bash
# Run with headed browser
pnpm test:e2e --headed

# Run with Playwright UI
pnpm test:e2e:ui

# Debug specific test
pnpm test:e2e --debug --grep "should complete setup"
```

## Environment Variables for Testing

Setup wizard respects environment variables:

```bash
# Storage configuration
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=minioadmin123456
S3_SECRET_KEY=minioadmin123456789012345678901234
S3_BUCKET=bugspotter-test
S3_REGION=us-east-1

# Instance configuration (optional)
INSTANCE_NAME=Test BugSpotter
INSTANCE_URL=http://localhost:3001

# Admin credentials (optional)
ADMIN_EMAIL=admin@bugspotter.io
ADMIN_PASSWORD=admin123
```

When these are set:

- Setup wizard shows info banner
- Fields are pre-filled
- Tests verify environment integration

## Test Coverage

### Setup Flow (`setup-comprehensive.spec.ts`)

- ✅ Redirect to setup wizard when uninitialized
- ✅ Display environment defaults (full mode)
- ✅ Show info banner (minimal mode)
- ✅ Complete minimal setup (admin only)
- ✅ Complete full setup (all steps)
- ✅ Prevent initialization when already initialized
- ✅ State transitions (uninitialized → initialized)

### Authentication Flow (`auth-setup.spec.ts`)

- ✅ Redirect to setup when uninitialized
- ✅ Show login page when initialized
- ✅ Login with valid credentials
- ✅ Show error with invalid credentials
- ✅ Persist authentication across page reloads
- ✅ Logout and redirect to login
- ✅ Redirect to login when session expires
- ✅ Handle token refresh on page load
- ✅ Protect routes when not authenticated
- ✅ Allow access to public routes

### Feature Tests

- ✅ Bug reports CRUD and filtering (`bug-reports.spec.ts`)
- ✅ API keys management (`api-keys.spec.ts`)
- ✅ Integration management UI (`integrations.spec.ts`)
- ✅ Notification UI elements (`notifications.spec.ts`)
- ✅ Notification delivery (Email, Slack, Discord) (`notification-delivery.spec.ts`)
- ✅ Jira integration (`jira-integration.spec.ts`)
- ✅ Audit logs (`audit-logs.spec.ts`)

## CI/CD Integration

### GitHub Actions Example

```yaml
e2e-tests:
  runs-on: ubuntu-latest

  steps:
    - uses: actions/checkout@v4

    - name: Install pnpm
      uses: pnpm/action-setup@v2
      with:
        version: 10

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'pnpm'

    - name: Install dependencies
      run: pnpm install

    - name: Build packages
      run: pnpm build

    - name: Install Playwright browsers
      run: pnpm --filter @bugspotter/admin exec playwright install chromium

    # Testcontainers automatically uses Docker (available in GitHub Actions)
    - name: Run E2E tests
      run: pnpm --filter @bugspotter/admin test:e2e
      env:
        CI: true

    - name: Upload test results
      if: always()
      uses: actions/upload-artifact@v4
      with:
        name: playwright-report
        path: apps/admin/e2e-debug/html-report/
        retention-days: 30
```

## Best Practices

1. **Use fixtures** for tests that need specific state
2. **Add skip checks** for tests that depend on system state
3. **Clear session state** before each test
4. **Use meaningful timeouts** for network operations
5. **Test both happy and error paths**
6. **Verify environment integration** when applicable

## Troubleshooting

### Tests Fail to Start

**Cause**: Docker not running or testcontainer can't start

**Solution**:

- Ensure Docker is running: `docker ps`
- Check Docker has sufficient resources (2GB+ RAM)
- Try: `docker system prune` to clean up old containers

### "Cannot connect to database" Error

**Cause**: Testcontainer failed to start or migrations failed

**Solution**:

- Check global-setup.ts logs for errors
- Verify migrations run successfully locally: `pnpm migrate`
- Check Docker logs: `docker logs <container-id>`

### Storage Connection Fails

**Cause**: MinIO/S3 not accessible or wrong credentials

**Solution**:

- Check MinIO is running: `docker ps | grep minio`
- Verify credentials in `.env.local`
- Ensure credentials meet length requirements (16+ chars for access key, 32+ for secret)

## Security Notes

⚠️ **IMPORTANT**:

- Tests use isolated databases via Testcontainers
- No test endpoints in production code
- Test containers are ephemeral and destroyed after run
- Credentials in tests are for isolated containers only
- Use strong credentials even in test environments
