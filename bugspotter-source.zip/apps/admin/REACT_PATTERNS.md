# React Anti-Patterns Fixed in Admin Panel

## 1. Setting State During Render ❌ → useEffect ✅

### Anti-Pattern (CRITICAL)

```tsx
// ❌ BAD: setState during render causes infinite loops
const { data } = useQuery({ ... });

if (data && !formData.instance_name) {
  setFormData(data);           // Triggers re-render
  setCorsInput(data.cors_origins?.join(', ') || '');  // Triggers re-render
}
```

**Problems:**

- Causes unpredictable re-renders
- Can create infinite render loops
- Violates React's rendering rules
- Hard to debug

**React Error (in StrictMode):**

```
Warning: Cannot update a component while rendering a different component.
```

### Correct Pattern ✅

```tsx
// ✅ GOOD: Side effects in useEffect
const { data } = useQuery({ ... });

useEffect(() => {
  if (data) {
    setFormData(data);
    setCorsInput(data.cors_origins?.join(', ') || '');
  }
}, [data]); // Only runs when data changes
```

**Benefits:**

- Predictable behavior
- Runs after render (no blocking)
- Proper dependency tracking
- No infinite loops

---

## 2. Incorrect useEffect Conditions ❌ → Proper Logic ✅

### Anti-Pattern (CRITICAL)

```tsx
// ❌ BAD: useEffect immediately cancels state change
const RoleSelector = ({ disabled, currentRole }) => {
  const [isEditing, setIsEditing] = useState(false);

  // BUG: When isEditing becomes true, this immediately sets it back to false!
  useEffect(() => {
    if (!disabled && isEditing) {
      setIsEditing(false); // ← Cancels the state change!
    }
  }, [disabled, isEditing]);

  return (
    <>
      {!isEditing ? (
        <button onClick={() => setIsEditing(true)}>Change Role</button>
      ) : (
        <select>{/* Options */}</select>
      )}
    </>
  );
};
```

**Problems:**

- Button click sets `isEditing = true`
- useEffect runs and sees `!disabled && isEditing`
- Immediately sets `isEditing = false`
- Select dropdown never appears
- User sees button but nothing happens

**Debugging this bug:**

- Button clicks WERE working (Playwright confirmed)
- But UI state never changed
- Browser console logging revealed state was being reset
- Root cause: Inverted useEffect condition

### Correct Pattern ✅

```tsx
// ✅ GOOD: Only reset when component becomes disabled
const RoleSelector = ({ disabled, currentRole }) => {
  const [isEditing, setIsEditing] = useState(false);

  // Only reset editing state when component becomes disabled
  useEffect(() => {
    if (disabled && isEditing) {
      setIsEditing(false);
    }
  }, [disabled, isEditing]);

  return (
    <>
      {!isEditing ? (
        <button onClick={() => setIsEditing(true)}>Change Role</button>
      ) : (
        <select>{/* Options */}</select>
      )}
    </>
  );
};
```

**Benefits:**

- State changes work as expected
- useEffect only cleans up when component is disabled
- Clear intent: "If disabled, cancel editing"
- No unexpected state resets

**Lesson:** When useEffect depends on state it modifies, be extremely careful with conditions. Inverted logic can create immediate reset loops.

---

## 3. Redundant State Management ❌ → Single Source of Truth ✅

### Anti-Pattern

```tsx
// ❌ BAD: Page maintains duplicate state while form also manages its own state
const RulesPage = () => {
  // Dialog state
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingRule, setEditingRule] = useState<IntegrationRule | null>(null);

  // ❌ Redundant form field states (duplicates form's internal state)
  const [name, setName] = useState('');
  const [enabled, setEnabled] = useState(true);
  const [priority, setPriority] = useState(0);
  const [filters, setFilters] = useState<FilterCondition[]>([]);
  const [throttle, setThrottle] = useState<ThrottleConfig | null>(null);
  const [autoCreate, setAutoCreate] = useState(false);
  const [fieldMappings, setFieldMappings] = useState<FieldMappings | null>(null);

  // ❌ handleSubmit with 11 dependencies (high stale state risk)
  const handleSubmit = useCallback(
    (values?) => {
      const submitValues = values || {
        name,
        enabled,
        priority,
        filters,
        throttle,
        autoCreate,
        fieldMappings,
      };
      // ... validation and mutation
    },
    [
      name,
      enabled,
      priority,
      filters,
      throttle,
      autoCreate,
      fieldMappings,
      editingRule,
      createMutation,
      updateMutation,
    ]
  );

  // ❌ Forms must update page state before calling handleSubmit
  return (
    <GenericRuleForm
      onSubmit={(values) => {
        setName(values.name);
        setEnabled(values.enabled);
        setPriority(values.priority);
        setFilters(values.filters);
        setAutoCreate(values.autoCreate);
        setFieldMappings(values.fieldMappings);
        setThrottle(values.throttle);
        handleSubmit(values); // Pass directly to avoid stale state
      }}
    />
  );
};
```

**Problems:**

- Two sources of truth (page state + form state)
- 7 redundant state variables
- 11 callback dependencies (stale state risk)
- Complex data flow: form → update page state → call handler → mutation
- Need workaround to avoid stale state bugs

### Correct Pattern ✅

```tsx
// ✅ GOOD: Single source of truth - form owns its state, page only tracks which rule to edit
const RulesPage = () => {
  // Only dialog state (no form field states)
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingRule, setEditingRule] = useState<IntegrationRule | null>(null);
  const [deletingRuleId, setDeletingRuleId] = useState<string | null>(null);

  // ✅ handleFormSubmit with 3 dependencies (no stale state risk)
  const handleFormSubmit = useCallback(
    (values: {
      name: string;
      enabled: boolean;
      priority: number;
      filters: FilterCondition[];
      throttle: ThrottleConfig | null;
      autoCreate: boolean;
      fieldMappings: FieldMappings | null;
    }) => {
      // Direct validation and mutation from values parameter
      const payload = {
        name: values.name.trim(),
        enabled: values.enabled,
        priority: values.priority,
        filters: values.filters,
        throttle: values.throttle,
        auto_create: values.autoCreate,
        field_mappings: values.fieldMappings,
      };

      if (editingRule) {
        updateMutation.mutate({ ruleId: editingRule.id, payload });
      } else {
        createMutation.mutate(payload);
      }
    },
    [editingRule, createMutation, updateMutation]
  );

  // ✅ Forms directly call handleFormSubmit (no intermediate state updates)
  return (
    <GenericRuleForm
      initialValues={
        editingRule
          ? {
              name: editingRule.name,
              enabled: editingRule.enabled,
              priority: editingRule.priority,
              filters: editingRule.filters,
              autoCreate: editingRule.auto_create || false,
              fieldMappings: editingRule.field_mappings || null,
              throttle: editingRule.throttle,
            }
          : undefined
      }
      onSubmit={(values) =>
        handleFormSubmit({
          ...values,
          fieldMappings: values.fieldMappings,
        })
      }
    />
  );
};
```

**Benefits:**

- Single source of truth: `editingRule` is the only form data source
- Eliminated 7 redundant state variables
- Reduced callback dependencies from 11 to 3
- Simple data flow: form → handleFormSubmit → mutation
- No stale state bugs
- ~70 lines of state update code removed

**Key Principle:** Parent components should track _which_ item to edit, not _duplicate_ the item's fields.

---

## 4. Not Resetting Form After Success ❌ → Reset in onSuccess ✅

### Anti-Pattern

```tsx
// ❌ BAD: Form keeps old values after update
const updateMutation = useMutation({
  mutationFn: adminService.updateSettings,
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['settings'] });
    toast.success('Settings updated successfully');
    // Form still has old values!
  },
});
```

**Problems:**

- Form values out of sync with server
- User sees stale data
- Confusing UX

### Correct Pattern ✅

```tsx
// ✅ GOOD: Reset form to server values
const updateMutation = useMutation({
  mutationFn: adminService.updateSettings,
  onSuccess: (updatedSettings) => {
    queryClient.invalidateQueries({ queryKey: ['settings'] });

    // Sync form with server values
    setFormData(updatedSettings);
    setCorsInput(updatedSettings.cors_origins?.join(', ') || '');

    toast.success('Settings updated successfully');
  },
});
```

**Benefits:**

- Form always shows current server state
- No stale data
- Clear user feedback

---

## 5. Component Prop Pattern ❌ → Render Prop Pattern ✅

### Anti-Pattern

```tsx
// ❌ BAD: Component prop requires type casting for platform-specific props
interface GenericFormProps {
  platform: string;
  projectId?: string; // Generic interface forces optional
  fieldMappingsComponent?: React.ComponentType<{
    projectId?: string;
    platform?: string;
    mappings: FieldMappings | null;
    onChange: (mappings: FieldMappings | null) => void;
  }>;
}

// Usage requires type hack
<GenericRuleForm
  platform="jira"
  projectId={projectId}
  fieldMappingsComponent={
    platform === 'jira'
      ? (JiraFieldMappingsForm as React.ComponentType<any>) // ❌ Loses type safety!
      : undefined
  }
/>;

// Why type cast needed:
// JiraFieldMappingsForm expects: projectId: string (required)
// Generic interface has: projectId?: string (optional)
// TypeScript error without cast
```

**Problems:**

- Requires type casting (`as React.ComponentType<any>`)
- Loses type safety for platform-specific props
- Generic interface must make all props optional
- Not scalable for platforms with different prop requirements
- Obscures what props are actually being passed

### Correct Pattern ✅

```tsx
// ✅ GOOD: Render prop pattern - platform code handles its own props
interface GenericFormProps {
  platform: string;
  renderFieldMappings?: (props: {
    mappings: FieldMappings | null;
    onChange: (mappings: FieldMappings | null) => void;
  }) => React.ReactNode;
}

// Usage - no type casting needed
<GenericRuleForm
  platform="jira"
  renderFieldMappings={
    platform === 'jira'
      ? ({ mappings, onChange }) => (
          <JiraFieldMappingsForm
            projectId={projectId!} // Platform code asserts requirement
            mappings={mappings as JiraFieldMappings | null}
            onChange={onChange as (mappings: JiraFieldMappings | null) => void}
          />
        )
      : undefined
  }
/>;
```

**Benefits:**

- No generic component type casting
- Platform-specific code handles its own prop requirements
- Type-safe at each platform level
- Clear what props are being passed (visible in render function)
- Easy to add new platforms with different requirements

**Scalability Example:**

```tsx
// Easy to add multiple platforms with different prop requirements
renderFieldMappings={
  platform === 'jira'
    ? ({ mappings, onChange }) => (
        <JiraFieldMappingsForm
          projectId={projectId!}
          mappings={mappings as JiraFieldMappings | null}
          onChange={onChange as (mappings: JiraFieldMappings | null) => void}
        />
      )
    : platform === 'slack'
    ? ({ mappings, onChange }) => (
        <SlackFieldMappingsForm
          workspaceId={workspaceId!} // Different required prop!
          mappings={mappings as SlackFieldMappings | null}
          onChange={onChange as (mappings: SlackFieldMappings | null) => void}
        />
      )
    : platform === 'github'
    ? ({ mappings, onChange }) => (
        <GitHubFieldMappingsForm
          repoId={repoId!} // Another different required prop!
          mappings={mappings as GitHubFieldMappings | null}
          onChange={onChange as (mappings: GitHubFieldMappings | null) => void}
        />
      )
    : undefined
}
```

**Key Principle:** Use render props when child components have platform-specific prop requirements that don't fit a generic interface.

---

## 6. Other Common React Anti-Patterns (To Avoid)

### ❌ Mutating State Directly

```tsx
// BAD
const items = [...state.items];
items[0] = newValue;
setState({ items }); // Reference changed but items mutated

// GOOD
setState({
  items: state.items.map((item, i) => (i === 0 ? newValue : item)),
});
```

### ❌ Using Index as Key in Dynamic Lists

```tsx
// BAD
{
  items.map((item, index) => <div key={index}>{item}</div>);
}

// GOOD
{
  items.map((item) => <div key={item.id}>{item}</div>);
}
```

### ❌ Not Memoizing Expensive Computations

```tsx
// BAD
const expensiveValue = heavyComputation(data); // Runs every render

// GOOD
const expensiveValue = useMemo(() => heavyComputation(data), [data]);
```

### ❌ Creating Functions in JSX

```tsx
// BAD (creates new function every render)
<Button onClick={() => handleClick(id)}>Click</Button>;

// GOOD
const handleButtonClick = useCallback(() => handleClick(id), [id]);
<Button onClick={handleButtonClick}>Click</Button>;
```

### ❌ Prop Drilling

```tsx
// BAD
<Parent>
  <Child data={data}>
    <GrandChild data={data}>
      <GreatGrandChild data={data} />
    </GrandChild>
  </Child>
</Parent>;

// GOOD - Use Context
const DataContext = createContext();
<DataProvider value={data}>
  <Parent>
    <Child>
      <GrandChild>
        <GreatGrandChild /> {/* Uses useContext(DataContext) */}
      </GrandChild>
    </Child>
  </Parent>
</DataProvider>;
```

---

## React Best Practices Summary

### Do ✅

1. **Use useEffect for side effects**
   - Data fetching
   - Subscriptions
   - Timers
   - DOM manipulation

2. **Keep render functions pure**
   - No side effects
   - No setState calls
   - Deterministic output

3. **Provide dependency arrays**
   - useEffect, useMemo, useCallback
   - List all dependencies
   - Use ESLint rules

4. **Use proper keys**
   - Stable identifiers (IDs)
   - Not array indices
   - Unique per list

5. **Memoize expensive operations**
   - useMemo for computations
   - useCallback for functions
   - React.memo for components

6. **Use TypeScript**
   - Catch errors at compile time
   - Better IDE support
   - Self-documenting code

### Don't ❌

1. **Never setState during render**
2. **Don't mutate state directly**
3. **Don't use index as key**
4. **Don't create functions in JSX**
5. **Don't ignore dependency warnings**
6. **Don't prop drill excessively**

---

## Testing Anti-Patterns

### ❌ Common Mistake: Querying by Text Content

```tsx
// ❌ BAD: Fragile, not accessible
expect(screen.getByText('Active')).toBeInTheDocument();
expect(screen.getByText('Project Name')).toBeInTheDocument();
```

**Problems**: Breaks on text changes, not accessible, ambiguous when text appears multiple times.

### ✅ Correct: Semantic Queries

```tsx
// ✅ GOOD: Query by role and accessible name
const badge = screen.getByRole('status', { name: /api key status: active/i });
expect(badge).toHaveTextContent('Active');

// ✅ GOOD: Table structure queries
const row = screen.getByRole('row', { name: /api-key-name/i });
const cells = within(row).getAllByRole('cell');
expect(cells[3]).toHaveTextContent('Project Name');
```

**Benefits**: Resilient to changes, tests accessibility, self-documenting.

**📖 Full Testing Guide**: See `TESTING_STRATEGY.md` for:

- Complete query priority hierarchy
- Table testing patterns with `within()` helper
- Status indicators and ARIA roles
- Pattern matching for dynamic content
- Real-world examples from `api-key-table.test.tsx`

---

### Before Fix (With Anti-Pattern)

```bash
# Console shows:
Warning: Cannot update a component while rendering...
# Or infinite render loops
```

### After Fix

```bash
# Clean console, no warnings
# Predictable behavior
```

---

## Resources

- [React Docs: Rules of Hooks](https://react.dev/reference/rules)
- [React Docs: You Might Not Need an Effect](https://react.dev/learn/you-might-not-need-an-effect)
- [React Testing Library: Guiding Principles](https://testing-library.com/docs/guiding-principles/)
- [Kent C. Dodds: Common Mistakes with React Testing Library](https://kentcdodds.com/blog/common-mistakes-with-react-testing-library)
- [React TypeScript Cheatsheet](https://react-typescript-cheatsheet.netlify.app/)
