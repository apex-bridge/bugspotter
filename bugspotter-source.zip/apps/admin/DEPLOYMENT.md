# Admin Panel Deployment Guide

## Overview

Deploy the BugSpotter admin panel to `demo.admin.bugspotter.io` using Docker.

## Prerequisites

- Docker & Docker Compose installed
- Domain configured: `demo.admin.bugspotter.io`
- API running at: `demo.api.bugspotter.io`
- SSL certificates (via Let's Encrypt or your provider)

## Deployment Steps

### 1. Configure Environment Variables

Create `.env` file in project root:

```bash
# API Configuration (for cross-origin deployments)
# Build-time: API URL baked into JavaScript
VITE_API_URL=https://demo.api.bugspotter.io

# Runtime: API domain for Content Security Policy (CSP)
API_DOMAIN=https://demo.api.bugspotter.io

# Content Security Policy (CSP) Domain Configuration (Optional)
# Customize which external domains are allowed in CSP headers
# Defaults work for standard BugSpotter deployment structure

# CDN for static assets (screenshots, logos)
CDN_DOMAIN=https://cdn.bugspotter.io  # Default

# Storage backend (R2/S3) for uploaded replay files
STORAGE_DOMAIN=https://*.r2.cloudflarestorage.com  # Default for Cloudflare R2

# Application domains for cross-origin resources (fonts, images, favicons)
APP_DOMAIN=https://*.demo.bugspotter.io  # Default for demo deployment

# For same-domain deployment with nginx proxy:
# Leave both empty - nginx will proxy /api/* requests
# VITE_API_URL=
# API_DOMAIN=

# Admin Panel
ADMIN_PORT=3001

# Backend CORS (must include admin domain for cross-origin)
# Supports wildcard patterns: subdomains (https://*.example.com), ports (http://localhost:*)
# Examples:
#   - Exact match: https://demo.admin.bugspotter.io
#   - Subdomain wildcard: https://*.demo.bugspotter.io (matches app.demo.*, test.demo.*, etc.)
#   - Port wildcard: http://localhost:* (matches localhost:3000, localhost:8080, etc.)
#   - IPv6: http://[::1]:* (matches any port on IPv6 localhost)
CORS_ORIGINS=https://demo.admin.bugspotter.io,http://localhost:3000,http://localhost:5173

# Frontend URL (for share token links - required in production)
# Used by backend to generate public replay share URLs
# Must match the admin panel's public domain where users access shared replays
# Development: http://localhost:3000 (default fallback)
# Production: https://demo.admin.bugspotter.io (same as admin domain)
FRONTEND_URL=https://demo.admin.bugspotter.io

# Share Token Configuration (optional - has sensible defaults)
SHARE_TOKEN_DEFAULT_EXPIRATION_HOURS=24    # Default: 24 hours (1-720 max)
PRESIGNED_URL_EXPIRATION_SECONDS=3600      # S3/storage URL validity: 1 hour

# Other required variables for full stack
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
ENCRYPTION_KEY=your-encryption-key
# ... (see .env.example)
```

### 2. Build the Admin Panel

```bash
# Build using Docker Compose
docker-compose build admin

# Or build standalone
docker build -f apps/admin/Dockerfile -t bugspotter-admin:latest .
```

### 3. Deploy with Docker Compose

```bash
# Start admin panel (with all services)
docker-compose up -d

# Or start only admin + dependencies
docker-compose up -d postgres redis minio api admin
```

The admin panel will be available at `http://localhost:3001`

### 4. Configure Reverse Proxy (nginx)

On your server, configure nginx to proxy `demo.admin.bugspotter.io` to the container:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name demo.admin.bugspotter.io;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name demo.admin.bugspotter.io;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/demo.admin.bugspotter.io/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/demo.admin.bugspotter.io/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Proxy to Docker container
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support (if needed for future features)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
```

### 5. Configure API CORS

Update API environment to allow admin panel origin:

```bash
# In API .env
CORS_ORIGINS=https://demo.admin.bugspotter.io,http://localhost:5173
```

Restart API:

```bash
docker-compose restart api
```

### 6. Verify Deployment

1. **Check containers are running:**

   ```bash
   docker-compose ps
   ```

2. **Check admin panel health:**

   ```bash
   curl -I http://localhost:3001
   # Should return 200 OK
   ```

3. **Check logs:**

   ```bash
   docker-compose logs -f admin
   ```

4. **Access admin panel:**
   - Open: https://demo.admin.bugspotter.io
   - Login with user credentials

## Troubleshooting

### Admin panel shows blank page

- Check browser console for errors
- Verify `VITE_API_URL` is set correctly (see deployment modes below)
- Check API CORS settings

### API URL shows double domain (e.g., `demo.admin.bugspotter.io/demo.admin.bugspotter.io/api/...`)

**Root cause**: `VITE_API_URL` is set to the admin domain instead of the API domain or left empty for nginx proxy.

**Solution for separate API domain**:

```bash
# In .env file - set to API domain, not admin domain:
VITE_API_URL=https://demo.api.bugspotter.io  # ✓ Correct
# NOT: VITE_API_URL=https://demo.admin.bugspotter.io  # ✗ Wrong!
```

**Solution for same-domain with nginx proxy**:

```bash
# In .env file - leave empty (nginx will proxy /api/* to backend):
VITE_API_URL=  # Empty or unset
```

**Why this happens**: Vite bakes `VITE_API_URL` into the JavaScript bundle at **build time**. If set to the wrong domain, axios will concatenate it with endpoint paths incorrectly.

**Rebuild after fixing**:

```bash
docker-compose build --no-cache admin
docker-compose up -d admin
```

### Cannot connect to API

- Verify API is running: `curl https://demo.api.bugspotter.io/health`
- Check CORS_ORIGINS includes admin URL
- Verify SSL certificates are valid
- Check `VITE_API_URL` matches your deployment mode (see above)

### 502 Bad Gateway

- Check container is running: `docker ps | grep admin`
- Check nginx logs: `docker logs bugspotter-admin`
- Verify port 3001 is accessible

## Deployment Modes

### Mode 1: Same-Domain with Nginx Proxy (Recommended for Docker Compose)

**Setup**: Admin panel nginx proxies `/api/*` requests to backend container.

**Configuration**:

```bash
# .env file
VITE_API_URL=  # Empty or unset

# Admin nginx.conf includes:
# location /api/ {
#     proxy_pass http://api:3000;
# }
```

**Benefits**:

- No CORS issues (same origin)
- Simpler SSL certificate management (one domain)
- Admin and API both at: `demo.bugspotter.io`

### Mode 2: Separate Domains (Cross-Origin)

**Setup**: Admin at `demo.admin.bugspotter.io`, API at `demo.api.bugspotter.io`.

**Configuration**:

```bash
# .env file - Both build and runtime config required
VITE_API_URL=https://demo.api.bugspotter.io  # Build-time: baked into JS
API_DOMAIN=https://demo.api.bugspotter.io     # Runtime: CSP policy

# Backend .env file
CORS_ORIGINS=https://demo.admin.bugspotter.io
FRONTEND_URL=https://demo.admin.bugspotter.io  # For share token URLs
```

**Benefits**:

- Independent scaling of admin and API
- Separate SSL certificates
- Can host on different servers
- Dynamic CSP based on environment variables

**Important**:

- Must configure CORS on backend to allow admin domain
- Both `VITE_API_URL` and `API_DOMAIN` must match your API domain
- Nginx CSP is dynamically configured at container startup

## Production Considerations

### 1. SSL/TLS

- Use Let's Encrypt for free SSL certificates
- Configure auto-renewal with certbot

### 2. Monitoring

- Set up uptime monitoring (UptimeRobot, etc.)
- Monitor container health
- Set up log aggregation

### 3. Backups

Not needed for admin panel (stateless), but ensure:

- Database backups are configured
- Environment variables are backed up

### 4. Security

- Keep Docker images updated
- Use strong JWT secrets
- Implement rate limiting on API
- Regular security audits

## Alternative Deployment: Standalone Static Hosting

If you prefer not to use Docker:

```bash
# Build static files
cd apps/admin
pnpm build

# Deploy dist/ folder to:
# - Vercel (easiest)
# - Netlify
# - AWS S3 + CloudFront
# - Any static file host

# Configure environment variable on hosting platform:
VITE_API_URL=https://demo.api.bugspotter.io
```

## CI/CD (Optional)

Automate deployment with GitHub Actions:

```yaml
name: Deploy Admin Panel

on:
  push:
    branches: [main]
    paths:
      - 'apps/admin/**'

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Build and deploy
        run: |
          docker build -f apps/admin/Dockerfile -t bugspotter-admin:latest .
          # Push to registry or deploy directly
```

## Support

For issues or questions:

- GitHub Issues: https://github.com/apexbridge-tech/bugspotter/issues
- Documentation: See project README
