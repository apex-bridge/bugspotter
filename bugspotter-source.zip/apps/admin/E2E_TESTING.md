# E2E Testing Guide

## Overview

E2E tests use **Testcontainers** for complete database isolation. Each test run gets a fresh PostgreSQL 16 container.

## Quick Start

### Prerequisites

- **Docker running** (`docker ps` should work)
- **No port conflicts**:
  - Port 4001 for admin panel (Vite dev server)
  - Port 4000 for E2E backend
- Development backend on port 3000 can remain running (no conflicts)

**Note**: The E2E backend starts automatically on port 4000 with CORS configured for `http://localhost:4001` - no manual setup required!

### How It Works

E2E tests use Playwright's global setup to automatically:

1. **Start PostgreSQL testcontainer** (isolated database on random port)
2. **Start Redis testcontainer** (isolated cache on random port)
3. **Run database migrations** on the PostgreSQL container
4. **Start backend server** on port 4000 with:
   - Connection to testcontainers
   - CORS enabled for `http://localhost:4001` (admin panel)
   - Test JWT secrets and encryption keys
5. **Wait for health check** (`/api/v1/health` responds OK)
6. **Run your tests** against the isolated environment
7. **Clean up** - kill backend process, stop both containers

No manual backend setup required! Just run the tests.

### Run Tests

**One Command - That's It!**

```bash
cd apps/admin
pnpm test:e2e:ui  # Interactive UI mode - RECOMMENDED for development
# OR
pnpm test:e2e     # Headless mode (CI/CD)
```

**What happens:**

1. Global setup starts testcontainer + backend on port 4000
2. Tests run with isolated database
3. Global teardown cleans up everything

**Why use `--ui` mode?**

- Interactive test selection
- See tests run in real browser
- Better debugging with screenshots
- Pause/resume tests

**Why port 4000?**

- No conflicts with your development backend (port 3000)
- Both can run simultaneously
- Clear separation between dev and test environments
- CORS automatically configured for E2E admin panel (port 4001)

**Run specific test files:**

```bash
cd apps/admin

# Run a single test file
pnpm test:e2e api-keys.spec.ts

# Run with grep to filter tests
pnpm test:e2e api-keys.spec.ts --grep "should create"

# Run in headed mode to see the browser
pnpm test:e2e api-keys.spec.ts --headed
```

## Architecture

### Database Isolation

**Global Setup** (`src/tests/e2e/global-setup.ts`):

1. Starts PostgreSQL 16 container via Testcontainers
2. Runs database migrations
3. Saves connection details to `.test-env`

**Global Teardown** (`src/tests/e2e/global-teardown.ts`):

- Stops PostgreSQL container
- Cleans up temporary files

**Database Reset** (`src/tests/utils/db-reset.ts`):

```typescript
import { resetDatabase } from '../utils/db-reset';

// Truncate all tables and reset sequences
await resetDatabase();
```

### Test Fixtures

**Setup Fixture** (`src/tests/fixtures/setup-fixture.ts`):

```typescript
import { test, expect } from '../fixtures/setup-fixture';

test('my test', async ({ setupState, request }) => {
  // Start with clean database
  await setupState.ensureUninitialized();

  // Or with initialized system (admin user + config)
  await setupState.ensureInitialized({
    email: 'admin@test.com',
    password: 'password123',
    name: 'Test Admin',
  });

  // Ensure a project exists (needed for API keys, bug reports, etc.)
  const authToken = 'your-jwt-token'; // Get from login
  await setupState.ensureProjectExists(authToken);
});
```

**Note**: `ensureProjectExists` is useful for tests that need a project (API keys, bug reports). It creates a test project only if none exists.

## Test Organization

### By System State

**Uninitialized Tests** (`setup-comprehensive.spec.ts`):

- Setup wizard flow
- First-time configuration
- Environment defaults

**Initialized Tests** (`auth-setup.spec.ts`):

- Login/logout
- Authentication persistence
- Protected routes
- Token refresh

**Feature Tests** (`bug-reports.spec.ts`, `notifications.spec.ts`):

- CRUD operations
- Filtering and pagination
- Integration features

**Replay Direct Storage Tests** (`replay-direct-storage.spec.ts`):

- Session replay fetching from storage
- Browser-side decompression
- rrweb-player rendering with Meta event injection
- Screenshot download functionality

### No Conditional Skips

❌ **Old approach**:

```typescript
if (!isInitialized) {
  test.skip(true, 'System not initialized');
}
```

✅ **New approach**:

```typescript
test.beforeEach(async ({ setupState }) => {
  await setupState.ensureInitialized(); // Reliable setup
});
```

## CI/CD Integration

### GitHub Actions Example

```yaml
e2e-tests:
  runs-on: ubuntu-latest

  steps:
    - uses: actions/checkout@v4

    - name: Install pnpm
      uses: pnpm/action-setup@v2
      with:
        version: 10

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'pnpm'

    - name: Install dependencies
      run: pnpm install

    - name: Build packages
      run: pnpm build

    - name: Install Playwright browsers
      run: pnpm --filter @bugspotter/admin exec playwright install chromium

    - name: Run E2E tests
      run: pnpm --filter @bugspotter/admin test:e2e
      env:
        CI: true

    - name: Upload test results
      if: always()
      uses: actions/upload-artifact@v4
      with:
        name: playwright-report
        path: apps/admin/e2e-debug/html-report/
        retention-days: 30
```

**Key Points:**

- Docker is available in GitHub Actions runners by default
- Testcontainers automatically uses Docker
- No manual database setup needed
- Tests run with full isolation

## Configuration

### Playwright Config (`playwright.config.ts`)

```typescript
export default defineConfig({
  globalSetup: './src/tests/e2e/global-setup.ts',
  globalTeardown: './src/tests/e2e/global-teardown.ts',
  timeout: 90000, // Testcontainer startup can take time
  workers: 1, // Sequential execution (shared backend on port 4000)
  retries: process.env.CI ? 2 : 0,

  use: {
    baseURL: 'http://localhost:4001', // Admin panel dev server
  },

  // Vite dev server for admin panel
  webServer: {
    command: `VITE_API_URL=http://localhost:4000 pnpm dev`,
    url: 'http://localhost:4001',
    reuseExistingServer: !process.env.CI,
    timeout: 120000,
  },
});
```

**Key settings:**

- **baseURL**: Admin panel runs on port 4001 (Vite dev server)
- **VITE_API_URL**: Points frontend to E2E backend on port 4000
- **workers: 1**: All tests share the same backend instance
- **reuseExistingServer**: Reuses Vite server in dev, fresh in CI

### Environment Variables

**Automatically set by global setup:**

- `DATABASE_URL` - PostgreSQL testcontainer connection
- `REDIS_URL` - Redis testcontainer connection
- `JWT_SECRET` - Test JWT secret (32+ chars)
- `ENCRYPTION_KEY` - Test encryption key (32+ chars)
- `CORS_ORIGINS` - Includes `http://localhost:4001` for admin panel
- `API_URL` - `http://localhost:4000` for tests

**Load from files (priority order):**

1. `apps/admin/.env.e2e` (E2E-specific config)
2. `packages/backend/.env.integration` (Jira credentials)
3. `.env` (root fallback)

**For Jira E2E tests**, set in `packages/backend/.env.integration`:

```bash
JIRA_E2E_BASE_URL=https://your-site.atlassian.net
JIRA_E2E_EMAIL=your-email@example.com
JIRA_E2E_API_TOKEN=your-api-token
JIRA_E2E_PROJECT_KEY=E2E
```

## Corepack Version Requirement

### Issue (Fixed in November 2025)

Node.js 20.18.2 ships with Corepack 0.29.4, which has a signature verification bug preventing pnpm 10.17.1+ from running:

```
Error: Cannot find matching keyid: {"signatures":[...]}
```

### Solution

Update Corepack to 0.34.3 or later:

```bash
# Update Corepack globally
corepack prepare pnpm@9.14.4 --activate

# Verify version
corepack --version  # Should show 0.34.3+
```

**Why this works:**

- Corepack 0.34.3 fixes the signature verification bug
- No code changes needed
- Works with standard `pnpm` commands
- E2E tests use `npx tsx` for migrations (more reliable in test environments)

**Benefits:**

- ✅ Standard pnpm workflows work correctly
- ✅ No signature verification errors
- ✅ Works on Windows, macOS, and Linux
- ✅ Integration tests run migrations via `pnpm migrate`
- ✅ One-time fix (survives pnpm version updates)

## Debugging

### Test Status (December 2025)

**✅ All 232 E2E tests passing (100%)**

- 2 tests skipped (intentional - test isolation features)
- Full isolation with PostgreSQL testcontainers
- Automated backend startup on port 4000
- No manual setup required

**Recent Fixes:**

1. **Description Field Disambiguation** - Added `data-testid` attributes to distinguish integration vs plugin description fields
2. **Toast Notification Handling** - Used `.first()` selector for duplicate Sonner toasts
3. **Obsolete Test Removal** - Cleaned up tests for removed "Custom Code (Filesystem)" plugin source

## Common Issues

**"Docker not running"**

```bash
# Check Docker status
docker ps

# Start Docker Desktop/daemon
sudo systemctl start docker  # Linux
```

**"CORS policy: No 'Access-Control-Allow-Origin'"**

The global setup automatically adds `http://localhost:4001` to `CORS_ORIGINS`. If you see CORS errors:

- Check that admin panel is running on port 4001
- Verify backend started successfully on port 4000
- Check backend logs for CORS configuration

**"Cannot connect to database"**

```bash
# Check testcontainer logs in global setup output
# Shows: Database: postgres://postgres:***@localhost:XXXXX

# Verify migrations work locally
cd packages/backend
pnpm migrate
```

**"Port 4000 or 4001 already in use"**

```bash
# Kill process on port 4000 (backend)
lsof -ti:4000 | xargs kill -9

# Kill process on port 4001 (admin)
lsof -ti:4001 | xargs kill -9
```

**"Tests timeout waiting for health check"**

```bash
# Check if backend started successfully
curl http://localhost:4000/api/v1/health

# Increase timeout in playwright.config.ts
timeout: 120000, // 2 minutes
```

### Debug Mode

```bash
# Headed browser (see what happens)
pnpm test:e2e --headed

# Debug with Inspector
pnpm test:e2e --debug

# Specific test
pnpm test:e2e --grep "should login"

# View HTML report
pnpm exec playwright show-report
```

### Screenshots & Traces

Located in `e2e-debug/`:

- `test-results/` - Screenshots on failure
- `html-report/` - Full test report with traces

## Benefits

✅ **Complete Isolation** - Fresh database per run  
✅ **No Shared State** - Tests can run in any order  
✅ **No Manual Setup** - Testcontainers handles everything  
✅ **No Conditional Skips** - Tests reliably control prerequisites  
✅ **CI/CD Ready** - Works in GitHub Actions out of the box  
✅ **Parallel Ready** - Can enable parallel execution when needed

## Performance

**First run** (~60-90s):

- Download PostgreSQL 16 image
- Start container
- Run migrations

**Subsequent runs** (~30-45s):

- Reuse cached image
- Start container
- Run migrations

**Per test** (~1-3s):

- Database truncation via `resetDatabase()`

## Test Architecture Best Practices

### 1. Unique Test Data Instead of Cleanup

❌ **Anti-Pattern: Shared data with cleanup**

```typescript
let testUser1: User;
let testUser2: User;

test.beforeEach(async () => {
  testUser1 = await createUser({ email: 'user1@test.com' });
  testUser2 = await createUser({ email: 'user2@test.com' });
});

test.afterEach(async () => {
  await deleteUser(testUser1.id);
  await deleteUser(testUser2.id);
});
```

**Problems:**

- Cleanup can fail, leaving orphaned data
- Tests can't run in parallel (shared resources)
- Flaky tests if cleanup doesn't complete
- Complex state management

✅ **Best Practice: Unique data per test**

```typescript
test('should add member to project', async ({ page }) => {
  // Create unique user for THIS test only
  const uniqueEmail = `add-member-${Date.now()}@bugspotter.io`;
  const newUser = await createUser({
    email: uniqueEmail,
    name: 'Add Member Test User',
  });

  // Test logic...
  // No cleanup needed - each test has unique data
});
```

**Benefits:**

- ✅ No cleanup needed (unique data doesn't conflict)
- ✅ Tests are fully independent
- ✅ Can run in parallel
- ✅ No orphaned data issues
- ✅ Easier to debug (clear test ownership)

### 2. Avoiding Playwright Strict Mode Violations

❌ **Anti-Pattern: Text-based selectors**

```typescript
// BAD: Can match multiple elements
const ownerBadge = page.locator('span:has-text("Owner")');
await expect(ownerBadge).toBeVisible();

// Error: strict mode violation: resolved to 2 elements:
// 1) <span class="bg-purple-100">Owner</span> (badge)
// 2) <span>Project Owner</span> (description text)
```

✅ **Best Practice: CSS class or role-based selectors**

```typescript
// GOOD: Use CSS class selector
const ownerBadge = page.locator('span.bg-purple-100').first();
await expect(ownerBadge).toBeVisible();

// GOOD: Use role-based selector with exact match
const cancelButton = dialog.getByRole('button', { name: 'Cancel', exact: true });
await cancelButton.click();
```

**Common fixes:**

- `span:has-text("Owner")` → `span.bg-purple-100`
- `getByLabel(/user/i)` → `getByLabel('User', { exact: true })`
- `getByRole('button', { name: /cancel/i })` → scoped to specific container

### 3. Date Input Handling

```typescript
// ✅ GOOD: Fill and blur to trigger onChange
await page.getByLabel('Start Date').fill('2099-01-01');
await page.getByLabel('Start Date').blur(); // Trigger change event

// ✅ GOOD: Clear before filling
await page.getByLabel('End Date').clear();
await page.getByLabel('End Date').fill('2099-12-31');
await page.getByLabel('End Date').blur();
```

### 4. Debugging with Browser Console

When UI interactions aren't working as expected:

```typescript
// Add console listeners to tests
page.on('console', (msg) => console.log('BROWSER:', msg.text()));

// Add debug logging in test
console.log('About to click button...');
await button.click();
console.log('Clicked button, checking state...');

// Check DOM state after interactions
const rowContent = await row.textContent();
console.log('Row content:', rowContent);
```

**This technique helped us discover:** A React useEffect bug where button clicks were working but state wasn't updating!

### 5. Toast Notifications (Sonner)

The admin panel uses **Sonner** (v1.4.41) for toast notifications. Always use the correct selector:

```typescript
// ✅ GOOD: Use Sonner's data attribute
await expect(page.locator('[data-sonner-toast]').first()).toBeVisible({
  timeout: 5000,
});

// ✅ GOOD: With text matching
const errorToast = page.locator('[data-sonner-toast]', { hasText: /error|failed/i });
await expect(errorToast.first()).toBeVisible();

// ❌ BAD: Don't use role="alert" (not guaranteed by Sonner)
await expect(page.locator('[role="alert"]')).toBeVisible();
```

**Why this matters:**

- Sonner doesn't guarantee `role="alert"` on all toast types
- `[data-sonner-toast]` is the stable, documented selector
- More resilient to library updates

### 6. Extract Constants for Maintainability

When tests use repeated values, extract them as constants:

```typescript
// ✅ GOOD: Constants at top of file
const TIMEOUTS = {
  LOGIN_INPUT: 10000,
  DASHBOARD_NAVIGATION: 30000,
  TOAST: 5000,
  PAGE_TRANSITION: 10000,
  NETWORK_IDLE: 10000,
} as const;

const PLUGIN_SOURCE = {
  GENERIC_HTTP: 'generic_http',
  FILESYSTEM: 'filesystem',
} as const;

// Use in tests
await expect(page.locator('[data-sonner-toast]').first()).toBeVisible({
  timeout: TIMEOUTS.TOAST,
});
await page.getByLabel('Plugin Source').selectOption(PLUGIN_SOURCE.GENERIC_HTTP);

// ❌ BAD: Magic numbers and strings scattered throughout
await expect(toast).toBeVisible({ timeout: 5000 });
await page.getByLabel('Plugin Source').selectOption('generic_http');
```

**Benefits:**

- Single source of truth for values
- Easy to update across all tests
- Self-documenting code
- Type safety with `as const`

### 7. Extract Helper Functions for Common Actions

When test code repeats, extract helper functions:

```typescript
// ✅ GOOD: Helper function for repeated form filling
async function fillBasicInfo(
  page: Page,
  type: string,
  displayName: string,
  description?: string
): Promise<void> {
  await page.getByLabel('Integration Type *').fill(type);
  await page.getByLabel('Display Name *').fill(displayName);
  if (description) {
    await page.getByLabel('Description').fill(description);
  }
}

// Use in tests
await fillBasicInfo(page, 'jira', 'Production Jira', 'Main Jira instance');

// ❌ BAD: Duplicate code in every test
await page.getByLabel('Integration Type *').fill('jira');
await page.getByLabel('Display Name *').fill('Production Jira');
await page.getByLabel('Description').fill('Main Jira instance');
```

**Benefits:**

- DRY (Don't Repeat Yourself) principle
- Easier to update when UI changes
- More readable tests

## Best Practices

1. **Use setupState fixture** for reliable state control
2. **Create unique test data** with timestamps - avoid cleanup
3. **Use CSS class or role-based selectors** - avoid text matching
4. **Use `[data-sonner-toast]` for Sonner toasts** - not `role="alert"`
5. **Extract timeout constants** - avoid magic numbers
6. **Extract repeated values as constants** - plugin sources, auth types, etc.
7. **Create helper functions** for repeated actions - form filling, navigation, etc.
8. **Avoid waitForTimeout** - Use `waitFor()` or `waitForLoadState()`
9. **Clear cookies/storage** in beforeEach hooks
10. **Test one thing at a time** - Keep tests focused
11. **Use accessibility selectors** - `getByRole()`, `getByLabel()`
12. **Add meaningful assertions** - Verify expected behavior
13. **Debug with browser console** - Add console listeners to tests

## Migration from Old Approach

### Before (Conditional Skips)

```typescript
test('my test', async ({ request }) => {
  const isInitialized = await checkSystemInitialized(request);
  if (!isInitialized) {
    test.skip(true, 'System not initialized');
  }
  // Test logic...
});
```

### After (Testcontainers)

```typescript
test.describe('My Tests', () => {
  test.beforeEach(async ({ setupState }) => {
    await setupState.ensureInitialized();
  });

  test('my test', async ({ page }) => {
    // Test logic - guaranteed initialized state
  });
});
```

**Benefits:**

- No conditional skips
- Explicit state requirements
- Tests always run (no skipped tests)
- Better error messages when setup fails

---

## Local Development Scripts

### Quick Start (Recommended)

Uses Playwright's global setup for backend/database, only starts Vite manually:

**Windows (PowerShell):**

```powershell
cd apps/admin
.\run-e2e-simple.ps1

# Or run specific test file
.\run-e2e-simple.ps1 bug-reports.spec.ts
```

**Linux/Mac:**

```bash
cd apps/admin
chmod +x run-e2e-local.sh
./run-e2e-local.sh project-members.spec.ts
```

### Full Manual Setup

**Windows:**

```powershell
cd apps/admin
.\run-e2e-local.ps1
```

**Linux/Mac:**

```bash
cd apps/admin
./run-e2e-local.sh
```

### Troubleshooting PowerShell

**"Cannot run because it is not digitally signed"**

Run this once:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Jira Integration Tests

For E2E testing of the Jira integration, we use a real Jira Cloud free instance.

### Jira Quick Setup

1. **Create Jira Cloud Account**: https://www.atlassian.com/software/jira/free
2. **Generate API Token**: https://id.atlassian.com/manage-profile/security/api-tokens
3. **Create Test Project** with key `E2E` or `TEST`
4. **Configure Environment** in `packages/backend/.env.integration`:

```bash
JIRA_E2E_BASE_URL=https://your-site.atlassian.net
JIRA_E2E_EMAIL=your-email@example.com
JIRA_E2E_API_TOKEN=your-api-token-here
JIRA_E2E_PROJECT_KEY=E2E
```

5. **Run Tests**:

```bash
cd apps/admin
pnpm test:e2e integrations.spec.ts
```

### Jira Troubleshooting

| Error                 | Solution                                                                            |
| --------------------- | ----------------------------------------------------------------------------------- |
| "Unauthorized"        | Regenerate API token at https://id.atlassian.com/manage-profile/security/api-tokens |
| "Project not found"   | Verify project key in Jira settings (case-sensitive)                                |
| "Rate limit exceeded" | Wait 60 seconds, or use `--workers=1` flag                                          |
| Connection timeout    | Verify base URL format (no trailing slash)                                          |

---

## Notification Integration Tests

Comprehensive E2E tests for Email, Slack, and Discord notifications.

### Notification Test Flow

```
1. Create notification channel (delete if exists)
   ↓
2. Create notification template (required for all channels)
   ↓
3. Create notification rule with trigger conditions
   ↓
4. Generate bug report matching rule criteria
   ↓
5. Verify message delivery via:
   - Notification history API (required)
   - Bot API verification (optional, if tokens configured)
   - Admin UI expandable details
   ↓
6. Clean up test data
```

### Notification Setup

All credentials are managed in `packages/backend/.env.integration`:

#### Email (Gmail Example)

```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-16-char-app-password
EMAIL_FROM_ADDRESS=noreply@example.com
EMAIL_RECIPIENTS=test1@example.com,test2@example.com
```

**Gmail App Password Setup**:

1. Enable 2FA: https://myaccount.google.com/security
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Use 16-character app password (not your account password)

#### Slack

```bash
SLACK_TEST_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL
SLACK_TEST_CHANNEL=#bugspotter-test
SLACK_BOT_TOKEN=xoxb-your-bot-token  # Optional for bot verification
SLACK_TEST_CHANNEL_ID=C1234567890     # Optional for bot verification
```

**Create Slack Webhook**:

1. Go to https://api.slack.com/apps → Create New App
2. Enable **Incoming Webhooks** → Add webhook to workspace
3. Copy webhook URL

#### Discord

```bash
DISCORD_TEST_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR/WEBHOOK/URL
DISCORD_BOT_TOKEN=your-bot-token        # Optional for bot verification
DISCORD_TEST_CHANNEL_ID=1234567890      # Optional for bot verification
```

**Create Discord Webhook**:

1. Go to Discord server → Channel Settings → Integrations → Webhooks
2. Create New Webhook → Copy URL

### Run Notification Tests

```bash
cd apps/admin

# All notification tests
pnpm test:e2e:notifications

# Specific platform
pnpm playwright test notification-delivery.spec.ts --grep "Email"
pnpm playwright test notification-delivery.spec.ts --grep "Slack"
pnpm playwright test notification-delivery.spec.ts --grep "Discord"

# Headed mode (watch browser)
pnpm test:e2e:notifications:headed
```

### Notification Troubleshooting

| Issue                      | Solution                                                    |
| -------------------------- | ----------------------------------------------------------- |
| Test timeout               | Ensure backend and queue worker running (`pnpm dev`)        |
| Auth token fails           | Update auth context to expose `__AUTH_TOKEN__` in test mode |
| Bot API verification fails | Test bot token manually with curl                           |
| No template error          | Notification channels require active template               |

---

## Related Documentation

- [Backend E2E Tests](../../packages/backend/tests/integration/E2E_TEST_FLOW_GUIDE.md) - Backend-focused E2E architecture
- [Testing Strategy](./TESTING_STRATEGY.md) - React Testing Library patterns
- [GitHub CI Setup](../../.github/NOTIFICATION_INTEGRATION_SETUP.md) - Automated GitHub Actions setup
