# Manual Testing Checklist for Auto-Create Ticket Feature

## Phase 1: Integration Rules Page - Auto-Create UI

### Prerequisites

1. Start backend: `docker-compose up -d` or `pnpm --filter @bugspotter/backend dev`
2. Start admin panel: `pnpm --filter @bugspotter/admin dev`
3. Log in to admin panel
4. Navigate to a project with at least one integration configured (e.g., Jira)

### Test Cases

#### TC1: Create Rule with Auto-Create Enabled

1. **Navigate** to Integrations → Rules page for a Jira integration
2. **Click** "Create Rule" button
3. **Fill in** rule details:
   - Name: "Auto-create test rule"
   - Check "Enabled"
   - Check "Automatically create tickets"
4. **Verify** field mappings section appears below filters
5. **Add** a field mapping:
   - Click "Priority" quick-add button OR "Add Custom Mapping"
   - Jira Field: `priority`
   - BugSpotter Field: `priority`
6. **Add** another mapping:
   - Click "Add Custom Mapping"
   - Jira Field: `labels`
   - BugSpotter Field: `["auto-created"]`
7. **Add** filter condition (e.g., priority = "high")
8. **Click** "Create Rule"
9. **Expected Result**:
   - Rule created successfully
   - Green "Auto-create" badge appears on rule card
   - Rule card shows "Enabled" and "Auto-create" badges

#### TC2: Edit Existing Rule - Enable Auto-Create

1. **Click** edit icon on an existing rule that has auto-create disabled
2. **Check** "Automatically create tickets" checkbox
3. **Verify** field mappings section appears
4. **Add** at least one field mapping
5. **Click** "Update Rule"
6. **Expected Result**:
   - Rule updated successfully
   - Green "Auto-create" badge now appears on rule card

#### TC3: Edit Auto-Create Rule - Modify Mappings

1. **Click** edit icon on a rule with auto-create enabled
2. **Verify** field mappings section is visible with existing mappings
3. **Modify** an existing mapping:
   - Change BugSpotter Field value
   - Click "Update Rule"
4. **Expected Result**:
   - Rule updated successfully
   - Changes saved (re-open to verify)

#### TC4: Remove Field Mapping

1. **Open** edit dialog for rule with auto-create enabled
2. **Click** trash icon next to a field mapping
3. **Verify** mapping is removed from the list
4. **Click** "Update Rule"
5. **Expected Result**:
   - Rule updated successfully
   - Mapping no longer appears when re-opened

#### TC5: Disable Auto-Create

1. **Open** edit dialog for rule with auto-create enabled
2. **Uncheck** "Automatically create tickets" checkbox
3. **Verify** field mappings section disappears
4. **Click** "Update Rule"
5. **Expected Result**:
   - Rule updated successfully
   - "Auto-create" badge no longer appears on rule card

#### TC6: Quick-Add Field Mappings (Jira)

1. **Create** or edit a Jira integration rule
2. **Check** "Automatically create tickets"
3. **Click** quick-add buttons: Priority, Labels, Assignee, etc.
4. **Verify** each mapping is added to the list with:
   - Jira Field ID pre-filled
   - BugSpotter Field suggested (e.g., "priority" for Priority)
5. **Expected Result**: All quick-add buttons work correctly

#### TC7: Custom Field Mapping

1. **Create** or edit a rule with auto-create enabled
2. **Click** "Add Custom Mapping"
3. **Type** custom Jira field ID (e.g., `customfield_10001`)
4. **Type** BugSpotter field path (e.g., `metadata.url`)
5. **Click** "Add Mapping"
6. **Expected Result**:
   - Custom mapping appears in list
   - Can be edited/removed like other mappings

#### TC8: Clear All Mappings

1. **Open** rule with multiple field mappings
2. **Click** "Clear All" button
3. **Verify** all mappings are removed
4. **Click** "Update Rule"
5. **Expected Result**:
   - Rule updated with no field mappings
   - Still has auto-create enabled (if checkbox was checked)

#### TC9: Cancel Dialog with Unsaved Changes

1. **Click** "Create Rule"
2. **Check** "Automatically create tickets"
3. **Add** some field mappings
4. **Click** "Cancel"
5. **Click** "Create Rule" again
6. **Expected Result**:
   - Dialog opens fresh with no field mappings
   - Auto-create checkbox is unchecked

#### TC10: Validate API Payload (Developer Check)

1. **Open** browser DevTools → Network tab
2. **Create** or update a rule with auto-create enabled and field mappings
3. **Check** the POST/PATCH request payload includes:
   ```json
   {
     "name": "...",
     "enabled": true,
     "auto_create": true,
     "field_mappings": {
       "priority": "priority",
       "labels": "[\"auto-created\"]"
     },
     "filters": [...],
     "throttle": {...}
   }
   ```
4. **Expected Result**: Payload structure matches above

### Browser Compatibility

Test in:

- [ ] Chrome/Edge (latest)
- [ ] Firefox (latest)
- [ ] Safari (if available)

### Accessibility Checks

- [ ] All form inputs have labels
- [ ] Keyboard navigation works (Tab, Enter, Escape)
- [ ] Screen reader announces field mappings section
- [ ] Trash/delete buttons have aria-labels
- [ ] Field mapping help text is visible

### Known Issues

None at this time.

### Notes

- Field mappings are only visible when "Automatically create tickets" is checked
- Platform-specific suggestions (e.g., Jira field IDs) appear based on integration platform
- BugSpotter field suggestions include common paths like `metadata.url`, `screenshot_url`, etc.
