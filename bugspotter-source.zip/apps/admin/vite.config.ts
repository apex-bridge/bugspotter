import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react({
      babel: {
        // Suppress Babel logs in console
        configFile: false,
        babelrc: false,
      },
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: process.env.PORT ? parseInt(process.env.PORT) : 3001,
    strictPort: true, // Fail if port is already in use
    // Only use proxy in development (when VITE_API_URL not set)
    // E2E tests set VITE_API_URL, so no proxy needed
    proxy: process.env.VITE_API_URL
      ? undefined
      : {
          '/api/': {
            target: 'http://localhost:3000',
            changeOrigin: true,
          },
        },
  },
});
